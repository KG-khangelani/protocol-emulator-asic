import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g2-banked-mapped-01'
OUT = ROOT / 'evidence/E0040-banked-read-screen/mapped'
OUT.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = read(BASE / 'result.json')
assert run['status'] == 'MAPPING_COMMANDS_SUCCEEDED_REQUIRES_AUDIT'
image = read(BASE / 'image-inspect.json')[0]
assert image['Id'] == 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
result = {'status': 'PASS_MATCHED_MAPPED_COST_SCREEN', 'scope': 'SYNTHESIS_ONLY_NO_ROUTED_OR_TIMING_RESULT',
          'runtime_image_id': image['Id'], 'pdk': '89d42ee6d2fd9b50b86a1aada6fee6673c3e6008', 'measurements': {}}
for label, expected_count, expected_area in [('gold', 34683, 477788.2578), ('gate', 32160, 502643.5722)]:
    job = run['runs'][label]
    assert job['returncode'] == 0 and not job['timed_out'] and job['wall_limit_seconds'] == 300
    step = BASE / label / 'runs/mapped-screen/06-yosys-synthesis'
    state = read(step / 'state_out.json')
    metrics = state['metrics']
    assert metrics['design__instance__count'] == expected_count and metrics['design__instance__area'] == expected_area
    for key in ('design__inferred_latch__count', 'design__instance_unmapped__count', 'synthesis__check_error__count', 'design__lint_error__count'):
        assert metrics[key] == 0
    module = read(step / 'tt_um_khangelani_protocol_emulator.nl.v.json')['modules']['tt_um_khangelani_protocol_emulator']
    counts = Counter(c['type'] for c in module['cells'].values())
    assert sum(counts.values()) == expected_count and counts['sg13cmos5l_dfrbpq_1'] == 4278
    assert not any('latch' in name.lower() for name in counts)
    log = (step / 'yosys-synthesis.log').read_text()
    assert 'Yosys 0.69' in log and '9f75ca1f9834a39a863915b5dae0c7b1e33533bc' in log
    assert float(re.findall(r'of which used for sequential elements: ([\d.]+)', log)[-1]) == 209574.0864
    assert float(re.findall(r"Chip area for module .*?: ([\d.]+)", log)[-1]) == expected_area
    assert {n: sha((BASE / label / 'src' / n).read_bytes()) for n in job['sources']} == job['sources']
    result['measurements'][label] = {'source_sha256': job['sources'], 'mapped_cells': expected_count,
          'mapped_area_um2': expected_area, 'sequential_cells': 4278, 'sequential_area_um2': 209574.0864,
          'buffers': sum(v for n,v in counts.items() if n.startswith('sg13cmos5l_buf_')),
          'cell_types': dict(sorted(counts.items())), 'metrics': metrics,
          'netlist_sha256': sha((step / 'tt_um_khangelani_protocol_emulator.nl.v').read_bytes())}
result['mapped_area_change_percent'] = (502643.5722/477788.2578-1)*100
result['decision'] = 'SET_ASIDE_BANKED_READ_NO_PHYSICAL_TRIAL'
files = {'result.json': (BASE / 'result.json').read_bytes(), 'image-inspect.json': (BASE / 'image-inspect.json').read_bytes(),
         'inputs/run_g2_banked_mapping.py': (ROOT / 'build/run_g2_banked_mapping.py').read_bytes(),
         'inputs/original-d39-resolved.json': (ROOT / 'build/g2-physical-shared/13966350208/runs/wokwi/resolved.json').read_bytes(),
         'inputs/g2-banked-mapped-screen.md': (ROOT / 'docs/specs/g2-banked-mapped-screen.md').read_bytes()}
for label in ('gold', 'gate'):
    for path in (BASE / label).rglob('*'):
        rel = path.relative_to(BASE).as_posix()
        if 'final' in path.relative_to(BASE).parts:
            continue
        if path.is_file() and path.suffix in ('.json', '.v', '.log', '.abc', '.sdc', '.txt'):
            files[rel] = path.read_bytes()
        elif path.is_file() and path.name == 'COMMANDS':
            files[rel] = path.read_bytes()
files['connectivity.json'] = (ROOT / 'build/g2-banked-connectivity.json').read_bytes()
files['inputs/g2_banked_connectivity.py'] = (ROOT / 'build/g2_banked_connectivity.py').read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
packed = gzip.compress(buffer.getvalue(), mtime=0)
(OUT / 'mapping.tar.gz').write_bytes(packed)
(OUT / 'archive.json').write_bytes((json.dumps({'sha256': sha(packed), 'files': {n: sha(v) for n,v in sorted(files.items())}},indent=2)+'\n').encode())
(OUT / 'verification.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps({'status': result['status'], 'mapped_area_change_percent': result['mapped_area_change_percent'],
                  'files': len(files), 'archive_bytes': len(packed)}))
