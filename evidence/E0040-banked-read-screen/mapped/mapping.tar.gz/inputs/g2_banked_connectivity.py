"""Describe actual generic connectivity; this is not a placement prediction."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g2-banked-read-01'
result = {'scope': 'GENERIC_CONNECTIVITY_ONLY_NO_PLACEMENT_OR_ROUTING_CLAIM', 'variants': {}}
for label in ('gold', 'gate'):
    path = BASE / (label+'-synth.json')
    modules = json.loads(path.read_bytes())['modules']
    module = modules['m1_program_store']
    loads = Counter()
    types = {}
    for name, cell in module['cells'].items():
        for port, bits in cell['connections'].items():
            if cell['port_directions'][port] == 'input':
                for bit in bits:
                    if isinstance(bit, int):
                        loads[bit] += 1
            elif cell['port_directions'][port] == 'output':
                for bit in bits:
                    types[bit] = cell['type']
    aliases = {}
    for name, net in module['netnames'].items():
        if not name.startswith('$'):
            for i, bit in enumerate(net['bits']):
                aliases.setdefault(bit, []).append(name+(f'[{i}]' if len(net['bits']) > 1 else ''))
    exclude = {bit for name in ('clk', 'rst_n', 'ena') for bit in module['ports'][name]['bits']}
    ranked = [(bit, count) for bit, count in loads.most_common() if bit not in exclude]
    result['variants'][label] = {'source_model_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'store_cells': len(module['cells']), 'nets_with_32_or_more_loads': sum(n >= 32 for b, n in ranked),
        'nets_with_128_or_more_loads': sum(n >= 128 for b, n in ranked),
        'highest_non_clock_reset_enable_loads': [{'bit': b, 'loads': n, 'driver_type': types.get(b, 'input'),
          'aliases': aliases.get(b, [])} for b, n in ranked[:20]],
        'named_read_address_retained': 'read_address' in module['netnames']}
out = ROOT / 'build/g2-banked-connectivity.json'
out.write_bytes((json.dumps(result, indent=2)+'\n').encode())
print(json.dumps({n: {k: v for k,v in r.items() if k not in ('highest_non_clock_reset_enable_loads', 'source_model_sha256')}
                  for n,r in result['variants'].items()}))
