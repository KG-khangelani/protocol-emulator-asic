import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path('/workspace')
OUT = ROOT / 'build/g2-banked-mapped-01'
PARENT = ROOT / 'build/g2-physical-shared/13966350208'
SCREEN = ROOT / 'build/g2-banked-read-01'
SPEC = ROOT / 'docs/specs/g2-banked-mapped-screen.md'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path, value):
    path.write_bytes((json.dumps(value, indent=2)+'\n').encode())

assert not OUT.exists()
OUT.mkdir(parents=True)
result = {'status': 'WAITING_FOR_ROUTING_DIAGNOSTIC', 'scope': 'MATCHED_SYNTHESIS_ONLY_NOT_PHYSICAL_QUALIFICATION',
          'spec_sha256': sha(SPEC), 'runner_sha256': sha(Path(__file__)), 'runs': {}}
write(OUT / 'result.json', result)
deadline = time.monotonic() + 1500
while json.loads((ROOT / 'build/g2-routing-diagnostic-02/ablation-result.json').read_bytes())['status'] == 'RUNNING':
    assert time.monotonic() < deadline, 'routing diagnostic has not terminated'
    time.sleep(10)
result['status'] = 'RUNNING'
write(OUT / 'result.json', result)
source_manifest = json.loads((SCREEN / 'result.json').read_bytes())['sources']
try:
    for label in ('gold', 'gate'):
        design = OUT / label
        src = design / 'src'
        src.mkdir(parents=True)
        for name, expected in source_manifest[label].items():
            original = SCREEN / label / 'src' / name
            assert sha(original) == expected
            (src / name).write_bytes(original.read_bytes())
        config = json.loads((PARENT / 'src/config_merged.json').read_bytes())
        config['VERILOG_FILES'] = [str(src / n) for n in source_manifest[label]]
        config['FP_DEF_TEMPLATE'] = str(ROOT / 'build/g1-upstream/support/tt_block_8x4_pgvdd.def')
        config['OPENROAD_THREADS'] = 4
        write(src / 'config_merged.json', config)
        command = ['librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l', '--to', 'Yosys.Synthesis',
                   '--run-tag', 'mapped-screen', '--design-dir', str(design), str(src / 'config_merged.json')]
        item = {'command': command, 'sources': source_manifest[label], 'config_sha256': sha(src / 'config_merged.json'),
                'wall_limit_seconds': 300, 'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        result['runs'][label] = item
        write(OUT / 'result.json', result)
        start = time.monotonic()
        with (design / 'run.log').open('w') as log:
            process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=300)
                timed_out = False
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                code, timed_out = 124, True
        item.update(returncode=code, timed_out=timed_out, seconds=round(time.monotonic()-start, 3))
        write(OUT / 'result.json', result)
        assert code == 0 and not timed_out, label
        assert {n: sha(src/n) for n in source_manifest[label]} == source_manifest[label]
    result['status'] = 'MAPPING_COMMANDS_SUCCEEDED_REQUIRES_AUDIT'
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE', error=str(error))
    raise
finally:
    write(OUT / 'result.json', result)
print(result['status'], flush=True)
