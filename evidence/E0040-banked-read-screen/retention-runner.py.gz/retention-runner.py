import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0040-banked-read-screen'
files = {}
for label, path in [('screen', ROOT / 'build/g2-banked-read-01'), ('controls', ROOT / 'build/g2-banked-controls-01')]:
    for entry in path.rglob('*'):
        if entry.is_file() and 'sim' not in entry.relative_to(path).parts and entry.suffix in ('.json', '.ys', '.il', '.log', '.v', '.sv', '.txt'):
            files[label + '/' + entry.relative_to(path).as_posix()] = entry.read_bytes()
for path in ('experiments/i2c/run_banked_read_screen.py', 'experiments/i2c/run_banked_read_controls.py',
             'docs/specs/g2-banked-read-screen.md', 'test/banked_read_store.sv'):
    files['inputs/' + Path(path).name] = (ROOT / path).read_bytes()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
index = {n: sha(raw) for n, raw in sorted(files.items())}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(raw), 0o644, 0
        archive.addfile(info, io.BytesIO(raw))
packed = gzip.compress(buffer.getvalue(), mtime=0)
(OUT / 'screen.tar.gz').write_bytes(packed)
(OUT / 'archive.json').write_bytes((json.dumps({'sha256': sha(packed), 'files': index}, indent=2)+'\n').encode())
(OUT / 'result.json').write_bytes(files['screen/result.json'])
(OUT / 'controls.json').write_bytes(files['controls/result.json'])
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
lines = [sha(path.read_bytes())+'  '+path.relative_to(OUT).as_posix() for path in sorted(OUT.rglob('*'))
         if path.is_file() and path.name != 'SHA256SUMS' and '__pycache__' not in path.parts]
(OUT / 'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files), 'files,', len(packed), 'archive bytes')
