"""Retain an audited original default-production CI archive and frozen inputs."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--directory', type=Path, required=True)
base = parser.parse_args().directory.resolve()
assert base.is_relative_to(root / 'build')
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = read(base / 'verification.json')
assert report['status'] == 'PASS_DEFAULT_PRODUCTION_COMMAND_CI_ORIGINAL_ARCHIVE'
out = root / 'evidence/E0045-g2-sram-qualification' / ('ci-default-' + report['source_commit'][:7])
assert not out.exists()
out.mkdir()
zip_name = str(report['artifact_id']) + '.zip'
for name in ('run.json', 'jobs.json', 'artifacts.json', 'verification.json', 'zip-files.json', zip_name):
    (out / name).write_bytes((base / name).read_bytes())
(out / 'current-job.log.gz').write_bytes(gzip.compress((base / 'current-job.log').read_bytes(), mtime=0))
evidence = read(base / 'original/build/current-production/evidence.json')
files = {}
for name, expected in evidence['verification_inputs'].items():
    raw = (base / 'inputs' / name).read_bytes()
    assert sha(raw) == expected
    files[name] = raw
with (out / 'inputs.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
packed = (out / 'inputs.tar.gz').read_bytes()
(out / 'inputs.json').write_bytes((json.dumps({'bytes': len(packed), 'sha256': sha(packed),
    'files': {name: sha(raw) for name, raw in sorted(files.items())}}, indent=2) + '\n').encode())
audit = (root / 'build/audit_production_current_ci.py').read_text()
assert audit.count('ROOT = Path(__file__).resolve().parents[1]') == 1
audit = audit.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path(__file__).resolve().parents[3]')
(out / 'audit.py').write_bytes(audit.encode())
verify = (root / 'evidence/E0044-sram-current-verification/ci-13660ac/verify.py').read_text()
verify = verify.replace('Replay the original SRAM normal-command CI ZIP', 'Replay the original actual-default-production CI ZIP')
verify = verify.replace('13986941634.zip', zip_name)
verify = verify.replace('PASS_RETAINED_CURRENT_SRAM_CI_1928_FILES_295_INPUTS_ALL_EIGHT_STAGES',
    f'PASS_RETAINED_DEFAULT_PRODUCTION_CI_{report["original_zip_files"]}_FILES_{len(files)}_INPUTS_ALL_EIGHT_STAGES')
(out / 'verify.py').write_bytes(verify.encode())
for name in ('retain_production_current_ci.py', 'collect_production_ci_inputs.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress((root / 'build' / name).read_bytes(), mtime=0))
summary = f'''# Actual default-production CI

Run {report['run_id']} at `{report['source_commit']}` passes all eight normal
verification stages using the actual `/workspace/src` files. No alternate
source-directory setting or experimental generator supplies the production RTL.
The complete current suite passes thirty groups in each simulator, and the
current formal properties and independent historical baseline pass. Both fresh
repository-check executions pass 127 tests.

The original ZIP contains {report['original_zip_files']:,} files. The frozen
audit verifies its GitHub digest/size, every member, all {len(files)} producing
input files, semantic results, container exit and exact built image identity.
The retained production guard binds all twenty adopted physical inputs to
E0045's separately qualified layout. This job does not rerun physical design.

Replay in the pinned Linux workbench, with the checkout mounted at `/workspace`:

```sh
python3 evidence/E0045-g2-sram-qualification/{out.name}/verify.py --output build/default-production-replay
```

Use a new output directory. The frozen waveform parser writes native line
endings, so this replay requires Linux, as did the preceding E0044 audit.
`inputs.tar.gz` supplies the original producing source and verification code;
the replay compares the complete report and original member hashes.
'''
(out / 'README.md').write_bytes(summary.encode())
(out / 'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n'
    for p in sorted(out.iterdir()) if p.is_file() and p.name != 'SHA256SUMS').encode())
print('RETAINED_DEFAULT_PRODUCTION_CI', out.relative_to(root), report['original_zip_files'], len(files))
