"""Capture a fresh Linux replay, keeping temporary extraction in the container."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

root = Path('/workspace')
retained = root / 'evidence/E0045-g2-sram-qualification/ci-default-75c1e7d'
out = root / 'build/g2-default-native-01/replay'
command = [sys.executable, str(retained / 'verify.py'), '--output', str(out)]
run = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(root / 'build/g2-default-native-replay.log').write_bytes(run.stdout)
print(run.stdout.decode(), end='')
assert run.returncode == 0
raw = (out / 'verification.json').read_bytes()
assert raw == (retained / 'verification.json').read_bytes()
assert (out / 'zip-files.json').read_bytes() == (retained / 'zip-files.json').read_bytes()
report = json.loads(raw)
result = {'status': 'PASS_RETAINED_DEFAULT_PRODUCTION_CI', 'platform': platform.platform(),
          'python': platform.python_version(), 'command': command, 'returncode': run.returncode,
          'local_workbench': 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909',
          'original_files': report['original_zip_files'], 'producing_inputs': report['verification_input_files'],
          'all_eight_stages': True, 'report_sha256': hashlib.sha256(raw).hexdigest(),
          'member_hashes_sha256': hashlib.sha256((out / 'zip-files.json').read_bytes()).hexdigest(),
          'scope': 'Fresh replay of the retained original ZIP and frozen producing inputs in Linux tmpfs; exact result and member hashes reproduced. No simulations or solvers rerun.'}
(root / 'build/g2-default-native-verification.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
