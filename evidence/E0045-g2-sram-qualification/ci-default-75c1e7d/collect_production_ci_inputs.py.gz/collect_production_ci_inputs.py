"""Fetch actual producing Git bytes for every input in the original CI receipt."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--directory', type=Path, required=True)
base = parser.parse_args().directory.resolve()
assert base.is_relative_to(root / 'build')
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = read(base / 'run.json')
assert run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['path'] == '.github/workflows/production-current.yaml'
artifacts = [a for a in read(base / 'artifacts.json')['artifacts']
             if a['name'] == 'current-production-' + run['head_sha']]
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == run['head_sha']
raw = (base / (str(artifact['id']) + '.zip')).read_bytes()
assert len(raw) == artifact['size_in_bytes'] and 'sha256:' + sha(raw) == artifact['digest']
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    evidence = json.loads(archive.read('build/current-production/evidence.json'))
assert evidence['status'] == 'PASS' and len(evidence['stages']) == 8
names = sorted(evidence['verification_inputs'])
target = base / 'inputs'
assert not target.exists()
target.mkdir()
# Bound Windows argument length without separate per-file Git processes.
for offset in range(0, len(names), 100):
    selected = names[offset:offset + 100]
    for name in selected:
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in name
    packed = subprocess.check_output(['git', 'archive', '--format=tar', run['head_sha'], '--', *selected], cwd=root)
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(packed)) as archive:
        for entry in archive:
            if entry.isdir():
                continue
            assert entry.isfile() and entry.name in selected and entry.name not in seen
            seen.add(entry.name)
            raw = archive.extractfile(entry).read()
            assert sha(raw) == evidence['verification_inputs'][entry.name], entry.name
            path = (target / entry.name).resolve()
            assert path.is_relative_to(target)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
    assert seen == set(selected)
assert {p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()} == set(names)
print('FROZEN_ACTUAL_DEFAULT_PRODUCTION_INPUTS', run['head_sha'], len(names))
