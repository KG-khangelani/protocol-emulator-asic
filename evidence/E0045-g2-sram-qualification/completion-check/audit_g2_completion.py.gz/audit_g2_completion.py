"""Close G2 only after actual production, physical, publication and tag gates pass."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.production_sram import verify
read = lambda name: json.loads((ROOT / name).read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
production = verify(ROOT)
profile = read('tools/production-profile.json')
physical = read(profile['qualification']['path'])
regression = read(profile['combined_regression']['path'])
pair = read(profile['corrected_netlist_pair']['path'])
release_path = 'evidence/E0045-g2-sram-qualification/publication/release-verification.json'
release = read(release_path)
assert release['status'] == 'PASS_G2_RELEASE_AND_PACKAGE'
assert release['publication']['production_qualification'] == production
assert release['original_physical_archives_verified'] == 6 and release['original_normal_command_archive_verified']
assert all(a['anonymous_download_verified'] for a in release['assets'].values())
assert release['production_stages']['rtl-icarus']['test_groups'] == release['production_stages']['rtl-verilator']['test_groups'] == 30
normal_path = 'evidence/E0045-g2-sram-qualification/ci-default-75c1e7d/verification.json'
normal = read(normal_path)
assert normal['status'] == 'PASS_DEFAULT_PRODUCTION_COMMAND_CI_ORIGINAL_ARCHIVE' and normal['production'] == production
assert normal['stages']['rtl-icarus']['test_groups'] == normal['stages']['rtl-verilator']['test_groups'] == 30
assert normal['profile']['source_sha256'] == physical['candidate']['source_sha256'] == production['source_sha256']
assert normal['profile']['model_sha256'] == physical['candidate']['model_sha256'] == production['model_sha256']
assert pair['netlist_sha256'] == physical['netlist_sha256']
assert pair['simulators']['icarus']['groups'] == pair['simulators']['verilator']['groups'] == 18
assert physical['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES'
assert all(j['conclusion'] == 'success' for j in physical['jobs'].values())
assert physical['physical_metrics']['status'] == 'PASS'
assert regression['candidate'] == physical['candidate']
oracle = read('evidence/E0032-i2c-oracle/qualification.json')
assert oracle['status'] == 'PASS' and oracle['tests'] == 19 and oracle['observations'] == 3902
assert oracle['witnesses'] == 53 and oracle['failures'] == oracle['errors'] == 0
assert read('evidence/E0033-i2c-existing-instructions/result.json')['status'] == 'PASS_SCOPED_KERNELS_AND_RETAINED_LIMITS'
tag_runs_path = 'evidence/E0045-g2-sram-qualification/publication/tag-runs.json'
runs = read(tag_runs_path)['workflow_runs']
required = {'atlas', 'docs', 'i2c-general', 'publish', 'spi-program-sensitivity', 'spi-timed-gpio', 'sram-candidate', 'test'}
assert {r['name'] for r in runs} == required and len(runs) == len(required)
assert all(r['head_sha'] == release['source_commit'] and r['head_branch'] == release['tag'] and
           r['event'] == 'push' and r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs)
required_groups = {
    'K-PIN-TRACE': ['test.randomized_trace_matches_reviewed_model',
                    'test_general_boundaries.public_open_drain_and_alternate_payload',
                    'test.public_pin_reload_changes_observable_program'],
    'K-INPUT-WAIT': ['test.k_input_wait_public_program_event_timeout_and_reload'],
    'K-SHIFT-8': ['test.k_shift_8_public_payload_both_orders'],
    'K-BOUNDED-LOOP': ['test.k_bounded_loop_public_program_counts'],
    'P-RELOAD': ['test.public_pin_reload_changes_observable_program', 'test_general_boundaries.public_store_banks_lengths_and_reset'],
    'P-UART-TX-8N1': ['test.uart_tx_8n1_public_pin_oracle'],
    'P-UART-RX-8N1': ['test_uart_rx_public.uart_rx_public_framing_and_bounded_timeouts',
                       'test_uart_rx_public.uart_rx_public_bounded_last_byte_delivery',
                       'test_uart_rx_public.uart_rx_host_service_last_safe_edge',
                       'test_uart_rx_public.uart_rx_host_service_late_read_counterexample',
                       'test_uart_rx_public.uart_rx_host_service_fault_abort_quarantine'],
    'P-SPI-HOST-4MODE': ['test_spi_timed_gpio.timed_public_programs', 'test_spi_timed_gpio.timed_instruction_and_abort_controls'],
    'P-I2C-CONTROLLER-100K': ['test_i2c_general_public.complete_i2c_transactions', 'test_i2c_abort_public.public_i2c_abort_and_reload',
                             'test_general_boundaries.public_open_drain_and_alternate_payload'],
}
matrix = {}
for workload, groups in required_groups.items():
    for record in (normal, {'stages': release['production_stages']}):
        for simulator in ('rtl-icarus', 'rtl-verilator'):
            assert set(groups) <= set(record['stages'][simulator]['required'])
    matrix[workload] = {'status': 'PASS', 'both_simulators': True, 'required_groups': groups}
for simulator in ('rtl-icarus', 'rtl-verilator'):
    assert normal['stages'][simulator]['records'] == release['production_stages'][simulator]['records']
    assert all(r['reference_identical'] for r in normal['stages'][simulator]['records'].values())
    assert normal['stages'][simulator]['current_bank_control']['observations'] == 44
for path in ('evidence/E0031-8x4-physical-comparison/completion-audit.json',
             'evidence/E0031-8x4-physical-comparison/attempts/d34/P/result.json',
             'evidence/E0010-pinned-cmos5l-run/result.json', 'docs/learning/progress.json'):
    prior = subprocess.check_output(['git', 'show', '75c1e7d:' + path], cwd=ROOT)
    current = subprocess.check_output(['git', 'show', 'HEAD:' + path], cwd=ROOT)
    assert current == prior and not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', path], cwd=ROOT), path

def evidence(*names):
    records = []
    for name in names:
        committed = subprocess.run(['git', 'show', 'HEAD:' + name], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if committed.returncode == 0:
            assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', name], cwd=ROOT), name
            raw = committed.stdout
        else:
            raw = (ROOT / name).read_bytes()
            assert b'\r\n' not in raw, 'new retained JSON must use its committed LF bytes'
        records.append({'path': name, 'sha256': sha(raw)})
    return records

requirements = [
    {'requirement': 'Freeze I2C contract/oracle before extending the ISA; measure existing-instruction alternatives.',
     'status': 'PASS', 'evidence': evidence('evidence/E0032-i2c-oracle/qualification.json',
        'evidence/E0033-i2c-existing-instructions/result.json', 'evidence/E0034-i2c-receive-reuse/result.json',
        'docs/decisions/0036-i2c-contract-before-isa.md'),
     'detail': 'Independent 19-group oracle and 3902 observations/53 witnesses precede the scoped compact10 baseline and existing SHIFT_STEP reuse screen; D37 documents the subsequent general instruction/capacity decision.'},
    {'requirement': 'Pass all mandatory kernels and UART TX/bounded RX, four-mode SPI and I2C on one candidate.',
     'status': 'PASS', 'evidence': evidence(profile['combined_regression']['path'], normal_path, release_path),
     'detail': 'Every matrix obligation maps to passing groups in both complete 30-group suites using the exact adopted SRAM source/model identities.'},
    {'requirement': 'Preserve UART framing, phase, service, delivery and adversarial-input limits.',
     'status': 'PASS', 'evidence': evidence('docs/specs/p-uart-rx-8n1.md', 'docs/specs/p-uart-rx-host-service.md', normal_path),
     'detail': 'Both simulator suites include bounded final-byte delivery, safe/late host reads, framing/timeout and reset/disable/quarantine controls. Continuous autonomous UART delivery remains unqualified.'},
    {'requirement': 'Both SPI bit orders/all four modes with input-hold assumptions and edge-only negatives.',
     'status': 'PASS', 'evidence': evidence('docs/specs/p-spi-host-4mode.md', normal_path, profile['qualification']['path']),
     'detail': '1052 unchanged reference records include the stated expected edge-only rejections; no unrestricted peripheral compatibility claim.'},
    {'requirement': 'Public-pin program reload without protocol-specific RTL, both simulators, relevant formal properties and meaningful controls.',
     'status': 'PASS', 'evidence': evidence(normal_path, profile['combined_regression']['path'],
        'docs/decisions/0037-general-io-i2c-candidate.md', profile['decision']),
     'detail': 'One generic temporal engine; program-bank/reset/length and 44-byte bank checks, complete protocol reloads, source-matched compositional engine/store/prefetch proofs, real faults and retained witnesses. Whole-chip proof timeouts remain inconclusive.'},
    {'requirement': 'Promote only after combined regression and fresh pinned physical/timing/precheck/public-netlist acceptance of that revision.',
     'status': 'PASS', 'evidence': evidence(profile['qualification']['path'], profile['corrected_netlist_pair']['path'],
        'tools/production-profile.json', normal_path),
     'detail': 'D48 adopts all twenty qualified inputs byte for byte. Original 8x4 physical run passes all gates and ten prechecks; eighteen public-netlist groups and the corrected local pair use the same netlist. Actual default commands and release commands verify actual src files.'},
    {'requirement': 'Publish original archives, reproducible evidence and matching tools package; verify downloads and all tag gates.',
     'status': 'PASS', 'evidence': evidence(release_path, tag_runs_path),
     'detail': 'Anonymous asset downloads and checksums, every curated committed member, complete publication CI, matching manifest/config/source/version tags and anonymous layer availability verified. Documentation closure is in the same follow-up commit.'},
]
result = {'schema': 'protocol-emulator-g2-completion-audit-v1', 'status': 'PASS_G2_COMPLETION_REQUIREMENTS',
          'observed_utc': datetime.now(timezone.utc).isoformat(), 'release_source_commit': release['source_commit'],
          'physical_source_commit': physical['source_commit'], 'default_command_source_commit': normal['source_commit'],
          'production': production, 'requirements': requirements, 'mandatory_workload_matrix': matrix,
          'tag_workflows': {r['name']: {'run_id': r['id'], 'conclusion': r['conclusion']} for r in runs},
          'historical_G1_P_rejection_M0_and_owner_learning_records_unchanged': True,
          'not_claimed': ['continuous autonomous UART receive', 'unrestricted SPI input timing', 'analog I2C compliance',
                          'silicon or board validation', 'maximum frequency', 'minimum ISA', 'isothermal fast SRAM corner',
                          'owner fluency', 'final submission readiness'],
          'next_goal': 'G3 remains queued: readable assembly, versioned protocol examples, loading/readback and reproducible pin traces.'}
target = ROOT / 'evidence/E0045-g2-sram-qualification/completion-audit.json'
assert not target.exists()
target.write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(result['status'], len(matrix), 'workloads', len(runs), 'tag workflows')
