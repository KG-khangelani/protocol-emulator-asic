"""Retain the final metadata check and verify unchanged qualification inputs."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.production_sram import verify

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

base = ROOT / 'evidence/E0045-g2-sram-qualification'
out = base / 'completion-check'
assert not out.exists()
production = verify(ROOT)
inputs = read(base / 'ci-default-75c1e7d/inputs.json')['files']
spec = importlib.util.spec_from_file_location('g2_package', base / 'release-tools/package.py')
package = importlib.util.module_from_spec(spec)
spec.loader.exec_module(package)
head = git('rev-parse', 'HEAD').decode().strip()
package.check_verification_inputs(inputs, head)
changed = git('diff', '--name-only', 'HEAD').decode().splitlines()
assert not set(changed).intersection(inputs), changed
assert len(inputs) == 329 and len(production['files_sha256']) == 20
manifest_results = {}
for name in ('ci-94a3082', 'ci-default-75c1e7d', 'publication'):
    parent = base / name
    entries = {}
    for line in (parent / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, relative = line.split('  ', 1)
        path = (parent / relative).resolve()
        assert path.is_relative_to(parent.resolve()) and path.is_file()
        assert sha(path.read_bytes()) == digest, str(path)
        entries[relative] = digest
    manifest_results[name] = {'status': 'PASS', 'files': len(entries),
                              'manifest_sha256': sha((parent / 'SHA256SUMS').read_bytes())}
completion = read(base / 'completion-audit.json')
assert completion['status'] == 'PASS_G2_COMPLETION_REQUIREMENTS'
assert len(completion['requirements']) == 7
assert len(completion['mandatory_workload_matrix']) == 9
references = set()
for requirement in completion['requirements']:
    assert requirement['status'] == 'PASS'
    for entry in requirement['evidence']:
        path = entry['path']
        tracked = subprocess.run(['git', 'show', 'HEAD:' + path], cwd=ROOT,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if tracked.returncode == 0:
            assert path not in changed
            raw = tracked.stdout
        else:
            raw = (ROOT / path).read_bytes()
            assert b'\r\n' not in raw
        assert sha(raw) == entry['sha256'], path
        references.add(path)
lock = ROOT / '.devcontainer/devcontainer-lock.json'
assert sha(lock.read_bytes()) == '41b8de31d8c52979a6a6624e594fdab2e57512383c7f690bc91f92078af653c2'
receipt_path = ROOT / 'build/g2-completion-check/receipts/check.json'
receipt = read(receipt_path)
assert receipt['status'] == 'PASS' and receipt['action'] == 'check'
assert receipt['source_directory'] == '/workspace/src'
assert receipt['profile']['source_sha256'] == production['source_sha256']
log = (ROOT / receipt['directory'] / 'run.log').read_bytes()
text = log.decode('utf-8')
groups = [int(n) for n in re.findall(r'^Ran (\d+) tests? in ', text, flags=re.MULTILINE)]
assert sum(groups) == 127 and len(groups) == len(re.findall(r'^OK\s*$', text, flags=re.MULTILINE))
assert 'FAILED' not in text and 'Traceback (most recent call last)' not in text
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
out.mkdir()
(out / 'check.json').write_bytes(receipt_path.read_bytes())
(out / 'check.log.gz').write_bytes(gzip.compress(log, mtime=0))
for name in ('audit_g2_completion.py', 'retain_g2_completion_check.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress((ROOT / 'build' / name).read_bytes(), mtime=0))
(out / 'document-encoding-repair.json').write_bytes((ROOT / 'build/g2-docs-encoding-repair.json').read_bytes())
result = {
    'status': 'PASS_G2_CLOSURE_METADATA_AND_INPUT_IDENTITY',
    'observed_utc': datetime.now(timezone.utc).isoformat(),
    'release_source_commit': head,
    'check_receipt_created_utc': receipt['created_utc'],
    'check_status': receipt['status'], 'repository_tests': sum(groups),
    'production_guard_status': production['status'],
    'qualified_physical_inputs_unchanged': 20,
    'committed_default_ci_inputs_unchanged': len(inputs),
    'changed_working_tree_verification_inputs': [],
    'retained_checksum_manifests': manifest_results,
    'completion_evidence_references_checked': len(references),
    'completion_audit_sha256': sha((base / 'completion-audit.json').read_bytes()),
    'unrelated_development_lock_unchanged': True,
    'scope': 'Local repository checks plus byte/source identity verification. Complete RTL, formal, physical and release CI are retained separately; this does not rerun them. Documentation wording and evidence closure are the only follow-up changes.',
}
(out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
(out / 'README.md').write_text('''# G2 completion follow-up checks

The pinned Linux workbench ran the normal `make check` command on actual
production sources after the completion documentation was drafted. All 127
repository tests and metadata checks pass. The original receipt and compressed
log are retained here. This follow-up does not rerun RTL, formal or physical
qualification; the original complete CI and release records remain authoritative.

The final review checks all twenty physical inputs, all 329 committed default-CI
inputs, the three retained checksum manifests and every completion evidence
reference. No verification input changed. `result.json` records the scope.
`document-encoding-repair.json` records the earlier two-heading Unicode repair;
its before/after hashes describe that intermediate repair, before final wording.

The gzip files preserve the exact completion-audit and final-review producers
from ignored `build/`. They are record-producing scripts which deliberately
refuse existing output paths; do not run them over retained evidence. The frozen
physical/default-CI replayers and publication auditor remain in their separately
documented locations. This record and the completion audit are a follow-up to
the immutable alpha.6 release, rather than assets inside their own source tag.
''', encoding='utf-8', newline='\n')
files = sorted(path for path in out.iterdir() if path.is_file())
(out / 'SHA256SUMS').write_text(''.join(sha(path.read_bytes()) + '  ' + path.name + '\n' for path in files), encoding='utf-8', newline='\n')
print(result['status'], result['repository_tests'], 'tests,', len(inputs), 'unchanged inputs')
