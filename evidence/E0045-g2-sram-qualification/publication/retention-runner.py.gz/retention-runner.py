"""Retain the real passing publication audit and completed tag workflow records."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-alpha6-publication-01'
out = root / 'evidence/E0045-g2-sram-qualification/publication'
assert not out.exists()
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = read(base / 'release-verification.json')
assert report['status'] == 'PASS_G2_RELEASE_AND_PACKAGE'
assert report['source_commit'] == '3cd1a62fb00efbf3bcb9d34e6371dfd382e36159'
runs = read(base / 'tag-runs.json')['workflow_runs']
assert len(runs) == 8 and all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in runs)
assert all(r['head_sha'] == report['source_commit'] and r['head_branch'] == report['tag'] for r in runs)
tag_jobs = read(base / 'tag-jobs.json')
assert set(tag_jobs) == {r['name'] for r in runs}
for run in runs:
    record = tag_jobs[run['name']]
    assert record['total_count'] == len(record['jobs']) and record['jobs']
    assert all(j['run_id'] == run['id'] and j['status'] == 'completed' and j['conclusion'] == 'success'
               for j in record['jobs'])
out.mkdir()
for name in ('run.json', 'jobs.json', 'artifacts.json', 'release.json', 'tag-ref.json', 'tag-object.json', 'tag-commit.json',
             'zip-files.json', 'release-verification.json', 'registry-manifest.json', 'registry-config.json',
             'tag-runs.json', 'tag-jobs.json', 'audit-runtime.json', 'packaging-runtime.json', str(report['publication_artifact_id']) + '.zip'):
    (out / name).write_bytes((base / name).read_bytes())
optional = base / 'registry-linux-amd64.json'
if optional.is_file():
    (out / optional.name).write_bytes(optional.read_bytes())
(out / 'current-job.log.gz').write_bytes(gzip.compress((base / 'current-job.log').read_bytes(), mtime=0))
(out / 'audit-linux.log.gz').write_bytes(gzip.compress((base / 'audit-linux.log').read_bytes(), mtime=0))
(out / 'audit-linux-runner.py.gz').write_bytes(gzip.compress((root / 'build/run_g2_publication_native.py').read_bytes(), mtime=0))
for name in ('publication.json', 'g2-sram-publication.json', 'SHA256SUMS', 'g2-sram-SHA256SUMS', 'production-profile.json'):
    target = 'workbench-SHA256SUMS' if name == 'SHA256SUMS' else name
    (out / target).write_bytes((base / 'downloaded' / name).read_bytes())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
script = root / 'evidence/E0045-g2-sram-qualification/release-tools/verify_publication.py'
checks = {'status': 'PASS_ALL_EIGHT_RELEASE_TAG_WORKFLOWS', 'source_commit': report['source_commit'], 'tag': report['tag'],
          'workflows': {r['name']: {'run_id': r['id'], 'conclusion': r['conclusion'],
                                  'jobs': [{'id': j['id'], 'name': j['name'], 'conclusion': j['conclusion']}
                                           for j in tag_jobs[r['name']]['jobs']]} for r in runs},
          'publication_auditor': script.relative_to(root).as_posix(), 'publication_auditor_sha256': sha(script)}
(out / 'tag-verification.json').write_bytes((json.dumps(checks, indent=2) + '\n').encode())
text = f'''# Alpha.6 publication and package verification

Release `{report['tag']}` uses source `{report['source_commit']}`. All eight
tag workflows and their {sum(len(r['jobs']) for r in tag_jobs.values())} jobs pass.
The publication job independently runs every default-production stage and the
preserved historical SPI release gates. Its original ZIP, job log and API
records are retained; {report['publication_original_zip_files']:,} original
members and all 329 producing inputs pass semantic/source audit.

All {len(report['assets'])} actual release assets were fetched anonymously into
a fresh directory, checked against GitHub's sizes/digests and compared with the
original publication artifact or prepared G2 package. Both checksum lists pass.
Six original physical ZIPs and the original normal-command ZIP are unchanged.
All {report['curated_evidence_files_identical_to_release_git_blobs']:,} curated
bundle members exactly match the release's committed Git bytes, including the
earlier failed trials and frozen replay inputs.

The public registry manifest/configuration bytes match their declared digests,
the version and source tags resolve to the same image, and Linux amd64
source/version labels match the release. Anonymous HEAD requests verify every
layer's read permission and declared size; layer bodies are not downloaded.
`release-verification.json` records the immutable image digest and boundaries.

The [frozen publication auditor](../release-tools/verify_publication.py) is
identified in `tag-verification.json`. Its initial byte comparison uses the
exact prepared package set. Preserve that set or reproduce it from a clean
checkout of the release tag using the Windows/Python/zlib producer recorded
in `packaging-runtime.json`, then copy this record's
API files, original ZIP and decompressed job log into a new ignored build
directory. Run the auditor there in the pinned Linux workbench to repeat the
semantic/source checks and anonymous release/registry downloads. It refuses
an existing extraction/download directory, preserving failed attempts.

ZIP creator metadata, compression and checksum-line ordering can differ on
another packaging platform/runtime. Cross-platform byte-identical repacking
is not claimed. The original archive checksums, all committed member bytes,
Linux publication audit and frozen qualification replays are separate checks.

This post-publication record is a separate follow-up to the immutable release;
the release does not claim to contain its own completed publication proof.
Physical qualification remains the exact E0045 run at 94a3082, with all twenty
adopted design/flow inputs unchanged. The complete default-command verification
at 75c1e7d has the same 329 inputs as the release commit. G1/P/M0 history and
all protocol, analog, silicon, Fmax and owner-learning boundaries remain.
'''
(out / 'README.md').write_bytes(text.encode())
(out / 'SHA256SUMS').write_bytes(''.join(sha(p) + '  ' + p.name + '\n'
    for p in sorted(out.iterdir()) if p.is_file() and p.name != 'SHA256SUMS').encode())
print('RETAINED_G2_PUBLICATION', len(report['assets']), 'assets', len(runs), 'workflows', len(list(out.iterdir())), 'files')
