"""Run the frozen publication audit in Linux tmpfs and preserve its observations."""
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

root = Path('/workspace')
base = root / 'build/g2-alpha6-publication-01'
out = root / 'build/g2-alpha6-runtime/audit'
assert not out.exists() and not (base / 'release-verification.json').exists()
run = json.loads((base / 'run.json').read_bytes())
assert run['status'] == 'completed' and run['conclusion'] == 'success'
artifacts = json.loads((base / 'artifacts.json').read_bytes())['artifacts']
matches = [a for a in artifacts if a['name'] == 'publication-' + run['head_sha']]
assert len(matches) == 1
zip_name = str(matches[0]['id']) + '.zip'
out.mkdir(parents=True)
for name in ('run.json', 'jobs.json', 'artifacts.json', 'release.json', 'tag-commit.json', 'current-job.log', zip_name):
    shutil.copyfile(base / name, out / name)
auditor = root / 'evidence/E0045-g2-sram-qualification/release-tools/verify_publication.py'
command = [sys.executable, str(auditor), '--directory', str(out)]
process = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
print(process.stdout.decode(), end='')
if process.returncode:
    failure = base / ('failed-audit-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    assert not failure.exists()
    shutil.copytree(out, failure)
    (failure / 'audit.log').write_bytes(process.stdout)
    raise SystemExit(process.returncode)
(base / 'audit-linux.log').write_bytes(process.stdout)
for name in ('release-verification.json', 'zip-files.json', 'registry-manifest.json', 'registry-config.json'):
    shutil.copyfile(out / name, base / name)
optional = out / 'registry-linux-amd64.json'
if optional.is_file():
    shutil.copyfile(optional, base / optional.name)
downloaded = base / 'downloaded'
assert not downloaded.exists()
downloaded.mkdir()
# The original prepared archives are already retained; keep the actual public
# metadata bodies and the digest/size observations for all verified downloads.
for name in ('publication.json', 'g2-sram-publication.json', 'SHA256SUMS', 'g2-sram-SHA256SUMS', 'production-profile.json'):
    shutil.copyfile(out / 'downloaded' / name, downloaded / name)
result = json.loads((out / 'release-verification.json').read_bytes())
runtime = {'status': 'PASS_NATIVE_PUBLICATION_AUDIT', 'command': command, 'returncode': process.returncode,
           'platform': platform.platform(), 'python': platform.python_version(),
           'image': 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909',
           'anonymous_downloads': len(result['assets']),
           'anonymous_download_bytes': sum(a['bytes'] for a in result['assets'].values()),
           'scope': 'The frozen auditor downloaded and hashed every asset in Linux tmpfs, compared prepared/CI bytes and committed bundle members, and checked public registry identity. The original prepared archives remain on the host; actual public metadata and all digest/size observations are retained.'}
(base / 'audit-runtime.json').write_bytes((json.dumps(runtime, indent=2) + '\n').encode())
