"""Demonstrate the first collector's omitted metadata input in an isolated fixture."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import current_profile
import current_run
import learning_status

OUT = ROOT / 'evidence/E0039-current-verification/initial-cache-control'
FIXTURE = ROOT / 'build/g2-metadata-cache-control-01'
assert not FIXTURE.exists()
FIXTURE.mkdir()
OUT.mkdir(parents=True, exist_ok=True)
names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT)
original = current_profile.verification_inputs()
for name, expected in original.items():
    path = FIXTURE / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((ROOT / name).read_bytes())
    assert current_profile.digest(path) == expected
metadata_name = 'docs/learning/progress.json'
assert metadata_name.encode() + b'\0' in names
metadata = FIXTURE / metadata_name
metadata.parent.mkdir(parents=True, exist_ok=True)
metadata.write_bytes((ROOT / metadata_name).read_bytes())
before = metadata.read_bytes()
corrupted = json.loads(before)
corrupted['schema'] = 'intentional-invalid-schema'
after = (json.dumps(corrupted, indent=2) + '\n').encode()
with patch.object(current_profile, 'ROOT', FIXTURE), patch.object(current_profile.subprocess, 'check_output', return_value=names):
    first = current_profile.verification_inputs()
    metadata.write_bytes(after)
    second = current_profile.verification_inputs()
assert first == second == original
artifacts = ROOT / 'build/g2-current-pipeline-01'
receipt = current_run.read(artifacts / 'receipts/check.json')
accepted = current_run.load_receipt(artifacts, 'check', receipt['profile'], second, receipt['runtime_identity'])
assert accepted['status'] == 'PASS'
try:
    learning_status.validate(corrupted)
except SystemExit as error:
    rejection = str(error)
else:
    raise AssertionError('corrupted learning metadata was not rejected by a fresh check')
result = {'status': 'COUNTEREXAMPLE_OMITTED_REPOSITORY_METADATA', 'metadata': metadata_name,
          'original_sha256': hashlib.sha256(before).hexdigest(), 'corrupted_sha256': hashlib.sha256(after).hexdigest(),
          'verification_fingerprint_unchanged': True, 'old_cached_check_accepted': True,
          'fresh_validator_rejection': rejection,
          'old_collector_sha256': current_profile.digest(ROOT / 'tools/current_run.py'),
          'old_input_selector_sha256': current_profile.digest(ROOT / 'tools/current_profile.py'),
          'scope': 'Isolated fixture only; actual repository metadata was never changed. Fix by running repository checks fresh during collection.'}
(OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(OUT / 'original.json').write_bytes(before)
(OUT / 'corrupted.json').write_bytes(after)
(OUT / 'driver.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(result['status'])
