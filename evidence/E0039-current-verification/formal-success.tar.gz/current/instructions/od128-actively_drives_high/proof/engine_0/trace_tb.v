`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_ena;
  reg [0:0] PI_instruction_valid;
  wire [0:0] PI_clk = clock;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_sampled_inputs;
  reg [7:0] PI_tx_payload;
  reg [31:0] PI_instruction;
  reg [7:0] PI_tx_payload_alt;
  m1_engine UUT (
    .ena(PI_ena),
    .instruction_valid(PI_instruction_valid),
    .clk(PI_clk),
    .rst_n(PI_rst_n),
    .sampled_inputs(PI_sampled_inputs),
    .tx_payload(PI_tx_payload),
    .instruction(PI_instruction),
    .tx_payload_alt(PI_tx_payload_alt)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$3006  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3012  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3054  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3060  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3066  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3072  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3084  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3090  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3102  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3108  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3114  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3132  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3138  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3144  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3156  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$2992  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3004  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3010  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3016  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3022  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3028  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3034  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3040  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3046  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3052  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3058  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3064  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3070  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3076  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3082  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3088  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3100  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3106  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3112  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3118  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3124  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3130  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3136  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3142  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3148  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3154  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3160  = 1'b1;
    // UUT.$past$engine.\v:475$15$0  = 1'b0;
    // UUT.$past$engine.\v:480$16$0  = 1'b0;
    // UUT.$past$engine.\v:483$18$0  = 1'b0;
    // UUT.$past$engine.\v:492$21$0  = 1'b0;
    // UUT.$past$engine.\v:500$30$0  = 1'b0;
    // UUT.$past$engine.\v:502$31$0  = 1'b0;
    // UUT.$past$engine.\v:504$32$0  = 1'b0;
    // UUT.$past$engine.\v:509$35$0  = 1'b0;
    // UUT.$past$engine.\v:513$37$0  = 1'b0;
    // UUT.$past$engine.\v:518$39$0  = 1'b0;
    UUT._witness_.anyinit_procdff_2864 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT._witness_.anyinit_procdff_2866 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2867 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_2869 = 1'b0;
    UUT._witness_.anyinit_procdff_2870 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2871 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2872 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2873 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2874 = 8'b11111110;
    UUT._witness_.anyinit_procdff_2875 = 8'b11111101;
    UUT._witness_.anyinit_procdff_2876 = 6'b000000;
    UUT._witness_.anyinit_procdff_2880 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_2881 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2883 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2885 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2887 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2888 = 1'b0;
    UUT._witness_.anyinit_procdff_2889 = 1'b1;
    UUT._witness_.anyinit_procdff_2890 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2891 = 8'b11111111;
    UUT._witness_.anyinit_procdff_2892 = 1'b0;
    UUT._witness_.anyinit_procdff_2893 = 1'b0;
    UUT._witness_.anyinit_procdff_2894 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2895 = 8'b11111111;
    UUT.f_past_valid = 1'b0;
    UUT.gpio_oe = 8'b11111111;
    UUT.gpio_value = 8'b00000000;
    UUT.loop_active = 1'b1;
    UUT.loop_end = 8'b00000001;
    UUT.loop_remaining = 8'b00000000;
    UUT.loop_start = 8'b00000000;
    UUT.pc = 8'b00000001;
    UUT.phase_active = 1'b1;
    UUT.phase_prepared = 1'b0;
    UUT.shift_active = 1'b0;
    UUT.shift_bits_done = 3'b000;
    UUT.shift_msb_first = 1'b0;
    UUT.shift_period = 16'b0000000000000000;
    UUT.shift_rx_data = 8'b00000000;
    UUT.shift_rx_pin = 3'b000;
    UUT.shift_tx_data = 8'b00000000;
    UUT.shift_tx_pin = 3'b000;
    UUT.shift_tx_slot = 1'b0;
    UUT.state = 2'b00;
    UUT.wait_failure_pc = 8'b00000010;
    UUT.wait_is_input = 1'b0;
    UUT.wait_left = 16'b0000000000000001;
    UUT.wait_level = 1'b0;
    UUT.wait_pin = 3'b000;
    UUT.wait_timeout_jump = 1'b1;
    UUT.wait_timeout_skip = 1'b0;

    // state 0
    PI_ena = 1'b0;
    PI_instruction_valid = 1'b1;
    PI_rst_n = 1'b0;
    PI_sampled_inputs = 8'b00000001;
    PI_tx_payload = 8'b10000000;
    PI_instruction = 32'b00010000000000000000000000000000;
    PI_tx_payload_alt = 8'b00000001;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ena <= 1'b1;
      PI_instruction_valid <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_sampled_inputs <= 8'b01011001;
      PI_tx_payload <= 8'b11000000;
      PI_instruction <= 32'b10110001000010010110000000100001;
      PI_tx_payload_alt <= 8'b00000001;
    end

    // state 2
    if (cycle == 1) begin
      PI_ena <= 1'b0;
      PI_instruction_valid <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_sampled_inputs <= 8'b00000001;
      PI_tx_payload <= 8'b00000010;
      PI_instruction <= 32'b00001101100000000000000000000000;
      PI_tx_payload_alt <= 8'b00000000;
    end

    // state 3
    if (cycle == 2) begin
      PI_ena <= 1'b0;
      PI_instruction_valid <= 1'b1;
      PI_rst_n <= 1'b0;
      PI_sampled_inputs <= 8'b00000001;
      PI_tx_payload <= 8'b10000000;
      PI_instruction <= 32'b00010001000000000000000000000000;
      PI_tx_payload_alt <= 8'b00000001;
    end

    genclock <= cycle < 3;
    cycle <= cycle + 1;
  end
endmodule
