`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_ena;
  reg [0:0] PI_register_select;
  reg [0:0] PI_register_write;
  reg [4:0] PI_register_address;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_data_in;
  reg [7:0] PI_shift_result_data;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_shift_result_write;
  m1_data_store_formal UUT (
    .ena(PI_ena),
    .register_select(PI_register_select),
    .register_write(PI_register_write),
    .register_address(PI_register_address),
    .clk(PI_clk),
    .data_in(PI_data_in),
    .shift_result_data(PI_shift_result_data),
    .rst_n(PI_rst_n),
    .shift_result_write(PI_shift_result_write)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$318  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$322  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$328  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$334  = 1'b1;
    UUT.dut.rx_result = 8'b00000010;
    UUT.dut.rx_valid = 1'b0;
    UUT.dut.tx_payload = 8'b00000000;
    UUT.dut.tx_payload_alt = 8'b00100000;
    UUT.reset_seen = 1'b0;

    // state 0
    PI_ena = 1'b0;
    PI_register_select = 1'b0;
    PI_register_write = 1'b0;
    PI_register_address = 5'b00000;
    PI_data_in = 8'b10000000;
    PI_shift_result_data = 8'b00000000;
    PI_rst_n = 1'b0;
    PI_shift_result_write = 1'b1;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ena <= 1'b1;
      PI_register_select <= 1'b1;
      PI_register_write <= 1'b0;
      PI_register_address <= 5'b00001;
      PI_data_in <= 8'b10100101;
      PI_shift_result_data <= 8'b00111100;
      PI_rst_n <= 1'b1;
      PI_shift_result_write <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_ena <= 1'b0;
      PI_register_select <= 1'b0;
      PI_register_write <= 1'b0;
      PI_register_address <= 5'b00000;
      PI_data_in <= 8'b10000000;
      PI_shift_result_data <= 8'b00000000;
      PI_rst_n <= 1'b0;
      PI_shift_result_write <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_ena <= 1'b0;
      PI_register_select <= 1'b0;
      PI_register_write <= 1'b0;
      PI_register_address <= 5'b00000;
      PI_data_in <= 8'b00000000;
      PI_shift_result_data <= 8'b00000000;
      PI_rst_n <= 1'b0;
      PI_shift_result_write <= 1'b0;
    end

    genclock <= cycle < 3;
    cycle <= cycle + 1;
  end
endmodule
