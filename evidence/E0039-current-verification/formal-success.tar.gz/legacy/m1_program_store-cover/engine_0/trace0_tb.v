`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_load_write;
  reg [0:0] PI_load_length;
  reg [0:0] PI_ena;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_data_in;
  wire [0:0] PI_clk = clock;
  reg [4:0] PI_byte_address;
  reg [0:0] PI_load_mode;
  reg [4:0] PI_pc;
  m1_program_store_formal UUT (
    .load_write(PI_load_write),
    .load_length(PI_load_length),
    .ena(PI_ena),
    .rst_n(PI_rst_n),
    .data_in(PI_data_in),
    .clk(PI_clk),
    .byte_address(PI_byte_address),
    .load_mode(PI_load_mode),
    .pc(PI_pc)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$1099  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$1097  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$1103  = 1'b1;
    UUT.dut.program_length = 4'b0001;
    UUT.dut.program_ready = 1'b1;
    UUT.dut.word0 = 32'b00000000000000010000000000000000;
    UUT.dut.word1 = 32'b00000000010000000000000000000000;
    UUT.dut.word2 = 32'b00000000001000000000000000000000;
    UUT.dut.word3 = 32'b00000000000000010000000000000000;
    UUT.dut.word4 = 32'b00000000000000100000000000000000;
    UUT.dut.word5 = 32'b00000000100000000000000000000000;
    UUT.dut.word6 = 32'b00000000000000010000001111110111;
    UUT.dut.word7 = 32'b00000000000001010000000000000000;
    UUT.reset_seen = 1'b0;

    // state 0
    PI_load_write = 1'b0;
    PI_load_length = 1'b0;
    PI_ena = 1'b0;
    PI_rst_n = 1'b0;
    PI_data_in = 8'b00000100;
    PI_byte_address = 5'b00010;
    PI_load_mode = 1'b0;
    PI_pc = 5'b00000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_load_write <= 1'b1;
      PI_load_length <= 1'b0;
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_data_in <= 8'b00000001;
      PI_byte_address <= 5'b11100;
      PI_load_mode <= 1'b1;
      PI_pc <= 5'b00000;
    end

    // state 2
    if (cycle == 1) begin
      PI_load_write <= 1'b0;
      PI_load_length <= 1'b1;
      PI_ena <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_data_in <= 8'b00000000;
      PI_byte_address <= 5'b11100;
      PI_load_mode <= 1'b0;
      PI_pc <= 5'b00000;
    end

    genclock <= cycle < 2;
    cycle <= cycle + 1;
  end
endmodule
