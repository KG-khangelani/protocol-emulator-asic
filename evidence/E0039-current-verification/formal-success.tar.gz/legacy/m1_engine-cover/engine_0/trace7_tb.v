`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_tx_payload_alt;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_tx_payload;
  reg [0:0] PI_instruction_valid;
  reg [31:0] PI_instruction;
  reg [0:0] PI_ena;
  reg [7:0] PI_sampled_inputs;
  m1_engine_formal UUT (
    .clk(PI_clk),
    .tx_payload_alt(PI_tx_payload_alt),
    .rst_n(PI_rst_n),
    .tx_payload(PI_tx_payload),
    .instruction_valid(PI_instruction_valid),
    .instruction(PI_instruction),
    .ena(PI_ena),
    .sampled_inputs(PI_sampled_inputs)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$7936  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$7922  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7928  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7934  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7940  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7946  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7952  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7958  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7964  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7970  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7976  = 1'b1;
    UUT.dut.gpio_oe = 8'b10000000;
    UUT.dut.gpio_value = 8'b00100000;
    UUT.dut.loop_active = 1'b1;
    UUT.dut.loop_end = 5'b01001;
    UUT.dut.loop_remaining = 8'b00100001;
    UUT.dut.loop_start = 5'b10000;
    UUT.dut.pc = 5'b01000;
    UUT.dut.shift_active = 1'b0;
    UUT.dut.shift_bits_done = 3'b001;
    UUT.dut.shift_msb_first = 1'b1;
    UUT.dut.shift_period = 16'b0010000000000000;
    UUT.dut.shift_rx_data = 8'b00000001;
    UUT.dut.shift_rx_pin = 3'b100;
    UUT.dut.shift_tx_data = 8'b10000000;
    UUT.dut.shift_tx_pin = 3'b010;
    UUT.dut.shift_tx_slot = 1'b0;
    UUT.dut.state = 2'b00;
    UUT.dut.wait_is_input = 1'b1;
    UUT.dut.wait_left = 16'b0000000000001001;
    UUT.dut.wait_level = 1'b0;
    UUT.dut.wait_pin = 3'b000;
    UUT.dut.wait_timeout_skip = 1'b1;
    UUT.reset_seen = 1'b0;

    // state 0
    PI_tx_payload_alt = 8'b00000100;
    PI_rst_n = 1'b0;
    PI_tx_payload = 8'b00000000;
    PI_instruction_valid = 1'b0;
    PI_instruction = 32'b01000000000000000010000000000000;
    PI_ena = 1'b0;
    PI_sampled_inputs = 8'b00000000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_tx_payload_alt <= 8'b01000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b11000000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b10110101011000000000000001000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00010000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b01000000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00100011;
    end

    // state 3
    if (cycle == 2) begin
      PI_tx_payload_alt <= 8'b00000010;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b01000000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000001;
    end

    // state 4
    if (cycle == 3) begin
      PI_tx_payload_alt <= 8'b00100000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00100000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b11000000000010000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000001;
    end

    // state 5
    if (cycle == 4) begin
      PI_tx_payload_alt <= 8'b00010000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b10000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b01000000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000001;
    end

    // state 6
    if (cycle == 5) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b10110101010000000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000100;
    end

    // state 7
    if (cycle == 6) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b10001000001000000000000001000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b10000000;
    end

    // state 8
    if (cycle == 7) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b10000001;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b00010000001000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000100;
    end

    // state 9
    if (cycle == 8) begin
      PI_tx_payload_alt <= 8'b00001000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b01000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b01000000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00001001;
    end

    // state 10
    if (cycle == 9) begin
      PI_tx_payload_alt <= 8'b10100000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b10000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b00000000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000001;
    end

    // state 11
    if (cycle == 10) begin
      PI_tx_payload_alt <= 8'b00001000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00001000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b11100100001000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000000;
    end

    // state 12
    if (cycle == 11) begin
      PI_tx_payload_alt <= 8'b00001000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b01000000000010000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010000;
    end

    // state 13
    if (cycle == 12) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b11101001000000000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b10000010;
    end

    // state 14
    if (cycle == 13) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b11010000000000000000000000100000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000100;
    end

    // state 15
    if (cycle == 14) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b00111000000000000000000000000001;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b10000000;
    end

    // state 16
    if (cycle == 15) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00001000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b11010000000000000001001000000100;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000101;
    end

    // state 17
    if (cycle == 16) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00000011;
      PI_instruction_valid <= 1'b1;
      PI_instruction <= 32'b10100000010000000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010010;
    end

    // state 18
    if (cycle == 17) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b00010000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b10100000010000000000000000000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010001;
    end

    // state 19
    if (cycle == 18) begin
      PI_tx_payload_alt <= 8'b00000000;
      PI_rst_n <= 1'b0;
      PI_tx_payload <= 8'b00000000;
      PI_instruction_valid <= 1'b0;
      PI_instruction <= 32'b00011001100000000000000000000000;
      PI_ena <= 1'b0;
      PI_sampled_inputs <= 8'b00000000;
    end

    genclock <= cycle < 19;
    cycle <= cycle + 1;
  end
endmodule
