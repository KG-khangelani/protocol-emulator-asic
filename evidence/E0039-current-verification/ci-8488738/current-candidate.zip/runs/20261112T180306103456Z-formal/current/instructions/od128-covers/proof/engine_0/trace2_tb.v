`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_instruction_valid;
  reg [7:0] PI_sampled_inputs;
  wire [0:0] PI_clk = clock;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_tx_payload_alt;
  reg [31:0] PI_instruction;
  reg [0:0] PI_ena;
  reg [7:0] PI_tx_payload;
  m1_engine UUT (
    .instruction_valid(PI_instruction_valid),
    .sampled_inputs(PI_sampled_inputs),
    .clk(PI_clk),
    .rst_n(PI_rst_n),
    .tx_payload_alt(PI_tx_payload_alt),
    .instruction(PI_instruction),
    .ena(PI_ena),
    .tx_payload(PI_tx_payload)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$3174  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$3178  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3184  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3190  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3196  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3202  = 1'b1;
    UUT.f_past_valid = 1'b0;
    UUT.gpio_oe = 8'b01000000;
    UUT.gpio_value = 8'b00000000;
    UUT.loop_active = 1'b0;
    UUT.loop_end = 8'b00000000;
    UUT.loop_remaining = 8'b00000000;
    UUT.loop_start = 8'b00000000;
    UUT.pc = 8'b00000000;
    UUT.phase_active = 1'b1;
    UUT.phase_prepared = 1'b1;
    UUT.shift_active = 1'b1;
    UUT.shift_bits_done = 3'b000;
    UUT.shift_msb_first = 1'b0;
    UUT.shift_period = 16'b0000000000000000;
    UUT.shift_rx_data = 8'b00000000;
    UUT.shift_rx_pin = 3'b010;
    UUT.shift_tx_data = 8'b00000000;
    UUT.shift_tx_pin = 3'b110;
    UUT.shift_tx_slot = 1'b0;
    UUT.state = 2'b00;
    UUT.wait_failure_pc = 8'b00000000;
    UUT.wait_is_input = 1'b0;
    UUT.wait_left = 16'b0000000000000000;
    UUT.wait_level = 1'b0;
    UUT.wait_pin = 3'b000;
    UUT.wait_timeout_jump = 1'b0;
    UUT.wait_timeout_skip = 1'b0;

    // state 0
    PI_instruction_valid = 1'b1;
    PI_sampled_inputs = 8'b00100100;
    PI_rst_n = 1'b0;
    PI_tx_payload_alt = 8'b00000010;
    PI_instruction = 32'b10111100100010000000000000000000;
    PI_ena = 1'b1;
    PI_tx_payload = 8'b00000001;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_instruction_valid <= 1'b1;
      PI_sampled_inputs <= 8'b00100100;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b10010000;
      PI_instruction <= 32'b10101100100010000000000000000000;
      PI_ena <= 1'b1;
      PI_tx_payload <= 8'b00000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_instruction_valid <= 1'b1;
      PI_sampled_inputs <= 8'b11100000;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00000010;
      PI_instruction <= 32'b01111010000000000000000000000100;
      PI_ena <= 1'b1;
      PI_tx_payload <= 8'b00000001;
    end

    // state 3
    if (cycle == 2) begin
      PI_instruction_valid <= 1'b1;
      PI_sampled_inputs <= 8'b00000100;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00000010;
      PI_instruction <= 32'b11110101010100010000000000000000;
      PI_ena <= 1'b1;
      PI_tx_payload <= 8'b00000001;
    end

    // state 4
    if (cycle == 3) begin
      PI_instruction_valid <= 1'b1;
      PI_sampled_inputs <= 8'b00100100;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00000010;
      PI_instruction <= 32'b10111100100010000000000000000000;
      PI_ena <= 1'b1;
      PI_tx_payload <= 8'b00000001;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
