`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_ena;
  reg [0:0] PI_rst_n;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_tx_payload_alt;
  reg [0:0] PI_instruction_valid;
  reg [7:0] PI_tx_payload;
  reg [31:0] PI_instruction;
  reg [7:0] PI_sampled_inputs;
  m1_engine UUT (
    .ena(PI_ena),
    .rst_n(PI_rst_n),
    .clk(PI_clk),
    .tx_payload_alt(PI_tx_payload_alt),
    .instruction_valid(PI_instruction_valid),
    .tx_payload(PI_tx_payload),
    .instruction(PI_instruction),
    .sampled_inputs(PI_sampled_inputs)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$3009  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3015  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3057  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3063  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3069  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3075  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3087  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3093  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3105  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3111  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3117  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3135  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3141  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3147  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$3159  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$2995  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3007  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3013  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3019  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3025  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3031  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3037  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3043  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3049  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3055  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3061  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3067  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3073  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3079  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3085  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3091  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3103  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3109  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3115  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3121  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3127  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3133  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3139  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3145  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3151  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3157  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$3163  = 1'b1;
    // UUT.$past$engine.\v:475$15$0  = 1'b0;
    // UUT.$past$engine.\v:480$16$0  = 1'b0;
    // UUT.$past$engine.\v:483$18$0  = 1'b0;
    // UUT.$past$engine.\v:492$21$0  = 1'b0;
    // UUT.$past$engine.\v:500$30$0  = 1'b0;
    // UUT.$past$engine.\v:502$31$0  = 1'b0;
    // UUT.$past$engine.\v:504$32$0  = 1'b0;
    // UUT.$past$engine.\v:509$35$0  = 1'b0;
    // UUT.$past$engine.\v:513$37$0  = 1'b0;
    // UUT.$past$engine.\v:518$39$0  = 1'b0;
    UUT._witness_.anyinit_procdff_2867 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT._witness_.anyinit_procdff_2869 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2870 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_2872 = 1'b1;
    UUT._witness_.anyinit_procdff_2873 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2874 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2875 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2876 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2877 = 8'b11111110;
    UUT._witness_.anyinit_procdff_2878 = 8'b11111101;
    UUT._witness_.anyinit_procdff_2879 = 6'b000000;
    UUT._witness_.anyinit_procdff_2883 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_2884 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2886 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2888 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2890 = 8'b00000000;
    UUT._witness_.anyinit_procdff_2891 = 1'b0;
    UUT._witness_.anyinit_procdff_2892 = 1'b1;
    UUT._witness_.anyinit_procdff_2893 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2894 = 8'b11111111;
    UUT._witness_.anyinit_procdff_2895 = 1'b0;
    UUT._witness_.anyinit_procdff_2896 = 1'b0;
    UUT._witness_.anyinit_procdff_2897 = 8'b00000001;
    UUT._witness_.anyinit_procdff_2898 = 8'b11111111;
    UUT.f_past_valid = 1'b0;
    UUT.gpio_oe = 8'b11111011;
    UUT.gpio_value = 8'b00000000;
    UUT.loop_active = 1'b1;
    UUT.loop_end = 8'b00000001;
    UUT.loop_remaining = 8'b00000000;
    UUT.loop_start = 8'b00000000;
    UUT.pc = 8'b00000001;
    UUT.phase_active = 1'b1;
    UUT.phase_prepared = 1'b0;
    UUT.shift_active = 1'b0;
    UUT.shift_bits_done = 3'b000;
    UUT.shift_msb_first = 1'b0;
    UUT.shift_period = 16'b0000000000000000;
    UUT.shift_rx_data = 8'b00000000;
    UUT.shift_rx_pin = 3'b000;
    UUT.shift_tx_data = 8'b00000000;
    UUT.shift_tx_pin = 3'b000;
    UUT.shift_tx_slot = 1'b0;
    UUT.state = 2'b00;
    UUT.wait_failure_pc = 8'b00000010;
    UUT.wait_is_input = 1'b0;
    UUT.wait_left = 16'b0000000000000001;
    UUT.wait_level = 1'b0;
    UUT.wait_pin = 3'b000;
    UUT.wait_timeout_jump = 1'b1;
    UUT.wait_timeout_skip = 1'b0;

    // state 0
    PI_ena = 1'b0;
    PI_rst_n = 1'b0;
    PI_tx_payload_alt = 8'b00000001;
    PI_instruction_valid = 1'b1;
    PI_tx_payload = 8'b10000000;
    PI_instruction = 32'b00010000000000000000000000000000;
    PI_sampled_inputs = 8'b00000001;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b10000011;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload <= 8'b10000011;
      PI_instruction <= 32'b01111101000000000000000011111111;
      PI_sampled_inputs <= 8'b00000100;
    end

    // state 2
    if (cycle == 1) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00001010;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload <= 8'b00000010;
      PI_instruction <= 32'b11010101111111100000000000000000;
      PI_sampled_inputs <= 8'b11011011;
    end

    // state 3
    if (cycle == 2) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00000010;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload <= 8'b00000000;
      PI_instruction <= 32'b10110101010010001000011000000000;
      PI_sampled_inputs <= 8'b00100000;
    end

    // state 4
    if (cycle == 3) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_tx_payload_alt <= 8'b00000001;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload <= 8'b10000000;
      PI_instruction <= 32'b00010101000000000000000000000000;
      PI_sampled_inputs <= 8'b00000001;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
