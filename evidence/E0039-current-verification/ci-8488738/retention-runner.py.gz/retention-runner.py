import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g2-ci-current-8488738'
OUT = ROOT / 'evidence/E0039-current-verification/ci-8488738'
OUT.mkdir(parents=True,exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
result = json.loads((BASE/'verification.json').read_bytes())
assert result['status'] == 'PASS_CURRENT_COMMAND_CI_ARCHIVE'
raw = (BASE/'13971730764.zip').read_bytes()
assert sha(raw) == result['original_zip_sha256'] and len(raw) == result['original_zip_bytes']
(OUT/'current-candidate.zip').write_bytes(raw)
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert archive.testzip() is None
    files = {e.filename:sha(archive.read(e)) for e in archive.infolist() if not e.is_dir()}
evidence = json.loads((BASE/'pipeline/evidence.json').read_bytes())
inputs = evidence['verification_inputs']
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,expected in sorted(inputs.items()):
        data = (BASE/'inputs'/name).read_bytes()
        assert sha(data) == expected
        entry = tarfile.TarInfo(name)
        entry.size,entry.mtime,entry.mode = len(data),0,0o644
        archive.addfile(entry,io.BytesIO(data))
packed = gzip.compress(buffer.getvalue(),mtime=0)
(OUT/'inputs.tar.gz').write_bytes(packed)
index = {'original_zip':{'sha256':sha(raw),'bytes':len(raw),'files':files},
         'inputs':{'sha256':sha(packed),'bytes':len(packed),'files':inputs}}
(OUT/'archives.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
for name in ('verification.json','artifacts.json','jobs.json'):
    (OUT/name).write_bytes((BASE/name).read_bytes())
(OUT/'audit.py').write_bytes((ROOT/'build/audit_current_ci.py').read_bytes())
(OUT/'current-job.log.gz').write_bytes(gzip.compress((BASE/'current-job.log').read_bytes(),mtime=0))
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines = [sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
         if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files),'CI files;',len(inputs),'exact commit inputs; archive hashes verified')
