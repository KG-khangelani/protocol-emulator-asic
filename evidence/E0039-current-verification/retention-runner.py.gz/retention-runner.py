"""Retain the normal-command current-profile qualification and historical regression."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from current_profile import verification_inputs
from current_run import STAGES, retained_files

BASE = ROOT / 'build/g2-current-pipeline-01'
OUT = ROOT / 'evidence/E0039-current-verification'


def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path): return json.loads(path.read_bytes())
def save(path, data): path.write_bytes((json.dumps(data, indent=2) + '\n').encode())


def pack(label, files):
    hashes = {}
    with (OUT / (label + '.tar.gz')).open('wb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for name, path in sorted(files.items()):
                    raw = path.read_bytes()
                    hashes[name] = sha(raw)
                    entry = tarfile.TarInfo(name)
                    entry.size = len(raw)
                    entry.mode = 0o644
                    entry.mtime = 0
                    archive.addfile(entry, io.BytesIO(raw))
    return {'archive_sha256': sha((OUT / (label + '.tar.gz')).read_bytes()), 'files': hashes}


receipts = {action: read(BASE / 'receipts' / (action + '.json')) for action in STAGES}
profile = receipts['doctor']['profile']
inputs_record = verification_inputs()
assert not (BASE / 'evidence.json').exists(), 'failed pipeline must not have a PASS envelope'
pipeline = {'provenance.json': BASE / 'provenance.json'}
for action, receipt in receipts.items():
    assert receipt['status'] == ('FAILED_OR_INCOMPLETE' if action == 'formal' else 'PASS')
    assert receipt['profile'] == profile and receipt['verification_inputs'] == inputs_record
    stage = ROOT / receipt['directory']
    assert stage.is_relative_to(BASE)
    retained = retained_files(stage)
    if action != 'formal':
        assert retained == receipt['artifact_sha256']
    for name in retained:
        path = stage / name
        pipeline[path.relative_to(BASE).as_posix()] = path
    pipeline['receipts/' + action + '.json'] = BASE / 'receipts' / (action + '.json')
assert len(list((BASE / 'runs').iterdir())) == 8
inputs = {n: ROOT / n for n in inputs_record}
legacy_root = ROOT / 'build/g2-legacy-harness-01'
legacy = {n: legacy_root / n for n in ('result.json', 'icarus/results.xml', 'icarus/run.log',
                                      'verilator/results.xml', 'verilator/run.log')}
legacy['runner.py'] = ROOT / 'build/check_g2_legacy_harness.py'
formal = {}
for label, root in [('current', ROOT / 'build/g2-current-formal-01'), ('legacy', ROOT / 'build/g2-legacy-formal-01')]:
    for name in retained_files(root):
        formal[label + '/' + name] = root / name
# Recover the exact initial driver's one earlier text-write statement and verify
# its recorded hash. This changes no proof input, property, depth or witness.
old_driver = (ROOT / 'experiments/i2c/run_general_formal.py').read_text().replace(
    'normalized.write_bytes(changed.encode())', 'normalized.write_text(changed)')
old_driver_path = ROOT / 'build/g2-current-formal-original-runner.py'
old_driver_path.write_bytes(old_driver.encode())
assert sha(old_driver_path.read_bytes()) == read(ROOT / 'build/g2-current-formal-01/instructions/result.json')['runner_sha256']
formal['original-run-general-formal.py'] = old_driver_path
index = {'pipeline': pack('pipeline', pipeline), 'inputs': pack('inputs', inputs),
         'legacy-regression': pack('legacy-regression', legacy), 'formal-success': pack('formal-success', formal)}
save(OUT / 'archives.json', index)
save(OUT / 'manifest.json', {'status': 'CURRENT_PROFILE_PREPARATION_WITH_INCOMPLETE_COMMAND_RUN',
    'profile': profile, 'pipeline_root': BASE.relative_to(ROOT).as_posix(),
    'verification_parent_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_identity_rule': 'Exact retained file hashes identify the uncommitted verification changes; candidate RTL matches immutable D39 and physical source 426cea1.',
    'verification_inputs': inputs_record, 'pipeline_statuses': {k:r['status'] for k,r in receipts.items()},
    'command_run': 'INCOMPLETE: current formal temporal equivalence reached its 300-second wall limit; no aggregate evidence PASS was written',
    'separate_formal': 'Earlier exact-source current proof and complete historical baseline both pass; retained separately',
    'production': 'NOT_PROMOTED', 'physical': 'D39_GLOBAL_ROUTING_FAILED',
    'legacy_regression': {'icarus': 22, 'verilator': 22}})
initial = OUT / 'initial-direct-runs'
initial.mkdir(exist_ok=True)
for label, root in [('current-regression', ROOT / 'build/g2-current-regression-01/regression'),
                    ('current-formal', ROOT / 'build/g2-current-formal-01'),
                    ('legacy-formal', ROOT / 'build/g2-legacy-formal-01')]:
    (initial / (label + '-result.json')).write_bytes((root / 'result.json').read_bytes())
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
files = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts)
(OUT / 'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes()) + '  ' + p.relative_to(OUT).as_posix() + '\n' for p in files).encode())
print('PASS: retained', sum(len(e['files']) for e in index.values()), 'exact files for replay')
