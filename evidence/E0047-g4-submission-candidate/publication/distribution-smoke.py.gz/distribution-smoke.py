# SPDX-License-Identifier: Apache-2.0
"""Rebuild the thirteen standalone examples from the actual G4 release bundle."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_FILES = {'program.bin', 'program.json', 'program.lst', 'load-plan.json'}
WINDOWS_DEVICES = {'con', 'prn', 'aux', 'nul'} | {
    prefix + str(number) for prefix in ('com', 'lpt') for number in range(1, 10)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def safe_member(name):
    path = PurePosixPath(name)
    require(bool(name) and not path.is_absolute() and '\\' not in name and ':' not in name and
            '..' not in path.parts and path.as_posix() == name, 'unsafe ZIP member: ' + name)
    require(all(part.rstrip(' .') == part and
                part.split('.', 1)[0].casefold() not in WINDOWS_DEVICES for part in path.parts),
            'nonportable ZIP member: ' + name)
    require(path.parts[0] != 'build', 'bundle collides with the fresh rebuild directory')
    return path


def extract_bundle(archive_path, output, source):
    with zipfile.ZipFile(archive_path) as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        require(len(names) == len(set(names)) == len({name.casefold() for name in names}),
                'duplicate or case-colliding ZIP member')
        for entry in entries:
            safe_member(entry.filename)
            mode = stat.S_IFMT(entry.external_attr >> 16)
            require(not entry.is_dir() and mode in (0, stat.S_IFREG),
                    'ZIP must contain only ordinary files: ' + entry.filename)
            require(not entry.flag_bits & 1, 'encrypted ZIP members are unsupported')
        require('g4-submission.json' in names, 'G4 package manifest missing')
        manifest = json.loads(archive.read('g4-submission.json'))
        require(manifest['schema'] == 'protocol-emulator-g4-release-package-v1' and
                manifest['release_source_commit'] == source and manifest['tag'] == 'v0.1.0' and
                manifest['target'] == 'od128-sram-v1' and manifest['interface_id'] == '0x22',
                'bundle source, version or interface identity differs')
        expected = dict(manifest['source_members_sha256'])
        for name, digest in manifest['frozen_evidence_members_sha256'].items():
            require(name not in expected, 'overlapping manifest member')
            expected[name] = digest
        for name, digest in manifest['compiled_members_sha256'].items():
            target = 'compiled/' + name
            require(target not in expected, 'overlapping compiled member')
            expected[target] = digest
        require(set(names) == set(expected) | {'README.md', 'restore-originals.py', 'g4-submission.json'},
                'bundle member inventory differs from its manifest')
        output.mkdir(parents=True)
        observed = {}
        for entry in entries:
            path = (output / safe_member(entry.filename)).resolve()
            require(path.is_relative_to(output), 'ZIP path escapes the extraction directory')
            raw = archive.read(entry)  # Reading to EOF also verifies the ZIP CRC.
            digest = sha(raw)
            if entry.filename in expected:
                require(digest == expected[entry.filename], 'bundle member digest differs: ' + entry.filename)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as target:
                target.write(raw)
            observed[entry.filename] = digest
    return manifest, observed


def run_cli(base, input_name, output_name):
    # Isolated mode ignores PYTHONPATH, the repository and user site packages;
    # -S also disables system site initialization. Only extracted code is run.
    command = [sys.executable, '-I', '-S', 'tools/assembler.py', input_name, '--out', output_name]
    completed = subprocess.run(command, cwd=base, capture_output=True, encoding='utf-8', timeout=120)
    return command, completed


def smoke(source, archive_path, output, result_path):
    require(re.fullmatch('[0-9a-f]{40}', source), '--source must be a full commit SHA')
    archive_path, output, result_path = (path.resolve() for path in (archive_path, output, result_path))
    build = (ROOT / 'build').resolve()
    require(archive_path.is_file(), 'release bundle does not exist')
    require(output.is_relative_to(build) and not output.exists(), 'use a fresh output directory under build/')
    require(result_path.is_relative_to(build) and result_path.suffix == '.json' and not result_path.exists(),
            'use a fresh JSON result path under build/')
    archive_digest = file_sha(archive_path)
    manifest, members = extract_bundle(archive_path, output, source)
    assembler = output / 'tools/assembler.py'
    imports = set()
    for node in ast.walk(ast.parse(assembler.read_bytes())):
        if isinstance(node, ast.Import):
            imports.update(item.name.split('.', 1)[0] for item in node.names)
        elif isinstance(node, ast.ImportFrom):
            require(node.level == 0 and node.module, 'standalone assembler contains a relative import')
            imports.add(node.module.split('.', 1)[0])
    require(imports <= sys.stdlib_module_names, 'standalone assembler imports a nonstandard module')
    catalog = json.loads((output / 'programs/od128-sram-v1/examples.json').read_bytes())
    require(catalog['schema'] == 'protocol-emulator-examples-v1' and catalog['target'] == 'od128-sram-v1',
            'example catalog target differs')
    examples = catalog['examples']
    require(len(examples) == 13 and len({example['name'] for example in examples}) == 13,
            'expected thirteen unique examples')
    require(len(manifest['compiled_members_sha256']) == 53, 'expected 52 compiled outputs and one catalog manifest')
    cases = []
    for example in examples:
        name, filename = example['name'], example['file']
        require(re.fullmatch('[A-Za-z0-9_-]+', name) and name != 'rejected-target', 'unsafe example name')
        require(PurePosixPath(filename).name == filename and filename.endswith('.asm') and
                '\\' not in filename and ':' not in filename, 'unsafe example source')
        source_name = 'programs/od128-sram-v1/' + filename
        command, completed = run_cli(output, source_name, 'build/' + name)
        require(completed.returncode == 0, 'standalone assembly failed for ' + name + ': ' + completed.stderr)
        actual_directory, expected_directory = output / 'build' / name, output / 'compiled' / name
        actual_paths, expected_paths = list(actual_directory.iterdir()), list(expected_directory.iterdir())
        require(all(path.is_file() for path in actual_paths + expected_paths), 'unexpected output directory')
        actual = {path.name: path.read_bytes() for path in actual_paths}
        expected = {path.name: path.read_bytes() for path in expected_paths}
        require(set(actual) == set(expected) == EXPECTED_FILES and actual == expected,
                'standalone output differs from the released program: ' + name)
        require(sha(actual['program.bin']) == example['binary_sha256'], 'catalog binary digest differs: ' + name)
        for filename in ('program.json', 'load-plan.json'):
            require(b'\r' not in actual[filename] and actual[filename].endswith(b'\n'),
                    'generated JSON is not LF-terminated UTF-8: ' + name + '/' + filename)
            json.loads(actual[filename].decode('utf-8'))
        cases.append({'name': name, 'command': command, 'returncode': completed.returncode,
                      'stdout': completed.stdout, 'stderr': completed.stderr,
                      'identical_files_sha256': {key: sha(raw) for key, raw in sorted(actual.items())}})
    invalid = output / 'build/invalid-target.asm'
    with invalid.open('xb') as target:
        target.write(b'.target od128-sram-v2\nHALT\n')
    command, rejected = run_cli(output, 'build/invalid-target.asm', 'build/rejected-target')
    require(rejected.returncode == 2 and '.asm:1: error:' in rejected.stderr and
            'od128-sram-v1' in rejected.stderr, 'unsupported target was not rejected at its source line')
    require(not (output / 'build/rejected-target').exists(), 'invalid target created output')
    record = {'schema': 'protocol-emulator-g4-distribution-smoke-v1',
              'status': 'PASS_STANDALONE_DISTRIBUTION', 'source_commit': source,
              'observed_utc': datetime.now(timezone.utc).isoformat(),
              'archive_sha256': archive_digest, 'archive_members': len(members),
              'assembler_sha256': members['tools/assembler.py'], 'assembler_standard_library_imports': sorted(imports),
              'python': sys.version, 'python_isolation_flags': ['-I', '-S'],
              'examples': len(cases), 'identical_generated_files': len(cases) * 4, 'cases': cases,
              'invalid_target_control': {'command': command, 'returncode': rejected.returncode,
                                         'stdout': rejected.stdout, 'stderr': rejected.stderr,
                                         'output_directory_absent': True},
              'scope': 'Standalone isolated CLI rebuild from the actual released G4 ZIP; 13 examples and 52 files compared byte for byte, with invalid-target rejection. No repository imports or simulator qualification.'}
    require(file_sha(archive_path) == archive_digest, 'release archive changed during verification')
    result_path.parent.mkdir(parents=True, exist_ok=True)
    with result_path.open('xb') as target:
        target.write((json.dumps(record, indent=2, sort_keys=True) + '\n').encode('utf-8'))
    print(record['status'], record['examples'], 'examples', record['identical_generated_files'], 'identical files')
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, help='full 40-character release commit SHA')
    parser.add_argument('--archive', type=Path, required=True, help='actual g4-submission-bundle.zip')
    parser.add_argument('--output', type=Path, required=True, help='fresh extraction/rebuild directory under build/')
    parser.add_argument('--result', type=Path, required=True, help='fresh JSON result path under build/')
    args = parser.parse_args()
    smoke(args.source, args.archive, args.output, args.result)


if __name__ == '__main__':
    main()
