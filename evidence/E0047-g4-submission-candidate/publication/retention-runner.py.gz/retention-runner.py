# SPDX-License-Identifier: Apache-2.0
"""Retain original final-release audit inputs and independently obtained results."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence/E0047-g4-submission-candidate'
PACKAGER = 'evidence/E0047-g4-submission-candidate/release-tools/package.py'
AUDITOR = 'evidence/E0047-g4-submission-candidate/release-tools/verify_publication.py'
IMAGE = 'ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307'
IMAGE_CONFIG = 'sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451'
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
raw_sha = lambda raw: hashlib.sha256(raw).hexdigest()
write = lambda path, value: path.write_bytes((json.dumps(value, indent=2) + '\n').encode('utf-8'))


def sealed(directory):
    entries = {}
    for line in (directory / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in name and ':' not in name
        assert re.fullmatch('[0-9a-f]{64}', digest) and name not in entries
        path = (directory / name).resolve()
        assert path.is_relative_to(directory.resolve()) and path.is_file() and sha(path) == digest
        entries[name] = digest
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*')
              if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts}
    assert actual == set(entries), 'unsealed CI proof member'
    return entries


def inspect_ci_proof(directory, phase, release_source):
    directory = directory.resolve()
    assert directory.is_relative_to(EVIDENCE.resolve()) and directory != EVIDENCE.resolve()
    sealed(directory)
    run, jobs, artifacts = (read(directory / name) for name in ('run.json', 'jobs.json', 'artifacts.json'))
    summary, source = read(directory / 'run-summary.json'), read(directory / 'source.json')
    expected_status = {'package': 'PASS_G4_LINUX_RELEASE_PACKAGE', 'publication': 'PASS_G4_LINUX_PUBLICATION_AUDIT'}[phase]
    assert summary['status'] == expected_status and summary['phase'] == phase
    assert summary['release_source_commit'] == release_source
    assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['event'] == 'push'
    assert run['head_branch'] == 'codex/g4-linux-verification' and run['path'] == '.github/workflows/g4-linux-verification.yaml'
    execution = summary['ci_execution']
    assert summary['source_commit'] == source['source_commit'] == run['head_sha'] == execution['source_commit']
    assert execution['workflow_execution_commit'] == execution['workflow_sha'] == run['head_sha']
    assert execution['repository'] == 'KG-khangelani/protocol-emulator-asic'
    assert execution['ref'] == 'refs/heads/codex/g4-linux-verification'
    assert execution['run_id'] == str(run['id']) and execution['run_attempt'] == str(run['run_attempt'])
    assert execution['runner_os'] == 'Linux' and execution['runner_arch'] == 'X64'
    assert len(jobs['jobs']) == 1
    job = jobs['jobs'][0]
    assert job['run_id'] == run['id'] and job['head_sha'] == run['head_sha']
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    matches = [a for a in artifacts['artifacts'] if a['name'] == 'g4-linux-proof-' + run['head_sha']]
    assert len(matches) == 1
    artifact = matches[0]
    assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == run['head_sha']
    assert artifact['digest'].startswith('sha256:')
    log = gzip.decompress((directory / 'job.log.gz').read_bytes())
    assert str(artifact['id']).encode() in log and artifact['digest'].split(':', 1)[1].encode() in log
    assert run['head_sha'].encode() in log and expected_status.encode() in log
    for name, digest in source['files_sha256'].items():
        assert sha(directory / 'source' / name) == digest
    binding = summary['workflow_binding']
    assert binding['source_commit'] == run['head_sha']
    for key, digest_key in (('path', 'sha256'), ('runner_path', 'runner_sha256'), ('request_path', 'request_sha256')):
        assert binding[digest_key] == sha(directory / 'source' / binding[key])
    assert summary['runner_sha256'] == binding['runner_sha256']
    indexed = read(directory / 'zip-files.json')
    assert set(summary['files']) == set(indexed) - {'run-summary.json'}
    assert all(indexed[name] == meta for name, meta in summary['files'].items())
    assert indexed['run-summary.json'] == {'bytes': (directory / 'run-summary.json').stat().st_size,
                                          'sha256': sha(directory / 'run-summary.json')}
    raw_members = None
    if phase == 'package':
        verification = read(directory / 'verification.json')
        assert verification['status'] == 'PASS_RETAINED_G4_PACKAGE_CI'
        assert verification['run_id'] == run['id'] and verification['job_id'] == job['id']
        assert verification['source_commit'] == run['head_sha'] and verification['release_source_commit'] == release_source
        assert verification['artifact_id'] == artifact['id'] and verification['artifact_bytes'] == artifact['size_in_bytes']
        assert 'sha256:' + verification['artifact_sha256'] == artifact['digest']
        assert verification['original_archive_files'] == len(indexed)
        assert verification['original_zip_retained'] is False and verification['omitted_asset_files'] == 17
        assets = {name: meta for name, meta in indexed.items() if name.startswith('assets/')}
        assert len(assets) == 17
        for name, meta in indexed.items():
            if name.startswith('assets/') or name == 'run-summary.json':
                continue
            path = directory / 'proof' / name
            assert path.stat().st_size == meta['bytes'] and sha(path) == meta['sha256']
        assert {name.removeprefix('assets/'): meta for name, meta in assets.items()} == summary['package']['files']
    else:
        archive = directory / (str(artifact['id']) + '.zip')
        assert archive.stat().st_size == artifact['size_in_bytes'] and 'sha256:' + sha(archive) == artifact['digest']
        with zipfile.ZipFile(archive) as stream:
            names = [item.filename for item in stream.infolist() if not item.is_dir()]
            assert len(names) == len(set(names)) == len(indexed) and set(names) == set(indexed)
            raw_members = {name: stream.read(name) for name in names}
        for name, raw in raw_members.items():
            assert indexed[name] == {'bytes': len(raw), 'sha256': raw_sha(raw)}
        assert raw_members['run-summary.json'] == (directory / 'run-summary.json').read_bytes()
    runtime = summary['runtime']
    assert runtime['image_reference'] == IMAGE and runtime['container_image']['Id'] == IMAGE_CONFIG
    assert IMAGE in runtime['container_image']['RepoDigests']
    assert runtime['container_image']['Os'] == 'linux' and runtime['container_image']['Architecture'] == 'amd64'
    public = summary['public_image_binding']
    assert public['image'] == IMAGE and public['config_digest'] == IMAGE_CONFIG
    assert public['record_sha256'] == sha(ROOT / public['record'])
    identity = {'proof_path': directory.relative_to(ROOT).as_posix(), 'phase': phase,
                'run_id': run['id'], 'job_id': job['id'], 'ci_source_commit': run['head_sha'],
                'release_source_commit': release_source, 'artifact_id': artifact['id'],
                'artifact_bytes': artifact['size_in_bytes'], 'artifact_sha256': artifact['digest'].split(':', 1)[1],
                'original_archive_files': len(indexed), 'original_zip_retained': phase == 'publication',
                'omitted_asset_files': 17 if phase == 'package' else 0,
                'seal_sha256': sha(directory / 'SHA256SUMS'), 'summary_sha256': sha(directory / 'run-summary.json'),
                'source_manifest_sha256': sha(directory / 'source.json'), 'runner_sha256': summary['runner_sha256'],
                'job_log_sha256': raw_sha(log), 'image': IMAGE, 'config_digest': IMAGE_CONFIG}
    return directory, summary, identity, raw_members


def validate_remote_invocation(invocation, raw_log, summary, kind, source):
    assert invocation['schema'] == 'protocol-emulator-g4-linux-' + kind + '-invocation-v1'
    assert invocation['host'] == 'linux' and invocation['returncode'] == 0 and invocation['release_source_commit'] == source
    assert invocation['ci_execution'] == summary['ci_execution'] and invocation['runtime'] == summary['runtime']
    assert invocation['runner_sha256'] == summary['runner_sha256'] and invocation['log_sha256'] == raw_sha(raw_log)
    assert IMAGE in invocation['command'] and '--pull=never' in invocation['command']
    label, argv_key, runtime_key = ('PACKAGE', 'packager_argv', 'actual_packager_python_runtime') if kind == 'package' else (
        'PUBLICATION', 'auditor_argv', 'actual_auditor_python_runtime')
    lines = raw_log.decode('utf-8').splitlines()
    observed = [json.loads(line.split(' ', 1)[1]) for line in lines if line.startswith('G4_' + label + '_ARGV ')]
    runtimes = [json.loads(line.split(' ', 1)[1]) for line in lines if line.startswith('G4_' + label + '_RUNTIME ')]
    assert observed == [invocation[argv_key]] and runtimes == [invocation[runtime_key]]
    assert runtimes[0] == {key: summary['runtime'][key] for key in ('python', 'platform', 'machine', 'executable')}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--directory', type=Path, required=True)
parser.add_argument('--package-proof', type=Path, required=True, help='sealed small package CI proof under E0047')
parser.add_argument('--publication-proof', type=Path, required=True, help='sealed original curated publication CI proof under E0047')
args = parser.parse_args()
base = args.directory.resolve()
assert base.is_relative_to((ROOT / 'build').resolve())
target = EVIDENCE / 'publication'
assert not target.exists()
result = read(base / 'release-verification.json')
assert result['status'] == 'PASS_G4_RELEASE_AND_PACKAGE' and result['tag'] == 'v0.1.0'
assert len(result['assets']) == 35 and len(result['tag_workflows']) == 9
assert result['physical_original_ci_archives_verified'] == 12
assert result['fresh_program_toolchain_replayed_from_downloaded_bundle']
platform = read(ROOT / 'build/g4-package-platform-identity.json')
smoke = read(ROOT / 'build/g4-distribution-smoke.json')
assert platform['status'] == 'PASS_WINDOWS_LINUX_PACKAGE_IDENTITY'
assert smoke['status'] == 'PASS_STANDALONE_DISTRIBUTION'
assert platform['source_commit'] == smoke['source_commit'] == result['source_commit']
assert len(platform['files']) == 17 and smoke['examples'] == 13 and smoke['identical_generated_files'] == 52
for name, meta in platform['files'].items():
    assert result['assets'][name]['sha256'] == meta['sha256']
assert smoke['archive_sha256'] == result['assets']['g4-submission-bundle.zip']['sha256']

package_dir, package_summary, package_identity, _ = inspect_ci_proof(args.package_proof, 'package', result['source_commit'])
publication_dir, publication_summary, publication_identity, publication_members = inspect_ci_proof(
    args.publication_proof, 'publication', result['source_commit'])
assert (ROOT / 'build/g4-package-platform-identity.json').read_bytes() == (package_dir / 'platform-identity.json').read_bytes()
assert platform['linux_ci']['proof_path'] == package_identity['proof_path']
windows_path = package_dir / 'windows/invocation.json'
windows = read(windows_path)
windows_log = package_dir / 'windows/windows-package.log.gz'
windows_log_raw = gzip.decompress(windows_log.read_bytes())
windows_helper = gzip.decompress((package_dir / 'windows/runner.py.gz').read_bytes())
assert windows['schema'] == 'protocol-emulator-g4-windows-package-invocation-v1'
assert windows['exit_code'] == 0 and windows['source_commit'] == result['source_commit']
assert windows['platform'].startswith('Windows-') and windows['python']
assert windows['log_sha256'] == raw_sha(windows_log_raw) and windows['log_bytes'] == len(windows_log_raw)
assert windows['runner_sha256'] == raw_sha(windows_helper)
source_packager = subprocess.check_output(['git', 'show', result['source_commit'] + ':' + PACKAGER], cwd=ROOT)
source_auditor = subprocess.check_output(['git', 'show', result['source_commit'] + ':' + AUDITOR], cwd=ROOT)
assert windows['packager_sha256'] == raw_sha(source_packager)
assert '--source' in windows['command'] and windows['command'][windows['command'].index('--source') + 1] == result['source_commit']
assert any(item.replace('\\', '/').endswith(PACKAGER) for item in windows['command']) and '--out' in windows['command']
linux_package_path = package_dir / 'proof/package/invocation-linux.json'
linux_package = read(linux_package_path)
linux_package_log_path = package_dir / 'proof/package/package-linux.log.gz'
linux_package_log = gzip.decompress(linux_package_log_path.read_bytes())
validate_remote_invocation(linux_package, linux_package_log, package_summary, 'package', result['source_commit'])
assert linux_package['compressed_log_sha256'] == sha(linux_package_log_path)
assert linux_package['packager_sha256'] == raw_sha(source_packager)
assert package_summary['package'] == read(package_dir / 'proof/package/result.json')
assert package_summary['package']['files'] == platform['files']
assert publication_summary['package']['files'] == platform['files']
for name, raw in publication_members.items():
    if name.startswith('publication/'):
        assert (base / name.removeprefix('publication/')).read_bytes() == raw, 'staged original publication member differs: ' + name
remote_audit = read(base / 'audit-runtime.json')
remote_audit_log = gzip.decompress((base / 'audit-linux.log.gz').read_bytes())
validate_remote_invocation(remote_audit, remote_audit_log, publication_summary, 'publication', result['source_commit'])
assert remote_audit['compressed_log_sha256'] == sha(base / 'audit-linux.log.gz')
assert remote_audit_log == (base / 'audit-linux.log').read_bytes()
assert remote_audit['uncompressed_log_sha256'] == raw_sha(remote_audit_log)
assert remote_audit['auditor_sha256'] == raw_sha(source_auditor)
assert remote_audit['release_verification_sha256'] == sha(base / 'release-verification.json')
assert remote_audit['input_binding_sha256'] == sha(base / 'input-binding.json')
assert publication_summary['publication']['status'] == 'PASS_G4_LINUX_PUBLICATION_AUDIT'
assert publication_summary['publication']['release_verification_sha256'] == sha(base / 'release-verification.json')
assert publication_summary['publication']['invocation_sha256'] == sha(base / 'audit-runtime.json')
assert publication_summary['publication']['published_image'] == result['image']
assert publication_summary['publication']['published_image_config_digest'] == result['config_digest']
target.mkdir()
files = ['run.json', 'jobs.json', 'artifacts.json', 'release.json', 'tag-ref.json', 'tag-object.json',
         'tag-commit.json', 'tag-workflows.json', 'registry-manifest.json', 'registry-config.json',
         'release-verification.json', 'zip-files.json', 'audit-runtime.json', 'input-binding.json', 'audit-linux.log.gz',
         'downloaded-fresh-program-verification.json', 'downloaded-gds-comparison.json',
         'downloaded-g2-comparison.json', str(result['publication_artifact_id']) + '.zip']
if (base / 'registry-linux-amd64.json').exists():
    files.append('registry-linux-amd64.json')
for name in files:
    shutil.copyfile(base / name, target / name)
shutil.copyfile(base / 'downloaded-reproduction/result.json', target / 'downloaded-reproduction.json')
for name in ('publication.json', 'production-profile.json', 'g4-submission.json', 'g4-SHA256SUMS'):
    shutil.copyfile(base / 'downloaded' / name, target / name)
# Large original G4 ZIPs and the bundle remain reproducible from committed originals;
# their downloaded identities and each checked bundle member are retained above.
shutil.copyfile(base / 'downloaded/SHA256SUMS', target / 'workbench-SHA256SUMS')
shutil.copyfile(ROOT / 'build/g4-package-platform-identity.json', target / 'packaging-platform-identity.json')
shutil.copyfile(ROOT / 'build/g4-distribution-smoke.json', target / 'distribution-smoke.json')
shutil.copyfile(windows_path, target / 'packaging-windows-invocation.json')
shutil.copyfile(linux_package_path, target / 'packaging-linux-invocation.json')
shutil.copyfile(package_dir / 'proof/package/result.json', target / 'packaging-linux-result.json')
shutil.copyfile(package_dir / 'windows/runner.py.gz', target / 'packaging-windows-runner.py.gz')
shutil.copyfile(windows_log, target / 'packaging-windows.log.gz')
shutil.copyfile(linux_package_log_path, target / 'packaging-linux.log.gz')
for proof_dir, summary, name in ((package_dir, package_summary, 'remote-package-runner.py.gz'),
                                (publication_dir, publication_summary, 'remote-publication-runner.py.gz')):
    source = proof_dir / 'source' / summary['workflow_binding']['runner_path']
    assert sha(source) == summary['runner_sha256']
    (target / name).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
for source, name in ((base / 'current-job.log', 'current-job.log.gz'),
                     (base / 'downloaded-reproduction.log', 'downloaded-reproduction.log.gz'),
                     (ROOT / 'build/g4_distribution_smoke.py', 'distribution-smoke.py.gz'),
                     (ROOT / 'build/receive_g4_publication.py', 'receive-originals.py.gz'),
                     (Path(__file__), 'retention-runner.py.gz')):
    (target / name).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
identity = {'schema': 'protocol-emulator-g4-publication-retention-v2',
            'status': 'PASS_RETAINED_PUBLICATION', 'observed_utc': datetime.now(timezone.utc).isoformat(),
            'release_source_commit': result['source_commit'],
            'publication_verification_sha256': sha(target / 'release-verification.json'),
            'auditor_sha256': raw_sha(source_auditor), 'packager_sha256': raw_sha(source_packager),
            'ci_proofs': {'package': package_identity, 'publication': publication_identity},
            'windows_package': {'invocation_path': 'packaging-windows-invocation.json',
                                'invocation_sha256': sha(target / 'packaging-windows-invocation.json'),
                                'log_path': 'packaging-windows.log.gz', 'log_sha256': windows['log_sha256'],
                                'runner_path': 'packaging-windows-runner.py.gz', 'runner_sha256': windows['runner_sha256']},
            'linux_package': {'invocation_path': 'packaging-linux-invocation.json',
                              'invocation_sha256': sha(target / 'packaging-linux-invocation.json'),
                              'log_path': 'packaging-linux.log.gz', 'log_sha256': linux_package['log_sha256'],
                              'runner_path': 'remote-package-runner.py.gz', 'runner_sha256': package_summary['runner_sha256']},
            'linux_publication': {'invocation_path': 'audit-runtime.json', 'invocation_sha256': sha(target / 'audit-runtime.json'),
                                  'log_path': 'audit-linux.log.gz', 'log_sha256': remote_audit['log_sha256'],
                                  'runner_path': 'remote-publication-runner.py.gz', 'runner_sha256': publication_summary['runner_sha256'],
                                  'audit_image': IMAGE, 'audit_image_config_digest': IMAGE_CONFIG,
                                  'published_image': result['image'], 'published_image_config_digest': result['config_digest']},
            'tag_workflows': len(result['tag_workflows']),
            'tag_jobs': sum(len(r['jobs']) for r in result['tag_workflows'].values()),
            'assets_verified': len(result['assets']), 'bundle_members_verified': result['bundle_members_verified'],
            'scope': 'Actual native Windows packaging and isolated GitHub Linux packaging/publication audit, separate from the immutable release commit. The package CI transport ZIP and 17 duplicate asset bodies are omitted from its sealed proof; the complete member map and authenticated download verification remain. The curated publication CI original ZIP is retained. No local Docker recovery or unused local Docker helper execution is claimed.'}
write(target / 'retention.json', identity)
(target / 'README.md').write_bytes(f'''# v0.1.0 publication verification

Release `{result['tag']}` uses source `{result['source_commit']}`.
All nine tag workflows and their {identity['tag_jobs']} jobs pass. The original
publication ZIP retains {result['publication_original_zip_files']} members;
all {result['current_verification_input_files_bound_to_release_git']} producing inputs match the release Git bytes,
including the unchanged 351 G3 inputs. Its eight normal stages, both public
RTL suites, current/historical formal checks and two fresh 147-test repository
checks pass semantic/source audit. Historical SPI gates keep their original scope.

All 35 actual release assets were downloaded anonymously into a fresh directory.
GitHub sizes/digests, both checksum lists and the prepared/original CI bytes agree.
The submission bundle has {result['bundle_members_verified']} checked members.
Native Windows and isolated Linux CI packaging produce identical seventeen-file downloads.
Running only the extracted assembler and example sources rebuilds all thirteen
examples into the same 52 per-example files and rejects an unsupported target.

The actual Linux package proof is
[run {package_identity['run_id']}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{package_identity['run_id']})
at CI execution source `{package_identity['ci_source_commit']}`.
The publication audit is
[run {publication_identity['run_id']}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{publication_identity['run_id']})
at CI execution source `{publication_identity['ci_source_commit']}`.
Both operate on the release source above; those isolated execution commits
are separate identities and are retained with their source and API envelopes.

Both fresh physical qualifications are replayed from the twelve original ZIPs
downloaded from this release. All {result['physical_original_archive_members_verified']} original physical archive members,
producer inputs, semantic results and retained UART landmarks pass audit.
The complete reproduction record is recomputed from those downloads. Only
standard GDS timestamps differ; netlists, geometry, timing/area and recorded
public observations agree. G2 continuity is separately recomputed from its
original submitted layout. The fresh program-tool CI audit is also rerun from
the downloaded bundle with its original archives and frozen source inputs.

Public registry manifest/configuration bodies match their digests. Version and
source tags, Linux amd64 configuration and actual tested image identity match
the release. Every layer accepts anonymous HEAD with its expected size. Layer
bodies were not downloaded; this does not claim a separate full image pull.

The [auditor](../release-tools/verify_publication.py) is identified by
retention.json. To repeat, copy these API files and the original publication ZIP
to a fresh directory under build/, decompress current-job.log.gz there, and
rebuild the seventeen package assets from the release source using
`../release-tools/package.py --source {result['source_commit']} --out build/g4-release-assets/{result['source_commit']}`.
Run the auditor in the pinned Linux workbench with --directory selecting the
fresh directory. It needs repository Git history, refuses existing extraction
directories and rechecks live anonymous downloads/registry access.
audit-runtime.json records the actual isolated Linux CI invocation, source and
Python runtime. Its audit image is the verified public alpha.7 workbench,
distinct from the newly published release image checked by the auditor.
The captured Windows helper/receipt and both actual remote runner sources are
retained; retention.json binds their raw logs, source hashes and authenticated
CI envelopes. No unused local Docker launcher is credited with this work.

The sealed package CI proof intentionally omits its large transport ZIP and
seventeen duplicate asset bodies. It retains the verified API size/digest,
upload log, complete member map, source, actual command receipts and platform
comparison; the final release supplies those asset bytes. The separate small
publication CI proof retains its original curated ZIP. Both proof directories
are named and sealed by retention.json and the completion audit.

Large original physical ZIPs are already sealed in the per-run evidence;
the distribution bundle is deterministic from committed source and evidence.
This directory retains their independently downloaded identities and complete
member maps without duplicating the bulk archives again.

This is a separate follow-up to the immutable release, which cannot contain its
own completed publication proof. G1-G3 history, twenty physical inputs and
protocol/electrical/owner-learning limits remain unchanged. No competition
entry, hardware expenditure, fabricated-chip or owner-fluency result is claimed.
'''.encode('utf-8'))
files = sorted(p for p in target.iterdir() if p.is_file())
(target / 'SHA256SUMS').write_bytes(''.join(sha(p) + '  ' + p.name + '\n' for p in files).encode())
print('RETAINED_G4_PUBLICATION', len(files), 'sealed files', identity['tag_jobs'], 'jobs')
