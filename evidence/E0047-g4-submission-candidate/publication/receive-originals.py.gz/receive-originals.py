"""Receive original GitHub publication metadata/logs and its unchanged archive."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--capture', type=Path, required=True)
parser.add_argument('--directory', type=Path, required=True)
args = parser.parse_args()
base = args.directory.resolve()
assert base.is_relative_to((ROOT / 'build').resolve()) and not base.exists()
capture = json.loads(args.capture.read_bytes())
names = ('run', 'jobs', 'artifacts', 'release', 'tag-ref', 'tag-object', 'tag-commit', 'tag-workflows')
records = {name: json.loads(capture[name]) for name in names}
run = records['run']
assert run['path'] == '.github/workflows/publish.yaml' and run['head_branch'] == 'v0.1.0'
assert run['status'] == 'completed' and run['conclusion'] == 'success'
matches = [item for item in records['artifacts']['artifacts'] if item['name'] == 'publication-' + run['head_sha']]
assert len(matches) == 1
meta = matches[0]
assert capture['download']['id'] == meta['id']
assert meta['workflow_run']['id'] == run['id'] and meta['workflow_run']['head_sha'] == run['head_sha']
base.mkdir(parents=True)
for name in names:
    (base / (name + '.json')).write_bytes(capture[name].encode('utf-8'))
(base / 'current-job.log').write_bytes(capture['current-job.log'].encode('utf-8'))
target = base / (str(meta['id']) + '.zip')
with urllib.request.urlopen(capture['download']['url'], timeout=90) as response, target.open('xb') as stream:
    while block := response.read(1024 * 1024):
        stream.write(block)
assert target.stat().st_size == meta['size_in_bytes']
assert 'sha256:' + hashlib.sha256(target.read_bytes()).hexdigest() == meta['digest']
print('RECEIVED_G4_PUBLICATION', run['id'], meta['id'], target.stat().st_size)
