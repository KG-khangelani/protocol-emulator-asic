"""Verify and retain the original isolated Linux physical-replay CI proof."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g4-linux-physical-proof'
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/linux-ci-43554467650'
SOURCE = '7b73d99fbf300c1041aa930409ea63fc031d20f4'
RUN, JOB, ARTIFACT = 43554467650, 132324068684, 14098180180
IMAGE = 'ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307'
CONFIG = 'sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451'
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
write = lambda path,value: path.write_bytes((json.dumps(value,indent=2)+'\n').encode())
capture = read(ROOT / 'build/g4-linux-physical-capture.json')
run, jobs, artifacts = (json.loads(capture[name]) for name in ('run','jobs','artifacts'))
assert run['id'] == RUN and run['head_sha'] == SOURCE and run['run_attempt'] == 1
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['event'] == 'push'
assert run['head_branch'] == 'codex/g4-linux-verification' and run['path'] == '.github/workflows/g4-linux-verification.yaml'
assert jobs['total_count'] == len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['id'] == JOB and job['run_id'] == RUN and job['head_sha'] == SOURCE and job['run_attempt'] == 1
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert all(step['conclusion'] == 'success' for step in job['steps'])
assert artifacts['total_count'] == len(artifacts['artifacts']) == 1
meta = artifacts['artifacts'][0]
assert meta['id'] == ARTIFACT and meta['name'] == 'g4-linux-proof-' + SOURCE and not meta['expired']
assert meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == SOURCE
assert capture['download']['id'] == ARTIFACT
assert str(ARTIFACT) in capture['log'] and meta['digest'].removeprefix('sha256:') in capture['log']
assert not BASE.exists() and not OUT.exists()
BASE.mkdir()
archive = BASE / (str(ARTIFACT)+'.zip')
with urllib.request.urlopen(capture['download']['url'], timeout=90) as response:
    archive.write_bytes(response.read())
assert archive.stat().st_size == meta['size_in_bytes'] and 'sha256:'+sha(archive.read_bytes()) == meta['digest']
files = BASE / 'files'
files.mkdir()
indexed = {}
with zipfile.ZipFile(archive) as zipped:
    for member in zipped.infolist():
        path = PurePosixPath(member.filename)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename and ':' not in member.filename
        assert not member.is_dir() and member.filename not in indexed
        target = files / path
        target.parent.mkdir(parents=True,exist_ok=True)
        raw = zipped.read(member)
        target.write_bytes(raw)
        indexed[member.filename] = {'bytes':len(raw),'sha256':sha(raw)}
summary = read(files / 'run-summary.json')
assert summary['status'] == 'PASS_G4_LINUX_PHYSICAL_REPLAYS' and summary['source_commit'] == SOURCE
assert summary['files'] == {name:item for name,item in indexed.items() if name != 'run-summary.json'}
execution = summary['ci_execution']
assert execution['run_id'] == str(RUN) and execution['run_attempt'] == '1'
assert execution['workflow_execution_commit'] == SOURCE and execution['source_commit'] == SOURCE
assert execution['job'] == job['name'] == 'physical' and execution['event_name'] == 'push'
assert execution['ref'] == 'refs/heads/codex/g4-linux-verification'
assert summary['runtime']['image_reference'] == IMAGE
identity = summary['runtime']['container_image']
assert identity['Id'] == CONFIG and identity['Os'] == 'linux' and identity['Architecture'] == 'amd64'
assert IMAGE in identity['RepoDigests']
source_files = {}
for name in ('.github/workflows/g4-linux-verification.yaml','.github/g4-linux-verification/run.py','.github/g4-linux-verification/request.json'):
    source_files[name] = subprocess.check_output(['git','show',SOURCE+':'+name],cwd=ROOT)
runner_hash = sha(source_files['.github/g4-linux-verification/run.py'])
assert runner_hash == summary['runner_sha256']
for path in (files / 'commands').glob('*.json'):
    invocation = read(path)
    assert invocation['returncode'] == 0 and invocation['runner_sha256'] == runner_hash
    raw = gzip.decompress((files / invocation['log_path']).read_bytes())
    assert sha(raw) == invocation['log_sha256']
assert read(files/'commands/image-pull.json')['command'] == ['docker','pull',IMAGE]
assert read(files/'image-inspection-before.json') == read(files/'image-inspection-after.json')
for role, number, controls in (('candidate',43543626249,False),('reproduction',43543629839,True)):
    existing = ROOT / 'evidence/E0047-g4-submission-candidate' / ('ci-'+str(number))
    proof = files / ('ci-'+str(number))
    result, report, invocation = (read(proof/name) for name in ('audit/result.json','verification.json','invocation-linux.json'))
    assert (proof/'audit/result.json').read_bytes() == (existing/'result.json').read_bytes()
    expected = read(existing/'verification-windows.json')
    expected['controls_executed'] = controls
    assert report == expected and report['original_archive_files'] == 1729 and report['producing_inputs'] == 84
    assert invocation['returncode'] == 0 and invocation['run_id'] == number and invocation['ci_execution'] == execution
    assert invocation['runner_sha256'] == runner_hash and invocation['runtime'] == summary['runtime']
    assert invocation['verification_sha256'] == sha((proof/'verification.json').read_bytes())
    assert invocation['verify_sha256'] == sha((existing/'verify.py').read_bytes())
    assert invocation['log_sha256'] == sha(gzip.decompress((proof/'replay-linux.log.gz').read_bytes()))
    assert ('--controls' in invocation['command']) == controls and IMAGE in invocation['command']
    if controls:
        fault = read(proof/'controls-result.json')
        assert fault['status'] == 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS' and len(fault['cases']) == 9
        assert fault['baseline_result_sha256'] == sha((existing/'result.json').read_bytes())
        assert fault['audit_sha256'] == sha((existing/'audit.py').read_bytes())
        assert fault['runner_sha256'] == sha((existing/'controls.py').read_bytes())
        for case in fault['cases']:
            assert case['status'] == 'PASS_REJECTED_CORRUPTION' and case['returncode'] != 0
            assert case['observed'] == {'status':'NOT_QUALIFIED','error':case['expected_error']}
            assert case['log_sha256'] == sha(gzip.decompress((proof/'controls-logs'/(case['name']+'.log.gz')).read_bytes()))
OUT.mkdir()
shutil.copyfile(archive,OUT/archive.name)
for name in ('run','jobs','artifacts'):
    (OUT/(name+'.json')).write_bytes(capture[name].encode())
(OUT/'job.log.gz').write_bytes(gzip.compress(capture['log'].encode(),mtime=0))
for name,raw in source_files.items():
    target = OUT/'source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(raw)
write(OUT/'source.json',{'source_commit':SOURCE,'files_sha256':{name:sha(raw) for name,raw in source_files.items()}})
shutil.copyfile(files/'run-summary.json',OUT/'run-summary.json')
write(OUT/'zip-files.json',indexed)
record = {'status':'PASS_RETAINED_G4_LINUX_CI_PROOF','run_id':RUN,'job_id':JOB,'source_commit':SOURCE,
          'artifact_id':ARTIFACT,'artifact_sha256':sha(archive.read_bytes()),'original_archive_files':len(indexed),
          'physical_runs':[43543626249,43543629839],'each_original_members_reaudited':1729,'each_frozen_inputs':84,
          'image':IMAGE,'config_digest':CONFIG,'reproduction_fault_controls':9,
          'scope':'Original isolated Linux CI proof, metadata/upload log/source/image identity and both complete replay results verified. This does not change the physical producer or establish local Docker recovery.'}
write(OUT/'verification.json',record)
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(OUT/'README.md').write_text(f'''# Isolated Linux replay proof

[Run {RUN}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{RUN})
at isolated source `{SOURCE}` passes both frozen physical replays. Each verifies
1,729 original members and 84 producing inputs; the reproduction run also
rejects all nine corruptions. Both full results exactly match their retained
records and Windows reports, apart from the declared controls flag.

The original {archive.name} retains {len(indexed)} indexed proof members,
including actual commands, raw compressed logs, results and runtime identities.
API size/digest, completed upload log, workflow source and all job steps agree.
The CI runner pulled the exact verified public alpha.7 image and inspected its
configuration before and after execution. Image manifest and configuration
digests have distinct roles and are retained in verification.json.

Source scripts and metadata are frozen here. The per-run directories retain
their extracted Linux reports/logs. The original archive preserves every member
without a second copy of the large physical archives. This is separate from
the failed local startup attempts and makes no claim of local Docker recovery.
''',encoding='utf-8',newline='\n')
members = sorted(path for path in OUT.rglob('*') if path.is_file())
(OUT/'SHA256SUMS').write_bytes(''.join(sha(path.read_bytes())+'  '+path.relative_to(OUT).as_posix()+'\n' for path in members).encode())
print(record['status'],len(indexed),'original proof members')
