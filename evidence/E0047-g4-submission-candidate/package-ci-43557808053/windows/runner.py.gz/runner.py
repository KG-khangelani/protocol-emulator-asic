"""Capture the actual native Windows packaging run for the frozen release source."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PACKAGER = 'evidence/E0047-g4-submission-candidate/release-tools/package.py'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', required=True)
args = parser.parse_args()
assert sys.platform == 'win32' and re.fullmatch('[0-9a-f]{40}', args.source)
output = ROOT / 'build/g4-release-assets' / args.source
diagnostics = ROOT / 'build/g4-windows-package' / args.source
assert not output.exists() and not diagnostics.exists()
diagnostics.mkdir(parents=True)
command = [sys.executable, str(ROOT / PACKAGER), '--source', args.source, '--out', str(output)]
log = diagnostics / 'windows-package.log'
started, timer = datetime.now(timezone.utc).isoformat(), time.monotonic()
print('START_WINDOWS_PACKAGE', args.source, flush=True)
with log.open('xb') as stream:
    process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=1800,
                             creationflags=subprocess.CREATE_NO_WINDOW)
record = {'schema': 'protocol-emulator-g4-windows-package-invocation-v1', 'source_commit': args.source,
          'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
          'elapsed_seconds': time.monotonic()-timer, 'command': command, 'working_directory': str(ROOT),
          'exit_code': process.returncode, 'log_path': log.relative_to(ROOT).as_posix(),
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'log_bytes': log.stat().st_size,
          'python': sys.version, 'platform': platform.platform(), 'machine': platform.machine(),
          'packager_sha256': hashlib.sha256((ROOT/PACKAGER).read_bytes()).hexdigest(),
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(diagnostics/'invocation.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print(log.read_text(encoding='utf-8'),end='')
raise SystemExit(process.returncode)
