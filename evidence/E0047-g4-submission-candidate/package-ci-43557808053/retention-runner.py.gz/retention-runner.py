# SPDX-License-Identifier: Apache-2.0
"""Authenticate actual package CI, compare Windows bytes, and seal small evidence.

The signed download response remains in the ignored capture. Original transport
and the seventeen bulk assets are omitted from the sealed proof, with their
complete identities retained. A platform PASS is written only after all checks.
"""
import argparse
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
E47 = ROOT / 'evidence/E0047-g4-submission-candidate'
PACKAGER = 'evidence/E0047-g4-submission-candidate/release-tools/package.py'
WORKFLOW = '.github/workflows/g4-linux-verification.yaml'
RUNNER = '.github/g4-linux-verification/run.py'
REQUEST = '.github/g4-linux-verification/request.json'
IMAGE_RECORD = 'evidence/E0046-program-toolchain/publication/release-verification.json'
IMAGE = 'ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307'
CONFIG = 'sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451'
PHYSICAL_SOURCE = '45c55f7cd95db2a883b0ffb5e864decd62d53601'
ASSETS = {'g4-submission-bundle.zip', 'g4-public-programs.zip', 'g4-windows-programs.zip',
          'g4-submission.json', 'g4-SHA256SUMS'} | {
    f'g4-{run}-{name}.zip' for run in (43543626249, 43543629839)
    for name in ('GDS_logs', 'tt_submission', 'sram-physical-candidate', 'precheck_reports',
                 'gatelevel_test_results', 'sram-netlist-check')}
RESULT = ROOT / 'build/g4-package-platform-identity.json'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode('utf-8')


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encoded(value))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def relative(path):
    return path.resolve().relative_to(ROOT).as_posix()


def safe(name):
    path = PurePosixPath(name)
    require(path.as_posix() == name and not path.is_absolute() and '..' not in path.parts and
            '\\' not in name and ':' not in name and not name.endswith('/'), 'unsafe proof member')
    for part in path.parts:
        require(part.rstrip(' .') == part and part.split('.')[0].upper() not in
                {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)),
                 *(f'LPT{i}' for i in range(1, 10))}, 'unsafe Windows proof member')
    return path


def no_signed_urls(raw, label):
    for url in re.findall(rb'https?://[^\s\"\'<>]+', raw):
        require(re.search(rb'[?&](?:sig|signature|token|access_token|jwt|x-amz-signature|x-goog-signature)=',
                          url, re.IGNORECASE) is None, 'signed URL cannot be retained in ' + label)


def utc_order(record):
    start = datetime.fromisoformat(record['started_utc'].replace('Z', '+00:00'))
    end = datetime.fromisoformat(record['completed_utc'].replace('Z', '+00:00'))
    require(end >= start and record['elapsed_seconds'] >= 0, 'invalid invocation timing')


def acquire_archive(capture, meta, supplied):
    started = now()
    path = supplied.resolve() if supplied else ROOT / 'build/g4-package-ci-originals' / (str(meta['id']) + '.zip')
    require(path.is_relative_to((ROOT / 'build').resolve()), 'original transport must remain under ignored build/')
    method = 'existing_local_archive_verified_against_api'
    if not path.exists():
        require(supplied is None, 'supplied original archive does not exist')
        require(capture['download']['id'] == meta['id'] and
                capture['download']['url'].startswith('https://'), 'invalid captured download response')
        path.parent.mkdir(parents=True, exist_ok=True)
        partial = path.with_suffix('.zip.part')
        require(not partial.exists(), 'preserve the existing incomplete download')
        try:
            with urllib.request.urlopen(capture['download']['url'], timeout=120) as response, partial.open('xb') as output:
                require(response.status == 200, 'original artifact download did not succeed')
                while chunk := response.read(1024 * 1024):
                    output.write(chunk)
            require(partial.stat().st_size == meta['size_in_bytes'] and
                    'sha256:' + digest(partial) == meta['digest'], 'downloaded original size/digest differs')
            partial.rename(path)
        except Exception as exc:
            raise ValueError('artifact download/validation failed; signed response remains ignored (' +
                             type(exc).__name__ + ')') from None
        method = 'actual_https_download_from_captured_artifact_response'
    require(path.is_file() and not path.is_symlink() and path.stat().st_size == meta['size_in_bytes'] and
            'sha256:' + digest(path) == meta['digest'], 'original artifact size/digest differs')
    return path, {'schema': 'protocol-emulator-g4-package-transport-v1', 'artifact_id': meta['id'],
                  'bytes': path.stat().st_size, 'sha256': digest(path), 'method': method,
                  'started_utc': started, 'completed_utc': now(), 'original_zip_retained': False,
                  'scope': 'API and upload-log digest bound to actual original ZIP bytes; signed URL omitted.'}


def inspect_archive(archive, windows):
    require({path.name for path in windows.iterdir()} == ASSETS and
            all(path.is_file() and not path.is_symlink() for path in windows.iterdir()),
            'Windows output must contain exactly seventeen regular asset files')
    indexed, small, files, mismatches, folded = {}, {}, {}, [], set()
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            safe(info.filename)
            require(info.filename not in indexed and info.filename.casefold() not in folded and
                    not info.is_dir() and not info.flag_bits & 1 and
                    (info.external_attr >> 16) & 0o170000 in (0, 0o100000), 'invalid or duplicate ZIP member')
            folded.add(info.filename.casefold())
            if info.filename.startswith('assets/'):
                name = info.filename.removeprefix('assets/')
                require(name in ASSETS, 'unexpected package asset in original CI ZIP')
                digest_a, digest_b, size_a, size_b, equal = hashlib.sha256(), hashlib.sha256(), 0, 0, True
                with zipped.open(info) as left, (windows / name).open('rb') as right:
                    while True:
                        a, b = left.read(1024 * 1024), right.read(1024 * 1024)
                        equal = equal and a == b
                        if not a and not b:
                            break
                        digest_a.update(a)
                        digest_b.update(b)
                        size_a += len(a)
                        size_b += len(b)
                item = {'bytes': size_a, 'sha256': digest_a.hexdigest()}
                files[name] = item
                if not equal:
                    mismatches.append({'name': name, 'linux': item,
                                       'windows': {'bytes': size_b, 'sha256': digest_b.hexdigest()}})
                indexed[info.filename] = item
            else:
                require(info.file_size <= 16 * 1024 * 1024, 'unexpected bulk non-asset proof member')
                raw = zipped.read(info)
                no_signed_urls(gzip.decompress(raw) if info.filename.endswith('.gz') else raw, info.filename)
                small[info.filename] = raw
                indexed[info.filename] = {'bytes': len(raw), 'sha256': sha(raw)}
            require(indexed[info.filename]['bytes'] == info.file_size, 'ZIP member length differs')
    require(set(files) == ASSETS, 'CI ZIP does not contain all seventeen assets')
    require(not mismatches, 'actual platform asset bytes differ: ' + json.dumps(mismatches))
    print('ACTUAL_BYTE_COMPARISON_PASSED 17 assets', flush=True)
    return indexed, small, files


def retain(args):
    started = now()
    require(re.fullmatch('[0-9a-f]{40}', args.source) is not None, 'source must be a full commit SHA')
    source, capture_path, windows, out = args.source, args.capture.resolve(), args.windows_assets.resolve(), args.proof_destination.resolve()
    require(capture_path.is_relative_to((ROOT / 'build').resolve()) and windows.is_relative_to((ROOT / 'build').resolve()),
            'capture and actual assets must remain under ignored build/')
    require(out.is_relative_to(E47.resolve()) or out.is_relative_to((ROOT / 'build').resolve()),
            'proof destination must be under E0047 or build/')
    require(not out.exists() and not RESULT.exists(), 'preserve existing proof/platform result')
    capture = read(capture_path)
    api = {name: capture[name].encode('utf-8') if isinstance(capture[name], str) else encoded(capture[name])
           for name in ('run', 'jobs', 'artifacts')}
    run, jobs, artifacts = (json.loads(api[name]) for name in ('run', 'jobs', 'artifacts'))
    ci_source = run['head_sha']
    require(re.fullmatch('[0-9a-f]{40}', ci_source) is not None and
            run['status'] == 'completed' and run['conclusion'] == 'success' and
            run['event'] in ('push', 'workflow_dispatch') and run['head_branch'] == 'codex/g4-linux-verification' and
            run['path'] == WORKFLOW, 'CI run identity/status differs')
    require(jobs['total_count'] == len(jobs['jobs']) == 1, 'expected one package verification job')
    job = jobs['jobs'][0]
    require(job['name'] == 'verification' and job['run_id'] == run['id'] and job['head_sha'] == ci_source and
            job['run_attempt'] == run['run_attempt'] and job['status'] == 'completed' and job['conclusion'] == 'success' and
            all(step['conclusion'] == 'success' for step in job['steps']), 'CI job or one of its steps did not pass')
    require(artifacts['total_count'] == len(artifacts['artifacts']) == 1, 'expected one original proof artifact')
    meta = artifacts['artifacts'][0]
    require(meta['name'] == 'g4-linux-proof-' + ci_source and not meta['expired'] and
            meta['workflow_run']['id'] == run['id'] and meta['workflow_run']['head_sha'] == ci_source and
            capture['download']['id'] == meta['id'], 'original artifact identity differs')
    require(f'Artifact ID {meta["id"]}' in capture['log'] and
            'SHA256 digest of uploaded artifact is ' + meta['digest'].removeprefix('sha256:') in capture['log'] and
            f'Final size is {meta["size_in_bytes"]} bytes' in capture['log'], 'completed upload log does not bind original API metadata')
    for name, raw in {**api, 'job.log': capture['log'].encode()}.items():
        no_signed_urls(raw, name)
    archive, transport = acquire_archive(capture, meta, args.archive)
    indexed, small, files = inspect_archive(archive, windows)
    summary = json.loads(small['run-summary.json'])
    package = json.loads(small['package/result.json'])
    require(summary['status'] == 'PASS_G4_LINUX_RELEASE_PACKAGE' and summary['phase'] == 'package' and
            summary['source_commit'] == ci_source and summary['release_source_commit'] == source and
            summary['physical_source_commit'] == PHYSICAL_SOURCE and summary['package'] == package,
            'actual original run summary/source/package differs')
    require(summary['files'] == {name: item for name, item in indexed.items() if name != 'run-summary.json'},
            'original summary does not bind every original proof member')
    require(package['status'] == 'PASS_G4_LINUX_RELEASE_PACKAGE' and package['release_source_commit'] == source and
            package['asset_count'] == 17 and package['asset_directory'] == 'assets' and package['files'] == files,
            'actual asset map differs from the original package result')
    execution = summary['ci_execution']
    require(execution['run_id'] == str(run['id']) and execution['run_attempt'] == str(run['run_attempt']) and
            execution['source_commit'] == execution['workflow_execution_commit'] == execution['workflow_sha'] == ci_source and
            execution['job'] == job['name'] and execution['repository'] == 'KG-khangelani/protocol-emulator-asic' and
            execution['ref'] == 'refs/heads/codex/g4-linux-verification' and execution['event_name'] == run['event'] and
            package['ci_execution'] == execution, 'CI execution metadata differs from the actual API run/job')
    source_files = {name: git('show', ci_source + ':' + name) for name in (WORKFLOW, RUNNER, REQUEST)}
    runner_sha = sha(source_files[RUNNER])
    for name, raw in source_files.items():
        no_signed_urls(raw, name)
    request = json.loads(source_files[REQUEST])
    require(request == json.loads(small['request.json']) and request['phase'] == 'package' and
            request['source'] == 'HEAD' and request['release_source_commit'] == source and
            summary['runner_sha256'] == runner_sha, 'workflow request or executed runner differs from Git')
    binding = summary['workflow_binding']
    require(binding == {'path': WORKFLOW, 'source_commit': ci_source, 'sha256': sha(source_files[WORKFLOW]),
                        'runner_path': RUNNER, 'runner_sha256': runner_sha,
                        'request_path': REQUEST, 'request_sha256': sha(source_files[REQUEST])},
            'workflow source binding differs')
    packager_raw = git('show', source + ':' + PACKAGER)
    require(git('show', ci_source + ':' + PACKAGER) == packager_raw, 'CI packager differs from release source')
    bindings = summary['git_bindings']
    require(bindings == package['git_bindings'] and bindings['release_source_commit'] == source and
            bindings['ci_checkout_commit'] == ci_source and bindings['packager_sha256'] == sha(packager_raw) and
            all(bindings[name] is True for name in ('release_source_is_ancestor_of_ci_checkout',
                'release_source_is_ancestor_of_origin_main', 'tracked_checkout_clean_before',
                'tracked_checkout_clean_after', 'executed_packager_identical_to_release_git_blob',
                'public_image_record_identical_to_release_git_blob')), 'package Git checks differ')
    git('merge-base', '--is-ancestor', source, ci_source)
    git('merge-base', '--is-ancestor', source, bindings['origin_main_snapshot'])
    require(bindings['ci_checkout_parents'] == git('rev-list', '--parents', '-n', '1', ci_source).decode().split()[1:],
            'CI parent identities differ')
    image_record = git('show', source + ':' + IMAGE_RECORD)
    require(git('show', ci_source + ':' + IMAGE_RECORD) == image_record and
            summary['public_image_binding']['record_sha256'] == sha(image_record) and
            json.loads(image_record)['image'] == IMAGE and json.loads(image_record)['config_digest'] == CONFIG,
            'public image binding differs from release Git')
    runtime = summary['runtime']
    identity = runtime['container_image']
    require(runtime['image_reference'] == package['image'] == IMAGE and
            identity['Id'] == package['config_digest'] == CONFIG and IMAGE in identity['RepoDigests'] and
            identity['Os'] == 'linux' and identity['Architecture'] == 'amd64' and runtime == package['runtime'] and
            runtime['platform'].startswith('Linux-') and runtime['machine'] == 'x86_64', 'actual runtime/image differs')
    for phase in ('before', 'after'):
        inspected = json.loads(small['image-inspection-' + phase + '.json'])
        require(len(inspected) == 1 and {key: inspected[0][key] for key in identity} == identity,
                'actual pre/post image inspection differs')
    for name, raw in small.items():
        if name.startswith('commands/') and name.endswith('.json'):
            invocation = json.loads(raw)
            require(invocation['returncode'] == 0 and invocation['runner_sha256'] == runner_sha,
                    'recorded CI command failed or used another runner')
            utc_order(invocation)
            log = small[invocation['log_path']]
            require(sha(log) == invocation['compressed_log_sha256'] and
                    sha(gzip.decompress(log)) == invocation['log_sha256'], 'CI command log differs')
    require(json.loads(small['commands/image-pull.json'])['command'] == ['docker', 'pull', IMAGE],
            'actual image pull did not use the verified digest')
    linux_raw = small['package/invocation-linux.json']
    linux = json.loads(linux_raw)
    require(linux['schema'] == 'protocol-emulator-g4-linux-package-invocation-v1' and
            linux['returncode'] == 0 and linux['release_source_commit'] == source and
            linux['runner_sha256'] == runner_sha and linux['packager_sha256'] == sha(packager_raw) and
            linux['runtime'] == runtime and linux['ci_execution'] == execution and
            package['invocation_sha256'] == sha(linux_raw), 'actual Linux packager invocation differs')
    utc_order(linux)
    linux_log = gzip.decompress(small[linux['log_path']])
    require(sha(linux_log) == linux['log_sha256'] == package['log_sha256'], 'actual Linux package log differs')
    driver = next(ast.literal_eval(node.value) for node in ast.parse(source_files[RUNNER]).body
                  if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'PACKAGE_DRIVER'
                                                         for target in node.targets))
    remote = linux['working_directory']
    output = '/workspace/build/g4-linux-verification-work/release-assets/' + source
    actual = linux['command']
    require(re.fullmatch(r'[0-9]+:[0-9]+', actual[6]) is not None, 'invalid container user identity')
    expected = ['docker', 'run', '--rm', '--pull=never', '--network=none', '--user', actual[6],
                '--env', 'HOME=/tmp', '--env', 'PYTHONDONTWRITEBYTECODE=1', '--env', 'GIT_OPTIONAL_LOCKS=0',
                '--mount', f'type=bind,source={remote},target=/workspace,readonly',
                '--mount', f'type=bind,source={remote}/build/g4-linux-verification-work,target=/workspace/build/g4-linux-verification-work',
                '--workdir', '/workspace', IMAGE, 'python3', '-u', '-c', driver, PACKAGER, source, output]
    require(actual == expected and linux['packager_argv'] == [PACKAGER, '--source', source, '--out', output],
            'actual Docker/package arguments differ from the intended immutable offline invocation')
    runtime_lines = [json.loads(line[len('G4_PACKAGE_RUNTIME '):]) for line in linux_log.decode().splitlines()
                     if line.startswith('G4_PACKAGE_RUNTIME ')]
    require(runtime_lines == [linux['actual_packager_python_runtime']] and runtime_lines[0] ==
            {key: runtime[key] for key in ('python', 'platform', 'machine', 'executable')}, 'actual process Python differs')
    win_base = ROOT / 'build/g4-windows-package' / source
    win_raw, win_log = (win_base / 'invocation.json').read_bytes(), (win_base / 'windows-package.log').read_bytes()
    win = json.loads(win_raw)
    win_runner = (ROOT / 'build/g4_windows_package.py').read_bytes()
    require(win['schema'] == 'protocol-emulator-g4-windows-package-invocation-v1' and win['source_commit'] == source and
            win['exit_code'] == 0 and win['platform'].startswith('Windows-') and win['packager_sha256'] == sha(packager_raw) and
            win['runner_sha256'] == sha(win_runner) and win['log_sha256'] == sha(win_log) and win['log_bytes'] == len(win_log),
            'actual native Windows receipt/log/runner differs')
    utc_order(win)
    require(len(win['command']) == 6 and Path(win['command'][1]).resolve() == ROOT / PACKAGER and
            win['command'][2:5] == ['--source', source, '--out'] and Path(win['command'][5]).resolve() == windows and
            Path(win['working_directory']).resolve() == ROOT, 'actual Windows package arguments differ')
    manifest = read(windows / 'g4-submission.json')
    require(manifest['schema'] == 'protocol-emulator-g4-release-package-v1' and
            manifest['release_source_commit'] == source and manifest['tag'] == 'v0.1.0' and
            manifest['artifacts'] == {name: item for name, item in files.items() if name.endswith('.zip')},
            'actual distribution manifest source/asset map differs')
    checksums = (windows / 'g4-SHA256SUMS').read_text(encoding='utf-8').splitlines()
    require(checksums == [files[name]['sha256'] + '  ' + name for name in sorted(ASSETS - {'g4-SHA256SUMS'})],
            'checksum bytes do not follow explicit portable filename order')
    end_line = f"PACKAGED_G4_SUBMISSION {source} {len(manifest['bundle_members_sha256'])} members 17 assets"
    require(win_log.decode().splitlines().count(end_line) == linux_log.decode().splitlines().count(end_line) == 1,
            'actual successful package completion output differs')
    for label, raw in (('windows invocation', win_raw), ('windows log', win_log), ('windows runner', win_runner)):
        no_signed_urls(raw, label)
    stage = Path(tempfile.mkdtemp(prefix='g4-package-retention-', dir=ROOT / 'build')).resolve()
    for name, raw in api.items():
        (stage / (name + '.json')).write_bytes(raw)
    (stage / 'job.log.gz').write_bytes(gzip.compress(capture['log'].encode(), mtime=0))
    (stage / 'run-summary.json').write_bytes(small['run-summary.json'])
    for name, raw in small.items():
        if name == 'run-summary.json':
            continue
        target = stage / 'proof' / safe(name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    for name, raw in source_files.items():
        target = stage / 'source' / safe(name)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
    write(stage / 'source.json', {'source_commit': ci_source, 'release_source_commit': source,
                                 'files_sha256': {name: sha(raw) for name, raw in source_files.items()}})
    write(stage / 'zip-files.json', indexed)
    write(stage / 'archive-transport.json', transport)
    (stage / 'windows').mkdir()
    (stage / 'windows/invocation.json').write_bytes(win_raw)
    windows_log_gzip = gzip.compress(win_log, mtime=0)
    (stage / 'windows/windows-package.log.gz').write_bytes(windows_log_gzip)
    (stage / 'windows/runner.py.gz').write_bytes(gzip.compress(win_runner, mtime=0))
    proof_path = relative(out)
    identity_result = {
        'schema': 'protocol-emulator-g4-package-platform-identity-v1',
        'status': 'PASS_WINDOWS_LINUX_PACKAGE_IDENTITY', 'source_commit': source,
        'files': files, 'asset_count': 17, 'comparison': 'Every actual asset compared byte-for-byte',
        'started_utc': started, 'completed_utc': now(), 'packager_sha256': sha(packager_raw),
        'windows': {'invocation_path': proof_path + '/windows/invocation.json', 'invocation_sha256': sha(win_raw),
                    'command': win['command'], 'exit_code': win['exit_code'],
                    'log_path': proof_path + '/windows/windows-package.log.gz', 'log_sha256': sha(win_log),
                    'compressed_log_sha256': sha(windows_log_gzip), 'log_bytes': len(win_log),
                    'runtime': {key: win[key] for key in ('python', 'platform', 'machine')},
                    'runner_sha256': win['runner_sha256']},
        'linux': {'invocation_path': proof_path + '/proof/package/invocation-linux.json',
                  'invocation_sha256': sha(linux_raw), 'command': linux['command'], 'exit_code': linux['returncode'],
                  'log_path': proof_path + '/proof/' + linux['log_path'], 'log_sha256': sha(linux_log),
                  'runtime': runtime, 'runner_sha256': runner_sha, 'ci_execution': execution},
        'linux_ci': {'proof_path': proof_path, 'source_commit': ci_source, 'run_id': run['id'],
                     'run_attempt': run['run_attempt'], 'job_id': job['id'], 'artifact_id': meta['id'],
                     'artifact_bytes': meta['size_in_bytes'], 'artifact_sha256': meta['digest'][7:],
                     'original_archive_files': len(indexed), 'original_zip_retained': False, 'omitted_asset_files': 17},
        'scope': 'Actual native Windows and isolated Linux packaging only; final publication/download checks remain separate.'}
    write(stage / 'platform-identity.json', identity_result)
    record = {'status': 'PASS_RETAINED_G4_PACKAGE_CI', 'source_commit': ci_source, 'release_source_commit': source,
              'run_id': run['id'], 'job_id': job['id'], 'artifact_id': meta['id'],
              'artifact_bytes': meta['size_in_bytes'], 'artifact_sha256': meta['digest'][7:],
              'original_archive_files': len(indexed), 'original_zip_retained': False, 'omitted_asset_files': 17,
              'asset_files_compared_byte_for_byte': 17, 'image': IMAGE, 'config_digest': CONFIG,
              'platform_identity_sha256': digest(stage / 'platform-identity.json'),
              'capture_sha256': digest(capture_path), 'packager_sha256': sha(packager_raw),
              'scope': 'Original CI API/upload-bound transport, complete member map, source/runtime/commands and actual platform asset bytes verified. Bulk originals intentionally omitted from this small proof.'}
    write(stage / 'verification.json', record)
    (stage / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    (stage / 'README.md').write_bytes(f'''# G4 Windows/Linux package identity

Release source `{source}` produced seventeen byte-identical assets in the actual native Windows run and [isolated Linux CI run {run['id']}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{run['id']}). The Linux workflow source is `{ci_source}`. The actual command receipts, logs, Python/image identities, clean-tree/source checks and all asset hashes are retained.

The original CI transport was authenticated against its API size/digest and completed upload log. `zip-files.json` indexes all {len(indexed)} original members, including the seventeen assets. `proof/` retains the original non-asset members; `run-summary.json` retains the unmodified original summary. `source/` freezes the actual CI workflow, runner and request from Git. No signed download response is retained.

The {meta['size_in_bytes']}-byte original transport ZIP and seventeen bulk assets are intentionally omitted here to avoid duplication. The original ZIP remains under ignored `build/g4-package-ci-originals/`; its SHA256 is `{meta['digest'][7:]}`. Asset names and identities correspond to the separately prepared v0.1.0 release assets. This packet alone does not reconstruct the original transport ZIP. Publication and anonymous-download proof remain separate gates.

`platform-identity.json` is byte-identical to the completed local `build/g4-package-platform-identity.json`. The sealed native Windows and Linux receipts describe the actual executions; no unused local Docker runner is credited. The Windows log is compressed without changing its original CRLF bytes; decompression matches the original receipt SHA256 and byte count.
'''.encode())
    paths = sorted((path for path in stage.rglob('*') if path.is_file()), key=lambda path: path.relative_to(stage).as_posix())
    (stage / 'SHA256SUMS').write_bytes(''.join(digest(path) + '  ' + path.relative_to(stage).as_posix() + '\n' for path in paths).encode())
    require(stage.is_relative_to((ROOT / 'build').resolve()) and
            (out.is_relative_to(E47.resolve()) or out.is_relative_to((ROOT / 'build').resolve())) and not out.exists(),
            'final proof move must stay within the checked workspace targets')
    out.parent.mkdir(parents=True, exist_ok=True)
    stage.rename(out)
    with RESULT.open('xb') as output:
        output.write((out / 'platform-identity.json').read_bytes())
    print(identity_result['status'], source, '17 actual assets; sealed', proof_path, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--capture', type=Path, required=True)
    parser.add_argument('--windows-assets', type=Path, required=True)
    parser.add_argument('--proof-destination', type=Path, required=True)
    parser.add_argument('--archive', type=Path, help='Reuse an actual original CI ZIP already under ignored build/')
    retain(parser.parse_args())
