"""Append the actual completed verification to the immutable-source release notes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
E47 = ROOT / 'evidence/E0047-g4-submission-candidate'
read = lambda p: json.loads(p.read_bytes())
result = read(E47 / 'publication/release-verification.json')
completion = read(E47 / 'completion-audit.json')
before = read(ROOT / 'build/g4-release-note-before.json')
assert result['status'] == 'PASS_G4_RELEASE_AND_PACKAGE' and completion['status'] == 'PASS_G4_COMPLETION_REQUIREMENTS'
assert before['id'] == result['release_id'] and before['tag_name'] == result['tag'] == 'v0.1.0'
assert not before['draft'] and not before['prerelease']
assert len(before['assets']) == len(result['assets']) == 35
for asset in before['assets']:
    verified = result['assets'][asset['name']]
    assert asset['id'] == verified['id'] and asset['size'] == verified['bytes']
    assert asset['digest'] == 'sha256:' + verified['sha256']
frozen_notes = subprocess.check_output(['git', 'show', result['source_commit'] + ':docs/releases/v0.1.0.md'], cwd=ROOT).decode().strip()
assert before['body'].replace('\r\n', '\n').strip().startswith(frozen_notes)
marker = '<!-- G4 verified publication closure -->'
assert marker not in before['body']
notes = before['body'].rstrip() + '''

<!-- G4 verified publication closure -->
**Publication verified on 2026-11-14; G4 is complete.**

All 35 public downloads, 435 bundle members, both original physical evidence
sets and the matching workbench image/source identities pass the independent
audit. All nine release-tag workflows / 22 jobs pass. Windows and Linux
produce 17 byte-identical assets; the standalone distribution rebuilds all
13 examples into 52 identical files.

[Publication audit](https://github.com/KG-khangelani/protocol-emulator-asic/blob/main/evidence/E0047-g4-submission-candidate/publication/README.md)
and [five-check completion audit](https://github.com/KG-khangelani/protocol-emulator-asic/blob/main/evidence/E0047-g4-submission-candidate/completion-audit.json)
retain the proof. The source-tag notes above preserve their pre-publication
snapshot. No competition entry has been sent; owner fluency remains separate.
'''
path = ROOT / 'build/g4-release-final-notes.md'
assert not path.exists()
path.write_bytes(notes.encode('utf-8'))
command = ['gh', 'release', 'edit', 'v0.1.0', '--repo', 'KG-khangelani/protocol-emulator-asic',
           '--title', 'Protocol Emulator ASIC v0.1.0 (verified G4 candidate)', '--notes-file', str(path)]
started, timer = datetime.now(timezone.utc).isoformat(), time.monotonic()
process = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120,
                         creationflags=subprocess.CREATE_NO_WINDOW)
receipt = {'source_commit': result['source_commit'], 'release_id': result['release_id'], 'tag': 'v0.1.0',
           'command': command, 'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
           'elapsed_seconds': time.monotonic() - timer, 'exit_code': process.returncode,
           'notes_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'stdout': process.stdout.decode('utf-8'),
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT / 'build/g4-release-note-invocation.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(process.stdout.decode('utf-8'), end='')
assert process.returncode == 0
print('UPDATED_G4_RELEASE_VERIFICATION_NOTICE')
