# SPDX-License-Identifier: Apache-2.0
"""Authenticate and retain an actual isolated G4 publication CI proof.

--source is the frozen release commit, not the isolated CI execution commit.
Only the original CI artifact is downloaded. No Docker or publication runs occur.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
E47 = ROOT / "evidence/E0047-g4-submission-candidate"
REPO = "KG-khangelani/protocol-emulator-asic"
BRANCH = "codex/g4-linux-verification"
WORKFLOW = ".github/workflows/g4-linux-verification.yaml"
RUNNER = ".github/g4-linux-verification/run.py"
REQUEST = ".github/g4-linux-verification/request.json"
INPUTS = ".github/g4-linux-verification/publication-inputs"
PACKAGER = "evidence/E0047-g4-submission-candidate/release-tools/package.py"
AUDITOR = "evidence/E0047-g4-submission-candidate/release-tools/verify_publication.py"
IMAGE_RECORD = "evidence/E0046-program-toolchain/publication/release-verification.json"
IMAGE = "ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307"
CONFIG = "sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451"
PHYSICAL = "45c55f7cd95db2a883b0ffb5e864decd62d53601"
STATUS = "PASS_G4_LINUX_PUBLICATION_AUDIT"
METADATA = {"run.json", "jobs.json", "artifacts.json", "tag-workflows.json", "release.json",
            "tag-commit.json", "tag-ref.json", "tag-object.json", "current-job.log"}
OUTPUTS = {"release-verification.json", "zip-files.json", "downloaded-fresh-program-verification.json",
           "downloaded-gds-comparison.json", "downloaded-g2-comparison.json",
           "downloaded-reproduction/result.json", "downloaded-reproduction.log",
           "downloaded/publication.json", "downloaded/production-profile.json",
           "downloaded/g4-submission.json", "downloaded/g4-SHA256SUMS", "downloaded/SHA256SUMS"}
REGISTRY = {"registry-manifest.json", "registry-config.json", "registry-linux-amd64.json"}
TAG_WORKFLOWS = {"test", "docs", "atlas", "i2c-general", "sram-candidate",
                 "spi-program-sensitivity", "spi-timed-gpio", "program-tools", "publish"}
ARCHIVES = {"GDS_logs", "tt_submission", "sram-physical-candidate",
            "precheck_reports", "gatelevel_test_results", "sram-netlist-check"}
ASSETS = {"g4-submission-bundle.zip", "g4-public-programs.zip", "g4-windows-programs.zip",
          "g4-submission.json", "g4-SHA256SUMS"} | {
    f"g4-{run_id}-{name}.zip" for run_id in (43543626249, 43543629839) for name in ARCHIVES}
STEP_NAMES = ["Set up job", "Check out the isolated verification source",
              "Run the requested verification phase in the verified public image",
              "Retain the original Linux proof artifact",
              "Post Check out the isolated verification source", "Complete job"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2) + "\n").encode("utf-8"))


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, stderr=subprocess.PIPE)


def git_text(*args):
    return git(*args).decode("utf-8").strip()


def blob(source, name):
    safe_name(name)
    return git("show", source + ":" + name)


def ancestor(left, right):
    require(subprocess.run(["git", "merge-base", "--is-ancestor", left, right], cwd=ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE).returncode == 0,
            "release source is not an ancestor of " + right)


def safe_name(name):
    require(isinstance(name, str) and name and "\x00" not in name, "invalid archive/source name")
    path = PurePosixPath(name)
    require(path.as_posix() == name and not path.is_absolute() and ".." not in path.parts
            and "\\" not in name and ":" not in name, "unsafe archive/source path: " + name)
    reserved = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)),
                *(f"lpt{i}" for i in range(1, 10))}
    require(all(part not in ("", ".", "..") and not part.endswith((" ", "."))
                and part.split(".", 1)[0].casefold() not in reserved for part in path.parts),
            "nonportable archive/source path: " + name)
    return path


def literal(source, name):
    matches = [node.value for node in ast.walk(ast.parse(source)) if isinstance(node, ast.Assign)
               and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
               and node.targets[0].id == name]
    require(len(matches) == 1, "missing/ambiguous runner literal: " + name)
    return ast.literal_eval(matches[0])


def validate_capture(capture, release_source):
    require(set(capture) == {"run", "jobs", "artifacts", "log", "download"},
            "capture must contain the original run/jobs/artifacts/log/download fields")
    require(all(isinstance(capture[name], str) for name in ("run", "jobs", "artifacts", "log")),
            "capture API/log values must be unchanged decoded strings")
    run, jobs, artifacts = (json.loads(capture[name]) for name in ("run", "jobs", "artifacts"))
    ci_source, attempt = run["head_sha"], run["run_attempt"]
    require(re.fullmatch("[0-9a-f]{40}", ci_source) and isinstance(attempt, int) and attempt > 0,
            "invalid CI source/attempt")
    require(run["status"] == "completed" and run["conclusion"] == "success"
            and run["event"] == "push" and run["head_branch"] == BRANCH and run["path"] == WORKFLOW,
            "capture is not a successful isolated publication CI run")
    require(run["repository"]["full_name"] == REPO and run["head_repository"]["full_name"] == REPO,
            "CI repository identity differs")
    require(jobs["total_count"] == len(jobs["jobs"]) == 1, "expected one complete CI job record")
    job = jobs["jobs"][0]
    require(job["name"] == "verification" and job["run_id"] == run["id"]
            and job["run_attempt"] == attempt and job["head_sha"] == ci_source
            and job["status"] == "completed" and job["conclusion"] == "success",
            "CI job identity/status differs")
    require([item["name"] for item in job["steps"]] == STEP_NAMES
            and all(item["status"] == "completed" and item["conclusion"] == "success" for item in job["steps"])
            and len({item["number"] for item in job["steps"]}) == len(STEP_NAMES),
            "expected exact successful checkout/verification/upload/post-job steps")
    require(artifacts["total_count"] == len(artifacts["artifacts"]) == 1, "expected one original CI artifact")
    artifact = artifacts["artifacts"][0]
    require(artifact["name"] == "g4-linux-proof-" + ci_source and not artifact["expired"]
            and artifact["workflow_run"]["id"] == run["id"]
            and artifact["workflow_run"]["head_sha"] == ci_source
            and artifact["workflow_run"]["head_branch"] == BRANCH,
            "CI artifact source/run identity differs")
    require(re.fullmatch("sha256:[0-9a-f]{64}", artifact["digest"])
            and isinstance(artifact["size_in_bytes"], int) and artifact["size_in_bytes"] > 0,
            "CI artifact has no valid API digest/size")
    require(isinstance(capture["download"], dict) and set(capture["download"]) == {"id", "url"}
            and capture["download"]["id"] == artifact["id"], "download is for a different original artifact")
    url = urllib.parse.urlsplit(capture["download"]["url"])
    require(url.scheme == "https" and url.hostname and not url.username and not url.password and not url.fragment,
            "original artifact download must use the connector's HTTPS URL")
    log = capture["log"]
    require(ci_source in log and release_source in log and STATUS in log,
            "completed CI log lacks the exact CI/release sources or passing phase")
    require("SHA256 digest of uploaded artifact is " + artifact["digest"].split(":", 1)[1] in log,
            "completed upload log digest differs")
    require(f"Artifact {artifact['name']} successfully finalized. Artifact ID {artifact['id']}" in log
            and f"Artifact {artifact['name']} has been successfully uploaded! Final size is {artifact['size_in_bytes']} bytes. Artifact ID is {artifact['id']}" in log,
            "completed upload log does not bind the exact artifact name/id/size")
    require(f"https://github.com/{REPO}/actions/runs/{run['id']}/artifacts/{artifact['id']}" in log,
            "completed upload log artifact URL differs")
    require(git_text("rev-parse", ci_source + "^{commit}") == ci_source
            and git_text("rev-parse", release_source + "^{commit}") == release_source,
            "CI/release Git commits are unavailable")
    ancestor(release_source, ci_source)
    sources = {name: blob(ci_source, name) for name in (WORKFLOW, RUNNER, REQUEST)}
    request = json.loads(sources[REQUEST])
    require(request == {"schema": "protocol-emulator-g4-linux-request-v1", "phase": "publication",
                        "source": request.get("source"), "release_source_commit": release_source,
                        "publication_inputs": INPUTS}
            and request["source"] in ("HEAD", ci_source), "committed request is not this release publication phase")
    workflow = sources[WORKFLOW].decode("utf-8")
    require(re.findall(r"^      - name: (.+)$", workflow, re.M) == STEP_NAMES[1:4]
            and "python3 " + RUNNER + " --request " + REQUEST in workflow
            and "actions/checkout@d23441a48e516b6c34aea4fa41551a30e30af803" in workflow
            and "actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a" in workflow
            and "path: build/g4-ci-proof/" in workflow, "workflow execution/upload contract differs")
    for name, expected in (("PUBLIC_IMAGE", IMAGE), ("PUBLIC_CONFIG", CONFIG), ("PHYSICAL_SOURCE", PHYSICAL),
                           ("PUBLICATION_METADATA", METADATA), ("PUBLICATION_OUTPUTS", OUTPUTS),
                           ("REGISTRY_OUTPUTS", REGISTRY), ("TAG_WORKFLOWS", TAG_WORKFLOWS)):
        require(literal(sources[RUNNER], name) == expected, "remote runner contract differs: " + name)
    release_files = {name: blob(release_source, name) for name in (PACKAGER, AUDITOR, IMAGE_RECORD)}
    require(all(blob(ci_source, name) == raw for name, raw in release_files.items()),
            "executed release tools or audit image evidence differ from the frozen release")
    return run, job, artifact, sources, release_files, request


def download_original(capture, artifact, output):
    destination = output / (str(artifact["id"]) + ".zip")
    partial = output / (destination.name + ".download")
    digest, size = hashlib.sha256(), 0
    request = urllib.request.Request(capture["download"]["url"], headers={"User-Agent": "g4-original-publication-ci-retention"})
    try:
        with urllib.request.urlopen(request, timeout=90) as response, partial.open("xb") as stream:
            require(response.status == 200, "artifact download did not return HTTP 200")
            while block := response.read(1024 * 1024):
                size += len(block)
                require(size <= artifact["size_in_bytes"], "artifact download exceeds its API size")
                digest.update(block)
                stream.write(block)
    except urllib.error.HTTPError as error:
        raise ValueError("artifact HTTP download failed with status " + str(error.code)) from None
    require(size == artifact["size_in_bytes"] and "sha256:" + digest.hexdigest() == artifact["digest"],
            "original artifact API size/SHA-256 differs")
    partial.rename(destination)
    return destination


def extract_original(archive, output):
    destination = output / "files"
    destination.mkdir()
    indexed, folded = {}, set()
    with zipfile.ZipFile(archive) as stream:
        members = stream.infolist()
        require(members, "original proof archive is empty")
        for item in members:
            name = item.filename
            safe_name(name)
            mode = stat.S_IFMT(item.external_attr >> 16)
            require(not item.is_dir() and mode in (0, stat.S_IFREG)
                    and not (item.flag_bits & 1), "proof member is not an unencrypted regular file: " + name)
            require(name not in indexed and name.casefold() not in folded, "duplicate/colliding proof member: " + name)
            folded.add(name.casefold())
            indexed[name] = None
        required = sum(item.file_size for item in members) + archive.stat().st_size
        require(shutil.disk_usage(output).free > required, "insufficient free space for exact extraction and retention")
        for item in members:
            target = (destination / item.filename).resolve()
            require(target.is_relative_to(destination.resolve()), "proof extraction escapes its output")
            target.parent.mkdir(parents=True, exist_ok=True)
            digest, size = hashlib.sha256(), 0
            with stream.open(item) as source, target.open("xb") as dest:
                for block in iter(lambda: source.read(1024 * 1024), b""):
                    digest.update(block)
                    size += len(block)
                    dest.write(block)
            require(size == item.file_size, "original ZIP member size differs: " + item.filename)
            indexed[item.filename] = {"bytes": size, "sha256": digest.hexdigest()}
    return destination, indexed


def validate_proof(files, indexed, run, job, artifact, source_files, release_files, request, capture, source):
    summary = read(files / "run-summary.json")
    ci = run["head_sha"]
    runner_hash = sha(source_files[RUNNER])
    require(summary["schema"] == "protocol-emulator-g4-linux-proof-v1"
            and summary["phase"] == "publication" and summary["status"] == STATUS
            and summary["source_commit"] == ci and summary["release_source_commit"] == source
            and summary["physical_source_commit"] == PHYSICAL, "publication summary identity/status differs")
    require(summary["files"] == {name: item for name, item in indexed.items() if name != "run-summary.json"},
            "summary does not cover every original proof member exactly")
    execution = summary["ci_execution"]
    require(execution["source_commit"] == execution["workflow_execution_commit"] == execution["workflow_sha"] == ci
            and execution["repository"] == REPO and execution["ref"] == "refs/heads/" + BRANCH
            and execution["run_id"] == str(run["id"]) and execution["run_attempt"] == str(run["run_attempt"])
            and execution["job"] == job["name"] and execution["event_name"] == run["event"]
            and execution["workflow_ref"] == REPO + "/" + WORKFLOW + "@refs/heads/" + BRANCH
            and execution["runner_os"] == "Linux" and execution["runner_arch"] == "X64"
            and execution["host_platform"].startswith("Linux-"), "actual CI execution metadata differs")
    expected_workflow = {"path": WORKFLOW, "source_commit": ci, "sha256": sha(source_files[WORKFLOW]),
                         "runner_path": RUNNER, "runner_sha256": runner_hash,
                         "request_path": REQUEST, "request_sha256": sha(source_files[REQUEST])}
    require(summary["workflow_binding"] == expected_workflow and summary["runner_sha256"] == runner_hash,
            "workflow/runner/request Git blob binding differs")
    require((files / "request.json").read_bytes() == (json.dumps(request, indent=2, ensure_ascii=False) + "\n").encode(),
            "retained request differs from the executed committed request")
    runtime = summary["runtime"]
    identity = runtime["container_image"]
    require(runtime["image_reference"] == IMAGE and identity["Id"] == CONFIG and IMAGE in identity["RepoDigests"]
            and identity["Os"] == "linux" and identity["Architecture"] == "amd64"
            and runtime["platform"].startswith("Linux-") and runtime["machine"] == "x86_64"
            and read(files / "runtime.json") == {"ci_execution": execution, "container": runtime},
            "actual audit image/platform/Python runtime differs")
    image_record = json.loads(release_files[IMAGE_RECORD])
    expected_image_binding = {"record": IMAGE_RECORD, "record_sha256": sha(release_files[IMAGE_RECORD]),
                              "record_commit": source, "tag": "v0.1.0-alpha.7",
                              "source_commit": image_record["source_commit"], "image": IMAGE, "config_digest": CONFIG}
    require(image_record["status"] == "PASS_G3_RELEASE_AND_PACKAGE" and image_record["image"] == IMAGE
            and image_record["config_digest"] == CONFIG and image_record["tag"] == "v0.1.0-alpha.7"
            and summary["public_image_binding"] == expected_image_binding, "public alpha.7 audit image binding differs")

    def receipt(path, schema):
        value = read(files / path)
        require(value["schema"] == schema and value["returncode"] == 0 and "execution_error" not in value
                and value["runner_sha256"] == runner_hash, "command was not a successful executed frozen runner: " + path)
        safe_name(value["log_path"])
        packed = (files / value["log_path"]).read_bytes()
        raw = gzip.decompress(packed)
        require(sha(packed) == value["compressed_log_sha256"] and sha(raw) == value["log_sha256"],
                "command log bytes differ: " + path)
        require("RUN " + json.dumps(value["command"]) in capture["log"],
                "actual CI job log does not contain the recorded command: " + path)
        require("RETURN 0: " + path in capture["log"], "actual CI job log lacks successful command return: " + path)
        started = datetime.fromisoformat(value["started_utc"].replace("Z", "+00:00"))
        completed = datetime.fromisoformat(value["completed_utc"].replace("Z", "+00:00"))
        require(completed >= started and value["elapsed_seconds"] >= 0, "invalid command execution timing")
        return value, raw

    invocation, package_log = receipt("package/invocation-linux.json",
                                     "protocol-emulator-g4-linux-package-invocation-v1")
    audit_invocation, audit_log = receipt("publication/audit-runtime.json",
                                         "protocol-emulator-g4-linux-publication-invocation-v1")
    working = invocation["working_directory"]
    host_root = PurePosixPath(working)
    require(host_root.is_absolute() and ".." not in host_root.parts
            and audit_invocation["working_directory"] == working, "CI working directory differs")
    command = invocation["command"]
    require("--user" in command and re.fullmatch(r"[0-9]+:[0-9]+", command[command.index("--user") + 1]),
            "expected the actual unprivileged CI Docker user")
    user = command[command.index("--user") + 1]
    scratch = working + "/build/g4-linux-verification-work"
    container_scratch = "/workspace/build/g4-linux-verification-work"

    def docker(network=False, writable_build=False):
        writable_source = working + "/build" if writable_build else scratch
        writable_target = "/workspace/build" if writable_build else container_scratch
        return ["docker", "run", "--rm", "--pull=never", "--network=bridge" if network else "--network=none",
                "--user", user, "--env", "HOME=/tmp", "--env", "PYTHONDONTWRITEBYTECODE=1",
                "--env", "GIT_OPTIONAL_LOCKS=0", "--mount", "type=bind,source=" + working + ",target=/workspace,readonly",
                "--mount", "type=bind,source=" + writable_source + ",target=" + writable_target,
                "--workdir", "/workspace", IMAGE]

    bindings = summary["git_bindings"]
    main_snapshot = bindings["origin_main_snapshot"]
    require(re.fullmatch("[0-9a-f]{40}", main_snapshot), "invalid original main snapshot")
    ancestor(source, main_snapshot)
    expected_bindings = {"release_source_commit": source, "ci_checkout_commit": ci,
                         "ci_checkout_parents": git_text("rev-list", "--parents", "-n", "1", ci).split()[1:],
                         "origin_main_snapshot": main_snapshot,
                         "release_source_is_ancestor_of_ci_checkout": True, "release_source_is_ancestor_of_origin_main": True,
                         "ci_commits_after_release_source": int(git_text("rev-list", "--count", source + ".." + ci)),
                         "tracked_checkout_clean_before": True, "tracked_checkout_clean_after": True,
                         "packager_path": PACKAGER, "packager_sha256": sha(release_files[PACKAGER]),
                         "executed_packager_identical_to_release_git_blob": True,
                         "public_image_record_identical_to_release_git_blob": True}
    require(bindings == expected_bindings, "package source/ancestry/clean-tree Git binding differs")
    commands = {
        "release-source-is-ci-ancestor": ["git", "merge-base", "--is-ancestor", source, ci],
        "release-source-is-main-ancestor": ["git", "merge-base", "--is-ancestor", source, main_snapshot],
        "publication-tag-source": ["git", "rev-parse", "refs/tags/v0.1.0^{commit}"],
        "docker-version": ["docker", "version", "--format", "{{json .}}"],
        "image-pull": ["docker", "pull", IMAGE],
        "image-inspection-before": ["docker", "image", "inspect", IMAGE],
        "image-inspection-after": ["docker", "image", "inspect", IMAGE],
        "container-python-runtime": docker() + ["python3", "-c", literal(source_files[RUNNER], "runtime_code")],
    }
    for label, expected in commands.items():
        item, raw = receipt("commands/" + label + ".json", "protocol-emulator-g4-ci-command-invocation-v1")
        require(item["command"] == expected and item["working_directory"] == working
                and item["log_path"] == "commands/" + label + ".log.gz", "command invocation differs: " + label)
        if label.startswith("image-inspection-"):
            require(raw == (files / (label + ".json")).read_bytes(), "inspection copy differs")
            observed = json.loads(raw)
            require(len(observed) == 1 and {key: observed[0][key] for key in identity} == identity,
                    "actual before/after image inspection differs")
        elif label == "container-python-runtime":
            require(json.loads(raw) == {key: runtime[key] for key in ("python", "platform", "machine", "executable")},
                    "executed container Python differs")
        elif label == "publication-tag-source":
            require(raw.decode().strip() == source, "actual CI tag resolution differs")

    def driver_receipt(value, raw, kind, argv, expected_command, tool):
        require(value["host"] == "linux" and value["release_source_commit"] == source
                and value["physical_source_commit"] == PHYSICAL and value["ci_execution"] == execution
                and value["runtime"] == runtime and value["command"] == expected_command,
                "actual " + kind + " invocation differs")
        prefix = "G4_" + kind.upper()
        lines = raw.decode("utf-8").splitlines()
        arguments = [json.loads(line[len(prefix + "_ARGV "):]) for line in lines if line.startswith(prefix + "_ARGV ")]
        runtimes = [json.loads(line[len(prefix + "_RUNTIME "):]) for line in lines if line.startswith(prefix + "_RUNTIME ")]
        key, runtime_key = ("packager_argv", "actual_packager_python_runtime") if kind == "package" else (
            "auditor_argv", "actual_auditor_python_runtime")
        require(arguments == [argv] and value[key] == argv
                and runtimes == [{key: runtime[key] for key in ("python", "platform", "machine", "executable")}]
                and value[runtime_key] == runtimes[0], "actual driver argv/runtime differs: " + kind)
        digest_key = "packager_sha256" if kind == "package" else "auditor_sha256"
        require(value[digest_key] == sha(release_files[tool]), "executed release Git blob differs: " + kind)

    package_out = container_scratch + "/release-assets/" + source
    package_argv = [PACKAGER, "--source", source, "--out", package_out]
    driver_receipt(invocation, package_log, "package", package_argv,
                   docker() + ["python3", "-u", "-c", literal(source_files[RUNNER], "PACKAGE_DRIVER"),
                               PACKAGER, source, package_out], PACKAGER)
    require(invocation["log_path"] == "package/package-linux.log.gz", "package raw log path differs")
    packaged = read(files / "package/result.json")
    require(summary["package"] == packaged and packaged["schema"] == "protocol-emulator-g4-linux-release-package-v1"
            and packaged["status"] == "PASS_G4_LINUX_RELEASE_PACKAGE" and packaged["release_source_commit"] == source
            and packaged["physical_source_commit"] == PHYSICAL and packaged["asset_count"] == 17
            and set(packaged["files"]) == ASSETS and packaged["asset_payload_retained"] is False
            and packaged["asset_directory_base"] == "repository"
            and packaged["asset_directory"] == "build/g4-linux-verification-work/release-assets/" + source,
            "publication-phase package scope/assets differ")
    require(packaged["git_bindings"] == bindings and packaged["ci_execution"] == execution
            and packaged["runtime"] == runtime and packaged["image"] == IMAGE and packaged["config_digest"] == CONFIG
            and packaged["invocation"] == "package/invocation-linux.json"
            and packaged["invocation_sha256"] == file_sha(files / packaged["invocation"])
            and packaged["log_path"] == invocation["log_path"] and packaged["log_sha256"] == invocation["log_sha256"],
            "actual package result is not bound to its invocation/runtime")

    pub = files / "publication"
    inputs = read(pub / "input-binding.json")
    require(summary["publication_input_binding"] == inputs and summary["publication"]["inputs"] == inputs,
            "publication input binding differs")
    require(inputs["input_directory"] == INPUTS and inputs["input_source_commit"] == ci
            and inputs["release_source_commit"] == source and inputs["tag"] == "v0.1.0"
            and inputs["auditor_path"] == AUDITOR and inputs["auditor_sha256"] == sha(release_files[AUDITOR])
            and inputs["executed_auditor_identical_to_release_git_blob"] is True,
            "publication committed input/auditor source differs")
    original_name = inputs["original_archive"]
    require(original_name == str(inputs["original_artifact_id"]) + ".zip"
            and set(inputs["files"]) == METADATA | {original_name}, "publication input membership differs")
    for name, identity_input in inputs["files"].items():
        raw = (pub / name).read_bytes()
        require(identity_input == {"bytes": len(raw), "sha256": sha(raw)}
                and raw == blob(ci, INPUTS + "/" + name), "original committed publication input differs: " + name)
    directory = container_scratch + "/publication-audit"
    auditor_argv = [AUDITOR, "--directory", directory, "--assets", package_out]
    driver_receipt(audit_invocation, audit_log, "publication", auditor_argv,
                   docker(True, True) + ["python3", "-u", "-c", literal(source_files[RUNNER], "PUBLICATION_DRIVER"),
                                        AUDITOR, directory, package_out], AUDITOR)
    require(audit_invocation["tag"] == "v0.1.0"
            and audit_invocation["log_path"] == "publication/audit-linux.log.gz"
            and audit_invocation["uncompressed_log_path"] == "publication/audit-linux.log"
            and audit_invocation["uncompressed_log_sha256"] == sha(audit_log)
            and (pub / "audit-linux.log").read_bytes() == audit_log
            and audit_invocation["input_binding_sha256"] == file_sha(pub / "input-binding.json"),
            "publication raw/compressed logs or input binding differ")

    report = read(pub / "release-verification.json")
    require(report["schema"] == "protocol-emulator-g4-release-verification-v1"
            and report["status"] == "PASS_G4_RELEASE_AND_PACKAGE" and report["source_commit"] == source
            and report["physical_source_commit"] == PHYSICAL and report["tag"] == "v0.1.0"
            and audit_invocation["release_verification_sha256"] == file_sha(pub / "release-verification.json"),
            "publication auditor report identity/hash differs")
    release, publish_run, publisher_jobs = (read(pub / name) for name in ("release.json", "run.json", "jobs.json"))
    require(publish_run["head_sha"] == source and publish_run["head_branch"] == "v0.1.0"
            and publish_run["path"] == ".github/workflows/publish.yaml" and publish_run["event"] == "push"
            and publish_run["status"] == "completed" and publish_run["conclusion"] == "success",
            "original stable publisher run differs")
    require(publisher_jobs["total_count"] == len(publisher_jobs["jobs"]) == 1, "publisher job metadata is incomplete")
    publisher_job = publisher_jobs["jobs"][0]
    require(publisher_job["name"] == "workbench" and publisher_job["head_sha"] == source
            and publisher_job["run_id"] == publish_run["id"] and publisher_job["run_attempt"] == publish_run["run_attempt"]
            and publisher_job["status"] == "completed" and publisher_job["conclusion"] == "success"
            and all(item["conclusion"] == "success" for item in publisher_job["steps"]),
            "original stable publisher job differs")
    require(release["tag_name"] == "v0.1.0" and release["draft"] is False and release["prerelease"] is False,
            "release is not the stable public version")
    assets = {item["name"]: item for item in release["assets"]}
    require(len(assets) == len(release["assets"]) == 35 and set(report["assets"]) == set(assets)
            and inputs["asset_names"] == sorted(assets), "release/publication asset membership differs")
    for name, item in report["assets"].items():
        actual = assets[name]
        require(item["id"] == actual["id"] and item["bytes"] == actual["size"]
                and "sha256:" + item["sha256"] == actual["digest"]
                and item["url"] == actual["browser_download_url"] and item["anonymous_download_verified"] is True,
                "actual anonymous asset verification differs: " + name)
    for name, identity_asset in packaged["files"].items():
        require(identity_asset == {key: report["assets"][name][key] for key in ("bytes", "sha256")},
                "regenerated package differs from the actual anonymously downloaded asset: " + name)
    package_manifest_path = pub / "downloaded/g4-submission.json"
    package_manifest = read(package_manifest_path)
    checksums_path = pub / "downloaded/g4-SHA256SUMS"
    require(package_manifest["schema"] == "protocol-emulator-g4-release-package-v1"
            and package_manifest["release_source_commit"] == source and package_manifest["tag"] == "v0.1.0"
            and package_manifest["target"] == "od128-sram-v1" and package_manifest["interface_id"] == "0x22"
            and package_manifest["artifacts"] == {name: meta for name, meta in packaged["files"].items()
                                                   if name.endswith(".zip")},
            "actual downloaded G4 manifest differs from regenerated package identities")
    require(packaged["files"]["g4-submission.json"] == {"bytes": package_manifest_path.stat().st_size,
            "sha256": file_sha(package_manifest_path)} and packaged["files"]["g4-SHA256SUMS"] == {
            "bytes": checksums_path.stat().st_size, "sha256": file_sha(checksums_path)},
            "actual downloaded G4 manifest/checksum bytes differ")
    checksum_map = {}
    for line in checksums_path.read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ", 1)
        require(re.fullmatch("[0-9a-f]{64}", digest) and name not in checksum_map,
                "malformed/duplicate actual G4 checksum record")
        checksum_map[name] = digest
    require(checksum_map == {name: meta["sha256"] for name, meta in packaged["files"].items()
                            if name != "g4-SHA256SUMS"}, "actual G4 checksums omit or change an asset")
    require(packaged["manifest_checks"] == {
        "manifest_sha256": file_sha(package_manifest_path), "checksums_sha256": file_sha(checksums_path),
        "bundle_members_verified": len(package_manifest["bundle_members_sha256"]),
        "original_archive_assets": len(package_manifest["original_archives"]),
        "tag": "v0.1.0", "target": "od128-sram-v1", "interface_id": "0x22"}
        and len(package_manifest["original_archives"]) == 14
        and report["bundle_members_verified"] == len(package_manifest["bundle_members_sha256"]),
        "package inventory report differs from the actual downloaded manifest")
    metadata = read(pub / "artifacts.json")["artifacts"]
    original = [item for item in metadata if item["id"] == inputs["original_artifact_id"]]
    require(len(original) == 1 and original[0]["name"] == "publication-" + source
            and original[0]["workflow_run"]["id"] == publish_run["id"]
            and original[0]["workflow_run"]["head_sha"] == source and not original[0]["expired"],
            "original publisher artifact metadata differs")
    original = original[0]
    require((pub / original_name).stat().st_size == original["size_in_bytes"]
            and "sha256:" + file_sha(pub / original_name) == original["digest"]
            and report["publication_artifact_id"] == original["id"]
            and report["publication_original_zip_sha256"] == file_sha(pub / original_name)
            and report["publication_job_id"] == publisher_job["id"]
            and report["publish_run"] == inputs["publish_run"] == publish_run["id"]
            and report["release_id"] == inputs["release_id"] == release["id"],
            "original publisher ZIP/run/job/release report binding differs")
    original_index = read(pub / "zip-files.json")
    observed_original = {}
    with zipfile.ZipFile(pub / original_name) as stream:
        entries = stream.infolist()
        require(len(entries) == len({item.filename for item in entries}), "duplicate original publisher ZIP member")
        for item in entries:
            if item.is_dir():
                continue
            digest = hashlib.sha256()
            with stream.open(item) as raw_member:
                for block in iter(lambda: raw_member.read(1024 * 1024), b""):
                    digest.update(block)
            observed_original[item.filename] = digest.hexdigest()
    require(original_index == observed_original and len(original_index) == report["publication_original_zip_files"],
            "original publisher member audit does not cover the exact archive")
    current_log = (pub / "current-job.log").read_text(encoding="utf-8-sig")
    require(f"Artifact ID {original['id']}" in current_log
            and original["digest"].split(":", 1)[1] in current_log, "original publisher upload log differs")
    tag_ref, tag_object, tag_commit = (read(pub / name) for name in ("tag-ref.json", "tag-object.json", "tag-commit.json"))
    require(tag_ref["ref"] == "refs/tags/v0.1.0" and tag_ref["object"]["type"] == "tag"
            and tag_ref["object"]["sha"] == tag_object["sha"] == inputs["tag_object_sha"]
            and tag_object["tag"] == "v0.1.0" and tag_object["object"] == tag_commit
            and tag_commit["type"] == "commit" and tag_commit["sha"] == source
            and git_text("cat-file", "-t", tag_object["sha"]) == "tag"
            and git_text("rev-parse", tag_object["sha"] + "^{commit}") == source,
            "actual annotated stable tag differs")
    tags = read(pub / "tag-workflows.json")
    require(len(tags["runs"]) == 9 and {item["name"] for item in tags["runs"]} == TAG_WORKFLOWS
            and set(report["tag_workflows"]) == TAG_WORKFLOWS, "tag workflow coverage differs")
    for tagged in tags["runs"]:
        name = tagged["name"]
        require(tagged["head_sha"] == source and tagged["head_branch"] == "v0.1.0"
                and tagged["event"] == "push" and tagged["status"] == "completed" and tagged["conclusion"] == "success",
                "tag workflow is not complete for the release: " + name)
        items = tags["jobs"][str(tagged["id"])]["jobs"]
        require(items and all(item["head_sha"] == source and item["run_id"] == tagged["id"]
                and item["run_attempt"] == tagged["run_attempt"] and item["status"] == "completed"
                and item["conclusion"] == "success"
                and all(step["conclusion"] in ("success", "skipped") for step in item["steps"]) for item in items),
                "tag workflow job evidence differs: " + name)
        require(report["tag_workflows"][name] == {"run_id": tagged["id"],
                "jobs": {item["name"]: item["id"] for item in items}, "conclusion": "success"}
                and inputs["tag_workflow_runs"][name] == tagged["id"], "tag workflow report differs: " + name)
    require(report["physical_original_ci_archives_verified"] == 12
            and report["physical_original_archive_members_verified"] == 3458
            and report["fresh_program_toolchain_replayed_from_downloaded_bundle"] is True
            and report["current_verification_input_files_bound_to_release_git"] == 352
            and report["verification_input_files_unchanged_from_clean_G3_CI"] == 351
            and report["metadata_check_executions"] == 2 and report["metadata_tests_each"] == 147,
            "required publication semantic audit coverage differs")
    for role, number in (("candidate", 43543626249), ("reproduction", 43543629839)):
        physical_path = f"evidence/E0047-g4-submission-candidate/ci-{number}/result.json"
        require(report["physical_runs_reaudited_from_public_downloads"][role] == {
            "run_id": number, "status": "PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES",
            "result_sha256": sha(blob(source, physical_path))}, "public physical re-audit result differs")
    require(read(pub / "downloaded-reproduction/result.json") ==
            json.loads(blob(source, "evidence/E0047-g4-submission-candidate/reproduction.json")),
            "actual downloaded reproduction output differs")
    require(report["downloaded_fresh_program_verification_sha256"] == file_sha(pub / "downloaded-fresh-program-verification.json")
            and report["downloaded_gds_comparison_sha256"] == file_sha(pub / "downloaded-gds-comparison.json")
            and report["downloaded_g2_comparison_sha256"] == file_sha(pub / "downloaded-g2-comparison.json"),
            "curated semantic result hashes differ")

    publication = read(pub / "downloaded/publication.json")
    require(report["publication"] == publication and report["image"] == publication["image"]
            and publication["source_commit"] == source and publication["physical_qualification"] == "NOT_EVALUATED",
            "published image receipt or its physical scope differs")
    raw_manifest = (pub / "registry-manifest.json").read_bytes()
    manifest = json.loads(raw_manifest)
    manifest_digest = "sha256:" + sha(raw_manifest)
    require(report["manifest_digest"] == manifest_digest and report["image"] == IMAGE.split("@")[0] + "@" + manifest_digest
            and report["verified_tag_digests"] == {"v0.1.0": manifest_digest, "sha-" + source: manifest_digest},
            "actual published manifest/aliases differ")
    registry_names = {"registry-manifest.json", "registry-config.json"}
    child_digest = manifest_digest
    if "manifests" in manifest:
        matches = [item for item in manifest["manifests"]
                   if item.get("platform", {}).get("os") == "linux" and item.get("platform", {}).get("architecture") == "amd64"]
        require(len(matches) == 1, "published manifest has ambiguous linux/amd64 child")
        child_digest = matches[0]["digest"]
        raw = (pub / "registry-linux-amd64.json").read_bytes()
        require("sha256:" + sha(raw) == child_digest, "actual published child manifest differs")
        manifest = json.loads(raw)
        registry_names.add("registry-linux-amd64.json")
    config_raw = (pub / "registry-config.json").read_bytes()
    published_config = "sha256:" + sha(config_raw)
    config = json.loads(config_raw)
    require(report["linux_amd64_manifest_digest"] == child_digest
            and report["config_digest"] == manifest["config"]["digest"] == published_config
            and config["os"] == "linux" and config["architecture"] == "amd64", "published image config/platform differs")
    labels = config["config"]["Labels"]
    require(labels["org.opencontainers.image.revision"] == labels["org.opencontainers.image.version"] == source
            and labels["org.opencontainers.image.source"] == "https://github.com/" + REPO, "published image source labels differ")
    require(report["anonymous_layer_heads"] == [{"digest": item["digest"], "bytes": item["size"],
            "anonymous_head_status": 200} for item in manifest["layers"]], "published layer HEAD coverage differs")

    curated = {name: indexed["publication/" + name] for name in OUTPUTS | registry_names}
    final = summary["publication"]
    require(final["schema"] == "protocol-emulator-g4-linux-publication-proof-v1" and final["status"] == STATUS
            and final["release_source_commit"] == source and final["physical_source_commit"] == PHYSICAL
            and final["tag"] == "v0.1.0" and final["release_id"] == release["id"]
            and final["asset_count"] == 35 and final["tag_workflow_count"] == 9
            and final["tag_workflows"] == report["tag_workflows"] and final["auditor_sha256"] == sha(release_files[AUDITOR])
            and final["release_verification_path"] == "publication/release-verification.json"
            and final["release_verification_sha256"] == file_sha(pub / "release-verification.json")
            and final["input_binding_path"] == "publication/input-binding.json" and final["inputs"] == inputs
            and final["curated_outputs"] == curated and final["ci_execution"] == execution
            and final["audit_image"] == IMAGE and final["audit_image_config_digest"] == CONFIG
            and final["published_image"] == report["image"] and final["published_image_config_digest"] == published_config
            and final["invocation"] == "publication/audit-runtime.json"
            and final["invocation_sha256"] == file_sha(pub / "audit-runtime.json")
            and final["log_path"] == "publication/audit-linux.log" and final["log_sha256"] == sha(audit_log)
            and final["tracked_checkout_clean_after"] is True, "complete publication phase result binding differs")
    expected_members = {"request.json", "runtime.json", "image-inspection-before.json",
                        "image-inspection-after.json", "run-summary.json", "package/result.json",
                        "package/invocation-linux.json", "package/package-linux.log.gz"}
    expected_members.update("commands/" + label + suffix for label in commands for suffix in (".json", ".log.gz"))
    expected_members.update("publication/" + name for name in METADATA | {original_name, "input-binding.json",
                            "audit-runtime.json", "audit-linux.log.gz", "audit-linux.log"} | OUTPUTS | registry_names)
    require(set(indexed) == expected_members, "unexpected/missing proof files, or bulk package/download assets retained")
    return summary, report


def retain(destination, output, archive, indexed, capture, run, job, artifact,
           source_files, release_files, summary, report, source):
    destination.mkdir(parents=True)
    shutil.copyfile(archive, destination / archive.name)
    require(file_sha(destination / archive.name) == artifact["digest"].split(":", 1)[1], "retained original ZIP differs")
    for name in ("run", "jobs", "artifacts"):
        (destination / (name + ".json")).write_bytes(capture[name].encode("utf-8"))
    (destination / "job.log.gz").write_bytes(gzip.compress(capture["log"].encode("utf-8"), mtime=0))
    for prefix, commit, selected in (("source", run["head_sha"], source_files), ("release-source", source, release_files)):
        for name, raw in selected.items():
            path = destination / prefix / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        write(destination / (prefix + ".json"), {"source_commit": commit,
              "files_sha256": {name: sha(raw) for name, raw in selected.items()}})
    shutil.copyfile(output / "files/run-summary.json", destination / "run-summary.json")
    write(destination / "zip-files.json", indexed)
    record = {"schema": "protocol-emulator-g4-retained-publication-ci-proof-v1",
              "status": "PASS_RETAINED_G4_LINUX_PUBLICATION_CI_PROOF",
              "run_id": run["id"], "run_attempt": run["run_attempt"], "job_id": job["id"],
              "source_commit": run["head_sha"], "release_source_commit": source,
              "artifact_id": artifact["id"], "artifact_bytes": artifact["size_in_bytes"],
              "artifact_sha256": artifact["digest"].split(":", 1)[1], "original_archive_files": len(indexed),
              "original_zip_retained": True, "runner_sha256": summary["runner_sha256"],
              "job_log_sha256": sha(capture["log"].encode("utf-8")), "summary_sha256": file_sha(output / "files/run-summary.json"),
              "publication_report_sha256": file_sha(output / "files/publication/release-verification.json"),
              "asset_count": 35, "tag_workflow_count": 9, "image": IMAGE, "config_digest": CONFIG,
              "published_image": report["image"], "published_config_digest": report["config_digest"],
              "extracted_publication_directory": (output / "files/publication").relative_to(ROOT).as_posix(),
              "observed_utc": datetime.now(timezone.utc).isoformat(),
              "scope": "Authenticated original remote publication CI proof, executed Git source, actual image/runtime/command logs and complete auditor output. Anonymous release reads occurred in CI; this retainer does not repeat those downloads, run Docker, publish a release, or establish local Docker recovery."}
    write(destination / "verification.json", record)
    (destination / "retention-runner.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    (destination / "README.md").write_bytes((
        "# Original isolated publication CI proof\n\n"
        f"[Run {run['id']}](https://github.com/{REPO}/actions/runs/{run['id']}), "
        f"job {job['id']}, attempt {run['run_attempt']}, completed the actual publication audit.\n"
        f"CI source: `{run['head_sha']}`. Frozen release source: `{source}`.\n\n"
        f"The unchanged original `{archive.name}` contains {len(indexed)} fully indexed proof files. "
        "API size/digest, completed upload log, exact successful job steps, workflow/request/runner Git bytes, "
        "actual command output, image inspections and audit results agree.\n\n"
        f"The auditor used `{IMAGE}` with configuration `{CONFIG}`. "
        "The separately published release image and its configuration are recorded in verification.json. "
        "All 35 anonymous asset checks and nine release-tag workflow results are bound to the actual CI output.\n\n"
        "The original publisher ZIP, raw invocation logs and curated semantic/registry outputs remain inside "
        "the original proof archive. Regenerated package assets and bulk anonymous downloads were deliberately "
        "excluded by the executed publication runner. Exact source snapshots and the retention script are sealed here.\n\n"
        "This is remote CI evidence; it makes no claim that an unused local runner executed or local Docker recovered.\n"
    ).encode("utf-8"))
    members = sorted(path for path in destination.rglob("*") if path.is_file())
    (destination / "SHA256SUMS").write_bytes("".join(file_sha(path) + "  " +
        path.relative_to(destination).as_posix() + "\n" for path in members).encode("utf-8"))
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, help="Full 40-hex frozen release commit (not the isolated CI commit)")
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--proof-destination", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="Fresh ignored build directory; exact proof is extracted under files/")
    args = parser.parse_args()
    require(re.fullmatch("[0-9a-f]{40}", args.source), "--source must be a full release commit SHA")
    capture_path, output, destination = (path.resolve() for path in (args.capture, args.output, args.proof_destination))
    require(capture_path.is_file() and not args.capture.is_symlink() and capture_path.is_relative_to(ROOT / "build"),
            "capture must be an existing regular file under ignored build/")
    require(output.is_relative_to(ROOT / "build") and output != ROOT / "build" and not output.exists(),
            "output must be a fresh contained directory under ignored build/")
    require(destination.is_relative_to(E47) and destination.parent == E47 and not destination.exists(),
            "proof destination must be a fresh direct child of E0047")
    require(not output.is_relative_to(capture_path) and not capture_path.is_relative_to(output),
            "capture and output paths overlap")
    capture = read(capture_path)
    run, job, artifact, sources, release_files, request = validate_capture(capture, args.source)
    require(destination.name == "publication-ci-" + str(run["id"]), "proof destination must name the authentic CI run")
    output.mkdir(parents=True)
    try:
        archive = download_original(capture, artifact, output)
        files, indexed = extract_original(archive, output)
        summary, report = validate_proof(files, indexed, run, job, artifact, sources, release_files,
                                         request, capture, args.source)
        record = retain(destination, output, archive, indexed, capture, run, job, artifact,
                        sources, release_files, summary, report, args.source)
    except Exception as error:
        message = re.sub(r"https?://\S+", "[URL omitted]", str(error))
        write(output / "retention-failure.json", {"status": "NOT_QUALIFIED", "error_type": type(error).__name__,
              "error": message, "run_id": run["id"], "source_commit": run["head_sha"],
              "release_source_commit": args.source})
        raise ValueError(message) from None
    print(record["status"], run["id"], len(indexed), "original proof members")
    print("EXTRACTED_PUBLICATION", record["extracted_publication_directory"])
    print("SEALED_PROOF", destination.relative_to(ROOT).as_posix())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
