"""Upload only the seventeen byte-verified assets after the publisher creates v0.1.0."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
record = json.loads((ROOT / 'build/g4-package-platform-identity.json').read_bytes())
assert record['status'] == 'PASS_WINDOWS_LINUX_PACKAGE_IDENTITY' and len(record['files']) == 17
source = record['source_commit']
assert subprocess.check_output(['git', 'rev-parse', 'v0.1.0^{commit}'], cwd=ROOT).decode().strip() == source
directory = ROOT / 'build/g4-release-assets' / source
assert {path.name for path in directory.iterdir()} == set(record['files'])
for name, expected in record['files'].items():
    path = directory / name
    assert path.stat().st_size == expected['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256']
diagnostics = ROOT / 'build/g4-upload'
assert not diagnostics.exists()
diagnostics.mkdir()
command = ['gh', 'release', 'upload', 'v0.1.0', '--repo', 'KG-khangelani/protocol-emulator-asic'] + [
    str(directory / name) for name in sorted(record['files'])]
started, timer = datetime.now(timezone.utc).isoformat(), time.monotonic()
log = diagnostics / 'upload.log'
with log.open('xb') as output:
    process = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT,
                             timeout=1800, creationflags=subprocess.CREATE_NO_WINDOW)
receipt = {'schema': 'protocol-emulator-g4-release-upload-v1', 'source_commit': source,
           'tag': 'v0.1.0', 'command': command, 'started_utc': started,
           'completed_utc': datetime.now(timezone.utc).isoformat(),
           'elapsed_seconds': time.monotonic() - timer, 'exit_code': process.returncode,
           'files': record['files'], 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
           'log_bytes': log.stat().st_size,
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(diagnostics / 'invocation.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(log.read_text(encoding='utf-8'), end='')
print('G4_RELEASE_UPLOAD_EXIT', process.returncode, len(record['files']), 'assets')
sys.exit(process.returncode)
