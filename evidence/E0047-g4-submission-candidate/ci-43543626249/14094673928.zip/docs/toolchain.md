# Toolchain and reproduction

## Source baseline

The original M0 template is `TinyTapeout/ttihp-verilog-template`, `cmos5l`,
commit `b86a2a781484bcab7ba522dc5de540086695a430`. Its verified inventory remains
in `upstream-template.json`. D33 audits the current 8x4 template at
`4b1204ab387b5ab94db1d57067051d8d89a2f83c`; D34 adds the documented common
fanout/clock-tree constraints. Current `src/config.json` is therefore distinct
from the historical M0 baseline. The separate lock entries preserve both.

The upstream devcontainer had `PDK=ihp-sg13g2` while its CMOS5L workflow and
test harness used `ihp-sg13cmos5l`. The devcontainer variable is aligned with
the latter. The optional devcontainer lane remains unverified; it is separate
from the qualified workbench and official physical runs.

## Fast local loop

The supported local path is `tools/workbench.ps1` on Windows or
`tools/workbench.sh` on Linux/WSL. It builds a Linux/amd64 Docker image from:

- Python 3.11.16 base image pinned by OCI digest;
- OSS CAD Suite `2026-07-29` archive pinned by SHA-256;
- Verible `v0.0-4296-g0f262651` archive pinned by SHA-256;
- exact Debian package versions; and
- direct and transitive Python packages pinned with hashes.

`Doctor` checks installed outputs against `tools/workbench/toolchain.lock.json`
and fails on a missing or different version. `Check` performs static consistency
only. `Lint` runs Verible with one documented Tiny Tapeout filename waiver.
`Test` invokes cocotb/Icarus, while `TestVerilator` runs the same oracle through
an independently implemented simulator; both reject missing, empty, skipped or
failed JUnit results. `LearnStatus` validates and prints the separate technical
and human milestone gates; it cannot auto-assess human understanding.
`LearnStatus` and `LearnM0` are read-only, standard-library Python lessons, so
the PowerShell wrapper prefers a working host Python and does not require Docker
for them. A clean Windows CI job exercises that route. If host Python is absent,
the same scripts fall back to the locked container. This exception is only for
reading committed evidence; every EDA operation remains container-locked.
`LearnWaveform` reruns Icarus in readable VCD mode, checks
all rising-edge transitions, deliberately corrupts one edge to verify rejection,
and prints selected events for a first-time waveform reader. `Formal` proves the M0 state/output contract, creates a
reset-to-wrap witness, and confirms the assertions reject an increment-by-two
mutant. `Synth` runs generic Yosys and leaves `build/synthesis.log` and
`build/synth.json`. `Evidence` records source hashes, exact commands, versions,
stage status, the rejected unearned-fluency self-test, and the learning
waveform/JUnit artifacts. See `formal/README.md`
for the proof assumptions and limits.

GitHub's Docker setup and build actions are also pinned by commit. E0011
qualifies Node 24-native setup-buildx v4.4.1 and build-push v7.4.0: the locked
image identity is unchanged, all seven stages pass, the artifact uploads, and
the prior Node 20 deprecation annotation is absent. These actions orchestrate
the container; they do not replace or redefine the EDA tools inside it. That
seven-stage statement describes E0011's historical source. Current evidence
adds `learning_status` and `learning_waveform` as eighth and ninth checked stages
without changing the RTL or physical acceptance flow.

## Physical gate

1. Push the intended source revision to the project repository.
2. Wait for `test` to pass and inspect the uploaded verification artifact.
3. Trigger **Actions → gds → Run workflow** on that revision's branch. Choose
   the experimental variant explicitly; D35 makes compact10 the default.
4. Inspect `gds`, `precheck` and `gl_test` independently; retain failure logs.
5. Download/archive artifacts; identify the input commit and resolved action,
   LibreLane, PDK and container versions.
6. Record mapped cell area, physical utilization, worst setup/hold slack,
   violation counts, final GDS SHA-256 and artifact/run URLs.
7. Rebuild from a clean checkout using the same resolved inputs. Compare
   functional acceptance and timing/area. Document expected tool nondeterminism
   instead of assuming every physical artifact must be byte-identical.

The Pages viewer is disabled during bootstrap and is not an acceptance gate.
The FPGA job remains manually available; no board compatibility is claimed.

For local hardening, consult the official guide in `sources.md`, but derive
the PDK and tooling from the pinned **official_cmos5l_8x4** lock entry. The
general guide still shows another IHP PDK and is not a drop-in process lock.
Do not blindly replace `ihp-sg13cmos5l` with `ihp-sg13g2`.

### Historical M0 physical-flow snapshot

E0003 first resolved the CMOS5L action branch to action commit
`3412659307918422f3f0727917cf9b499aaca588`, Tiny Tapeout support tools
`d66cf179e7bc4d296362ab7e2e3b344dc3c4f665`, LibreLane `3.1.0.dev3`, and
IHP Open PDK `2bbec755dc67ca3db0261c3d6163e15735d66710`. The GDS and precheck jobs
passed. The gate-level runner used Python 3.11.16 and Icarus 13.0, but failed
at elaboration because `test/Makefile` omitted `sg13cmos5l_udp.v`. That source
list is corrected, and E0006 passes GDS, gate-level regression, and all nine
prechecks with the same candidate identities. Direct workflow actions and the
support-tools/LibreLane inputs are now pinned. Clean run E0010 passes the same
three gates, reproduces E0006's metrics, and has identical non-timestamp GDS
records. This snapshot is qualified for M0. The official composite action
remains a recorded transitive trust boundary.

### Qualified 8x4 experimental pilot

D35/E0031 qualifies compact10 at source
`29f4b73ae66d2b955f512b5be250f6ed0afcdab8`, run43173116485. All required
routed metrics, ten prechecks and twelve real-netlist public groups pass.
The lock records the result digest, GDS/netlist hashes and source identity;
the static repository check enforces their agreement with the evaluation contract.

The frozen flow uses action `5e7361fdc445649261c0725dc15f38242dfad330`,
support tools `9d13ff3e3e6202090740110438c6a10c1d62ca0f`, LibreLane
`3.1.0.dev4` in the recorded immutable image, and IHP Open PDK
`89d42ee6d2fd9b50b86a1aada6fee6673c3e6008`. Exact resolved inputs, timing
constraints and actual action identities are retained in
[E0031](../evidence/E0031-8x4-physical-comparison/README.md). The official
composites' internally tagged dependencies remain an observed trust boundary.

This qualifies the identified generated compact10 chip. The workflow stages
experimental sources, so it does not qualify or promote the checked-in
production core. Future integrated protocol changes need new regression and
physical evidence; the previous 6x4/M0 qualification remains separate.

## Setup limitations

When opened, signed Docker Desktop 4.92.0 works on the Windows host. The owner
clarified that it had simply been closed; no repair is claimed. E0015 qualifies
all nine local evidence stages. Native Windows `make`, Icarus and Yosys remain
absent by design; the verified container workbench provides the supported local
lane. E0007 proves the image recipe, two simulators, formal verification, and
synthesis in clean GitHub CI. E0009 proves the complete fast ladder from a fresh
Windows clone. E0010 archives the clean repository-pinned physical result. The
optional FPGA and devcontainer lanes remain unverified.
