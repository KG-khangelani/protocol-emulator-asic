# Goals to submission readiness

Updated: 2026-11-14. Decisions: [D32](decisions/0032-goals-to-submission-readiness.md), [D49](decisions/0049-freeze-g4-submission-candidate.md).
The equal engineering and owner-learning outcomes remain in [the project goal](goal.md).

Build a useful, reprogrammable chip with evidence another person can reproduce.
G1, G2 and G3 are complete. The qualified shared-protocol core now has a
verified assembler, loading plans and reproducible examples. G4 is active:
prepare the final chip release and submission package under its frozen contract.
Further instruction compression is valuable only when it improves that outcome.

## Priorities and planning targets

Dates below are internal planning targets, not measured completion promises.
The external deadline is 2027-01-18; aim to have the submission package ready on
2027-01-11, leaving a week for corrections.

| Goal | Outcome | State | Target | Existing work |
|---|---|---|---|---|
| G1 | Qualify the current physical setup and decide whether timed GPIO P is worth adopting | **COMPLETE 2026-11-12** | 2026-11-20 | M3-T01, M3-T02, M5-T01 |
| G2 | Demonstrate UART, four-mode SPI and I2C through programs on one core | **COMPLETE 2026-11-13**; qualified SRAM adopted, default CI and publication audited | 2026-12-11 | M1-T03, M2-T01, M3-T01 |
| G3 | Make programs easy to assemble, load, inspect and reproduce | **COMPLETE 2026-11-13**; clean-clone/CI qualification and alpha.7 publication verified | 2026-12-18 | M4-T01 |
| G4 | Deliver a reproducible final chip release and submission package | ACTIVE 2026-11-14; unchanged candidate, fresh physical reproduction and submission packet | Candidate freeze 2027-01-04; package 2027-01-11 | M5-T01 |
| G5 | Demonstrate one useful capability beyond the initial protocol set | CONDITIONAL experiment, after G2 | Decide by 2026-12-18 | M3-T02 |
| G6 | Make the design and its limits explainable by the owner | PARALLEL; M0 teach-back PENDING | At each milestone | M0-T01 and later learning gates |

```mermaid
flowchart LR
    G1["G1: Physical decision"] --> G2["G2: Shared-core protocols"]
    G1 --> G3["G3: Usable toolchain"]
    G2 --> G4["G4: Reproducible submission package"]
    G3 --> G4
    G2 -. bounded optional experiment .-> G5["G5: Novel capability"]
    G5 -. include only if qualified .-> G4
    G6["G6: Owner understanding"] -. alongside every milestone .-> G4
```

## G1 - Establish physical feasibility before more optimization

The official November 9 update confirms 8x4 tiles. D33 updates the checked-in
configuration and freezes the [comparison](specs/g1-cmos5l-physical-comparison.md);
D34 adds a shared correction for the measured fanout violations. D35/E0031
qualifies compact10's experimental physical pilot and rejects P's remaining
fanout failure. Historical evidence retains 6x4.
See [S1](sources.md) for the rule observation. Configuration is not qualification.

Completion checks:

- [x] Record a reviewed 8x4 configuration and immutable CMOS5L flow inputs;
  update metadata, configuration, checks and the evaluation contract together.
  Preserve the archived 6x4 source identities and results.
- [x] Compare the complete P and compact10 chips with the same library, corner,
  flow, pin assumptions and 50 MHz target. Include their real loader, stores
  and support logic; retain each variant's actual capacity.
- [x] Record mapped area, timing, storage cost and functional/formal compatibility.
  Run an official routed pilot of the selected candidate with precheck and
  appropriate gate-level public-pin tests. Report setup/hold, physical checks
  and utilization; unresolved failures remain failures.
- [x] Publish a supported adopt/reject/revise decision with source hashes and
  retained artifacts. A mapped saving alone is not a routed saving; route both
  variants before claiming a routed cost comparison.

A negative result still resolves the P decision, but physical feasibility stays
open until a candidate passes its gate. If P loses its advantage, retain the
simpler viable alternative. Revisit clock or capacity through a documented,
matched comparison instead of silently relaxing a failing condition.

**Completed 2026-11-12.** D35 selects compact10's qualified experimental pilot
and rejects P under the frozen D34 flow. Both candidates were routed with
matched conditions; their costs, capacities, compatibility and failures remain
in E0031. Compact10 passes every required routed metric, ten official prechecks
and twelve public netlist groups with 1,052 unchanged SPI records.

[Alpha.5](https://github.com/KG-khangelani/protocol-emulator-asic/releases/tag/v0.1.0-alpha.5)
publishes D35 and the original archives. All 28 release assets were downloaded
anonymously and verified, including nine original physical archives and the
curated evidence snapshot. The matching image/source identity and public
access pass; all six tag workflows pass.
[Publication verification](../evidence/E0031-8x4-physical-comparison/release-verification.json)
and the [completion audit](../evidence/E0031-8x4-physical-comparison/completion-audit.json)
record the evidence. G2 builds on this qualification; further P tuning remains deferred.

## G2 - Prove useful protocols on the same programmable machine

Activated by the owner on 2026-11-12. Commit and push cohesive verified steps
to main as work progresses. This goal includes combined protocol regression and
fresh physical qualification before production promotion; a contract or oracle
alone does not complete it.

Latest checkpoint: E0045's D47 run at `94a3082` passes GDS, all ten prechecks
and all eighteen public-netlist groups. Windows/native replays verify 1,713
original files and 55 producing inputs; five corruption controls are rejected.
UI0002 preserves the pre-adoption atlas checks. D48 now adopts all twenty exact
physical inputs; 127 repository tests, style, generic synthesis, exact physical
regeneration and 23 data/fifteen browser tests pass locally. Clean actual-
default-command run43361418837 passes all eight stages at 75c1e7d; its original
1,922 files, 329 producing inputs and frozen Linux replay pass audit. Milestone
publication is now verified: alpha.6 has 28 anonymously checked assets,
1,369 curated files identical to the release commit, matching public image
identity and all eight tag workflows passing.

**Completed 2026-11-13.** The [completion audit](../evidence/E0045-g2-sram-qualification/completion-audit.json)
maps every requirement and all nine mandatory workloads to retained evidence.
G3 is now complete in E0046; the owner-learning gate remains separate.

The following paragraphs retain earlier checkpoints and their then-open gates;
the latest checkpoint above gives the current status.

The [frozen I2C contract](specs/p-i2c-controller-100k.md) and D36/E0032 independent
oracle pass 19 groups with 3,902 reference/control observations. This includes
all bytes, ordinary addresses, stretching, final-edge priority and bounded
cleanup. It qualifies no RTL; compact10 remains the integration baseline.

E0033 measures ten identical public records per simulator on unchanged compact10:
bounded inline cleanup fits ten words, waits inside LOOP retain held-SDA faults,
and a literal write-wire list needs 122 words against a real ten-word store.
These are scoped kernels and a capacity screen, not complete I2C transactions.

E0034 confirms nine-word existing SHIFT_STEP receive reuse, with 268 identical
records per simulator (all bytes, eight stretch positions, four negatives).
The measured 98,619.329 Hz kernel has no full I2C framing/cleanup qualification.

D37/E0035 advances experimental od128: 96 words for combined write/read versus
211 literal words, with actual 128/255-word stores. Both simulators agree on
1,160 od128 I2C records and the twelve existing public kernel/UART/SPI groups;
all 1,052 SPI records match compact10. Current boundaries, scoped instruction
proofs and cleanup equivalence pass. The initial whole-memory induction
timeouts remain inconclusive. E0036 closes the 31ebf82 CI audit with all three G2 jobs and
verified archive/source identities; both candidates pass the full I2C matrix
in both simulators. Its complete partitioned store proofs now pass every word's
transition/read relation and common controls (652/1,287 assertions), with
checked reset-reachable mutations. The exact eighteen-group selection passes
both simulators at e2ff52e. literal255 fails fixed-footprint placement at
111.564% adjusted utilization. od128 maps to 39,806 cells / 564,744.3984 square
micrometres, then fails global routing with GRT-0228 congestion; dependent
precheck/netlist jobs are skipped. E0036 retains the verified failure.
All five d3c340f CI gates and their downloaded artifacts are now audited,
including a complete 100-task store run with both variants and checked controls.

That checkpoint led to G3's usable program toolchain, completed below.
The historical checkpoints below retain their original conditions and failures.
Run43348171110 at clean 94a3082 now passes the complete physical audit.
D47's earlier 191-file report/native/pin-checker replays,
four native fault controls, two staging controls and 118 repository tests pass.
The original checker rejects the old export and accepts the repaired one;
all wires and signal pins remain identical and both grids pass. Run43337581691 at 232ee20 passes
the full corrected manufacturing build and nine prechecks, but fails the
power-port check with 148 LEF errors. Its 1,216 original files and 52 producing
inputs pass Windows/native replay; aggregate qualification rejects the run.
The completed official netlist job passes all eighteen groups and exact
records; its 477 additional original files pass Windows/native replay. Both
local simulators also pass the identical corrected netlist in
3,682.630/5,393.933 seconds. Its 1,246-file replay retains 194 frozen inputs
and the qualified reset-model probe. Production remains unchanged. Earlier guarded
run43320295442 at 2be7f5d is rejected with 36 Magic contact findings; all other
final physical conditions pass. Its 1,027 original files and 42 frozen inputs
pass audit. Geometry resolves the findings to the same 32 isolated contact
locations and matches local trial 05 on all 28 layers. The local identical trial 03
netlist pair now passes all eighteen groups and every reference record; its
1,145-file replay passes while preserving that layout's physical rejection.
Complete normal `sram-current`
CI now passes at 13660ac/run43309369604: all eight stages, the historical
baseline and two fresh 116-check executions. The original 1,928-file ZIP,
295 exact inputs and producing runtime pass audit and retained Linux replay.
D44/E0044's earlier local historical timeout at its unchanged 300-second
limit remains incomplete in the 2,154-file preparation replay. D45's original
961-file failure replay and 342-file diagnostic replay pass; native replay
rejects the old pin geometry and passes all 43 corrected pins and both grids.
The fresh guarded full run retains every original physical gate.
Portable guarded staging reproduces the same database in 41.669 seconds;
its 369-file archive, native replay and eight bad-configuration controls pass.
The official workflow now stages this setup for fresh complete qualification.
The bounded native LVS diagnostic and its 137-file replay pass: 4,717 nets,
4,684 devices and all 45 top-level pins match; routed pin geometry also passes.
The corrected GDS also passes the complete KLayout rule-deck diagnostic,
with 332 report categories and zero violations; both retained audits pass.
Magic DRC and fresh official qualification remain open; run43320295442 is
retained as rejected, with its dependent precheck/netlist jobs skipped.
D46's scoped contact-rule correction now clears all 32 isolated-macro
findings. Actual geometry, 48 boundary cases and the 111-file native replay
pass; complete corrected full-layout checks and fresh qualification remain
required. The original official result and geometric match now justify the
rehearsed correction's use in a new official run. Production is unchanged.
Portable alignment passes its 396-file native replay, twelve configuration
controls and three changed-input controls. Both one-hour whole-layout
follow-ups time out without a report; their 17-file replay preserves this.
The original 20-minute attempts remain incomplete. Native full trial 05
completes within its 10,800-second limit with the same 36-finding failure;
its 927-file replay passes. Both simulators are testing the corrected routed
netlist with frozen inputs and the previously qualified model setup.
Fresh official run43337581691's manufacturing pass and power-port rejection
are described above. E0044's later
physical-baseline relocation preserves all nine configuration/source profiles;
its 358-file replay and 118 repository tests pass. Production stays unchanged.
The
buffered run clears all extracted electrical limits and has positive setup/hold
margins at all three declared model sets. Portable staging reproduces the exact
power database; six corruption controls and its 742-file retained replay pass.
Clean SRAM CI
and its 1,359-file semantic/source/runtime replay pass. The two explicit D43
power stages pass a fresh 31.625-second pilot with the exact repaired database;
all 80 original stages remain in order. The
first two full trials clear routing but fail nine extracted SRAM-input slew
limits and are retained as rejected. Nine local buffers clear fresh typical
estimated violations and preserve actual connectivity; two rewired controls
are caught. The 1,744-file electrical-trial replay passes. The
native power trial fails, but 144 short edge connections pass both fresh grids
and the exact-database replay. The complete 30-group simulator pair
and exact records pass; matched mapped footprint is 78.5306% below D39,
including the actual macro. The retained regression and mapped replays pass.
D42 declares clocked program-byte readback as interface 0x22; instruction
timing, logical capacity and the UART/SPI/I2C expectations remain unchanged.
Preserve the pinned 8x4 limits, G1's pilot and all rejected trials. Integration
and publication remain required.

D38/E0037 now qualifies that rewrite locally: all 652 store assertions,
checked controls and both simulators' eighteen public groups pass; all required
reference records are identical. The retained evidence replay and physical
staging preflight pass. All seven e5eef5b CI jobs pass and both new-candidate
archives are audited. Physical run43241097269 at 869ee34 fails global routing
with GRT-0228 congestion. Its 40,242 mapped cells / 561,244.4208 square
micrometres save only 0.620% mapped area versus original od128; precheck and
netlist jobs are skipped. E0037 retains the verified failure. A separate shared-read screen saves 37.64%
generic cells from D38 with reset-reachable complete-chip equivalence, but
the physical gate remains. D39/E0038 reproduces that source; fresh whole-chip
proof/reset and all three read-path mutation controls pass in both simulators.
Both simulators pass all eighteen public groups with identical reference
records; retained replay, ten audit-corruption controls and staging preflight
pass. All nine b774915 CI jobs pass and both new-candidate ZIPs are audited.
Physical run43249867361 at 426cea1 maps to 34,683 cells / 477,788.2578 square
micrometres, 15.3974% below original od128, but fails GRT-0228 global routing.
The original archives, runtime/source/fixed-condition audit and failure are
retained in E0038. Dependent precheck/netlist jobs are skipped. The isolated
default-integration probe exposes four obsolete test expectations; those must
be handled explicitly before production promotion and publication.

D40/E0039 now handles those expectations through an explicit source profile:
30 groups pass in each simulator, while all 22 original groups still pass on
the historical source. Initial current and complete historical formal runs
pass. The later normal-command temporal proof reaches its 300-second wall
limit; seven other stages pass, with no aggregate PASS. The 1,717-file replay
preserves this distinction. A reproduced metadata-cache omission is fixed by
running repository checks fresh; all 114 checks pass. Complete current-command
CI passes at 8488738/run43267588725; its original 1,532-file ZIP and 250 exact
inputs are audited with all eight stages passing. Physical acceptance remains open.

D41/E0040 retains a complete-store-equivalent banked read with passing
reset and both simulators' port/mutation controls. Generic cells increase
2.5113% with the same real storage. A matched pinned mapping reproduces D39's
parent cost exactly and finds 5.20216% more area for the banked candidate; set
it aside without routing. E0041 retains the clock-spacing diagnostic's first
1,200-second timeout at iteration 40/50. Its separately declared 2,400-second
follow-up changes the same sixteen assignments on a copied database and
completes with 159,781 overflow / 152.09% Metal3 usage. Stop this branch and
investigate the PDK's SRAM under an explicit loading/fetch contract. Subsequent
functional/formal and physical qualification remain required before adoption.

D42/E0042 now passes the isolated engine/store screen. All 128 engine state
bits and 128 original outputs pass compositional equivalence and reset; both
whole-chip 120-second timeouts remain retained. The complete vendor memory
passes arbitrary-word induction, four coverage witnesses and a checked
partial-mask fault. Both simulators pass store-port checks and all four
deliberate fault controls; the historical 22-group suites remain passing.
The retained screen replay passes. Both simulators now pass all 30 SRAM groups
with exact reference records and the 44-byte bank control; the 994-file replay
passes. Matched mapping reproduces D39 exactly and measures 102,578.259 total
square micrometres including SRAM, 78.5306% lower. The actual mapped netlist
has one macro and 353 flip-flops; its 144-file replay passes. No routed/timing,
precheck or real-netlist acceptance is claimed yet.

Completion checks:

- [x] Freeze the I2C controller contract and independent oracle before extending
  the ISA. Cover 100 kHz operation, 7-bit addressing, write/read, repeated START,
  ACK/NACK, open-drain release, clock stretching and bounded timeout.
- [x] Pass the [mandatory workload matrix](research/evaluation-contract.md) on
  one candidate revision: pin traces, input wait, shifting, bounded loops,
  public-pin reload, UART TX/RX, four-mode SPI and I2C.
- [x] Retain UART framing/phase/error and host-service boundaries. State which
  received bytes are available and when; continuous autonomous delivery remains
  unqualified until separately implemented and tested.
- [x] Check both SPI bit orders and all four modes with explicit input timing
  assumptions. Preserve held-response successes and edge-only negative controls.
  Do not advertise broad SPI compatibility from a narrower input contract.
- [x] Load the different protocol programs through public pins without changing
  the RTL. Pass both simulators, relevant formal properties and meaningful
  wrong-program/adversarial-input controls; retain seeds and counterexamples.
- [x] Promote the chosen candidate only with the combined regression and fresh
  physical evidence for that revision. Earlier isolated or M0 results do not
  qualify the promoted chip.

The checked functional/formal requirements began with E0035/E0036 and are now
reproduced on the exact E0042 SRAM source, with E0044's complete normal-command
audit and E0045's fresh physical qualification. The stated protocol limits
remain. D48 adopts the exact qualified files; clean full default-command CI and
its retained replay pass. Alpha.6 publication, downloads, exact image/source
identity and all tag workflows are verified. G2 is complete within these limits.

A protocol that needs a new dedicated RTL path falsifies the current flexibility
hypothesis. First test whether a general instruction or a stated scope change
resolves it, with a measured cost and an explicit decision.

## G3 - Make the chip practical to program

Activated 2026-11-13 after G2 completion. The [toolchain contract](specs/g3-program-toolchain.md)
targets the unchanged qualified `od128-sram` core and interface 0x22. Preserve
all twenty physical inputs and historical program bytes. Commit verified steps
to main; the first deliverable is a versioned assembler and inspectable listing.

Local implementation passes: thirteen examples match the frozen G2 words,
both simulators agree on all 55 public cases (15 expected rejections), and 53
generated files match between Windows and Linux. [E0046](../evidence/E0046-program-toolchain/README.md)
retains the original outputs and all 147 passing repository tests. Clean
clone and Windows/Linux CI at `0297655` now pass; their original records,
351 producing inputs and all artifact/trace identities pass the retained audit.
**Completed 2026-11-13.** All four engineering checks below pass.
[Alpha.7](https://github.com/KG-khangelani/protocol-emulator-asic/releases/tag/v0.1.0-alpha.7)
has 23 anonymously verified assets, 73 verified toolchain bundle members and a
matching public image; all nine tag workflows and their 22 jobs pass. Windows
and Linux produce identical packages, and the standalone distribution rebuilds
all thirteen examples. The [completion audit](../evidence/E0046-program-toolchain/completion-audit.json)
maps every requirement to retained evidence. G4 remains queued; owner fluency
and all original hardware/protocol limits are unchanged.

Completion checks:

- [x] Provide a small assembler with readable instructions, symbols, capacity
  checks, deterministic encoding and useful invalid-program diagnostics.
- [x] Emit a cycle/schedule listing that makes timing assumptions inspectable.
- [x] Provide documented load, readback and run steps, plus versioned UART, SPI
  and I2C examples for the selected ISA.
- [x] From a clean clone, build the examples and reproduce their public-pin
  traces using the pinned workbench and the independent oracle.

Start with an assembler. Build a larger temporal IR/compiler only if a concrete
programming problem justifies it. Compatibility changes need an ISA version and
migration note, not silently changed example bytes.

## G4 - Close and publish the final design

Activated by the owner on 2026-11-14. [D49](decisions/0049-freeze-g4-submission-candidate.md)
and the [acceptance contract](specs/g4-submission-candidate.md) freeze the exact
qualified core before two clean official runs. E0047 records their original
archives, reproduction, current documentation and verified final package.
Commit and push cohesive verified steps throughout. Actual submission and
owner fluency remain separate.

Completion checks:

- [ ] Freeze a candidate by January 4 and run the official 8x4 CMOS5L GDS flow,
  timing checks, precheck and real netlist simulation for the final core.
  Gate-level tests must exercise the actual public loading/protocol paths.
- [ ] Reproduce the result from a clean checkout with pinned tools. Retain source
  revisions, commands, timing/area reports, checksums and relevant failures.
- [ ] Publish the final verified release and matching workbench package; verify
  download checksums, image/source identity and public access. Update research
  releases after qualified milestones; a planning-only change needs no release.
- [ ] Prepare a readable architecture/ISA guide, examples, verification and
  AI-use account, measured tradeoffs, external host/electrical assumptions and
  unresolved limitations. Every positive claim points to evidence.
- [ ] Recheck submission rules and assemble the ready-to-submit repository link
  and supporting material by January 11.

This goal ends at submission readiness. Actual competition submission, hardware
spending and fabricated-silicon results remain separate owner decisions.
If a required gate is still failing, report that gap and revise scope explicitly.

## G5 - Reserve a bounded opportunity for a useful breakthrough

Default experiment: use firmware alone to replay an irregular digital waveform
or inject a controlled timing fault. This tests whether the same substrate is
useful beyond the protocols used to design it.

- [ ] Before running, choose one use case, a control program, expected pin trace,
  measurement and a two-working-day total investigation budget.
- [ ] Demonstrate it through public-pin-loaded programs with zero new RTL, an
  independent trace check, and explicit timing/input limits.
- [ ] Keep a successful example and explain its value; retain a failed result
  and stop if the budget expires or mandatory closure slips.

Only start after G2 passes. Decide by December 18; defer if prerequisites are
late. This experiment is optional and does not delay G4. Storage macros or a
different substrate become candidates only if measured area/timing identifies
the corresponding bottleneck. USB/Ethernet, extra engines and further packing
are deferred unless new evidence materially changes the plan.

## G6 - Build independent understanding alongside the chip

At each milestone, use the [learning loop](goal.md) and record only demonstrated
fluency:

- [ ] The owner can trace a program from source to pin events and distinguish a
  simulation result, a formal claim, mapped area and routed timing.
- [ ] The owner can rerun one relevant check, predict a small change, inspect the
  outcome and explain a retained failure or assumption.
- [ ] The owner can explain the chosen architecture, the rejected alternative,
  its limits and the final release's provenance in plain language.

Automation may prepare lessons and validate records. Only the owner's
explanation and follow-up reasoning can satisfy these checks. Pending fluency
does not stop engineering under [D8](decisions/0008-decouple-engineering-learning.md).

## Keeping the goals honest

Keep one active engineering goal. Within it, use one bounded experiment with a
question, frozen conditions, success/failure criteria and retained artifacts.
After each milestone or a material failure, update this file, [state](state.md),
the [backlog](backlog.md) and the [research ledger](research-ledger.md).
Reassess dates and priority when evidence changes; do not convert a missed gate
into a pass. This plan itself supplies no new hardware qualification.
