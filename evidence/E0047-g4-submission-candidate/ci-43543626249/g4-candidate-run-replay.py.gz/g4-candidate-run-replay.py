"""Capture one candidate replay's exact invocation and runtime identity."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
IMAGE = 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
DIGEST = IMAGE.split('@', 1)[1]
VERIFY = 'evidence/E0047-g4-submission-candidate/ci-43543626249/verify.py'
parser = argparse.ArgumentParser()
parser.add_argument('host', choices=('windows', 'linux'))
args = parser.parse_args()
assert ROOT == Path(r'H:\hikrepos\protocol-emulator-asic')
out = ROOT / ('build/g4-candidate-' + args.host)
assert not out.exists()
prefix = ROOT / ('build/g4-candidate-' + args.host)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
version_code = 'import json,platform,sys;print(json.dumps(dict(python=sys.version,platform=platform.platform(),machine=platform.machine())))'
if args.host == 'windows':
    runtime = {'python': sys.version, 'platform': platform.platform(), 'machine': platform.machine()}
    command = [sys.executable, VERIFY, '--output', str(out), '--controls']
else:
    inspected = json.loads(subprocess.check_output(['docker', 'image', 'inspect', IMAGE], cwd=ROOT, env=env))
    assert len(inspected) == 1
    image = inspected[0]
    assert image['Id'] == DIGEST and IMAGE in image['RepoDigests']
    docker = ['docker', 'run', '--rm', '--pull=never', '--init', '--env', 'HOME=/tmp',
              '--env', 'PYTHONDONTWRITEBYTECODE=1', '--mount',
              'type=bind,source=' + str(ROOT) + ',target=/workspace', '--workdir', '/workspace', IMAGE]
    runtime = json.loads(subprocess.check_output(docker + ['python3', '-c', version_code], cwd=ROOT, env=env))
    runtime['container_image'] = {k: image[k] for k in ('Id', 'RepoDigests', 'Os', 'Architecture')}
    command = docker + ['python3', VERIFY, '--output', '/workspace/build/g4-candidate-linux']
started = datetime.now(timezone.utc).isoformat()
free_before = shutil.disk_usage(ROOT).free
print('CANDIDATE_REPLAY_START', args.host, 'H_FREE_BYTES', free_before, flush=True)
completed = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
free_after = shutil.disk_usage(ROOT).free
log = completed.stdout + completed.stderr
log_path = prefix.with_name(prefix.name + '-replay.log')
log_path.write_bytes(log)
receipt = {'schema': 'protocol-emulator-g4-physical-replay-invocation-v1',
           'run_id': 43543626249, 'host': args.host, 'started_utc': started,
           'completed_utc': datetime.now(timezone.utc).isoformat(),
           'command': command, 'working_directory': str(ROOT), 'runtime': runtime,
           'returncode': completed.returncode, 'log_sha256': sha(log),
           'disk_free_before_bytes': free_before, 'disk_free_after_bytes': free_after,
           'runner_sha256': sha(Path(__file__).read_bytes()),
           'verify_sha256': sha((ROOT / VERIFY).read_bytes())}
verification = out / 'verification.json'
if verification.exists():
    receipt['verification_sha256'] = sha(verification.read_bytes())
prefix.with_name(prefix.name + '-invocation.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(log.decode('utf-8', errors='replace'), end='', flush=True)
print('CANDIDATE_REPLAY_RETURN', args.host, completed.returncode, flush=True)
print('H_FREE_BYTES', free_after, flush=True)
sys.exit(completed.returncode)
