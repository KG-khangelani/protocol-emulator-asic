"""Curate the candidate's completed platform replays and seal all retained files."""
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'evidence/E0047-g4-submission-candidate/ci-43543626249'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
result = read(HERE / 'result.json')
assert result['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES'
assert result['run_id'] == 43543626249
assert result['source_commit'] == '45c55f7cd95db2a883b0ffb5e864decd62d53601'
run, jobs = (read(HERE / name) for name in ('run.json', 'jobs.json'))
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['run_attempt'] == 1
assert len(jobs['jobs']) == 3 and all(j['conclusion'] == 'success' for j in jobs['jobs'])
old_seal = (HERE / 'SHA256SUMS').read_bytes()
old_files = {name: digest for digest, name in
             (line.split('  ', 1) for line in old_seal.decode().splitlines())}
assert len(old_files) == 42
for name, digest in old_files.items():
    assert sha((HERE / name).read_bytes()) == digest, name
windows = read(HERE / 'verification-windows.json')
assert windows['status'] == 'PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION'
assert windows['run_id'] == result['run_id'] and windows['source_commit'] == result['source_commit']
assert windows['controls_executed'] is True
windows_invocation = read(HERE / 'invocation-windows.json')
assert windows_invocation['returncode'] == 0
assert windows_invocation['log_sha256'] == sha(gzip.decompress((HERE / 'replay-windows.log.gz').read_bytes()))
assert windows_invocation['verification_sha256'] == sha((HERE / 'verification-windows.json').read_bytes())
assert windows_invocation['verify_sha256'] == sha((HERE / 'verify.py').read_bytes())
assert windows_invocation['runner_sha256'] == sha(gzip.decompress((HERE / 'g4-candidate-run-replay.py.gz').read_bytes()))
controls = read(HERE / 'controls-result.json')
assert controls['status'] == 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS'
assert len(controls['cases']) == 9
assert controls['run_id'] == result['run_id']
assert controls['audit_sha256'] == sha((HERE / 'audit.py').read_bytes())
assert controls['runner_sha256'] == sha((HERE / 'controls.py').read_bytes())
assert controls['baseline_result_sha256'] == sha((HERE / 'result.json').read_bytes())
for case in controls['cases']:
    assert case['status'] == 'PASS_REJECTED_CORRUPTION'
    raw = gzip.decompress((HERE / 'controls-logs' / (case['name'] + '.log.gz')).read_bytes())
    assert sha(raw) == case['log_sha256']

common = HERE.parent / 'linux-ci-43554467650'
extracted = ROOT / 'build/g4-linux-physical-proof/files/ci-43543626249'
for line in (common / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    assert sha((common / name).read_bytes()) == digest, name
proof, summary, source = (read(common / name) for name in ('verification.json', 'run-summary.json', 'source.json'))
assert proof['status'] == 'PASS_RETAINED_G4_LINUX_CI_PROOF'
assert (proof['run_id'], proof['job_id'], proof['artifact_id']) == (43554467650, 132324068684, 14098180180)
assert proof['source_commit'] == source['source_commit'] == summary['source_commit'] == '7b73d99fbf300c1041aa930409ea63fc031d20f4'
assert summary['status'] == 'PASS_G4_LINUX_PHYSICAL_REPLAYS'
candidate = summary['runs']['candidate']
assert candidate['run_id'] == result['run_id'] and candidate['physical_source_commit'] == result['source_commit']
assert candidate['retained_seal_sha256'] == sha(old_seal)
assert candidate['result_sha256'] == sha((HERE / 'result.json').read_bytes())
assert candidate['retained_verify_sha256'] == sha((HERE / 'verify.py').read_bytes())
assert candidate['full_audit_result_identical_to_retained'] is True
assert candidate['verification_matches_retained_windows_except_controls_flag'] is True
assert candidate['controls_executed'] is False
for name, digest in source['files_sha256'].items():
    assert sha((common / 'source' / name).read_bytes()) == digest
archive_path = common / (str(proof['artifact_id']) + '.zip')
assert sha(archive_path.read_bytes()) == proof['artifact_sha256']
index = read(common / 'zip-files.json')
assert len(index) == proof['original_archive_files'] == 33
members = {}
with zipfile.ZipFile(archive_path) as archive:
    for name in ('verification.json', 'invocation-linux.json', 'replay-linux.log.gz', 'audit/result.json'):
        member = 'ci-43543626249/' + name
        raw = archive.read(member)
        identity = {'bytes': len(raw), 'sha256': sha(raw)}
        assert identity == index[member] == summary['files'][member]
        assert raw == (extracted / name).read_bytes(), member
        members[name] = raw
assert members['audit/result.json'] == (HERE / 'result.json').read_bytes()
linux = json.loads(members['verification.json'])
assert linux['status'] == 'PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION'
assert linux['controls_executed'] is False
invocation = json.loads(members['invocation-linux.json'])
assert invocation['run_id'] == result['run_id'] and invocation['host'] == 'linux' and invocation['role'] == 'candidate'
assert invocation['returncode'] == 0
assert invocation['compressed_log_sha256'] == sha(members['replay-linux.log.gz'])
assert invocation['log_sha256'] == sha(gzip.decompress(members['replay-linux.log.gz']))
assert invocation['verification_sha256'] == sha(members['verification.json']) == candidate['verification_sha256']
assert invocation['verify_sha256'] == candidate['retained_verify_sha256']
assert invocation['result_sha256'] == candidate['result_sha256']
assert invocation['runner_sha256'] == source['files_sha256']['.github/g4-linux-verification/run.py'] == summary['runner_sha256']
assert invocation['ci_execution'] == summary['ci_execution']
assert invocation['ci_execution']['run_id'] == str(proof['run_id']) and invocation['ci_execution']['run_attempt'] == '1'
assert invocation['physical_source_commit'] == result['source_commit']
assert invocation['runtime'] == summary['runtime']
image = 'ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307'
config = 'sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451'
assert invocation['runtime']['image_reference'] == proof['image'] == image
assert invocation['runtime']['container_image']['Id'] == proof['config_digest'] == config
assert image in invocation['runtime']['container_image']['RepoDigests']
assert invocation['command'][0:2] == ['docker', 'run'] and image in invocation['command']
assert all(flag in invocation['command'] for flag in ('--pull=never', '--network=none'))
assert summary['public_image_binding']['image'] == image and summary['public_image_binding']['config_digest'] == config
assert sha((ROOT / summary['public_image_binding']['record']).read_bytes()) == summary['public_image_binding']['record_sha256']
assert {k:v for k,v in windows.items() if k != 'controls_executed'} == {k:v for k,v in linux.items() if k != 'controls_executed'}
copies = {'verification-linux.json': 'verification.json', 'invocation-linux.json': 'invocation-linux.json',
          'replay-linux.log.gz': 'replay-linux.log.gz'}
for destination, name in copies.items():
    target = HERE / destination
    assert not target.exists() or target.read_bytes() == members[name]
    target.write_bytes(members[name])
record_binding = lambda path: {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path.read_bytes())}
binding = {'schema': 'protocol-emulator-g4-remote-linux-binding-v1',
           'status': 'PASS_BOUND_RETAINED_REMOTE_LINUX_REPLAY',
           'physical_run_id': result['run_id'], 'physical_source_commit': result['source_commit'],
           'ci_run_id': proof['run_id'], 'ci_job_id': proof['job_id'], 'ci_source_commit': proof['source_commit'],
           'artifact_id': proof['artifact_id'], 'original_archive': record_binding(archive_path),
           'proof_record': record_binding(common / 'verification.json'),
           'source_record': record_binding(common / 'source.json'),
           'run_summary': record_binding(common / 'run-summary.json'),
           'image_reference': image, 'image_config_digest': config,
           'pre_linux_retained_seal_sha256': sha(old_seal),
           'physical_result_sha256': candidate['result_sha256'],
           'copied_members': {destination: {'archive_member': 'ci-43543626249/' + name,
                              'bytes': len(members[name]), 'sha256': sha(members[name])}
                              for destination, name in copies.items()},
           'scope': 'Original successful GitHub Linux replay, copied without byte conversion. Windows and physical evidence remain unchanged; no local Docker recovery is claimed.'}
(HERE / 'linux-ci-binding.json').write_bytes((json.dumps(binding, indent=2) + '\n').encode())
(HERE / 'g4-candidate-finalize.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
flow = result['flow_execution']
metrics = result['physical_metrics']['checked']
area = result['area']
records = result['netlist_tests']['records']
assert result['precheck']['test_count'] == 10 and result['netlist_tests']['public_test_groups'] == 18
assert len(result['production']['files_sha256']) == 20
assert result['uart_landmarks']['count'] == 97
assert {k:v['count'] for k,v in records.items()} == {
    'spi/cases.jsonl': 1052, 'i2c/cases.jsonl': 1160, 'i2c/boundaries.jsonl': 4, 'i2c/aborts.jsonl': 36}
lines = [
    '# G4 candidate: complete official qualification',
    '',
    'Run [43543626249](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/43543626249)',
    'completed all three production workflow jobs successfully on 2026-11-14.',
    'Source: `' + result['source_commit'] + '`, attempt 1.',
    'This is the first of the two predeclared clean G4 runs under D49.',
    '',
    '`result.json` reports `PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES`.',
    'All six original archives pass their API sizes and SHA-256 digests; every',
    'one of their ' + str(windows['original_archive_files']) + ' file members is indexed in `zip-files.json`.',
    'The sealed producer contains ' + str(windows['producing_inputs']) + ' exact files. The frozen production',
    'guard verifies all twenty adopted physical inputs and their original G2 references.',
    '',
    '| Check | Observed result |',
    '|---|---|',
    '| Configured construction/check stages | ' + str(flow['configured_stages']) + ' |',
    '| Executed top-level stages | ' + str(flow['executed_top_level']) + ' |',
    '| Nested antenna substages | ' + str(flow['nested_stages']) + ' |',
    '| Frozen gate-disabled stages | ' + str(flow['gated_skips']) + ' |',
    '| Official prechecks | 10 passed; none skipped |',
    '| Actual-netlist public groups | 18 passed; none of the required groups skipped |',
    '| Setup / hold slack at 20 ns | ' + str(metrics['timing__setup__ws']) + ' / ' + str(metrics['timing__hold__ws']) + ' ns |',
    '| Mapped total cells / standard-cell area | ' + str(area['mapped']['cells']) + ' / ' + str(area['mapped']['area_um2']) + ' um2 |',
    '| Routed standard cells / area | ' + str(area['routed']['design__instance__count__stdcell']) + ' / ' + str(area['routed']['design__instance__area__stdcell']) + ' um2 |',
    '| Public records | 1,052 SPI; 1,160 I2C; 4 boundary; 36 abort |',
    '',
    'The mapped total includes one SRAM macro; its area is unknown to the',
    'synthesis report and is excluded from that mapped area. The physical macro',
    'area is audited separately as 49,488.4992 um2.',
    '',
    'All audited routing, antenna, DRC, LVS, power-grid, fanout, capacitance and',
    'slew violation counts are zero. The actual producer/consumer logs bind the',
    'submitted GDS/netlist, runtime/PDK identity and macro models.',
    '',
    'Raw GDS SHA-256: `' + result['gds_sha256'] + '`.',
    'Netlist SHA-256: `' + result['netlist_sha256'] + '`.',
    '',
    'Both retained replays return `PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION`.',
    'Windows runs all nine deliberate corruption controls; every corruption',
    'is rejected with its expected error. Controls include rehashed semantic',
    'changes to production identity, stage configuration/skip, power-port count,',
    'required test execution and submitted netlist, plus incomplete workflow,',
    'wrong archive digest and wrong job source.',
    '',
    'The Linux replay ran in isolated [CI run 43554467650](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/43554467650),',
    'job `132324068684`, at source `7b73d99fbf300c1041aa930409ea63fc031d20f4`.',
    'The runner pulled the previously verified public alpha.7 workbench image:',
    '`' + image + '`.',
    'Its actual configuration/image ID was `' + config + '`.',
    'The replay used `--pull=never` and `--network=none`; its source checkout',
    'was mounted read-only with a separate writable replay output directory.',
    '',
    'The [common Linux proof](../linux-ci-43554467650/README.md) retains the',
    'original 33-member archive `14098180180.zip`, completed job log, API',
    'observations, frozen workflow/runner source and image inspection records.',
    '`linux-ci-binding.json` binds this candidate to that original proof and',
    'the three copied Linux members. Their bytes are unchanged, including the',
    'compressed raw log. `invocation-linux.json` is the actual CI receipt.',
    'The independent Windows invocation and all nine control records are',
    'preserved unchanged. This record makes no claim of local Docker recovery.',
    '',
    'From the repository root, use a fresh output directory:',
    '',
    '```text',
    'python evidence/E0047-g4-submission-candidate/ci-43543626249/verify.py --output build/g4-candidate-replay --controls',
    '```',
    '',
    'The replay reconstructs the original ZIPs, verifies every original member',
    'and the sealed producer, and requires the full semantic audit result to',
    'equal the retained record. It audits archived evidence rather than running',
    'a new physical build. The independently dispatched second run and geometry',
    'comparison are recorded separately by E0047.',
    '',
    'Public netlist testing is functional zero-delay simulation. Seven UART',
    'groups execute assertions; the retained comparison data contain 96 RX',
    'landmarks and one late-reader landmark, not complete UART TX waveforms.',
    'The fast model set combines -40 C standard cells and -55 C SRAM. These',
    'results do not measure silicon, isothermal characterization or maximum clock frequency.',
    '',
    'The optional rendering archive is outside this six-archive qualification.',
    '`SHA256SUMS` covers every curated retained file except itself.',
    ''
]
(HERE / 'README.md').write_bytes('\n'.join(lines).encode())
for name, digest in old_files.items():
    assert sha((HERE / name).read_bytes()) == digest, 'changed earlier retained file: ' + name
files = sorted(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name != 'SHA256SUMS')
seal = ''.join(sha(p.read_bytes()) + '  ' + p.relative_to(HERE).as_posix() + '\n' for p in files)
(HERE / 'SHA256SUMS').write_bytes(seal.encode())
print('SEALED_G4_CANDIDATE', len(files), windows['original_archive_files'], windows['producing_inputs'], len(controls['cases']))
