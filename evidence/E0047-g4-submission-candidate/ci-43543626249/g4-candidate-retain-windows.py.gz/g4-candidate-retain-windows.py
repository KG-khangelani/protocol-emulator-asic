"""Retain the completed Windows replay while Linux startup remains pending."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'evidence/E0047-g4-submission-candidate/ci-43543626249'
BASE = ROOT / 'build/g4-candidate-windows'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
verification = read(BASE / 'verification.json')
assert verification['status'] == 'PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION'
assert verification['run_id'] == 43543626249 and verification['controls_executed'] is True
invocation_path = ROOT / 'build/g4-candidate-windows-invocation.json'
invocation = read(invocation_path)
log = (ROOT / 'build/g4-candidate-windows-replay.log').read_bytes()
assert invocation['returncode'] == 0 and invocation['log_sha256'] == sha(log)
assert invocation['verification_sha256'] == sha((BASE / 'verification.json').read_bytes())
assert invocation['verify_sha256'] == sha((HERE / 'verify.py').read_bytes())
assert invocation['runner_sha256'] == sha((ROOT / 'build/g4-candidate-run-replay.py').read_bytes())
shutil.copyfile(BASE / 'verification.json', HERE / 'verification-windows.json')
shutil.copyfile(invocation_path, HERE / 'invocation-windows.json')
(HERE / 'replay-windows.log.gz').write_bytes(gzip.compress(log, mtime=0))
controls = read(BASE / 'controls/result.json')
assert controls['status'] == 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS'
assert len(controls['cases']) == 9 and controls['run_id'] == 43543626249
assert controls['audit_sha256'] == sha((HERE / 'audit.py').read_bytes())
assert controls['runner_sha256'] == sha((HERE / 'controls.py').read_bytes())
assert controls['baseline_result_sha256'] == sha((HERE / 'result.json').read_bytes())
shutil.copyfile(BASE / 'controls/result.json', HERE / 'controls-result.json')
(HERE / 'controls-logs').mkdir()
for case in controls['cases']:
    assert case['status'] == 'PASS_REJECTED_CORRUPTION'
    raw = (BASE / 'controls' / case['name'] / 'audit.log').read_bytes()
    assert case['log_sha256'] == sha(raw)
    (HERE / 'controls-logs' / (case['name'] + '.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
for name in ('g4-candidate-run-replay.py', 'g4-candidate-retain-windows.py'):
    (HERE / (name + '.gz')).write_bytes(gzip.compress((ROOT / 'build' / name).read_bytes(), mtime=0))
files = sorted(p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name != 'SHA256SUMS')
(HERE / 'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes()) + '  ' + p.relative_to(HERE).as_posix() + '\n' for p in files).encode())
print('RETAINED_WINDOWS_PASS_LINUX_PENDING', len(files), len(controls['cases']))
