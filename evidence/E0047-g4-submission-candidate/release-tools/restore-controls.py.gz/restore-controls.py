import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / 'evidence/E0047-g4-submission-candidate/release-tools/package.py'
spec = importlib.util.spec_from_file_location('g4_package_controls', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out = ROOT / ('build/g4-package-restore-controls-' + hashlib.sha256(path.read_bytes()).hexdigest()[:12])
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_STORED) as archive:
    entry = zipfile.ZipInfo('example.bin', date_time=(1980, 1, 1, 0, 0, 0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    archive.writestr(entry, bytes(range(256)))
original = buffer.getvalue()
pieces = (original[:127], original[127:])
storage = [{'path': 'evidence/E0047-g4-submission-candidate/ci-1/1.zip.part' + str(i),
            'bytes': len(raw), 'sha256': sha(raw)} for i,raw in enumerate(pieces)]
record = {'asset': 'g4-test.zip', 'bytes': len(original), 'sha256': sha(original), 'storage': storage}
results = []
for case in ('positive', 'wrong-archive', 'wrong-part', 'unsafe-path', 'existing-different'):
    directory = out / case
    directory.mkdir()
    (directory / 'restore-originals.py').write_bytes(module.RESTORE_SCRIPT.encode())
    item = json.loads(json.dumps(record))
    payload = original
    expected = None
    if case == 'wrong-archive':
        payload = original[:-1] + bytes([original[-1] ^ 1])
        expected = 'original asset identity differs'
    if case == 'wrong-part':
        item['storage'][0]['sha256'] = '0' * 64
        expected = 'original part identity differs'
    if case == 'unsafe-path':
        item['storage'][0]['path'] = '../escape'
        expected = 'unsafe retained path'
    if case == 'existing-different':
        target = directory / storage[0]['path']
        target.parent.mkdir(parents=True)
        target.write_bytes(b'preserve this file')
        expected = 'existing file differs'
    manifest = {'schema': 'protocol-emulator-g4-release-package-v1', 'original_archives': [item]}
    (directory / 'g4-submission.json').write_bytes(module.encoded(manifest))
    (directory / 'g4-test.zip').write_bytes(payload)
    result = subprocess.run([sys.executable, str(directory / 'restore-originals.py')],
                            cwd=directory, capture_output=True)
    log = result.stdout + result.stderr
    (directory / 'control.log').write_bytes(log)
    if expected is None:
        assert result.returncode == 0, log
        assert [ (directory / part['path']).read_bytes() for part in storage ] == list(pieces)
        again = subprocess.run([sys.executable, str(directory / 'restore-originals.py')],
                               cwd=directory, capture_output=True)
        assert again.returncode == 0, again.stderr
        observed = 'PASS_RESTORED_SPLIT_ORIGINAL_AND_PRESERVED_REPLAY'
    else:
        assert result.returncode != 0 and expected.encode() in log, log
        if case == 'existing-different':
            assert (directory / storage[0]['path']).read_bytes() == b'preserve this file'
        observed = 'PASS_REJECTED_' + case.upper().replace('-', '_')
    results.append({'case': case, 'status': observed, 'returncode': result.returncode,
                    'log_sha256': sha(log)})
    print(observed)
assert not (out / 'escape').exists()
(out / 'result.json').write_bytes(module.encoded({'status': 'PASS_G4_RESTORE_CONTROLS',
    'packager_sha256': sha(path.read_bytes()), 'restore_script_sha256': sha(module.RESTORE_SCRIPT.encode()),
    'cases': results}))
