"""Retain the observed first G4 Windows/Linux checksum-order rejection."""
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = '6140001b47a6643471a1e4c4b361cb2f52975368'
CI_SOURCE = 'fd4564ee5e83c7d58faff95c0f021bb71f0df17b'
RUN, JOB, ARTIFACT = 43556669842, 132330956297, 14098950805
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/package-portability'
WINDOWS = ROOT / 'build/g4-release-assets' / SOURCE
ARCHIVE = ROOT / 'build/g4-package-ci-originals/14098950805.zip'
PACKAGER = 'evidence/E0047-g4-submission-candidate/release-tools/package.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe(name):
    path = PurePosixPath(name)
    assert path.as_posix() == name and not path.is_absolute() and '..' not in path.parts
    assert '\\' not in name and ':' not in name and not name.endswith('/')
    return path


assert not OUT.exists()
capture = read(ROOT / 'build/g4-package-ci-capture.json')
run, jobs, artifacts = (json.loads(capture[name]) for name in ('run', 'jobs', 'artifacts'))
assert run['id'] == RUN and run['head_sha'] == CI_SOURCE
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['event'] == 'push'
assert run['head_branch'] == 'codex/g4-linux-verification'
assert run['path'] == '.github/workflows/g4-linux-verification.yaml'
assert jobs['total_count'] == len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['id'] == JOB and job['run_id'] == RUN and job['head_sha'] == CI_SOURCE
assert job['run_attempt'] == run['run_attempt'] and job['conclusion'] == 'success'
assert all(step['conclusion'] == 'success' for step in job['steps'])
assert artifacts['total_count'] == len(artifacts['artifacts']) == 1
meta = artifacts['artifacts'][0]
assert meta['id'] == ARTIFACT and meta['name'] == 'g4-linux-proof-' + CI_SOURCE
assert meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == CI_SOURCE and not meta['expired']
assert capture['download']['id'] == ARTIFACT
assert f'Artifact ID {ARTIFACT}' in capture['log']
assert 'SHA256 digest of uploaded artifact is ' + meta['digest'][7:] in capture['log']
assert ARCHIVE.stat().st_size == meta['size_in_bytes'] and 'sha256:' + digest(ARCHIVE) == meta['digest']
expected = {'g4-submission-bundle.zip', 'g4-public-programs.zip', 'g4-windows-programs.zip',
            'g4-submission.json', 'g4-SHA256SUMS'} | {
    f'g4-{number}-{name}.zip' for number in (43543626249, 43543629839)
    for name in ('GDS_logs', 'tt_submission', 'sram-physical-candidate', 'precheck_reports',
                 'gatelevel_test_results', 'sram-netlist-check')}
assert {path.name for path in WINDOWS.iterdir()} == expected
indexed, linux, windows, comparisons, small = {}, {}, {}, {}, {}
with zipfile.ZipFile(ARCHIVE) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    for info in archive.infolist():
        safe(info.filename)
        assert not info.is_dir()
        if info.filename.startswith('assets/'):
            name = info.filename.removeprefix('assets/')
            assert name in expected and '/' not in name
            a_hash, b_hash, total, equal = hashlib.sha256(), hashlib.sha256(), 0, True
            with archive.open(info) as a, (WINDOWS / name).open('rb') as b:
                while True:
                    left, right = a.read(1024 * 1024), b.read(1024 * 1024)
                    equal = equal and left == right
                    if not left and not right:
                        break
                    a_hash.update(left)
                    b_hash.update(right)
                    total += len(left)
            linux[name] = {'bytes': total, 'sha256': a_hash.hexdigest()}
            windows[name] = {'bytes': (WINDOWS / name).stat().st_size, 'sha256': b_hash.hexdigest()}
            comparisons[name] = equal
            indexed[info.filename] = linux[name]
        else:
            raw = archive.read(info)
            small[info.filename] = raw
            indexed[info.filename] = {'bytes': len(raw), 'sha256': sha(raw)}
    linux_checksums = archive.read('assets/g4-SHA256SUMS')
windows_checksums = (WINDOWS / 'g4-SHA256SUMS').read_bytes()
assert set(linux) == expected and [name for name, same in comparisons.items() if not same] == ['g4-SHA256SUMS']
assert sum(comparisons.values()) == 16
summary = json.loads(small['run-summary.json'])
assert summary['status'] == 'PASS_G4_LINUX_RELEASE_PACKAGE' and summary['source_commit'] == CI_SOURCE
assert summary['release_source_commit'] == SOURCE and summary['package']['files'] == linux
assert summary['files'] == {name: item for name, item in indexed.items() if name != 'run-summary.json'}
linux_lines, windows_lines = linux_checksums.decode().splitlines(), windows_checksums.decode().splitlines()
assert len(linux_lines) == len(windows_lines) == 16 and set(linux_lines) == set(windows_lines)
pairs = {line.split('  ', 1)[1]: line.split('  ', 1)[0] for line in linux_lines}
assert pairs == {name: item['sha256'] for name, item in linux.items() if name != 'g4-SHA256SUMS'}
assert [line.split('  ', 1)[1] for line in linux_lines] == [str(p) for p in sorted(map(PurePosixPath, pairs))]
assert [line.split('  ', 1)[1] for line in windows_lines] == [str(p) for p in sorted(map(PureWindowsPath, pairs))]
source_files = {name: subprocess.check_output(['git', 'show', CI_SOURCE + ':' + name], cwd=ROOT)
                for name in ('.github/workflows/g4-linux-verification.yaml',
                             '.github/g4-linux-verification/run.py', '.github/g4-linux-verification/request.json')}
assert sha(source_files['.github/g4-linux-verification/run.py']) == summary['runner_sha256']
request = json.loads(source_files['.github/g4-linux-verification/request.json'])
assert request['phase'] == 'package' and request['release_source_commit'] == SOURCE
win_base = ROOT / 'build/g4-windows-package' / SOURCE
win_invocation = read(win_base / 'invocation.json')
win_log = (win_base / 'windows-package.log').read_bytes()
assert win_invocation['source_commit'] == SOURCE and win_invocation['exit_code'] == 0
assert win_invocation['log_sha256'] == sha(win_log)
packager_raw = subprocess.check_output(['git', 'show', SOURCE + ':' + PACKAGER], cwd=ROOT)
assert win_invocation['packager_sha256'] == sha(packager_raw)
assert b'sorted(output.iterdir())' in packager_raw and b'sorted(output.glob(' in packager_raw
runner = (ROOT / 'build/g4_windows_package.py').read_bytes()
assert sha(runner) == win_invocation['runner_sha256']
OUT.mkdir()
for name in ('run', 'jobs', 'artifacts'):
    (OUT / (name + '.json')).write_bytes(capture[name].encode())
(OUT / 'job.log.gz').write_bytes(gzip.compress(capture['log'].encode(), mtime=0))
for name, raw in small.items():
    path = OUT / 'proof' / safe(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
for name, raw in source_files.items():
    path = OUT / 'source' / safe(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
write(OUT / 'source.json', {'source_commit': CI_SOURCE, 'release_source_commit': SOURCE,
                          'files_sha256': {name: sha(raw) for name, raw in source_files.items()}})
write(OUT / 'zip-files.json', indexed)
write(OUT / 'windows-assets.json', windows)
write(OUT / 'linux-assets.json', linux)
(OUT / 'windows').mkdir()
(OUT / 'windows/invocation.json').write_bytes((win_base / 'invocation.json').read_bytes())
(OUT / 'windows/windows-package.log').write_bytes(win_log)
(OUT / 'windows/runner.py.gz').write_bytes(gzip.compress(runner, mtime=0))
(OUT / 'windows/g4-SHA256SUMS').write_bytes(windows_checksums)
(OUT / 'linux-g4-SHA256SUMS').write_bytes(linux_checksums)
record = {'status': 'REJECTED_CROSS_PLATFORM_CHECKSUM_ORDER', 'release_source_commit': SOURCE,
          'source_commit': CI_SOURCE, 'run_id': RUN, 'job_id': JOB, 'artifact_id': ARTIFACT,
          'artifact_bytes': ARCHIVE.stat().st_size, 'artifact_sha256': digest(ARCHIVE),
          'original_archive_files': len(indexed), 'original_zip_retained': False, 'omitted_asset_files': 17,
          'asset_count': 17, 'assets_compared_byte_for_byte': comparisons, 'identical_asset_count': 16,
          'different_assets': ['g4-SHA256SUMS'], 'checksum_entries_identical': True,
          'checksum_entries': pairs, 'packager_sha256': sha(packager_raw),
          'root_cause': 'sorted(Path) compares WindowsPath names case-insensitively and PosixPath names case-sensitively. GDS_logs and gatelevel_test_results swap positions for each physical run.',
          'required_fix': 'Use sorted(paths, key=lambda path: path.name) for checksum and ZIP inventory iteration; commit a new source and rerun both actual packages.',
          'scope': 'Actual authenticated CI transport and all seventeen native-Windows/Linux asset byte comparisons. This attempt is rejected; no platform identity PASS is issued.'}
write(OUT / 'verification.json', record)
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(OUT / 'README.md').write_bytes(f'''# Rejected first G4 package portability attempt

Release source `{SOURCE}` and [Linux run {RUN}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{RUN}) produced seventeen assets. Direct byte comparison finds sixteen identical assets. Only `g4-SHA256SUMS` differs, with the same sixteen name/hash pairs in a different order.

WindowsPath sorting is case-insensitive; PosixPath sorting is case-sensitive. `GDS_logs` and `gatelevel_test_results` swap positions for each physical run. The required correction is an explicit `key=lambda path: path.name`, followed by a newly committed source and fresh Windows/Linux package runs. This retained attempt remains rejected.

Both actual checksum files, all asset identities, original CI API records/upload log, frozen workflow source, original non-asset proof members and native Windows invocation/log are retained. `zip-files.json` indexes every original transport member. The authenticated {ARCHIVE.stat().st_size}-byte original ZIP and seventeen bulk assets remain in ignored build storage and are intentionally omitted here to avoid duplication. Its API/upload-bound SHA256 is `{record['artifact_sha256']}`. This small packet does not reconstruct the original transport ZIP. Public release verification is a separate gate.
'''.encode())
members = sorted(path for path in OUT.rglob('*') if path.is_file())
(OUT / 'SHA256SUMS').write_bytes(''.join(digest(path) + '  ' + path.relative_to(OUT).as_posix() + '\n'
                                     for path in members).encode())
print(record['status'], record['identical_asset_count'], 'actual assets byte-identical; checksum ordering differs')
