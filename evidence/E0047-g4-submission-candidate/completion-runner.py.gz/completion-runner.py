# SPDX-License-Identifier: Apache-2.0
"""Map completed G4 requirements to sealed evidence; refuse incomplete closure."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--check-only', action='store_true',
                    help='run all completion checks and compute references without writing completion-audit.json')
args = parser.parse_args()

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = 'evidence/E0047-g4-submission-candidate'
HERE = ROOT / EVIDENCE
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
head = git('rev-parse', 'HEAD').decode().strip()
freeze = read(HERE / 'candidate-freeze.json')
publication = read(HERE / 'publication/release-verification.json')
retention = read(HERE / 'publication/retention.json')
assert publication['status'] == 'PASS_G4_RELEASE_AND_PACKAGE'
assert publication['tag'] == 'v0.1.0' and len(publication['assets']) == 35
assert len(publication['tag_workflows']) == 9
release = publication['source_commit']
assert retention['schema'] == 'protocol-emulator-g4-publication-retention-v2'
assert retention['status'] == 'PASS_RETAINED_PUBLICATION' and retention['release_source_commit'] == release
assert retention['publication_verification_sha256'] == sha((HERE / 'publication/release-verification.json').read_bytes())
assert set(retention['ci_proofs']) == {'package', 'publication'}
assert git('rev-parse', 'v0.1.0^{commit}').decode().strip() == release
assert subprocess.run(['git', 'merge-base', '--is-ancestor', release, head], cwd=ROOT).returncode == 0

def sealed(directory):
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts and p.name != 'SHA256SUMS'}
    lines = (directory / 'SHA256SUMS').read_text(encoding='utf-8').splitlines()
    expected = {}
    for line in lines:
        digest, name = line.split('  ', 1)
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in name and ':' not in name
        assert re.fullmatch('[0-9a-f]{64}', digest) and name not in expected
        assert (directory / name).resolve().is_relative_to(directory.resolve())
        expected[name] = digest
        assert sha((directory / name).read_bytes()) == digest, str(directory / name)
    assert actual == set(expected), 'unsealed retained member'
    return len(expected)

seals = {}
required_folders = {'ci-43543626249', 'ci-43543629839', 'program-tools', 'publication', 'linux-ci-43554467650'}
ci_folders = {}
for phase, binding in retention['ci_proofs'].items():
    directory = (ROOT / binding['proof_path']).resolve()
    assert directory.is_relative_to(HERE.resolve()) and directory.parent == HERE.resolve()
    assert binding['phase'] == phase and binding['release_source_commit'] == release
    assert sha((directory / 'SHA256SUMS').read_bytes()) == binding['seal_sha256']
    assert sha((directory / 'run-summary.json').read_bytes()) == binding['summary_sha256']
    assert sha((directory / 'source.json').read_bytes()) == binding['source_manifest_sha256']
    summary, source, run = (read(directory / name) for name in ('run-summary.json', 'source.json', 'run.json'))
    assert summary['status'] == {'package': 'PASS_G4_LINUX_RELEASE_PACKAGE',
                                 'publication': 'PASS_G4_LINUX_PUBLICATION_AUDIT'}[phase]
    assert summary['phase'] == phase and summary['release_source_commit'] == release
    assert run['id'] == binding['run_id'] and run['status'] == 'completed' and run['conclusion'] == 'success'
    assert summary['source_commit'] == source['source_commit'] == run['head_sha'] == binding['ci_source_commit']
    assert summary['ci_execution']['run_id'] == str(run['id'])
    assert summary['ci_execution']['source_commit'] == summary['ci_execution']['workflow_execution_commit'] == run['head_sha']
    jobs = read(directory / 'jobs.json')['jobs']
    assert len(jobs) == 1 and jobs[0]['id'] == binding['job_id']
    assert jobs[0]['status'] == 'completed' and jobs[0]['conclusion'] == 'success' and jobs[0]['head_sha'] == run['head_sha']
    matches = [a for a in read(directory / 'artifacts.json')['artifacts'] if a['id'] == binding['artifact_id']]
    assert len(matches) == 1 and matches[0]['size_in_bytes'] == binding['artifact_bytes']
    assert matches[0]['digest'] == 'sha256:' + binding['artifact_sha256']
    assert matches[0]['workflow_run']['id'] == run['id'] and matches[0]['workflow_run']['head_sha'] == run['head_sha']
    assert len(read(directory / 'zip-files.json')) == binding['original_archive_files']
    assert sha(gzip.decompress((directory / 'job.log.gz').read_bytes())) == binding['job_log_sha256']
    assert summary['runner_sha256'] == binding['runner_sha256']
    for name, digest in source['files_sha256'].items():
        assert sha((directory / 'source' / name).read_bytes()) == digest
    if phase == 'package':
        verified = read(directory / 'verification.json')
        assert verified['status'] == 'PASS_RETAINED_G4_PACKAGE_CI'
        assert verified['run_id'] == run['id'] and verified['release_source_commit'] == release
        assert verified['artifact_sha256'] == binding['artifact_sha256']
        assert verified['original_zip_retained'] is binding['original_zip_retained'] is False
        assert verified['omitted_asset_files'] == binding['omitted_asset_files'] == 17
    else:
        assert binding['original_zip_retained'] is True and binding['omitted_asset_files'] == 0
        original = directory / (str(binding['artifact_id']) + '.zip')
        assert original.stat().st_size == binding['artifact_bytes'] and sha(original.read_bytes()) == binding['artifact_sha256']
    ci_folders[phase] = directory
    required_folders.add(directory.name)
# Sealing a preserved failure binds its bytes; it does not turn its outcome into a pass.
required_folders.update(p.name for p in HERE.iterdir() if p.is_dir() and (p / 'SHA256SUMS').is_file())
for folder in sorted(required_folders):
    seals[folder] = sealed(HERE / folder)
physical_linux = read(HERE / 'linux-ci-43554467650/verification.json')
assert physical_linux['status'] == 'PASS_RETAINED_G4_LINUX_CI_PROOF' and physical_linux['run_id'] == 43554467650
assert physical_linux['source_commit'] == '7b73d99fbf300c1041aa930409ea63fc031d20f4'
assert physical_linux['physical_runs'] == [43543626249, 43543629839]
physical = {}
for role, run in (('candidate', 43543626249), ('reproduction', 43543629839)):
    folder = HERE / ('ci-' + str(run))
    result = read(folder / 'result.json')
    assert result['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES'
    assert result['run_id'] == run and result['source_commit'] == publication['physical_source_commit']
    assert result['staged_sha256'] == freeze['physical_inputs']['files_sha256']
    assert result['precheck']['test_count'] == 10 and result['netlist_tests']['public_test_groups'] == 18
    assert len(result['archives']) == 6
    controls = read(folder / 'controls-result.json')
    assert controls['status'] == 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS'
    assert len(controls['cases']) == 9 and all(c['status'].startswith('PASS_') for c in controls['cases'])
    for platform in ('windows', 'linux'):
        replay = read(folder / ('verification-' + platform + '.json'))
        assert replay['status'] == 'PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION'
        assert replay['run_id'] == run and replay['source_commit'] == result['source_commit']
    physical[role] = {'run_id': run, 'source_commit': result['source_commit'],
                      'gds_sha256': result['gds_sha256'], 'netlist_sha256': result['netlist_sha256']}
reproduction = read(HERE / 'reproduction.json')
assert reproduction['status'] == 'PASS_REPRODUCED_G4_PHYSICAL_CANDIDATE'
assert reproduction['comparisons']['normalized_gds']['equivalent_except_timestamps']
assert reproduction['comparisons']['stages']['configuration_and_state_bytes_identical']
assert reproduction['comparisons']['public_records']['uart_retained_landmarks'] == 97
assert publication['reproduction_record_sha256'] == sha((HERE / 'reproduction.json').read_bytes())
programs = read(HERE / 'program-tools/verification.json')
assert programs['status'] == 'PASS_G4_FRESH_PROGRAM_TOOLCHAIN_CI'
assert programs['examples'] == 13 and programs['public_cases_each'] == 55
assert publication['fresh_program_toolchain_replayed_from_downloaded_bundle']
packaging = read(HERE / 'publication/packaging-platform-identity.json')
smoke = read(HERE / 'publication/distribution-smoke.json')
assert packaging['status'] == 'PASS_WINDOWS_LINUX_PACKAGE_IDENTITY' and len(packaging['files']) == 17
assert smoke['status'] == 'PASS_STANDALONE_DISTRIBUTION' and smoke['identical_generated_files'] == 52
assert packaging['source_commit'] == smoke['source_commit'] == release
assert packaging['linux_ci']['proof_path'] == retention['ci_proofs']['package']['proof_path']
assert (HERE / 'publication/packaging-platform-identity.json').read_bytes() == (ci_folders['package'] / 'platform-identity.json').read_bytes()
package_summary = read(ci_folders['package'] / 'run-summary.json')
publication_summary = read(ci_folders['publication'] / 'run-summary.json')
assert package_summary['package']['files'] == publication_summary['package']['files'] == packaging['files']
for name, meta in packaging['files'].items():
    assert publication['assets'][name]['sha256'] == meta['sha256']
assert smoke['archive_sha256'] == publication['assets']['g4-submission-bundle.zip']['sha256']
for label in ('windows_package', 'linux_package', 'linux_publication'):
    binding = retention[label]
    folder = HERE / 'publication'
    assert sha((folder / binding['invocation_path']).read_bytes()) == binding['invocation_sha256']
    assert sha(gzip.decompress((folder / binding['log_path']).read_bytes())) == binding['log_sha256']
    assert sha(gzip.decompress((folder / binding['runner_path']).read_bytes())) == binding['runner_sha256']
    invocation = read(folder / binding['invocation_path'])
    assert invocation['runner_sha256'] == binding['runner_sha256'] and invocation['log_sha256'] == binding['log_sha256']
    if label == 'windows_package':
        assert invocation['schema'] == 'protocol-emulator-g4-windows-package-invocation-v1'
        assert invocation['exit_code'] == 0 and invocation['source_commit'] == release
        assert invocation['platform'].startswith('Windows-')
        assert (folder / binding['invocation_path']).read_bytes() == (ci_folders['package'] / 'windows/invocation.json').read_bytes()
    else:
        phase = 'package' if label == 'linux_package' else 'publication'
        summary = package_summary if phase == 'package' else publication_summary
        assert invocation['schema'] == 'protocol-emulator-g4-linux-' + phase + '-invocation-v1'
        assert invocation['returncode'] == 0 and invocation['release_source_commit'] == release
        assert invocation['ci_execution'] == summary['ci_execution'] and invocation['runtime'] == summary['runtime']
        assert invocation['runtime']['image_reference'] == retention['ci_proofs'][phase]['image']
        assert invocation['runtime']['container_image']['Id'] == retention['ci_proofs'][phase]['config_digest']
        if phase == 'package':
            assert (folder / binding['invocation_path']).read_bytes() == (ci_folders['package'] / 'proof/package/invocation-linux.json').read_bytes()
        else:
            assert invocation['release_verification_sha256'] == retention['publication_verification_sha256']
            assert binding['published_image'] == publication['image'] and binding['published_image_config_digest'] == publication['config_digest']
            assert binding['audit_image'] == invocation['runtime']['image_reference']
            assert binding['audit_image_config_digest'] == invocation['runtime']['container_image']['Id']
assert retention['packager_sha256'] == sha(git('show', release + ':evidence/E0047-g4-submission-candidate/release-tools/package.py'))
assert retention['auditor_sha256'] == sha(git('show', release + ':evidence/E0047-g4-submission-candidate/release-tools/verify_publication.py'))
rules = read(HERE / 'rules-closure-observation.json')
assert rules['retrieval']['http_status'] == 200 and rules['actual_submission'] == 'OUT_OF_SCOPE'
assert rules['maximum_tiles'] == '8x4' and rules['deadline'] == '2027-01-18'

unchanged = {**freeze['physical_inputs']['files_sha256'], **freeze['metadata_flow_and_guard_inputs_sha256']}
for name, digest in unchanged.items():
    assert sha(git('show', release + ':' + name)) == digest
    assert sha(git('show', head + ':' + name)) == digest
changed_evidence = git('diff', '--name-only', freeze['baseline_commit'], head, '--', 'evidence').decode().splitlines()
assert all(name == 'evidence/README.md' or name.startswith(EVIDENCE + '/') for name in changed_evidence)
unrelated = {name: sha((ROOT / name).read_bytes()) for name in freeze['unrelated_files_sha256']}
assert unrelated == freeze['unrelated_files_sha256'], 'unrelated file changed; inspect without reverting it'

def reference(name):
    raw = (ROOT / name).read_bytes()
    assert b'\r\n' not in raw, 'canonicalize generated text before sealing: ' + name
    return {'path': name, 'sha256': sha(raw)}

def requirement(text, names, detail):
    return {'requirement': text, 'status': 'PASS',
            'evidence': [reference(name) for name in names], 'detail': detail}

requirements = [
    requirement('Freeze the final core and pass official GDS, routed checks, precheck and actual public-netlist tests.',
        [EVIDENCE + '/candidate-freeze.json', EVIDENCE + '/dispatches.json'] +
        [EVIDENCE + '/ci-' + str(run) + '/result.json' for run in (43543626249, 43543629839)],
        'Both separately registered clean production builds pass all required physical conditions, ten prechecks and eighteen actual-netlist public groups with unchanged twenty physical inputs.'),
    requirement('Reproduce from clean committed source with pinned tools, original artifacts and inspectable failures.',
        [EVIDENCE + '/reproduction.json', EVIDENCE + '/reproduce.py',
         EVIDENCE + '/linux-ci-43554467650/verification.json',
         EVIDENCE + '/linux-ci-43554467650/run-summary.json',
         EVIDENCE + '/ci-43543629839/startup-diagnostics/status.json'] +
        [EVIDENCE + '/ci-' + str(run) + '/' + name for run in (43543626249, 43543629839)
         for name in ('producer.json', 'verification-windows.json', 'verification-linux.json', 'invocation-linux.json', 'controls-result.json')],
        'Twelve original ZIPs and frozen producer inputs pass local Windows and authenticated isolated Linux CI replay; nine corruptions per run are rejected. The local Linux startup failure remains preserved. Netlists, metrics, area, stage configuration/state and retained public observations match. Geometry differs only in standard timestamp fields; G2 continuity remains separate.'),
    requirement('Publish and verify the final release and matching public workbench package.',
        [EVIDENCE + '/publication/' + name for name in ('release-verification.json', 'retention.json', 'packaging-platform-identity.json',
         'distribution-smoke.json', 'packaging-windows-invocation.json', 'packaging-linux-invocation.json', 'audit-runtime.json')] +
        [retention['ci_proofs'][phase]['proof_path'] + '/' + name for phase in ('package', 'publication')
         for name in ('run-summary.json', 'source.json', 'zip-files.json')],
        'Thirty-five anonymous downloads, exact source/member identities, both physical replays, fresh toolchain replay, all nine tag workflows and tested image identity pass. Seventeen actual native Windows and isolated Linux CI package assets match; all thirteen standalone examples rebuild. Package CI retains its authenticated member/source/command proof while omitting duplicate bulk assets and transport ZIP; publication CI retains its original curated ZIP. The audit image is separate from the published release image. Registry manifests/configuration were downloaded and layer access checked with HEAD.'),
    requirement('Provide readable architecture, ISA, programs, verification, AI use, measured tradeoffs and limitations.',
        ['docs/' + name + '.md' for name in ('architecture', 'isa', 'programming', 'verification', 'ai-use', 'toolchain', 'submission')] +
        [EVIDENCE + '/program-tools/verification.json'],
        'Current guides describe the frozen SRAM/prefetch design and nine opcodes, thirteen preserved examples, explicit host/electrical/timing assumptions, failed alternatives and scoped evidence. Fresh CI retains 55 cases per simulator and 53 identical compiled files; owner fluency is separate.'),
    requirement('Recheck official submission rules and assemble repository/release links and supporting material.',
        [EVIDENCE + '/rules-closure-observation.json', 'docs/submission.md', 'docs/releases/v0.1.0.md'],
        'The dated official-rule review is mapped to the prepared public source, qualified GDS, guides, examples, verification and AI-use account. The final submission-form status is recorded explicitly; no entry was sent.')]
assert len(requirements) == 5
record = {'schema': 'protocol-emulator-g4-completion-audit-v1', 'status': 'PASS_G4_COMPLETION_REQUIREMENTS',
          'observed_utc': datetime.now(timezone.utc).isoformat(), 'closure_baseline_commit': head,
          'release_source_commit': release, 'physical_source_commit': publication['physical_source_commit'],
          'physical_runs': physical, 'sealed_files': seals, 'requirements': requirements,
          'isolated_ci_proofs': retention['ci_proofs'],
          'release': publication['url'], 'image': publication['image'],
          'original_physical_inputs_preserved': len(freeze['physical_inputs']['files_sha256']),
          'history_baseline_commit': freeze['baseline_commit'], 'historical_evidence_unchanged': True,
          'unrelated_files_sha256': unrelated, 'final_submission_form': rules['final_submission_form'],
          'actual_submission': 'NOT_SENT', 'owner_learning': 'M0 teach-back remains pending; no inferred progress.',
          'explicit_nonclaims': ['No fabricated-silicon or FPGA result', 'No analog-bus or unrestricted interoperability qualification',
                                'No measured Fmax or minimum-ISA proof', 'No unrestricted autonomous UART receiver',
                                'No owner-fluency sign-off', 'No actual competition submission or hardware expenditure'],
          'next_engineering_work': 'G5 remains a separately authorized optional experiment; G6 owner teach-back remains pending.'}
target = HERE / 'completion-audit.json'
if args.check_only:
    print('PASS_G4_COMPLETION_PREFLIGHT', len(requirements), 'requirements', len(publication['assets']), 'assets')
else:
    assert not target.exists()
    target.write_bytes((json.dumps(record, indent=2) + '\n').encode('utf-8'))
    print(record['status'], len(requirements), 'requirements', len(publication['assets']), 'assets')
