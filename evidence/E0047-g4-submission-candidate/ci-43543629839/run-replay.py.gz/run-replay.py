"""Capture actual reproduction replay invocations and complete stdout/stderr."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'evidence/E0047-g4-submission-candidate/ci-43543629839'
IMAGE = 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
parser = argparse.ArgumentParser()
parser.add_argument('--platform', choices=('windows', 'linux'), required=True)
args = parser.parse_args()
label = args.platform
output = ROOT / ('build/g4-reproduction-' + label)
log = ROOT / ('build/g4-reproduction-' + label + '.log')
receipt = ROOT / ('build/g4-reproduction-' + label + '.invocation.json')
assert not output.exists() and not log.exists() and not receipt.exists()
relative_verify = (BASE / 'verify.py').relative_to(ROOT).as_posix()
relative_output = output.relative_to(ROOT).as_posix()
if label == 'windows':
    command = [sys.executable, relative_verify, '--output', relative_output]
    runtime = {'python': sys.version, 'platform': platform.platform()}
else:
    inspected = json.loads(subprocess.check_output(['docker', 'image', 'inspect', IMAGE], cwd=ROOT))[0]
    assert inspected['Os'] == 'linux' and inspected['Architecture'] == 'amd64'
    command = ['docker', 'run', '--rm', '--pull=never', '--init', '--env', 'HOME=/tmp',
               '--mount', 'type=bind,source=' + str(ROOT) + ',target=/workspace',
               '--workdir', '/workspace', IMAGE, 'python3', relative_verify,
               '--output', relative_output, '--controls']
    runtime = {'image_reference': IMAGE, 'actual_image_id': inspected['Id'],
               'repo_digests': inspected['RepoDigests'], 'os': inspected['Os'],
               'architecture': inspected['Architecture']}
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
observed = {'schema': 'protocol-emulator-g4-reproduction-invocation-v1', 'status': 'RUNNING',
            'platform': label, 'run_id': 43543629839,
            'argv': command, 'cwd': str(ROOT), 'runtime': runtime,
            'started_utc': datetime.now(timezone.utc).isoformat(),
            'verify_sha256': digest(BASE / 'verify.py'),
            'log_path': log.relative_to(ROOT).as_posix(),
            'free_bytes_before': shutil.disk_usage(ROOT).free}
save = lambda: receipt.write_bytes((json.dumps(observed, indent=2, sort_keys=True) + '\n').encode())
save()
print('START_REPRODUCTION_REPLAY', label, 'free_bytes', observed['free_bytes_before'], flush=True)
try:
    with log.open('wb') as stream:
        completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                                   timeout=1800, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    observed['exit_code'] = completed.returncode
    observed['status'] = 'PASS' if completed.returncode == 0 else 'FAILED'
except BaseException as error:
    observed.update(status='FAILED_OR_INTERRUPTED', error=repr(error))
    raise
finally:
    observed['completed_utc'] = datetime.now(timezone.utc).isoformat()
    observed['free_bytes_after'] = shutil.disk_usage(ROOT).free
    if log.exists():
        observed['log_sha256'] = digest(log)
    if (output / 'verification.json').exists():
        observed['verification_sha256'] = digest(output / 'verification.json')
    save()
print(log.read_text(encoding='utf-8', errors='replace'), end='')
print('REPRODUCTION_REPLAY_EXIT', label, observed['exit_code'], 'free_bytes', observed['free_bytes_after'])
raise SystemExit(observed['exit_code'])
