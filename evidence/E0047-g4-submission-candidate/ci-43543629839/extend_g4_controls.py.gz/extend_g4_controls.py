"""Add semantic controls for the new production and full-stage checks."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
old = ROOT / 'evidence/E0045-g2-sram-qualification/ci-94a3082/controls.py'
path = ROOT / 'build/g4-tools/controls.py'
text = old.read_text(encoding='utf-8')

def change(before, after):
    global text
    assert text.count(before) == 1, before
    text = text.replace(before, after)

change("         ('rehashed-netlist', 'tt_submission', 'submitted netlist differs')]", """         ('rehashed-netlist', 'tt_submission', 'submitted netlist differs'),
         ('wrong-job-source', None, 'G4 job source differs'),
         ('rehashed-production', 'sram-physical-candidate', 'production verification differs'),
         ('rehashed-stage-configuration', 'GDS_logs', 'G4 executed stage configuration differs'),
         ('rehashed-stage-skip', 'GDS_logs', 'configured G4 stage sequence differs')]""")
change("    mutation = None", """    if label == 'wrong-job-source':
        jobs['jobs'][0]['head_sha'] = '0' * 40
    mutation = None""")
change("            else:\n                member = 'tt_submission/tt_um_khangelani_protocol_emulator.v'", """            elif label == 'rehashed-production':
                member = 'build/sram-physical/inputs.json'
                before = source.read(member)
                data = json.loads(before)
                data['production']['qualified_run_id'] += 1
                after = (json.dumps(data, indent=2) + '\\n').encode()
            elif label == 'rehashed-stage-configuration':
                member = 'runs/wokwi/01-verilator-lint/config.json'
                before = source.read(member)
                data = json.loads(before)
                data['meta']['step'] = 'Unqualified.Stage'
                after = (json.dumps(data, indent=2) + '\\n').encode()
            elif label == 'rehashed-stage-skip':
                member = 'runs/wokwi/flow.log'
                before = source.read(member)
                expected = b"Gating variable for step 'OpenROAD.RepairDesignPostGRT' set to 'False'"
                assert before.count(expected) == 1
                after = before.replace(expected, expected.replace(b"'False'", b"'True'"))
            else:
                member = 'tt_submission/tt_um_khangelani_protocol_emulator.v'""")
change('PASS_FIVE_COMPLETE_QUALIFICATION_FAULT_CONTROLS', 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS')
path.write_bytes(text.encode())
print('PREPARED_NINE_G4_AUDIT_CONTROLS')
