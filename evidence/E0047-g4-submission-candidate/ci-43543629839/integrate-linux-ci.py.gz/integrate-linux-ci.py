"""Integrate original isolated Linux proof without rewriting local startup failures."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/ci-43543629839'
PROOF = OUT.parent / 'linux-ci-43554467650'
EXTRACTED = ROOT / 'build/g4-linux-physical-proof/files/ci-43543629839'
RUN, CI_RUN, CI_JOB, ARTIFACT = 43543629839, 43554467650, 132324068684, 14098180180
SOURCE = '45c55f7cd95db2a883b0ffb5e864decd62d53601'
CI_SOURCE = '7b73d99fbf300c1041aa930409ea63fc031d20f4'
IMAGE = 'ghcr.io/kg-khangelani/protocol-emulator-asic-workbench@sha256:f487aaf03906535a3187690557ff97ca1707e966b48ae8a99362683b5f68e307'
CONFIG = 'sha256:6f45e71162641466c4e9e08601a383c8a081c06b263114903a181d5f8f971451'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
file_sha = lambda p: sha(p.read_bytes())
write = lambda p, v: p.write_bytes((json.dumps(v, indent=2, sort_keys=True) + '\n').encode())

for directory in (PROOF, OUT):
    indexed = {}
    for line in (directory / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        assert name not in indexed and file_sha(directory / name) == digest
        indexed[name] = digest
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*')
              if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts}
    assert set(indexed) == actual
original = {p.relative_to(OUT).as_posix(): file_sha(p) for p in OUT.rglob('*')
            if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts}
proof = read(PROOF / 'verification.json')
assert proof['status'] == 'PASS_RETAINED_G4_LINUX_CI_PROOF'
assert (proof['run_id'], proof['job_id'], proof['artifact_id']) == (CI_RUN, CI_JOB, ARTIFACT)
assert proof['source_commit'] == CI_SOURCE and proof['image'] == IMAGE and proof['config_digest'] == CONFIG
archive_path = PROOF / (str(ARTIFACT) + '.zip')
assert file_sha(archive_path) == proof['artifact_sha256']
members = read(PROOF / 'zip-files.json')
assert len(members) == proof['original_archive_files'] == 33
with zipfile.ZipFile(archive_path) as archive:
    assert {p.filename for p in archive.infolist() if not p.is_dir()} == set(members)
    for name, item in members.items():
        raw = archive.read(name)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    retained = {'verification.json': 'verification-linux.json', 'invocation-linux.json': 'invocation-linux.json',
                'replay-linux.log.gz': 'replay-linux.log.gz', 'controls-result.json': 'controls-result.json'}
    controls = read(EXTRACTED / 'controls-result.json')
    assert controls['status'] == 'PASS_NINE_COMPLETE_QUALIFICATION_FAULT_CONTROLS'
    assert len(controls['cases']) == 9 and all(c['status'] == 'PASS_REJECTED_CORRUPTION' for c in controls['cases'])
    for case in controls['cases']:
        name = 'controls-logs/' + case['name'] + '.log.gz'
        retained[name] = name
        assert sha(gzip.decompress((EXTRACTED / name).read_bytes())) == case['log_sha256']
    assert archive.read(OUT.name + '/audit/result.json') == (OUT / 'result.json').read_bytes()
    for name, target in retained.items():
        raw = (EXTRACTED / name).read_bytes()
        assert raw == archive.read(OUT.name + '/' + name)
        destination = OUT / target
        assert not destination.exists()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)

result = read(OUT / 'result.json')
windows = read(OUT / 'verification-windows.json')
linux = read(OUT / 'verification-linux.json')
assert result['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES'
assert windows['controls_executed'] is False and linux['controls_executed'] is True
assert {k: v for k, v in windows.items() if k != 'controls_executed'} == {
    k: v for k, v in linux.items() if k != 'controls_executed'}
assert (linux['run_id'], linux['source_commit']) == (RUN, SOURCE)
assert controls['baseline_result_sha256'] == file_sha(OUT / 'result.json')
assert controls['audit_sha256'] == file_sha(OUT / 'audit.py')
assert controls['runner_sha256'] == file_sha(OUT / 'controls.py')
invocation = read(OUT / 'invocation-linux.json')
assert invocation['schema'] == 'protocol-emulator-g4-physical-replay-invocation-v1'
assert invocation['returncode'] == 0 and invocation['run_id'] == RUN and invocation['role'] == 'reproduction'
assert invocation['physical_source_commit'] == SOURCE
assert invocation['ci_execution']['source_commit'] == CI_SOURCE
assert invocation['ci_execution']['run_id'] == str(CI_RUN)
assert invocation['verify_sha256'] == file_sha(OUT / 'verify.py')
assert invocation['verification_sha256'] == file_sha(OUT / 'verification-linux.json')
assert invocation['result_sha256'] == file_sha(OUT / 'result.json')
assert invocation['compressed_log_sha256'] == file_sha(OUT / 'replay-linux.log.gz')
assert invocation['log_sha256'] == sha(gzip.decompress((OUT / 'replay-linux.log.gz').read_bytes()))
runtime = invocation['runtime']
assert runtime['image_reference'] == IMAGE
assert runtime['container_image']['Id'] == CONFIG and IMAGE in runtime['container_image']['RepoDigests']
assert IMAGE in invocation['command'] and '--controls' in invocation['command']
binding = {
    'schema': 'protocol-emulator-g4-reproduction-linux-ci-binding-v1',
    'status': 'PASS_ORIGINAL_LINUX_CI_REPLAY_AND_NINE_CONTROLS',
    'physical_run_id': RUN, 'physical_source_commit': SOURCE,
    'ci_run_id': CI_RUN, 'ci_job_id': CI_JOB, 'ci_source_commit': CI_SOURCE,
    'proof_directory': '../' + PROOF.name, 'proof_verification_sha256': file_sha(PROOF / 'verification.json'),
    'artifact_id': ARTIFACT, 'artifact_sha256': proof['artifact_sha256'],
    'image_reference': IMAGE, 'image_config_digest': CONFIG,
    'copied_members': {OUT.name + '/' + name: {'retained_path': target, **members[OUT.name + '/' + name]}
                       for name, target in retained.items()},
    'complete_audit_result_identical': True, 'result_sha256': file_sha(OUT / 'result.json'),
    'scope': 'Original isolated CI member bytes, with verification.json renamed only. Physical source and result remain unchanged. Local startup failures are preserved and no local Docker recovery is claimed.'}
write(OUT / 'linux-ci-binding.json', binding)
windows_runtime = read(OUT / 'windows-runtime.json')['windows']
windows_runtime = {**windows_runtime, 'invocation_path': 'invocation-windows.json',
                   'invocation_sha256': file_sha(OUT / 'invocation-windows.json'), 'execution_environment': 'LOCAL_WINDOWS'}
write(OUT / 'replay-runtime.json', {
    'schema': 'protocol-emulator-g4-physical-replay-runtime-v1',
    'status': 'PASS_RETAINED_REPRODUCTION_REPLAY_BOTH_PLATFORMS',
    'run_id': RUN, 'source_commit': SOURCE, 'result_sha256': file_sha(OUT / 'result.json'),
    'same_complete_audit_results': True, 'windows': windows_runtime,
    'linux': {'execution_environment': 'GITHUB_ACTIONS_LINUX', 'image_reference': IMAGE,
              'actual_image_id': CONFIG, 'repo_digests': runtime['container_image']['RepoDigests'],
              'os': runtime['container_image']['Os'], 'architecture': runtime['container_image']['Architecture'],
              'argv': invocation['command'], 'exit_code': invocation['returncode'],
              'started_utc': invocation['started_utc'], 'completed_utc': invocation['completed_utc'],
              'ci_execution': invocation['ci_execution'], 'ci_job_id': CI_JOB,
              'invocation_path': 'invocation-linux.json', 'invocation_sha256': file_sha(OUT / 'invocation-linux.json'),
              'log_path': 'replay-linux.log.gz', 'log_sha256': invocation['log_sha256'],
              'compressed_log_sha256': invocation['compressed_log_sha256'],
              'verify_sha256': invocation['verify_sha256'], 'verification_sha256': invocation['verification_sha256'],
              'controls_sha256': file_sha(OUT / 'controls-result.json'), 'fault_controls': 9,
              'proof_directory': '../' + PROOF.name, 'proof_verification_sha256': file_sha(PROOF / 'verification.json')},
    'scope': 'Local Windows and isolated GitHub Linux replay audit the same original physical CI evidence. The Linux public image manifest and configuration are distinct identities. No new place-and-route or simulation ran, and failed local Linux startup remains recorded separately.'})

text = (OUT / 'README.md').read_text(encoding='utf-8')
start, end = text.index('Windows replays the complete audit successfully.'), text.index('Replay into fresh directories under `build/`:')
text = text[:start] + f'''Windows and isolated Linux CI replay the complete audit successfully and
reproduce the same result. Windows runs locally; [Linux run {CI_RUN}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{CI_RUN})
uses execution source `{CI_SOURCE}`, distinct from the
physical source above. Its actual public alpha.7 workbench manifest is
`{IMAGE}`;
its inspected configuration is `{CONFIG}`.

Linux also rejects all nine deliberate evidence faults: pending workflow,
wrong archive digest, altered supply-port count, skipped public test, changed
submitted netlist, wrong job source, changed production identity, changed stage
configuration and changed stage-skip record. Rehashed semantic faults are
rejected beyond archive integrity. `controls-result.json` and the nine
`controls-logs/` files retain the actual failures.

`replay-runtime.json` binds the local Windows receipt and actual Linux CI
receipt, logs, verification reports and immutable image identities.
`linux-ci-binding.json` maps the unchanged copied CI member bytes to the
[common original proof](../{PROOF.name}/README.md), including its
33-member artifact, source, API and job-log records. The `verification.json`
member is named `verification-linux.json` here; its bytes are unchanged.

`startup-diagnostics/` preserves the earlier local Docker create-API EOF
failure (exit125), both bounded probe timeouts and the pending snapshot.
No verification or fault controls ran in that local attempt. The isolated CI
success makes no claim that local Docker recovered. `windows-runtime.json`
preserves the earlier Windows-only checkpoint; `replay-runtime.json` records
the completed comparison. Historical failure records remain unchanged.

''' + text[end:]
(OUT / 'README.md').write_bytes(text.encode())
(OUT / 'integrate-linux-ci.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
for name, digest in original.items():
    if name != 'README.md':
        assert file_sha(OUT / name) == digest, name
files = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts)
(OUT / 'SHA256SUMS').write_bytes(''.join(file_sha(p) + '  ' + p.relative_to(OUT).as_posix() + '\n' for p in files).encode())
print('PASS_REPRODUCTION_WINDOWS_AND_ORIGINAL_LINUX_CI', RUN, len(retained), 'unchanged copied members', len(files), 'sealed files')
