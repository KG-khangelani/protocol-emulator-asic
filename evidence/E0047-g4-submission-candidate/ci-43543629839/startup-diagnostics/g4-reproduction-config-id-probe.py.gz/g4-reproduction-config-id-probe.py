import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[1]
command = ['docker', 'run', '--rm', '--pull=never', '--network', 'none',
           '--name', 'g4-reproduction-config-id-probe', '--entrypoint', 'python3',
           'sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909',
           '-c', "print('PASS_EXACT_IMAGE_ID')"]
record = {'argv': command, 'timeout_seconds': 20}
start = time.monotonic()
try:
    result = subprocess.run(command, cwd=root, capture_output=True, timeout=20,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    record.update(status='COMPLETED', exit_code=result.returncode,
                  stdout=result.stdout.decode('utf-8', errors='replace'),
                  stderr=result.stderr.decode('utf-8', errors='replace'))
except subprocess.TimeoutExpired as error:
    record.update(status='TIMEOUT', stdout=(error.stdout or b'').decode('utf-8', errors='replace'),
                  stderr=(error.stderr or b'').decode('utf-8', errors='replace'))
record['elapsed_seconds'] = time.monotonic() - start
(root / 'build/g4-reproduction-config-id-probe.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(json.dumps(record, indent=2))
