"""Prepare a new G4 auditor without changing the frozen G2 auditor."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / 'evidence/E0045-g2-sram-qualification/ci-94a3082'
OUT = ROOT / 'build/g4-tools'
OUT.mkdir(exist_ok=True)

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

support = (OLD / 'sram_official_frozen_support.py').read_text(encoding='utf-8')
support = replace(support, 'ROOT = Path(__file__).resolve().parents[3]',
                  'ROOT = Path(__file__).resolve().parents[2]')
start = support.index("            index = json.loads((HERE / 'producer.json').read_bytes())")
end = support.index('            path.parent.mkdir', start)
support = support[:start] + "            raw = subprocess.check_output(['git', 'show', source + ':' + name], cwd=ROOT)\n" + support[end:]
marker = '    return SimpleNamespace(common=common, physical_g2=physical_g2, physical_sram=physical_sram,'
addition = '''    production = selected('tools/production_sram.py', ['PROFILE', 'require', 'sha', 'relative_file', 'verify'],
        dict(Path=Path, PurePosixPath=PurePosixPath, json=json, re=re, hashlib=hashlib, ROOT=destination))
'''
support = replace(support, marker, addition + marker)
support = replace(support, '        alignment=alignment, audit=audit, runtime=runtime, frozen=frozen,',
                  '        alignment=alignment, audit=audit, runtime=runtime, frozen=frozen, production=production,')
(OUT / 'sram_official_frozen_support.py').write_bytes(support.encode())

audit = (OLD / 'audit.py').read_text(encoding='utf-8')
audit = replace(audit, 'ROOT = Path(__file__).resolve().parents[3]',
                "ROOT = Path(__file__).resolve().parents[2]\nHERE = Path(__file__).resolve().parent")
audit = replace(audit, 'from sram_official_frozen_support import load',
                'from sram_official_frozen_support import load\nfrom flow_audit import inspect_flow')
audit = replace(audit, "    require(run['path'] == '.github/workflows/gds-sram.yaml', 'wrong workflow')", '''    require(run['path'] == '.github/workflows/gds.yaml', 'wrong workflow')
    require(run['id'] in (43543626249, 43543629839), 'unregistered G4 run')
    require(run['head_sha'] == '45c55f7cd95db2a883b0ffb5e864decd62d53601', 'G4 frozen revision differs')
    require(run['run_attempt'] == 1, 'G4 attempt differs')
    require(run['event'] == 'workflow_dispatch', 'G4 dispatch identity differs')''')
audit = replace(audit, "    source = run['head_sha']", '''    require(len(job_list) == 3 and set(jobs) == {'gds', 'precheck', 'gl_test'}, 'unexpected G4 job set')
    require(all(job['head_sha'] == run['head_sha'] for job in job_list), 'G4 job source differs')
    source = run['head_sha']''')
marker = "        for name, expected in inputs['staged_sha256'].items():"
addition = '''        require(inputs['status'] == 'PREPARED_MATCHING_QUALIFIED_PRODUCTION', 'production preparation missing')
        profile = json.loads(frozen(source, 'tools/production-profile.json'))
        references = ['info.yaml', profile['decision']] + list(profile['files_sha256'])
        references += [profile[key]['path'] for key in ('qualification', 'combined_regression',
            'normal_command_verification', 'corrected_netlist_pair')]
        for name in references:
            frozen(source, name)
        production = producing.production.verify(producing.directory)
        require(production == inputs['production'], 'production verification differs')
        freeze = json.loads(frozen(source, 'evidence/E0047-g4-submission-candidate/candidate-freeze.json'))
        require(production['files_sha256'] == inputs['staged_sha256'] == freeze['physical_inputs']['files_sha256'],
                'twenty frozen physical inputs differ')
        require(len(inputs['staged_sha256']) == 20, 'G4 physical input count differs')
        for name, expected in freeze['metadata_flow_and_guard_inputs_sha256'].items():
            require(sha(frozen(source, name)) == expected, 'G4 frozen control input differs: ' + name)
'''
audit = replace(audit, marker, addition + marker)
audit = replace(audit, "        ported = 'power_port_selection' in inputs",
                "        require('power_port_selection' in inputs, 'G4 power-port contract missing')\n        ported = 'power_port_selection' in inputs")
audit = replace(audit, "        routed = staged.json('build/sram-physical/resolved-inputs.json')",
                "        routed = staged.json('build/sram-physical/resolved-inputs.json')\n        require(routed['production'] == production, 'routed production identity differs')")
marker = "        precheck = inspect_precheck(archives['precheck_reports'].bytes('results.xml'))"
addition = '''        gl_log = (base / 'gl_test-job.log').read_bytes().decode('utf-8')
        compile_lines = [line for line in gl_log.splitlines() if '/usr/bin/iverilog -o ' in line]
        require(len(compile_lines) == 1 and all(token in compile_lines[0] for token in
            ('-DG2_SRAM', '/build/sram-physical/candidate/models/RM_IHPSG13_1P_256x32_c2_bm_bist.v',
             '/build/sram-physical/candidate/models/RM_IHPSG13_1P_core_behavioral_bm_bist.v')),
            'actual SRAM model compiler inputs missing')
        uart_landmarks = [line[line.index('RX edge='):] if 'RX edge=' in line else line[line.index('Late-reader'):]
                          for line in gl_log.splitlines() if 'RX edge=' in line or 'Late-reader' in line]
        require(len(uart_landmarks) == 97, 'UART retained landmark count differs')
        (out / 'uart-landmarks.json').write_bytes((json.dumps(uart_landmarks, indent=2) + '\\n').encode())
'''
audit = replace(audit, marker, addition + marker)
audit = replace(audit, '        stage_configs = {name: logs.json(name) for name in logs.file.namelist()',
                '        execution = inspect_flow(logs, resolved, require)\n        stage_configs = {name: logs.json(name) for name in logs.file.namelist()')
audit = replace(audit, "                'workflow_path': run['path'],", "                'workflow_path': run['path'], 'production': production,\n                'g4_frozen_candidate_sha256': sha(frozen(source, 'evidence/E0047-g4-submission-candidate/candidate-freeze.json')),")
audit = replace(audit, "                'staging_manifest_sha256': sha(staged.bytes('build/sram-physical/inputs.json')),",
                "                'staging_manifest_sha256': sha(staged.bytes('build/sram-physical/inputs.json')),\n                'flow_execution': execution,")
audit = replace(audit, "                'precheck': precheck, 'netlist_tests': checked, 'macro_views': inputs['macro_views'],",
                "                'precheck': precheck, 'netlist_tests': checked, 'macro_views': inputs['macro_views'],\n                'uart_landmarks': {'count': len(uart_landmarks), 'sha256': sha((out / 'uart-landmarks.json').read_bytes()),\n                    'scope': 'Seven UART groups execute assertions. Only retained RX landmarks are compared; complete UART TX traces were not retained.'},")
audit = replace(audit, "                    'physical_qualification': 'NOT_COMPLETE', 'production': 'NOT_PROMOTED',",
                "                    'physical_qualification': 'NOT_COMPLETE', 'production': production,\n                    'flow_execution': execution,")
audit = replace(audit, "Production adoption/publication remain separate.'}",
                "Fresh G4 production qualification. Reproduction comparison, publication and submission readiness remain separate.'}")
(OUT / 'audit.py').write_bytes(audit.encode())
for name in ('verify.py', 'controls.py'):
    (OUT / name).write_bytes((OLD / name).read_bytes())
(OUT / 'audit-baseline.json').write_bytes((ROOT / 'evidence/E0047-g4-submission-candidate/audit-baseline.json').read_bytes())
print('PREPARED_NEW_G4_AUDIT_SOURCE')
