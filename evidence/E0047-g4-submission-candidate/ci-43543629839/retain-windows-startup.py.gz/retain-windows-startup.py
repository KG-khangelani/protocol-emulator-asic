"""Retain completed Windows replay and the actual local Linux startup failure."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/ci-43543629839'
RUN = 43543629839
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_bytes((json.dumps(v, indent=2, sort_keys=True) + '\n').encode())
result = read(OUT / 'result.json')
assert result['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES' and result['run_id'] == RUN
source = ROOT / 'build/g4-reproduction-windows'
verified = read(source / 'verification.json')
assert verified['status'] == 'PASS_RETAINED_COMPLETE_SRAM_QUALIFICATION'
assert verified['run_id'] == RUN and verified['controls_executed'] is False
assert read(source / 'audit/result.json') == result
invocation_path = ROOT / 'build/g4-reproduction-windows.invocation.json'
invocation = read(invocation_path)
assert invocation['status'] == 'PASS' and invocation['exit_code'] == 0
assert invocation['verify_sha256'] == sha(OUT / 'verify.py')
assert invocation['verification_sha256'] == sha(source / 'verification.json')
log = ROOT / invocation['log_path']
assert invocation['log_sha256'] == sha(log)
shutil.copyfile(source / 'verification.json', OUT / 'verification-windows.json')
shutil.copyfile(invocation_path, OUT / 'invocation-windows.json')
(OUT / 'replay-windows.log.gz').write_bytes(gzip.compress(log.read_bytes(), mtime=0))
write(OUT / 'windows-runtime.json', {
    'schema': 'protocol-emulator-g4-physical-windows-replay-v1',
    'status': 'PASS_RETAINED_REPRODUCTION_WINDOWS_REPLAY',
    'run_id': RUN, 'source_commit': result['source_commit'],
    'result_sha256': sha(OUT / 'result.json'),
    'windows': {'python': invocation['runtime']['python'],
                'platform': invocation['runtime']['platform'],
                'argv': invocation['argv'], 'exit_code': invocation['exit_code'],
                'started_utc': invocation['started_utc'], 'completed_utc': invocation['completed_utc'],
                'log_path': 'replay-windows.log.gz', 'log_sha256': invocation['log_sha256'],
                'verify_sha256': invocation['verify_sha256'],
                'verification_sha256': invocation['verification_sha256']},
    'remaining_gate': 'Pinned Linux replay and nine fault controls; local Docker failed before creating the replay container.',
    'scope': 'Windows replay audits original physical CI evidence and frozen producing dependencies; it does not rerun physical design or simulation.'})

diagnostics = OUT / 'startup-diagnostics'
diagnostics.mkdir(exist_ok=True)
failed_path = ROOT / 'build/g4-reproduction-linux.invocation.json'
failed = read(failed_path)
assert failed['status'] == 'FAILED' and failed['exit_code'] == 125
assert failed['verify_sha256'] == sha(OUT / 'verify.py')
assert 'verification_sha256' not in failed
failed_log = ROOT / failed['log_path']
assert failed['log_sha256'] == sha(failed_log)
assert b'containers/create' in failed_log.read_bytes() and b'EOF' in failed_log.read_bytes()
assert not (ROOT / 'build/g4-reproduction-linux').exists()
shutil.copyfile(failed_path, diagnostics / 'invocation-linux-startup-failed.json')
(diagnostics / 'replay-linux-startup-failed.log.gz').write_bytes(gzip.compress(failed_log.read_bytes(), mtime=0))
for name in ('g4-reproduction-no-bind-probe.json', 'g4-reproduction-config-id-probe.json',
             'g4-reproduction-linux.initial-pending.json', 'g4-reproduction-startup-diagnostic.json'):
    shutil.copyfile(ROOT / 'build' / name, diagnostics / name)
for name in ('g4-reproduction-no-bind-probe.py', 'g4-reproduction-config-id-probe.py'):
    (diagnostics / (name + '.gz')).write_bytes(gzip.compress((ROOT / 'build' / name).read_bytes(), mtime=0))
probes = {}
for name in ('g4-reproduction-no-bind-probe.json', 'g4-reproduction-config-id-probe.json'):
    receipt = read(diagnostics / name)
    assert receipt['status'] == 'TIMEOUT' and receipt['stdout'] == '' and receipt['stderr'] == ''
    probes[name] = {'sha256': sha(diagnostics / name), 'timeout_seconds': receipt['timeout_seconds'],
                    'elapsed_seconds': receipt['elapsed_seconds']}
write(diagnostics / 'status.json', {
    'schema': 'protocol-emulator-g4-local-linux-startup-failure-v1',
    'status': 'FAILED_BEFORE_LINUX_REPLAY_CONTAINER_CREATION',
    'recorded_utc': datetime.now(timezone.utc).isoformat(), 'run_id': RUN,
    'source_commit': result['source_commit'], 'exit_code': failed['exit_code'],
    'invocation_path': 'invocation-linux-startup-failed.json',
    'invocation_sha256': sha(diagnostics / 'invocation-linux-startup-failed.json'),
    'log_path': 'replay-linux-startup-failed.log.gz', 'log_sha256': failed['log_sha256'],
    'verify_sha256': failed['verify_sha256'], 'output_directory_created': False,
    'runtime_inspected_before_launch': failed['runtime'], 'probes': probes,
    'scope': 'Local startup failed with Docker create API pipe EOF. No Linux replay or fault control executed in this attempt. The client exited naturally; a guarded process-stop check found it already absent, so this agent stopped no client, daemon or other container. Cause is not established.'})

flow = result['flow_execution']
metrics = result['physical_metrics']['checked']
text = f'''# G4 independent production reproduction

[Run {RUN}](https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/{RUN})
uses source `{result['source_commit']}`. GDS, all ten official prechecks and
the eighteen-group actual public-netlist selection pass. The complete audit is
`PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES`. This is the separately registered
reproduction run, not a retry replacing another physical outcome.

Six original ZIPs retain {verified['original_archive_files']:,} members. Every archive
matches its GitHub API size/digest, and producing/consuming logs bind the actual
jobs to the submitted layout and netlist. The frozen audit includes
{verified['producing_inputs']} producing files; all match canonical Git blobs at the
recorded source. `storage.json` records unchanged archive storage and
`zip-files.json` covers every member. Optional rendering is outside these six
required verification archives.

All twenty production inputs match the adopted SRAM profile. The flow audit
checks {flow['configured_stages']} configured entries, {flow['executed_top_level']}
executed top-level stages, {flow['nested_stages']} nested stages and
{flow['gated_skips']} gated skips, including their exact sequences and configuration
and state artifacts. Original Magic DRC, LVS and the required timing/electrical,
power-grid and antenna gates pass.

Worst setup slack is **{metrics['timing__setup__ws']} ns** and hold slack is
**{metrics['timing__hold__ws']} ns** at the 20 ns target. These are routed
measurements, not measured maximum frequency or silicon. The fast model mixes
-40 C standard cells and -55 C SRAM. The exact Magic contact alignment and SRAM
power/buffer/pin integration remain explicit.

The public tests reproduce 1,052 SPI, 1,160 I2C, four boundary and 36 abort
records. Seven UART groups execute their assertions; 97 RX/service landmarks
are retained, not complete UART TX traces. Netlist testing is functional
zero-delay simulation. `uart-landmarks.json` records that comparison scope.

Windows replays the complete audit successfully. `verification-windows.json`,
`invocation-windows.json`, `replay-windows.log.gz` and `windows-runtime.json`
retain the actual command, exit code, complete audit equality and log/hash
bindings. Linux replay and its nine deliberate corruption controls remain
pending in this record. The local Docker invocation exited125 with a create
API pipe EOF before any replay output directory was created; two bounded
minimal startup probes also timed out. `startup-diagnostics/` preserves those
receipts and the original pending snapshot. None is counted as a verification
pass. No Docker daemon or other service was restarted by this agent.

Replay into fresh directories under `build/`:

```sh
python evidence/E0047-g4-submission-candidate/ci-43543629839/verify.py --output build/reproduction-replay
python evidence/E0047-g4-submission-candidate/ci-43543629839/verify.py --output build/reproduction-replay-controls --controls
```

Replays audit retained evidence and frozen source; they do not rerun place-and-route
or simulation. `SHA256SUMS` seals all retained files. Cross-run geometry comparison,
publication and submission readiness are separate G4 records. FPGA, analog,
fabricated-chip and owner-fluency completion are not inferred.
'''
(OUT / 'README.md').write_bytes(text.encode())
(OUT / 'retain-windows-startup.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(OUT / 'run-replay.py.gz').write_bytes(gzip.compress((ROOT / 'build/g4-reproduction-run-replay.py').read_bytes(), mtime=0))
files = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts)
(OUT / 'SHA256SUMS').write_bytes(''.join(sha(p) + '  ' + p.relative_to(OUT).as_posix() + '\n' for p in files).encode())
print('RETAINED_WINDOWS_SUCCESS_AND_LOCAL_LINUX_STARTUP_FAILURE', RUN, len(files), 'sealed files')
