"""Freeze each original G4 archive, actual producer inputs and the new audit."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--base', type=Path, required=True)
args = parser.parse_args()
base = args.base.resolve()
assert base.is_relative_to(ROOT / 'build')
review = base / 'audit'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
write = lambda p,v: p.write_bytes((json.dumps(v, indent=2) + '\n').encode())
result = read(review / 'result.json')
assert result['status'] == 'PASS_ALL_SRAM_OFFICIAL_PHYSICAL_GATES'
assert result['flow_execution']['configured_stages'] == 85
assert result['flow_execution']['executed_top_level'] == 77
assert result['production']['status'] == 'PASS_PRODUCTION_MATCHES_QUALIFIED_SRAM'
out = ROOT / 'evidence/E0047-g4-submission-candidate' / ('ci-' + str(result['run_id']))
assert not out.exists()
out.mkdir()
indexed, storage = {}, {}
for a in read(base / 'artifacts.json')['artifacts']:
    if a['name'] not in result['archives']:
        continue
    name = str(a['id']) + '.zip'
    raw = (base / name).read_bytes()
    assert len(raw) == a['size_in_bytes'] and 'sha256:' + sha(raw) == a['digest']
    assert result['archives'][a['name']]['sha256'] == sha(raw)
    chunks = [raw] if len(raw) < 100_000_000 else [raw[i:i+64_000_000] for i in range(0, len(raw), 64_000_000)]
    storage[name] = []
    for i, chunk in enumerate(chunks):
        target = name if len(chunks) == 1 else name + '.part' + str(i + 1).zfill(2)
        (out / target).write_bytes(chunk)
        storage[name].append({'name': target, 'bytes': len(chunk), 'sha256': sha(chunk)})
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        indexed[a['name']] = {n: sha(z.read(n)) for n in z.namelist() if not n.endswith('/')}
assert len(indexed) == 6
write(out / 'storage.json', storage)
write(out / 'zip-files.json', indexed)
for name in ('result.json', 'uart-landmarks.json'):
    shutil.copyfile(review / name, out / name)
for name in ('run.json', 'jobs.json', 'artifacts.json'):
    shutil.copyfile(base / name, out / name)
for name in ('gds', 'precheck', 'gl_test'):
    (out / (name + '-job.log.gz')).write_bytes(gzip.compress((base / (name + '-job.log')).read_bytes(), mtime=0))
inputs = {p.relative_to(review / 'producer').as_posix(): p.read_bytes()
          for p in (review / 'producer').rglob('*') if p.is_file()}
with (out / 'producer.tar.gz').open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(inputs.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
write(out / 'producer.json', {'source_commit': result['source_commit'],
    'sha256': sha((out / 'producer.tar.gz').read_bytes()), 'files': {n:sha(r) for n,r in sorted(inputs.items())}})
support = (ROOT / 'build/g4-tools/sram_official_frozen_support.py').read_text(encoding='utf-8')
support = support.replace('ROOT = Path(__file__).resolve().parents[2]', 'ROOT = Path(__file__).resolve().parents[3]')
old = "            raw = subprocess.check_output(['git', 'show', source + ':' + name], cwd=ROOT)"
assert support.count(old) == 1
new = '''            index = json.loads((HERE / 'producer.json').read_bytes())
            assert source == index['source_commit']
            archive = HERE / 'producer.tar.gz'
            assert hashlib.sha256(archive.read_bytes()).hexdigest() == index['sha256']
            with tarfile.open(archive) as stream:
                raw = stream.extractfile(name).read()
            assert hashlib.sha256(raw).hexdigest() == index['files'][name]'''
(out / 'sram_official_frozen_support.py').write_bytes(support.replace(old, new).encode())
audit = (ROOT / 'build/g4-tools/audit.py').read_text(encoding='utf-8')
assert audit.count('ROOT = Path(__file__).resolve().parents[2]') == 1
(out / 'audit.py').write_bytes(audit.replace('ROOT = Path(__file__).resolve().parents[2]',
    'ROOT = Path(__file__).resolve().parents[3]').encode())
for name in ('verify.py', 'controls.py', 'flow_audit.py', 'audit-baseline.json'):
    shutil.copyfile(ROOT / 'build/g4-tools' / name, out / name)
for name in ('setup_g4_audit.py', 'extend_g4_controls.py', 'retain_g4_physical.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress((ROOT / 'build' / name).read_bytes(), mtime=0))
files = sorted(p for p in out.iterdir() if p.is_file())
(out / 'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n' for p in files).encode())
print('RETAINED_G4_ORIGINAL_ARCHIVES', result['run_id'], sum(map(len, indexed.values())), len(inputs))
