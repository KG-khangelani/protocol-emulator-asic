"""Prepare a source-frozen G4 program CI audit without altering the G3 auditor."""
from pathlib import Path
import gzip

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/program-tools'
OUT.mkdir(parents=True, exist_ok=True)
assert not (OUT / 'verify.py').exists()
source = (ROOT / 'evidence/E0046-program-toolchain/ci-0297655/verify.py').read_text(encoding='utf-8')
source = source.replace('Audit original G3 CI archives and the separate clean committed checkout.',
    'Audit fresh G4 program CI from retained original archives and frozen producing source.')
source = source.replace("SOURCE = '0297655e22ded931baae483b6deff81b7c9ccffd'", "SOURCE = 'ae2ac7bf800bd02d83fe62677a56bc4131e98b06'")
source = source.replace('RUN = 43393826878', 'RUN = 43544749692')
source = source.replace("    assert len(result['inputs_sha256']) == 351", "    assert len(result['inputs_sha256']) == 352, 'producing input count differs'")
start = source.index('def git(*args):')
end = source.index('\ndef zip_files(path):', start)
source = source[:start] + '''HERE = Path(__file__).resolve().parent
_producer = None


def producer():
    global _producer
    if _producer is None:
        index = read(HERE / 'producer.json')
        raw = (HERE / 'producer.tar.gz').read_bytes()
        assert index['source_commit'] == SOURCE and sha(raw) == index['sha256'], 'frozen producer identity differs'
        files = {}
        with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
            for entry in archive:
                name = PurePosixPath(entry.name)
                assert entry.isfile() and entry.name not in files
                assert not name.is_absolute() and '..' not in name.parts and '\\\\' not in entry.name
                files[entry.name] = archive.extractfile(entry).read()
        assert {n: sha(raw) for n, raw in files.items()} == index['files'], 'frozen source bytes differ'
        assert all(hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\\0' + raw).hexdigest() == index['git_blob_sha1'][n]
                   for n, raw in files.items()), 'canonical Git blob identity differs'
        _producer = (index, files)
    return _producer


def git(*args):
    # Compatibility adapter for the original audit's source reads; no Git or network execution.
    assert len(args) == 2 and args[0] == 'show' and args[1].startswith(SOURCE + ':')
    return producer()[1][args[1].split(':', 1)[1]]


def committed_inputs(inputs):
    index, files = producer()
    assert inputs == index['verification_inputs_sha256'], 'producing input set differs'
    assert all(sha(files[n]) == digest for n, digest in inputs.items()), 'producing source digest differs'

''' + source[end:]
source = source.replace("    assert len(result['stages']) == 4 and all(s['returncode'] == 0 for s in result['stages'])", """    assert len(result['stages']) == 4 and all(s['returncode'] == 0 for s in result['stages'])
    assert result['stages'][0]['command'][1:] == ['tools/doctor.py']
    assert result['stages'][0]['log_sha256'] == sha(files['doctor.log'])
    assert result['stages'][1]['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'test', '-p', 'test_program_tools.py']
    assert result['stages'][1]['log_sha256'] == sha(files['unit-tests.log'])""")
source = source.replace("assert len(cases) == 4 and {c.get('name') for c in cases} == GROUPS and all(not list(c) for c in cases)",
    "assert len(cases) == 4 and {c.get('name') for c in cases} == GROUPS and all(not list(c) for c in cases), 'required public group failed or skipped'")
source = source.replace("assert binary == b''.join(int(w, 16).to_bytes(4, 'little') for w in image['words'])",
    "assert binary == b''.join(int(w, 16).to_bytes(4, 'little') for w in image['words']), 'compiled binary differs from catalog'")
source = source.replace("assert run['event'] == 'push' and run['status'] == 'completed' and run['conclusion'] == 'success'",
    "assert run['event'] == 'push' and run['status'] == 'completed' and run['conclusion'] == 'success', 'program-tools workflow is incomplete'")
source = source.replace("    jobs = {job['name']: job for job in jobs['jobs']}",
    "    assert len(jobs['jobs']) == 2 and len({job['name'] for job in jobs['jobs']}) == 2\n    jobs = {job['name']: job for job in jobs['jobs']}")
source = source.replace("assert job['run_id'] == RUN and job['run_attempt'] == run['run_attempt']",
    "assert job['run_id'] == RUN and job['run_attempt'] == run['run_attempt'] and job['head_sha'] == SOURCE")
source = source.replace("    artifact_ids = {'public': 14022181491, 'windows': 14022515054}", """    assert artifacts['total_count'] == len(artifacts['artifacts'])
    assert len({a['id'] for a in artifacts['artifacts']}) == artifacts['total_count']
    artifact_ids = {}
    for kind in ('public', 'windows'):
        selected = [a for a in artifacts['artifacts'] if a['name'] == f'program-tools-{kind}-' + SOURCE]
        assert len(selected) == 1, 'missing or duplicate program archive'
        artifact_ids[kind] = selected[0]['id']
    excluded_artifacts = [a for a in artifacts['artifacts'] if a['id'] not in artifact_ids.values()]
    assert all(a['name'].startswith('KG-khangelani~protocol-emulator-asic~') and
               a['name'].endswith('.dockerbuild') for a in excluded_artifacts), 'unexpected extra CI artifact'""")
source = source.replace("assert 'sha256:' + sha(path.read_bytes()) == meta['digest']",
    "assert 'sha256:' + sha(path.read_bytes()) == meta['digest'], 'original archive digest differs'")
start = source.index("    clone = read(base / 'clean-checkout.json')")
end = source.index("    return {'schema':", start)
source = source[:start] + '''    baseline_path = 'evidence/E0046-program-toolchain/ci-0297655/'
    baseline_verification = json.loads(git('show', SOURCE + ':' + baseline_path + 'verification.json'))
    assert baseline_verification['status'] == 'PASS_G3_CLEAN_CHECKOUT_AND_CI' and baseline_verification['run_id'] == 43393826878
    baseline_archive = git('show', SOURCE + ':' + baseline_path + '14022181491.zip')
    old_identity = baseline_verification['artifacts']['public']
    assert old_identity['sha256'] == sha(baseline_archive) and old_identity['bytes'] == len(baseline_archive)
    with zipfile.ZipFile(io.BytesIO(baseline_archive)) as archive:
        assert archive.testzip() is None
        historical = {e.filename: archive.read(e) for e in archive.infolist() if not e.is_dir()}
    assert baseline_verification['archive_members']['public'] == {n: sha(raw) for n, raw in historical.items()}
    old_result = json.loads(historical['result.json'])
    assert old_result['source_commit'] == '0297655e22ded931baae483b6deff81b7c9ccffd'
    assert old_result['status'] == 'PASS_ASSEMBLER_AND_BOTH_PUBLIC_SIMULATORS'
    assert old_result['icarus']['records'] == old_result['verilator']['records']
    old_inputs, new_inputs = old_result['inputs_sha256'], public['inputs_sha256']
    assert len(old_inputs) == 351 and all(new_inputs.get(n) == h for n, h in old_inputs.items()), 'G3 producing input changed'
    additions = {n: h for n, h in new_inputs.items() if n not in old_inputs}
    assert set(additions) == {'docs/specs/g4-submission-candidate.md'}, 'unexpected source-input addition'
    assert old_result['icarus']['records'] == public['icarus']['records'], 'G3 public observations changed'
    assert all(historical['examples/' + path] == raw for path, raw in window_files.items()), 'G3 compiled artifacts changed'
    windows_log = gzip.decompress((base / 'windows-job.log.gz').read_bytes()).decode('utf-8-sig')
    assert re.search(r'Ran 20 tests in', windows_log) and re.search(r'(?m)^.*\\bOK\\s*$', windows_log)
    # The exact workflow binds clean action checkouts to the observed job/source identities.
    workflow = git('show', SOURCE + ':.github/workflows/program-tools.yaml').decode()
    assert workflow.count('uses: actions/checkout@d23441a48e516b6c34aea4fa41551a30e30af803') == 2
    assert 'build/g3-ci/workbench-image.json' in workflow and 'test_program_tools.py' in workflow
''' + source[end:]
source = source.replace("'protocol-emulator-g3-ci-audit-v1', 'status': 'PASS_G3_CLEAN_CHECKOUT_AND_CI'",
    "'protocol-emulator-g4-program-ci-audit-v1', 'status': 'PASS_G4_FRESH_PROGRAM_TOOLCHAIN_CI'")
source = source.replace("'both_simulators_and_clean_checkout_records_identical': True,\n            'windows_linux_and_clean_checkout_artifact_files_identical': len(window_files),",
    """'both_simulators_and_g3_records_identical': True,
            'windows_linux_and_g3_artifact_files_identical': len(window_files),
            'fresh_local_clone_simulation': 'NOT_RUN_HARDWARE_AND_SOFTWARE_UNCHANGED',
            'g3_continuity': {'source_commit': old_result['source_commit'], 'run_id': baseline_verification['run_id'],
                              'unchanged_verification_inputs': len(old_inputs), 'added_inputs': additions,
                              'original_public_archive_sha256': sha(baseline_archive)},
            'frozen_producer': {'sha256': producer()[0]['sha256'], 'files': len(producer()[1])},""")
source = source.replace("for kind, files in {**unpacked, 'clean-checkout': clean}.items()", "for kind, files in unpacked.items()")
source = source.replace("            'artifacts': identities, 'committed_verification_inputs': len(public['inputs_sha256']),", """            'artifacts': identities, 'committed_verification_inputs': len(public['inputs_sha256']),
            'excluded_artifacts': [{'id': a['id'], 'name': a['name'], 'bytes': a['size_in_bytes'],
                                    'sha256': a['digest'].removeprefix('sha256:'),
                                    'reason': 'Buildx auxiliary metadata; tested image identity is bound by completed job log and image inspection.'}
                                   for a in excluded_artifacts],""")
source = source.replace('Original CI archives and independent clean local clone of the committed software; unchanged G2 hardware. Program and trace identity, not a new physical or owner-learning qualification.',
    'Two original fresh CI archives from separate clean Windows/Linux action checkouts; frozen producing source and unchanged G3 input/trace/program comparison. No fresh local clone simulation, physical, analog, silicon or owner-fluency claim.')
source = source.replace("    report = audit(args.records.resolve())", """    records = args.records.resolve()
    if records == HERE:
        for line in (HERE / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
            expected, name = line.split('  ', 1)
            assert '/' not in name and '\\\\' not in name
            assert sha((HERE / name).read_bytes()) == expected, 'retained file changed: ' + name
    report = audit(records)
    if records == HERE:
        assert report == read(HERE / 'verification.json'), 'retained audit report differs'""")
source = source.replace('import subprocess\n', '')
(OUT / 'verify.py').write_bytes(source.encode('utf-8'))
(OUT / 'prepare-audit.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
compile(source, str(OUT / 'verify.py'), 'exec')
print('PREPARED_G4_AUDIT', len(source), 'bytes')
