"""Freeze canonical source blobs for standalone G4 program-tool evidence replay."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/program-tools'
SOURCE = 'ae2ac7bf800bd02d83fe62677a56bc4131e98b06'
BASE = 'evidence/E0046-program-toolchain/ci-0297655/'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
write = lambda p, value: p.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())
assert not (OUT / 'producer.json').exists()
baseline_raw = git('show', SOURCE + ':' + BASE + '14022181491.zip')
with zipfile.ZipFile(io.BytesIO(baseline_raw)) as archive:
    previous = json.loads(archive.read('result.json'))['inputs_sha256']
assert len(previous) == 351
inputs = dict(previous)
addition = 'docs/specs/g4-submission-candidate.md'
inputs[addition] = sha(git('show', SOURCE + ':' + addition))
dependencies = {
    'evidence/E0045-g2-sram-qualification/ci-default-75c1e7d/verification.json',
    BASE + '14022181491.zip', BASE + 'verification.json', BASE + 'verify.py',
}
names = sorted(set(inputs) | dependencies)
files = {}
for offset in range(0, len(names), 80):
    selected = names[offset:offset + 80]
    raw = git('archive', '--format=tar', SOURCE, '--', *selected)
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for item in archive:
            if item.isdir():
                continue
            assert item.isfile() and item.name in selected and item.name not in files
            files[item.name] = archive.extractfile(item).read()
assert set(files) == set(names)
assert all(sha(files[name]) == digest for name, digest in inputs.items())
objects = {}
for raw in git('ls-tree', '-r', '-z', SOURCE).split(b'\0'):
    if not raw:
        continue
    metadata, name = raw.split(b'\t', 1)
    mode, kind, oid = metadata.decode().split()
    name = name.decode()
    if name in files:
        assert kind == 'blob' and mode in ('100644', '100755')
        assert hashlib.sha1(b'blob ' + str(len(files[name])).encode() + b'\0' + files[name]).hexdigest() == oid
        objects[name] = oid
assert set(objects) == set(files)
with (OUT / 'producer.tar.gz').open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
write(OUT / 'producer.json', {
    'schema': 'protocol-emulator-g4-program-producing-source-v1', 'source_commit': SOURCE,
    'sha256': sha((OUT / 'producer.tar.gz').read_bytes()),
    'verification_inputs_sha256': inputs, 'files': {n: sha(raw) for n, raw in sorted(files.items())},
    'git_blob_sha1': objects, 'additional_audit_dependencies': sorted(dependencies - set(inputs)),
    'provenance': 'git archive of the exact source commit, with each canonical blob identity verified against git ls-tree; no Windows worktree text conversion.'})
(OUT / 'freeze-source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('FROZEN_CANONICAL_SOURCE', len(inputs), 'verification inputs', len(files), 'total audit dependencies',
      sum(map(len, files.values())), 'uncompressed bytes')
