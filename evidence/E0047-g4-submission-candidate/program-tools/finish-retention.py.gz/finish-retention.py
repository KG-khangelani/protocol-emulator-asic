"""Retain completed cross-platform replay observations and seal G4 program CI evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0047-g4-submission-candidate/program-tools'
IMAGE = 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())
write = lambda path, value: path.write_bytes((json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

baseline = (OUT / 'verification.json').read_bytes()
assert read(OUT / 'verification.json')['status'] == 'PASS_G4_FRESH_PROGRAM_TOOLCHAIN_CI'
for label in ('windows', 'linux'):
    path = ROOT / ('build/g4-program-replay-' + label + '-01.json')
    assert path.read_bytes() == baseline
windows = read(ROOT / 'build/g4-program-controls-windows-01/result.json')
linux = read(ROOT / 'build/g4-program-controls-linux-01/result.json')
for result in (windows, linux):
    assert result['status'] == 'PASS_FIVE_G4_PROGRAM_EVIDENCE_CONTROLS'
    assert all(c['status'] == 'PASS_REJECTED_CORRUPTION' for c in result['cases'])
assert [(c['case'], c['observed_error']) for c in windows['cases']] == [(c['case'], c['observed_error']) for c in linux['cases']]
(OUT / 'controls-result-linux.json').write_bytes((ROOT / 'build/g4-program-controls-linux-01/result.json').read_bytes())
inspect = json.loads(subprocess.check_output(['docker', 'image', 'inspect', IMAGE], cwd=ROOT))[0]
assert inspect['Os'] == 'linux' and inspect['Architecture'] == 'amd64'
write(OUT / 'replays.json', {
    'schema': 'protocol-emulator-g4-program-replays-v1', 'status': 'PASS_FROZEN_REPLAY_ON_WINDOWS_AND_PINNED_LINUX',
    'verification_sha256': sha(baseline), 'both_complete_audit_reports_byte_identical': True,
    'windows': {'python': sys.version, 'platform': platform.platform(),
                'command': 'python evidence/E0047-g4-submission-candidate/program-tools/verify.py --output build/g4-program-replay-windows-01.json',
                'exit_code': 0},
    'linux': {'requested_image': IMAGE, 'actual_image_id': inspect['Id'],
              'repo_digests': inspect['RepoDigests'], 'os': inspect['Os'], 'architecture': inspect['Architecture'],
              'command': 'python3 evidence/E0047-g4-submission-candidate/program-tools/verify.py --output build/g4-program-replay-linux-01.json',
              'exit_code': 0},
    'controls': {'windows': {'path': 'controls-result.json', 'sha256': sha((OUT / 'controls-result.json').read_bytes())},
                 'linux': {'path': 'controls-result-linux.json', 'sha256': sha((OUT / 'controls-result-linux.json').read_bytes())},
                 'cases_each': 5, 'same_observed_rejections': True, 'complete_reports_equal': windows == linux},
    'scope': 'Replays audit retained original CI artifacts and frozen source; they do not rerun simulation or physical design.'})
(OUT / 'finish-retention.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
files = sorted(p for p in OUT.iterdir() if p.is_file() and p.name != 'SHA256SUMS')
(OUT / 'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes()) + '  ' + p.name + '\n' for p in files).encode())
print('RETAINED_G4_PROGRAM_CI', len(files), 'sealed files;', 'Windows/Linux audit bytes identical;',
      'controls reports equal:', windows == linux)
