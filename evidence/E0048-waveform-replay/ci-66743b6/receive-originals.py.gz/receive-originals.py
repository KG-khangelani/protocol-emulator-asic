from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import json
import urllib.request
import zipfile

root = Path(__file__).resolve().parents[1]
capture = json.loads((root / 'build/g5-ci-capture.json').read_bytes())
target = root / 'evidence/E0048-waveform-replay/ci-66743b6'
assert not target.exists()
target.mkdir()
for name in ('run', 'jobs', 'artifacts'):
    data = json.loads(capture[name])
    (target / (name + '.json')).write_bytes((json.dumps(data, indent=2, sort_keys=True) + '\n').encode())
artifacts = json.loads(capture['artifacts'])['artifacts']
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['id'] == 14155007514
assert artifact['workflow_run']['head_sha'] == '66743b60b93508d2f00f23fa2cc2ac7db244bc3a'
url = capture['download']['file_uri']['download_url']
with urllib.request.urlopen(url, timeout=120) as response:
    raw = response.read()
assert len(raw) == artifact['size_in_bytes']
assert 'sha256:' + hashlib.sha256(raw).hexdigest() == artifact['digest']
archive_path = target / (str(artifact['id']) + '.zip')
archive_path.write_bytes(raw)
with zipfile.ZipFile(archive_path) as archive:
    names = [entry.filename for entry in archive.infolist()]
    assert len(names) == len(set(names))
    for name in names:
        p = PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name
    members = {entry.filename: {'bytes': entry.file_size, 'sha256': hashlib.sha256(archive.read(entry)).hexdigest()}
               for entry in archive.infolist() if not entry.is_dir()}
(target / 'zip-files.json').write_bytes((json.dumps(members, indent=2, sort_keys=True) + '\n').encode())
(target / 'job.log.gz').write_bytes(gzip.compress(capture['log']['content'].encode(), mtime=0))
(target / 'receive-originals.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
receipt = {'schema': 'protocol-emulator-g5-original-transport-v1', 'status': 'PASS_ORIGINAL_TRANSPORT',
           'received_utc': datetime.now(timezone.utc).isoformat(), 'artifact_id': artifact['id'],
           'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'members': len(members),
           'source_commit': artifact['workflow_run']['head_sha'], 'run_id': 43697229433}
(target / 'transport.json').write_bytes((json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode())
print(json.dumps(receipt))
