"""Retain a fresh read-only observation of the final G5 release state."""
from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'evidence/E0048-waveform-replay'
OUT = BASE / 'release-observation'
SOURCE = '022834146efcb5f388a4d6ec23b3b705a0df7ef8'
capture = json.loads((ROOT / 'build/g5-release-final-capture.json').read_bytes())
proof = json.loads((BASE / 'publication/verification.json').read_bytes())
release, latest, tag_ref = [capture[name] for name in ('release', 'latest', 'tag_ref')]
original = json.loads((BASE / 'publication/release.json').read_bytes())
tag_original = json.loads((BASE / 'publication/tag-ref.json').read_bytes())

def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

assert proof['status'] == 'PASS_G5_RELEASE_AND_PACKAGE' and proof['source_commit'] == SOURCE
assert release['id'] == latest['id'] == original['id'] == proof['release_id']
assert release['tag_name'] == latest['tag_name'] == 'v0.1.1'
assert not release['draft'] and not release['prerelease'] and not latest['draft'] and not latest['prerelease']
assert release['name'] == original['name'] and release['body'] == original['body']
notes = subprocess.check_output(['git', 'show', SOURCE + ':docs/releases/v0.1.1.md'], cwd=ROOT).decode().strip()
assert release['body'].replace('\r\n', '\n').strip().startswith(notes)
assert tag_ref == tag_original
assert len(release['assets']) == len(latest['assets']) == 22
def inventory(value):
    return {a['name']: {'id': a['id'], 'bytes': a['size'], 'sha256': a['digest'].removeprefix('sha256:')}
            for a in value['assets']}
expected = {name: {key: value[key] for key in ('id', 'bytes', 'sha256')} for name, value in proof['assets'].items()}
assert inventory(release) == inventory(latest) == inventory(original) == expected
g4 = capture['g4_release']
g4_proof = json.loads((BASE / 'g4-continuity/verification.json').read_bytes())
assert g4['id'] == g4_proof['release_id'] and g4['tag_name'] == 'v0.1.0'
assert g4['name'] == g4_proof['title'] and sha(g4['body'].encode()) == g4_proof['body_sha256']
assert inventory(g4) == {name: {'id': value['id'], 'bytes': value['size'], 'sha256': value['digest'].removeprefix('sha256:')}
                         for name, value in g4_proof['assets'].items()}
assert not OUT.exists() and not (BASE / 'release-notice.json').exists()
OUT.mkdir()
for name, value in capture.items():
    (OUT / (name + '.json.gz')).write_bytes(gzip.compress(encoded(value), mtime=0))
(OUT / 'observe-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
result = {'schema': 'protocol-emulator-g5-final-release-observation-v1',
          'status': 'PASS_G5_RELEASE_NOTICE_AND_LATEST', 'observed_utc': datetime.now(timezone.utc).isoformat(),
          'release_id': release['id'], 'source_commit': SOURCE, 'tag': 'v0.1.1', 'url': release['html_url'],
          'asset_count': 22, 'latest_stable_release': True, 'title': release['name'],
          'g4_release_unchanged': True, 'g4_assets_unchanged': 35,
          'body_sha256': sha(release['body'].encode()), 'original_notes_unchanged': True,
          'scope': 'Fresh API read confirms stable latest release, original qualified notes, unchanged tag and all verified asset identities. No post-publication title/body edit.',
          'files_sha256': {p.relative_to(BASE).as_posix(): sha(p.read_bytes()) for p in sorted(OUT.iterdir())}}
(BASE / 'release-notice.json').write_bytes(encoded(result))
print(result['status'], result['release_id'], result['asset_count'])
