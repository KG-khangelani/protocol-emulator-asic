# Triggered waveform replay (v0.1.1)

Two 20-word / 80-byte programs for interface 0x22, od128-sram-v1.
The fault program moves one rising edge by two clocks while preserving later
output transitions. Both programs explicitly release all outputs before HALT.

Build with Python 3.11 or later, using new output directories:

```
python tools/assembler.py experiments/waveform_replay/control.asm --out build/my-control
python tools/assembler.py experiments/waveform_replay/timing_fault.asm --out build/my-fault
```

`compiled/` contains the eight original qualified program artifacts. Start with
`docs/waveform-replay.md` for the pin assignment, load/readback procedure and
timing limits. `docs/programming.md` documents the assembler. The independent
literal trace checker and its tests are included; run from this bundle root:

```
python -m unittest discover -s test -p test_waveform_replay_oracle.py
```

The bundle supports standalone assembly and checker tests. Complete public-pin
simulation uses a repository checkout and the pinned workbench:
https://github.com/KG-khangelani/protocol-emulator-asic/tree/022834146efcb5f388a4d6ec23b3b705a0df7ef8

Qualification source: 66743b60b93508d2f00f23fa2cc2ac7db244bc3a
Qualification run: https://github.com/KG-khangelani/protocol-emulator-asic/actions/runs/43697229433
Release source: 022834146efcb5f388a4d6ec23b3b705a0df7ef8

The separate `g5-original-ci.zip` asset preserves the original CI transport:
two simulator runs, clean-clone reproduction and the existing G3 protocol
guard. The external manifest and `g5-SHA256SUMS` bind the downloadable assets.
This ZIP uses stored entries, fixed metadata and lexical filename order.

Hardware and physical evidence remain the stable G4 candidate:
https://github.com/KG-khangelani/protocol-emulator-asic/releases/tag/v0.1.0

This is a digital simulation example, not a physical fixture, analog glitch
generator, unrestricted timing guarantee or fabricated-chip measurement.
