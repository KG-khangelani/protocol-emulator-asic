from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = '022834146efcb5f388a4d6ec23b3b705a0df7ef8'
HELPER = '672e68aa4d388f43f2de6adf21c3c036dc72e905'
OUT = ROOT / 'evidence/E0048-waveform-replay/package-ci-43698190050'
CAPTURE = json.loads((ROOT / 'build/g5-package-ci-capture.json').read_bytes())
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

assert not OUT.exists()
OUT.mkdir()
for name in ('run','jobs','artifacts'):
    (OUT / (name+'.json')).write_bytes(encoded(json.loads(CAPTURE[name])))
run = json.loads(CAPTURE['run']); jobs = json.loads(CAPTURE['jobs']); artifacts = json.loads(CAPTURE['artifacts'])
assert run['id'] == 43698190050 and run['head_sha'] == HELPER and run['conclusion'] == 'success'
assert len(jobs['jobs']) == 1 and jobs['jobs'][0]['id'] == 132763264046
assert jobs['jobs'][0]['conclusion'] == 'success' and all(s['conclusion'] == 'success' for s in jobs['jobs'][0]['steps'])
assert len(artifacts['artifacts']) == 1
artifact = artifacts['artifacts'][0]
assert artifact['id'] == 14155561054 and artifact['workflow_run']['head_sha'] == HELPER
with urllib.request.urlopen(CAPTURE['download']['file_uri']['download_url'], timeout=120) as response:
    raw = response.read()
assert len(raw) == artifact['size_in_bytes'] and 'sha256:'+sha(raw) == artifact['digest']
(OUT / '14155561054.zip').write_bytes(raw)
log = CAPTURE['log']['content'].encode()
assert sha(raw).encode() in log and b'14155561054' in log and HELPER.encode() in log
(OUT / 'job.log.gz').write_bytes(gzip.compress(log,mtime=0))
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    names = archive.namelist(); assert len(names) == len(set(names))
    assert all(not name.startswith('/') and '..' not in Path(name).parts and '\\' not in name for name in names)
    files = {name:archive.read(name) for name in names if not name.endswith('/')}
result = json.loads(files['result.json']); request = json.loads(files['request.json'])
assert result['status'] == 'PASS_G5_LINUX_PACKAGE_AND_WINDOWS_IDENTITY'
assert result['source_commit'] == request['source_commit'] == SOURCE and result['ci_source_commit'] == HELPER
assert int(result['run_id']) == run['id'] and result['job'] == 'verification'
assert files['runner.py'] == subprocess.check_output(['git','show',HELPER+':.github/g5-linux-verification/run.py'],cwd=ROOT)
assert files['request.json'] == subprocess.check_output(['git','show',HELPER+':.github/g5-linux-verification/request.json'],cwd=ROOT)
labels = ('clone-source','checkout-source','source-head','source-status','docker-version','image-pull',
          'image-inspect-before','audit','controls','package','smoke','image-inspect-after')
for name in labels:
    receipt = json.loads(files[name+'.json'])
    assert receipt['returncode'] == 0 and receipt['log_sha256'] == sha(files[name+'.log'])
assert files['source-head.log'].decode().strip() == SOURCE and not files['source-status.log'].strip()
assert json.loads(files['checkout-source.json'])['command'] == ['git','checkout','--detach',SOURCE]
before=json.loads(files['image-inspect-before.log']); after=json.loads(files['image-inspect-after.log'])
assert before == after and len(before)==1
assert before[0]['Id']==request['image_id'] and request['image'] in before[0]['RepoDigests']
assert before[0]['Config']['Labels']['org.opencontainers.image.revision']==request['image_source']
assert before[0]['Os']=='linux' and before[0]['Architecture']=='amd64'
assert json.loads(files['g5-audit.json']) == json.loads((ROOT/'evidence/E0048-waveform-replay/ci-66743b6/verification.json').read_bytes())
controls=json.loads(files['g5-controls.json'])
assert controls['status']=='PASS_FIVE_REHASHED_CONTROLS' and len(controls['controls'])==5 and all(x['rejected'] for x in controls['controls'])
smoke=json.loads(files['smoke/result.json'])
assert smoke['status']=='PASS_G5_STANDALONE_DISTRIBUTION' and smoke['outside_repository'] and smoke['oracle_tests']==12
assert smoke['runtime']['platform'].startswith('Linux-') and smoke['release_source_commit']==SOURCE
native=ROOT/'build/g5-windows-release-0228341'
assets={}
for path in sorted(native.iterdir()):
    assert path.read_bytes() == files['assets/'+path.name], 'actual Windows/Linux asset bytes differ: '+path.name
    assets[path.name]={'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())}
assert len(assets)==4 and assets==result['assets']==request['windows_assets']
native_smoke=json.loads((ROOT/'build/g5-windows-smoke-0228341/result.json').read_bytes())
assert native_smoke['compiled_sha256']==smoke['compiled_sha256'] and native_smoke['bundle_sha256']==smoke['bundle_sha256']
assert native_smoke['outside_repository'] and native_smoke['runtime']['platform'].startswith('Windows-')
report={'schema':'protocol-emulator-g5-package-ci-audit-v1','status':'PASS_G5_WINDOWS_LINUX_PACKAGE_AND_SMOKE',
        'observed_utc':datetime.now(timezone.utc).isoformat(),'source_commit':SOURCE,'ci_source_commit':HELPER,
        'run_id':run['id'],'job_id':jobs['jobs'][0]['id'],'artifact':{'id':artifact['id'],'bytes':len(raw),'sha256':sha(raw),'members':len(files)},
        'assets':assets,'audit':'PASS_G5_RETAINED_ORIGINALS','rehashed_controls':5,
        'standalone':{'programs':2,'compiled_files':8,'oracle_tests':12,'platforms':['Windows','Linux'],'outside_repository':True},
        'runtime':result['image']}
(OUT/'verification.json').write_bytes(encoded(report))
(OUT/'windows-smoke.json').write_bytes(encoded(native_smoke))
for name in ('control.log','timing_fault.log','oracle-tests.log'):
    (OUT/('windows-'+name+'.gz')).write_bytes(gzip.compress((ROOT/'build/g5-windows-smoke-0228341'/name).read_bytes(),mtime=0))
(OUT/'retain-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
(OUT/'zip-files.json').write_bytes(encoded({name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}))
(OUT/'retention.json').write_bytes(encoded({'status':'PASS_RETAINED_PACKAGE_PROOF','files_sha256':{p.name:sha(p.read_bytes()) for p in sorted(OUT.iterdir())}}))
print(json.dumps(report))
