/* SPDX-License-Identifier: Apache-2.0 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { buildAtlas, repoRoot, sequentialRegisters } from '../tools/export_atlas.mjs';
import { failedActiveQualification } from './atlas_qualification_controls.mjs';

test('state accounting distinguishes comparisons from assignments and includes indexed writes', () => {
  const source = `input [7:0] data_in;
reg [7:0] count;
reg [127:0] valid;
reg [7:0] condition_only;
wire in_range = (data_in <= 8'd128);
always @(posedge clk) begin
  if (condition_only <= 8'd10) count <= data_in;
  valid[address[6:0]] <= 1'b1;
end`;
  assert.deepEqual(sequentialRegisters(source), [{ name: 'count', bits: 8 }, { name: 'valid', bits: 128 }]);
});

test('actual nonblocking state totals and grouping match the qualified source', () => {
  const data = buildAtlas();
  assert.equal(data.totalStateBits, data.storage.memoryBits ? 353 : 410);
  assert.deepEqual(data.modules.map((module) => module.stateBits), data.storage.memoryBits ? [0, 184, 128, 25, 16] : [0, 261, 108, 25, 16]);
  if (data.storage.memoryBits) {
    assert.deepEqual(data.storage, { logicalWords: 128, memoryBits: 8192, interfaceId: '0x22' });
    assert.equal(data.source.qualification, 'E0045');
    assert.equal(data.physical.status, 'PASS');
    assert.equal(data.relations.find((item) => item.id === 'engine-program').wire, 'prefetch_pc');
  }
  assert.equal(data.source.allSourceMatches, true);
  assert.equal(data.source.matchCount, 5);
  assert.equal(data.clockTargetHz, 50_000_000);
  assert.equal(data.tileAllocation, '8x4');
  assert.equal(data.evidence.find((item) => item.id === 'E0016').status, 'PASS');
});
test('synchronization, fetch, TX/RX and GPIO dependencies are actual named connections', () => {
  const data = buildAtlas();
  assert.equal(data.relations.find((item) => item.id === 'sync-engine').wire, 'sampled_inputs');
  assert.equal(data.relations.find((item) => item.id === 'raw-sync').from, 'top');
  assert.equal(data.relations.some((item) => item.from === 'data' && item.to === 'sync'), false);
  assert.equal(data.modules.find((item) => item.id === 'program').note.includes('Writable'), true);
});
test('changed RTL does not retain a current-source PASS', () => {
  const path = 'src/m1_engine.v';
  const source = readFileSync(resolve(repoRoot, path), 'utf8');
  const data = buildAtlas(repoRoot, { [path]: `${source}\n// retained source-drift seed\n` });
  assert.equal(data.source.allSourceMatches, false);
  assert.equal(data.evidence.find((item) => item.id === 'E0018').currentSourceMatches, false);
});
test('incorrect wiring is rejected rather than drawn as a fabricated relation', () => {
  const path = 'src/project.v';
  const source = readFileSync(resolve(repoRoot, path), 'utf8');
  assert.throws(() => buildAtlas(repoRoot, { [path]: source.replace('.sampled_in(sampled_inputs)', '.sampled_in(wrong_signal)') }), /wiring mismatch/);
});
test('missing or corrupted evidence cannot assert verified qualification', () => {
  for (const replacement of [null, '{}']) {
    const data = buildAtlas(repoRoot, { 'evidence/E0018-uart-rx-public/ci-manifest.json': replacement });
    if (data.source.qualification === 'E0018') assert.equal(data.source.evidenceIntegrity, false);
    assert.equal(data.evidence.find((item) => item.id === 'E0018').status, 'NOT_VERIFIED');
  }
});
test('archived physical evidence, owner learning and unvisualized host service remain distinct', () => {
  const data = buildAtlas();
  assert.equal(data.evidence.find((item) => item.id === 'E0010').archived, true);
  assert.equal(data.learning.m0Fluency, 'PENDING');
  assert.equal(data.deferred.status, 'MODEL NOT VISUALIZED');
  assert.equal(data.deferred.reportStatus, 'RETAINED REPORT AVAILABLE');
  assert.match(data.deferred.reportHash, /^[0-9a-f]{64}$/);
  assert.equal(data.evidence.some((item) => item.id === 'E0019'), false);
  assert.ok(data.hypotheses.every((item) => item.status === 'UNPROVEN'));
  assert.equal(JSON.stringify(data).includes('libfile_'), false);
});
test('missing host-service report does not imply retained or qualified evidence', () => {
  const data = buildAtlas(repoRoot, { 'evidence/E0019-uart-rx-host-service/README.md': null });
  assert.equal(data.deferred.reportStatus, 'RETAINED REPORT UNAVAILABLE');
  assert.equal(data.deferred.reportHash, null);
  assert.equal(data.deferred.status, 'MODEL NOT VISUALIZED');
  assert.equal(data.evidence.some((item) => item.id === 'E0019'), false);
});
test('hypothesis status comes from the ledger, not a hardcoded UI promotion', () => {
  const path = 'docs/research-ledger.md';
  const source = readFileSync(resolve(repoRoot, path), 'utf8');
  const replacement = source.replace(/^\| H1 \|.*$/m, '| H1 | altered fixture | unqualified | Not evaluated |');
  assert.equal(buildAtlas(repoRoot, { [path]: replacement }).hypotheses[0].status, 'NOT EVALUATED');
});
test('missing TX manifest cannot retain recorded TX PASS or invent tool identities', () => {
  const data = buildAtlas(repoRoot, { 'evidence/E0016-uart-tx-8n1/ci-manifest.json': null });
  const tx = data.evidence.find((item) => item.id === 'E0016');
  assert.equal(tx.status, 'NOT_VERIFIED');
  assert.deepEqual(tx.tools, []);
});
test('legacy TX qualification requires its actual retained run outcomes and cannot override explicit failure', () => {
  const path = 'evidence/E0016-uart-tx-8n1/qualification.json';
  const source = JSON.parse(readFileSync(resolve(repoRoot, path), 'utf8'));
  for (const replacement of [{ ...source, implementation_ci: 'FAIL' }, { ...source, runs: {} }]) {
    assert.equal(buildAtlas(repoRoot, { [path]: JSON.stringify(replacement) }).evidence.find((item) => item.id === 'E0016').status, 'NOT_VERIFIED');
  }
});
test('a PASS summary cannot override failed, cancelled or missing required CI outcomes', () => {
  for (const [id, folder] of [['E0016', 'E0016-uart-tx-8n1'], ['E0018', 'E0018-uart-rx-public']]) {
    const path = `evidence/${folder}/qualification.json`;
    for (const name of ['push_test', 'pull_request_test', 'push_docs']) {
      for (const outcome of ['failure', 'cancelled', undefined]) {
        const replacement = JSON.parse(readFileSync(resolve(repoRoot, path), 'utf8'));
        replacement.implementation_ci = 'PASS';
        replacement.runs[name].conclusion = outcome;
        const data = buildAtlas(repoRoot, { [path]: JSON.stringify(replacement) });
        assert.equal(data.evidence.find((item) => item.id === id).status, 'NOT_VERIFIED', `${id}/${name}/${outcome}`);
      }
    }
  }
});
test('unverified RX evidence cannot retain measured generic metrics', () => {
  for (const replacement of [null, '{}']) {
    const data = buildAtlas(repoRoot, { 'evidence/E0018-uart-rx-public/ci-manifest.json': replacement });
    assert.equal(data.genericScreen.cells, null);
    assert.equal(data.genericScreen.stateBits, null);
    assert.equal(data.genericScreen.provenance, 'NOT_VERIFIED');
    assert.equal(data.totalStateBits, data.storage.memoryBits ? 353 : 410, 'source-derived declarations remain independently inspectable');
  }
});

test('an invalid production profile cannot borrow a historical qualification', () => {
  const data = buildAtlas(repoRoot, { 'tools/production-profile.json': '{}' });
  assert.equal(data.source.allSourceMatches, false);
  assert.equal(data.source.evidenceIntegrity, false);
  assert.equal(data.physical.status, 'NOT_VERIFIED');
  assert.equal(data.evidence.find((item) => item.id === 'E0045').status, 'NOT_VERIFIED');
  assert.equal(data.genericScreen.cells, null);
});

test('a failed job in the active qualification cannot produce current-source PASS', () => {
  const control = failedActiveQualification();
  const data = buildAtlas(repoRoot, control.overrides);
  assert.equal(data.source.allSourceMatches, false);
  assert.equal(data.source.evidenceIntegrity, false);
  assert.equal(data.evidence.find((item) => item.id === control.id).status, 'NOT_VERIFIED');
  assert.equal(data.genericScreen.cells, null);
});

test('production qualification checks actual file bytes before newline normalization', (t) => {
  if (!existsSync(resolve(repoRoot, 'tools/production-profile.json'))) return t.skip('historical production profile');
  const baseline = buildAtlas();
  assert.equal(baseline.source.allSourceMatches, true);
  const profile = JSON.parse(readFileSync(resolve(repoRoot, 'tools/production-profile.json'), 'utf8'));
  assert.equal(baseline.evidence.find((item) => item.id === 'E0045').revision, profile.qualification.source_commit);
  const source = readFileSync(resolve(repoRoot, 'src/project.v'), 'utf8');
  assert.ok(!source.includes('\r'));
  const changed = buildAtlas(repoRoot, { 'src/project.v': source.replaceAll('\n', '\r\n') });
  assert.equal(changed.source.allSourceMatches, false);
  assert.equal(changed.physical.status, 'NOT_VERIFIED');
});
