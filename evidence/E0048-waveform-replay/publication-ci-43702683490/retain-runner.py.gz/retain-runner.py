"""Receive and authenticate the actual isolated G5 publication audit."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'evidence/E0048-waveform-replay'
SOURCE = '022834146efcb5f388a4d6ec23b3b705a0df7ef8'
CAPTURE = json.loads((ROOT / 'build/g5-publication-ci-capture.json').read_bytes())


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def blob(commit, name): return subprocess.check_output(['git', 'show', commit + ':' + name], cwd=ROOT)


run, jobs, artifacts = [json.loads(CAPTURE[name]) for name in ('run', 'jobs', 'artifacts')]
helper = CAPTURE['expected_helper']
assert run['head_sha'] == helper and run['head_branch'] == 'codex/g5-linux-verification'
assert run['event'] == 'push' and run['status'] == 'completed' and run['conclusion'] == 'success'
assert run['path'] == '.github/workflows/g5-linux-verification.yaml'
assert len(jobs['jobs']) == 1
job = jobs['jobs'][0]
assert job['name'] == 'verification' and job['run_id'] == run['id'] and job['head_sha'] == helper
assert job['run_attempt'] == run['run_attempt'] and job['status'] == 'completed' and job['conclusion'] == 'success'
assert all(step['conclusion'] == 'success' for step in job['steps'])
assert len(artifacts['artifacts']) == 1
artifact = artifacts['artifacts'][0]
assert artifact['name'] == 'g5-linux-proof-' + helper
assert artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == helper
out = BASE / ('publication-ci-' + str(run['id']))
publication = BASE / 'publication'
assert not out.exists() and not publication.exists(), 'preserve previous attempts'
out.mkdir()
for name, value in zip(('run', 'jobs', 'artifacts'), (run, jobs, artifacts)):
    (out / (name + '.json')).write_bytes(encoded(value))
with urllib.request.urlopen(CAPTURE['download']['file_uri']['download_url'], timeout=120) as response:
    raw = response.read()
assert len(raw) == artifact['size_in_bytes'] and 'sha256:' + sha(raw) == artifact['digest']
(out / (str(artifact['id']) + '.zip')).write_bytes(raw)
log = CAPTURE['log']['content'].encode()
assert sha(raw).encode() in log and str(artifact['id']).encode() in log and helper.encode() in log
(out / 'job.log.gz').write_bytes(gzip.compress(log, mtime=0))
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert all(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
               and '\\' not in name and ':' not in name for name in names)
    files = {name: archive.read(name) for name in names if not name.endswith('/')}
result = json.loads(files['result.json'])
request = json.loads(files['request.json'])
assert result['status'] == 'PASS_G5_PUBLICATION_IN_PINNED_LINUX'
assert result['source_commit'] == request['source_commit'] == SOURCE and result['ci_source_commit'] == helper
assert int(result['run_id']) == run['id'] and result['job'] == 'verification'
prefix = '.github/g5-linux-verification/'
assert files['runner.py'] == blob(helper, prefix + 'run.py')
assert files['request.json'] == blob(helper, prefix + 'request.json')
assert files['verify_publication.py'] == blob(helper, prefix + 'verify_publication.py')
assert sha(files['verify_publication.py']) == request['auditor_sha256']
assert files['verify_publication.py'] == blob(CAPTURE['auditor_commit'], 'evidence/E0048-waveform-replay/release-tools/verify_publication.py')
for name, digest in request['inputs_sha256'].items():
    assert files['publication/' + name] == blob(helper, prefix + 'publication-inputs/' + name)
    assert sha(files['publication/' + name]) == digest
labels = ('clone-source', 'checkout-source', 'source-head', 'source-status', 'docker-version',
          'image-pull', 'image-inspect-before', 'package', 'publication', 'image-inspect-after')
for name in labels:
    receipt = json.loads(files[name + '.json'])
    assert receipt['returncode'] == 0 and receipt['log_sha256'] == sha(files[name + '.log'])
assert files['source-head.log'].decode().strip() == SOURCE and not files['source-status.log'].strip()
assert json.loads(files['checkout-source.json'])['command'] == ['git', 'checkout', '--detach', SOURCE]
before = json.loads(files['image-inspect-before.log']); after = json.loads(files['image-inspect-after.log'])
assert before == after and len(before) == 1 and before[0]['Id'] == request['image_id']
assert request['image'] in before[0]['RepoDigests'] and before[0]['Os'] == 'linux' and before[0]['Architecture'] == 'amd64'
assert before[0]['Config']['Labels']['org.opencontainers.image.revision'] == request['image_source']
for name in ('package', 'publication'):
    command = json.loads(files[name + '.json'])['command']
    assert command[:5] == ['docker', 'run', '--rm', '--pull=never', '--init']
    assert command.count(request['image']) == 1 and command[command.index(request['image']) + 1] == 'python3'
    assert '--privileged' not in command and not any('token' in value.lower() for value in command)
    assert '--env' in command and command[command.index('--env') + 1] == 'HOME=/tmp'
    assert '--workdir' in command and command[command.index('--workdir') + 1] == '/workspace'
    assert any(value.startswith('type=bind,source=') and value.endswith(',target=/audit,readonly') for value in command)
assert json.loads(files['publication.json'])['command'][-7:] == [
    '/audit/verify_publication.py', '--repository', '/workspace', '--directory',
    '/workspace/build/g5-publication', '--assets', '/workspace/build/g5-assets']
checked = json.loads(files['publication/verification.json'])
assert sha(files['publication/verification.json']) == result['verification_sha256']
assert checked['status'] == 'PASS_G5_RELEASE_AND_PACKAGE' and checked['source_commit'] == SOURCE
assert len(checked['assets']) == 22 and len(checked['tag_workflows']) == 10
assert sum(len(item['jobs']) for item in checked['tag_workflows'].values()) == 23
assert checked['publisher_input_count'] == 361 and checked['g5_qualified_input_count'] == 366
assert checked['metadata_tests_each'] == 159 and len(checked['stages']) == 8
assert checked['standalone'] == {'programs': 2, 'compiled_files': 8, 'oracle_tests': 12, 'outside_repository': True}
for name, identity in checked['assets'].items():
    data = files['publication/downloaded/' + name]
    assert len(data) == identity['bytes'] and sha(data) == identity['sha256'] and identity['anonymous_download']
native = ROOT / 'build/g5-windows-release-0228341'
for path in native.iterdir():
    assert path.read_bytes() == files['publication/downloaded/' + path.name], 'public bytes differ from Windows package'
assert len(list(native.iterdir())) == 4
publication.mkdir()
for name, data in files.items():
    if name.startswith('publication/'):
        destination = publication / name.removeprefix('publication/')
        assert destination.resolve().is_relative_to(publication.resolve())
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
for name in ('result.json', 'request.json'):
    (out / name).write_bytes(files[name])
for name in ('runner.py', 'verify_publication.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress(files[name], mtime=0))
(out / 'retain-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(out / 'zip-files.json').write_bytes(encoded({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())}))
report = {'schema': 'protocol-emulator-g5-publication-ci-audit-v1', 'status': 'PASS_G5_PUBLICATION_RECEIPTS',
          'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': SOURCE, 'ci_source_commit': helper,
          'run_id': run['id'], 'job_id': job['id'], 'artifact': {'id': artifact['id'], 'bytes': len(raw), 'sha256': sha(raw), 'members': len(files)},
          'publication_verification_sha256': sha(files['publication/verification.json']),
          'auditor_commit': CAPTURE['auditor_commit'], 'auditor_sha256': request['auditor_sha256'],
          'audit_runtime': result['audit_runtime'], 'public_assets': 22, 'tag_workflows': 10, 'tag_jobs': 23,
          'scope': 'Actual pinned Linux execution of frozen public-download and registry audit; new-image scope is stated in publication/verification.json.'}
(out / 'verification.json').write_bytes(encoded(report))
for directory in (out, publication):
    (directory / 'retention.json').write_bytes(encoded({'status': 'PASS_RETAINED_PUBLICATION_PROOF',
        'files_sha256': {p.relative_to(directory).as_posix(): sha(p.read_bytes()) for p in sorted(directory.rglob('*')) if p.is_file()}}))
print(json.dumps(report))
