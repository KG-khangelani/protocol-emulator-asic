import argparse,gzip,hashlib,json,subprocess,urllib.request,zipfile
from pathlib import Path
from functools import lru_cache
from datetime import datetime,timezone
REPO="KG-khangelani/protocol-emulator-asic"
E=Path("evidence/E0030-timed-gpio-comparison")
BASE=Path("build/timed-remote-verification");BASE.mkdir(exist_ok=True)
def gh(*args):return subprocess.check_output(["gh",*args])
def api(path):return json.loads(gh("api",f"repos/{REPO}/{path}"))
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8",newline="\n")
@lru_cache(maxsize=None)
def git_blob_hash(commit,path):return sha(subprocess.check_output(['git','show',f'{commit}:{path}']))
def inputs(result,commit):
 for path,digest in result["input_sha256"].items():
  assert git_blob_hash(commit,path)==digest,path
def timed(result,comparison,commit):
 inputs(result,commit);inputs(comparison,commit)
 assert result["status"]=="QUALIFIED_COMPARISON" and result["selected_candidate"]=="P"
 assert result["candidate_qualification"]["P"]=="PASS"
 local=json.loads((E/"comparison/result.json").read_text(encoding="utf-8"))
 assert comparison["status"]==local["status"]=="PASS_PUBLIC_AND_GENERIC_COMPARISON_FORMAL_PENDING"
 assert comparison["measurements"]==local["measurements"]
 assert result["measurements"]==local["measurements"]
 assert comparison["reference"]==local["reference"]
 assert comparison["cross_simulator_records_identical"] and comparison["cross_variant_spi_contract_traces_identical"]
 for v in ("compact10","P","F"):
  assert comparison["sources"][v]["source_sha256"]==local["sources"][v]["source_sha256"]
  assert comparison["public"][v]==local["public"][v],v
def artifact(run_id,commit,name):
 run=api(f"actions/runs/{run_id}");assert run["head_sha"]==commit and run["conclusion"]=="success"
 a=next(a for a in api(f"actions/runs/{run_id}/artifacts")["artifacts"] if a["name"]==name)
 z=BASE/f"{run_id}.zip"
 if not z.exists():
  with z.open("wb") as f:subprocess.run(["gh","api",f"repos/{REPO}/actions/artifacts/{a['id']}/zip"],stdout=f,check=True)
 assert "sha256:"+sha(z.read_bytes())==a["digest"]
 folder=BASE/str(run_id);folder.mkdir(exist_ok=True)
 with zipfile.ZipFile(z) as archive:
  for info in archive.infolist():assert (folder/info.filename).resolve().is_relative_to(folder.resolve())
  archive.extractall(folder)
 return run,a,z,folder
def ci(run_id,commit):
 run,a,z,folder=artifact(run_id,commit,"spi-timed-gpio-"+commit)
 for line in (folder/"SHA256SUMS").read_text().splitlines():
  digest,name=line.split(maxsplit=1);assert sha((folder/name).read_bytes())==digest,name
 result=json.loads((folder/"result.json").read_text())
 comparison=json.loads((folder/"comparison/result.json").read_text());timed(result,comparison,commit)
 for name,gate in result["gates"].items():
  raw=(folder/name/"result.json").read_bytes()
  assert sha(raw)==gate["result_sha256"]
  inputs(json.loads(raw),commit)
 for v in ("compact10","P","F"):
  for sim in ("icarus","verilator"):
   p=folder/"comparison"/v/("public-"+sim)/"records"
   assert sha(gzip.decompress((p/"cases.jsonl.gz").read_bytes()))==comparison["public"][v][sim]["records_sha256"]
   for name,digest in comparison["public"][v][sim]["trace_files"].items():
    assert sha((p/name).read_bytes())==digest,name
 write(E/"remote-result.json",result)
 record={"source":commit,"run":run_id,"url":run["html_url"],"conclusion":"success",
         "artifact_id":a["id"],"artifact_zip_sha256":sha(z.read_bytes()),
         "artifact_checksums_verified":True,"all_input_hashes_match_git_blobs":True,
         "all_six_public_record_sets_and_corner_traces_match_local":True,
         "all_generic_measurements_match_local":True,"candidate_qualification":result["candidate_qualification"],
         "selected_candidate":"P","physical":"NOT_EVALUATED","checked_utc":datetime.now(timezone.utc).isoformat()}
 write(E/"remote-qualification.json",record);print(json.dumps(record,indent=2))
def prior(run_id,commit):
 run,a,z,folder=artifact(run_id,commit,"spi-sensitivity-"+commit)
 results={}
 for sub,status in (("spi-program-sensitivity","PASS"),("spi-four-mode-screen","PASS_SCOPED_SCREEN"),("spi-held-proof","PROVED_HELD_MODE0_MODE2_WITH_CHECKED_CONTROLS"),("spi-phase1-capacity","PASS_DECLARED_PHASE1_CAPACITY_SCREEN")):
  result=json.loads((folder/sub/"ci/result.json").read_text())
  assert result["status"]==status
  inputs(result,commit);results[sub]=status
 record={"source":commit,"run":run_id,"url":run["html_url"],"conclusion":"success","artifact_zip_sha256":sha(z.read_bytes()),"all_input_hashes_match_git_blobs":True,"prior_gates":results}
 write(E/"prior-spi-verification.json",record);print(json.dumps(record,indent=2))
def release(run_id,commit):
 tag="v0.1.0-alpha.4"
 run=api(f"actions/runs/{run_id}");assert run["head_sha"]==commit and run["conclusion"]=="success"
 rel=api("releases/tags/"+tag);assert rel["prerelease"] and not rel["draft"]
 folder=BASE/tag;folder.mkdir(exist_ok=True)
 subprocess.run(["gh","release","download",tag,"--repo",REPO,"--dir",str(folder),"--clobber"],check=True)
 hashes={}
 for line in (folder/"SHA256SUMS").read_text().splitlines():
  digest,name=line.split(maxsplit=1);assert name==Path(name).name
  assert sha((folder/name).read_bytes())==digest,name;hashes[name]=digest
 publication=json.loads((folder/"publication.json").read_text())
 assert publication["source_commit"]==commit and publication["ref"]=="refs/tags/"+tag
 assert publication["verification_run"]==run["html_url"]
 result=json.loads((folder/"spi-timed-gpio.json").read_text())
 comparison=json.loads((folder/"spi-timed-comparison.json").read_text());timed(result,comparison,commit)
 statuses={}
 for name,status in (("spi-sensitivity.json","PASS"),("spi-four-mode.json","PASS_SCOPED_SCREEN"),("spi-held-proof.json","PROVED_HELD_MODE0_MODE2_WITH_CHECKED_CONTROLS"),("spi-phase1-capacity.json","PASS_DECLARED_PHASE1_CAPACITY_SCREEN")):
  r=json.loads((folder/name).read_text());assert r["status"]==status;inputs(r,commit);statuses[name]=status
 for label,gate in result["gates"].items():
  raw=(folder/("spi-timed-"+label+".json")).read_bytes()
  assert sha(raw)==gate["result_sha256"];inputs(json.loads(raw),commit)
 package="kg-khangelani/protocol-emulator-asic-workbench"
 def request(url,headers=None):
  with urllib.request.urlopen(urllib.request.Request(url,headers=headers or {}),timeout=60) as response:return response.read(),dict(response.headers)
 data,_=request("https://ghcr.io/token?service=ghcr.io&scope=repository:"+package+":pull")
 token=json.loads(data)["token"]
 headers={"Authorization":"Bearer "+token,"Accept":"application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.manifest.v1+json"}
 data,returned=request("https://ghcr.io/v2/"+package+"/manifests/"+tag,headers);digest="sha256:"+sha(data)
 assert publication["image"]=="ghcr.io/"+package+"@"+digest
 assert next(v for k,v in returned.items() if k.lower()=="docker-content-digest")==digest
 manifest=json.loads(data);data,_=request("https://ghcr.io/v2/"+package+"/blobs/"+manifest["config"]["digest"],headers)
 assert "sha256:"+sha(data)==manifest["config"]["digest"]
 config=json.loads(data);assert config["architecture"]=="amd64" and config["os"]=="linux"
 assert config["config"]["Labels"]["org.opencontainers.image.revision"]==commit
 assert publication["toolchain_lock_sha256"]==sha(subprocess.check_output(["git","show",commit+":tools/workbench/toolchain.lock.json"]))
 record={"tag":tag,"url":rel["html_url"],"source":commit,"publish_run":run_id,"conclusion":"success",
         "asset_sha256_verified":hashes,"image":publication["image"],"anonymous_package_pull_manifest_verified":True,
         "image_digest_and_source_revision_verified":True,"all_input_hashes_match_git_blobs":True,
         "timed_records_and_cost_match_local":True,"candidate_qualification":result["candidate_qualification"],
         "prior_spi_gates":statuses,"physical":"NOT_EVALUATED","checked_utc":datetime.now(timezone.utc).isoformat()}
 write(E/"release-verification.json",record);print(json.dumps(record,indent=2))
p=argparse.ArgumentParser();p.add_argument("kind",choices=("ci","prior","release"));p.add_argument("run",type=int);p.add_argument("commit")
args=p.parse_args();{"ci":ci,"prior":prior,"release":release}[args.kind](args.run,args.commit)
