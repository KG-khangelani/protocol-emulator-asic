`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_load_bank;
  reg [7:0] PI_pc;
  reg [7:0] PI_prefetch_pc;
  reg [0:0] PI_load_write;
  reg [7:0] PI_data_in;
  reg [4:0] PI_byte_address;
  wire [0:0] PI_clk = clock;
  reg [0:0] PI_load_mode;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_load_length;
  reg [0:0] PI_ena;
  m1_program_store UUT (
    .load_bank(PI_load_bank),
    .pc(PI_pc),
    .prefetch_pc(PI_prefetch_pc),
    .load_write(PI_load_write),
    .data_in(PI_data_in),
    .byte_address(PI_byte_address),
    .clk(PI_clk),
    .load_mode(PI_load_mode),
    .rst_n(PI_rst_n),
    .load_length(PI_load_length),
    .ena(PI_ena)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$677  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$683  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$695  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$713  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$681  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$687  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$693  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$699  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$705  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$711  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$717  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$723  = 1'b1;
    // UUT.$past$m1_program_store.\v:153$5$0  = 1'b0;
    // UUT.$past$m1_program_store.\v:155$6$0  = 1'b0;
    // UUT.$past$m1_program_store.\v:158$9$0  = 1'b0;
    UUT._witness_.anyinit_procdff_637 = 8'b00100000;
    UUT._witness_.anyinit_procdff_638 = 4'b0001;
    UUT._witness_.anyinit_procdff_640 = 8'b00000010;
    UUT._witness_.anyinit_procdff_641 = 8'b00000001;
    UUT._witness_.anyinit_procdff_642 = 8'b00000000;
    UUT._witness_.anyinit_procdff_643 = 8'b10000001;
    UUT._witness_.anyinit_procdff_644 = 8'b00000001;
    UUT._witness_.anyinit_procdff_645 = 8'b00000000;
    UUT._witness_.anyinit_procdff_646 = 4'b0000;
    UUT._witness_.anyinit_procdff_647 = 1'b0;
    UUT._witness_.anyinit_procdff_648 = 1'b0;
    UUT.f_expected = 32'b00000000000000000000000000000000;
    UUT.f_past_valid = 1'b0;
    UUT.f_read_address = 8'b00000000;
    UUT.f_read_expected = 32'b00000000000000000000000000000000;
    UUT.f_read_lane = 2'b00;
    UUT.f_reset_seen = 1'b0;
    UUT.program_bank = 4'b0010;
    UUT.program_length = 8'b00001000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.dr_r = 32'b00000000000000000000000000000000;
    UUT.program_ready = 1'b1;
    UUT.read_address = 8'b00000000;
    UUT.read_lane = 2'b00;
    UUT.read_present = 1'b0;
    UUT.word_valid = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.word_zero = 32'b00000000000000000000000000000000;
    UUT.f_index = 7'b0000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b00000100] = 32'b00000000000000000000000000000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b00000000] = 32'b11111111000000011111111111111111;

    // state 0
    PI_load_bank = 1'b0;
    PI_pc = 8'b00000000;
    PI_prefetch_pc = 8'b00000100;
    PI_load_write = 1'b0;
    PI_data_in = 8'b00000010;
    PI_byte_address = 5'b00010;
    PI_load_mode = 1'b0;
    PI_rst_n = 1'b0;
    PI_load_length = 1'b0;
    PI_ena = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_load_bank <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_prefetch_pc <= 8'b00000100;
      PI_load_write <= 1'b1;
      PI_data_in <= 8'b00000001;
      PI_byte_address <= 5'b00010;
      PI_load_mode <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_load_length <= 1'b0;
      PI_ena <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_load_bank <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_prefetch_pc <= 8'b00000100;
      PI_load_write <= 1'b0;
      PI_data_in <= 8'b00000010;
      PI_byte_address <= 5'b00010;
      PI_load_mode <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_load_length <= 1'b1;
      PI_ena <= 1'b0;
    end

    genclock <= cycle < 2;
    cycle <= cycle + 1;
  end
endmodule
