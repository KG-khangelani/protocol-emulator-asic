`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_ena;
  reg [0:0] PI_load_length;
  reg [7:0] PI_pc;
  reg [0:0] PI_load_write;
  reg [7:0] PI_prefetch_pc;
  reg [7:0] PI_data_in;
  reg [4:0] PI_byte_address;
  reg [0:0] PI_load_bank;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_load_mode;
  wire [0:0] PI_clk = clock;
  m1_program_store UUT (
    .ena(PI_ena),
    .load_length(PI_load_length),
    .pc(PI_pc),
    .load_write(PI_load_write),
    .prefetch_pc(PI_prefetch_pc),
    .data_in(PI_data_in),
    .byte_address(PI_byte_address),
    .load_bank(PI_load_bank),
    .rst_n(PI_rst_n),
    .load_mode(PI_load_mode),
    .clk(PI_clk)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:116:execute$735  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$741  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$747  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$753  = 1'b1;
    UUT.f_expected = 32'b00000000000000000000000000000000;
    UUT.f_past_valid = 1'b0;
    UUT.f_reset_seen = 1'b0;
    UUT.f_seen_write = 1'b0;
    UUT.program_bank = 4'b0000;
    UUT.program_length = 8'b00000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.dr_r = 32'b00000000000000000000000100000000;
    UUT.program_ready = 1'b0;
    UUT.read_address = 8'b00000000;
    UUT.read_lane = 2'b00;
    UUT.read_present = 1'b0;
    UUT.word_valid = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.word_zero = 32'b00000000000000000000000000000000;
    UUT.f_index = 7'b0000001;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b00000001] = 32'b00000000000000000000000000000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b10000010] = 32'b00000000000000000000000000000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b10000000] = 32'b00000000000000000000000000000000;

    // state 0
    PI_ena = 1'b1;
    PI_load_length = 1'b0;
    PI_pc = 8'b00000000;
    PI_load_write = 1'b1;
    PI_prefetch_pc = 8'b00001000;
    PI_data_in = 8'b00000001;
    PI_byte_address = 5'b00101;
    PI_load_bank = 1'b0;
    PI_rst_n = 1'b0;
    PI_load_mode = 1'b1;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ena <= 1'b1;
      PI_load_length <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_load_write <= 1'b1;
      PI_prefetch_pc <= 8'b00001000;
      PI_data_in <= 8'b10000000;
      PI_byte_address <= 5'b00101;
      PI_load_bank <= 1'b0;
      PI_rst_n <= 1'b1;
      PI_load_mode <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_ena <= 1'b0;
      PI_load_length <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_load_write <= 1'b0;
      PI_prefetch_pc <= 8'b10000010;
      PI_data_in <= 8'b00000001;
      PI_byte_address <= 5'b00000;
      PI_load_bank <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_load_mode <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_ena <= 1'b1;
      PI_load_length <= 1'b1;
      PI_pc <= 8'b00000001;
      PI_load_write <= 1'b1;
      PI_prefetch_pc <= 8'b10000000;
      PI_data_in <= 8'b00000001;
      PI_byte_address <= 5'b00001;
      PI_load_bank <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_load_mode <= 1'b1;
    end

    // state 4
    if (cycle == 3) begin
      PI_ena <= 1'b1;
      PI_load_length <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_load_write <= 1'b1;
      PI_prefetch_pc <= 8'b00001000;
      PI_data_in <= 8'b00000001;
      PI_byte_address <= 5'b00101;
      PI_load_bank <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_load_mode <= 1'b1;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
