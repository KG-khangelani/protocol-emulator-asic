import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'build/g2-legacy-harness-02'
assert not OUT.exists()
OUT.mkdir()
source = ROOT / 'src'
hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.v')}
result = {'status': 'RUNNING', 'sources': hashes, 'scope': 'Historical production 22-group suite unchanged under explicit legacy profile', 'stages': []}
def save(): (OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
try:
    for simulator in ('icarus', 'verilator'):
        path = OUT / simulator
        path.mkdir()
        env = dict(os.environ, G2_CURRENT='no', G2_SRAM='no')
        for key in ('G2_PHYSICAL', 'G1_PHYSICAL', 'GATES', 'GENERAL_IO', 'COCOTB_TEST_FILTER', 'COCOTB_TESTCASE', 'MAKEFLAGS'):
            env.pop(key, None)
        command = ['make', '-C', 'test', 'SIM='+simulator, 'SRC_DIR='+str(source), 'SIM_BUILD='+str(path/'sim'),
                   'COCOTB_RESULTS_FILE='+str(path/'results.xml'), 'FST=', 'COCOTB_PLUSARGS=+NO_DUMP']
        start = time.monotonic()
        with (path / 'run.log').open('w') as log:
            proc = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        assert proc.returncode == 0
        root = ET.parse(path / 'results.xml').getroot()
        cases = root.findall('.//testcase')
        assert len(cases) == 22 and not any(root.findall('.//'+t) for t in ('error', 'failure', 'skipped'))
        result['stages'].append({'simulator': simulator, 'command': command, 'seconds': round(time.monotonic()-start,3), 'passed_groups':22})
        save()
    assert hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.v')}
    result['status'] = 'PASS_HISTORICAL_DEFAULT_SUITE_BOTH_SIMULATORS'
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE',error=str(error))
    raise
finally:
    save()
print(result['status'])
