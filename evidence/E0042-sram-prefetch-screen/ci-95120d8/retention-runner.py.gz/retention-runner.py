import ast, gzip, hashlib, io, json, subprocess, tarfile, zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'build/g2-sram-ci-95120d8'
out=ROOT/'evidence/E0042-sram-prefetch-screen/ci-95120d8'
out.mkdir(exist_ok=True)
assert not (out/'inputs.tar.gz').exists()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
head='95120d87c3f09b7598f362f0bb0e66772112d3f7'
jobs=json.loads((src/'jobs-final.json').read_bytes())['jobs']
artifacts=json.loads((src/'artifacts-final.json').read_bytes())['artifacts']
selected=[a for a in artifacts if a['name'].startswith('sram-')]
assert len(selected)==3
names=set()
files={}
for artifact in selected:
    name=str(artifact['id'])+'.zip'
    raw=(src/name).read_bytes()
    assert sha(raw)=='{}'.format(artifact['digest'].split(':')[1]) and len(raw)==artifact['size_in_bytes']
    (out/name).write_bytes(raw)
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        result=json.loads(archive.read('sram-ci/result.json'))
        names.update(result['inputs'])
        assert result['git_head']==head
        job=next(j for j in jobs if j['name']==f"qualify ({result['gate']})")
        log=(src/(str(job['id'])+'.log')).read_bytes()
        (out/(str(job['id'])+'.log.gz')).write_bytes(gzip.compress(log,mtime=0))
for name in ('artifacts-final.json','jobs-final.json'):
    (out/name).write_bytes((src/name).read_bytes())
names.update(['.github/workflows/sram-candidate.yaml','tools/workbench/Dockerfile',
              'tools/workbench/toolchain.lock.json','tools/workbench/requirements.lock',
              'tools/workbench.sh','tools/doctor.py',
              'evidence/E0038-shared-program-read/sources/source-manifest.json',
              'evidence/E0042-sram-prefetch-screen/candidate.json'])
for name in sorted(names):
    files[name]=subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)
reference_archive=ROOT/'evidence/E0042-sram-prefetch-screen/regression/regression.tar.gz'
reference_index=json.loads((reference_archive.parent/'archive.json').read_bytes())
assert sha(reference_archive.read_bytes())==reference_index['sha256']
for name in ('architecture/combined/icarus/records/cases.jsonl.gz',
             'od128/protocols/icarus/records/cases.jsonl.gz',
             'architecture/boundaries/od128-icarus/records/boundaries.jsonl.gz',
             'architecture/aborts/od128-icarus/records/aborts.jsonl.gz'):
    with tarfile.open(reference_archive) as archive:
        raw=archive.extractfile('references/ci/'+name).read()
    assert sha(raw)==reference_index['files']['references/ci/'+name]
    files['references/ci/'+name]=raw
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(out/'inputs.tar.gz').write_bytes(packed)
index={'head':head,'run_id':43287092840,'sha256':sha(packed),'bytes':len(packed),
       'files':{n:sha(r) for n,r in sorted(files.items())}}
(out/'inputs.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())

# Reuse the already reviewed semantic assertions on the actual CI directories.
# Drop only local-summary comparisons and unrelated historical failed attempts.
text=(ROOT/'evidence/E0042-sram-prefetch-screen/verify.py').read_text()
header=text[text.index('def functions('):text.index('\ndef main():')]
core=text[text.index("    core=read(out/'engine/result.json')"):text.index("    old=read(ROOT/")]
checks=text[text.index("    controls=read(out/'store-controls/result.json')"):text.index("    summary=")]
for label,name in [('core','engine-proof'),('controls','store-controls'),('formal','store-formal')]:
    target=f"{label}==read(HERE/'{name}.json') and "
    assert (core+checks).count(target)==1
    core=core.replace(target,'');checks=checks.replace(target,'')
checks=checks.replace("out/'inputs/run_sram_store_controls.py'","out/'inputs/experiments/i2c/run_sram_store_controls.py'")
checks=checks.replace("out/'inputs/sram_program_store.sv'","out/'inputs/test/sram_program_store.sv'")
proof='# SPDX-License-Identifier: Apache-2.0\n"""E0042 semantic proof checks, applied to the original CI files."""\nimport ast, hashlib, json, re\nread=lambda p:json.loads(p.read_bytes())\ndigest=lambda b:hashlib.sha256(b).hexdigest()\n\n'+header
proof+='\ndef check(out, candidate, old):\n'+core
proof+="    assert core['engine_sources']['gold']==old['m1_engine.v']\n    assert core['unchanged_surrounding_sources']=={n:s for n,s in old.items() if n!='m1_engine.v'}\n"
proof+=checks
proof+="    return {'engine_compared_bits':331,'engine_reset_vectors':69,'store_assertions':18,'covers':4,'faults_per_simulator':4}\n"
ast.parse(proof)
(out/'proof_checks.py').write_bytes(proof.encode())
(out/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('RETAINED_ORIGINAL_CI_ARTIFACTS',len(selected),'frozen inputs',len(files))
