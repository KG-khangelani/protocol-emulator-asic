/* SPDX-License-Identifier: Apache-2.0 */
`default_nettype none

module engine_boundary #(parameter reg [0:0] COMPACT_PHASE = 1'b1) (
    input wire clk, input wire rst_n, input wire ena,
    input wire [31:0] instruction, input wire instruction_valid,
    input wire [7:0] sampled_inputs, input wire [7:0] tx_payload,
    input wire [7:0] tx_payload_alt,
    output reg [7:0] pc, output reg [1:0] state,
    output reg [15:0] wait_left,
    output reg [7:0] gpio_value, output reg [7:0] gpio_oe,
    output wire wait_is_input_status, output wire [2:0] wait_pin_status,
    output wire wait_level_status, output wire wait_timeout_skip_status,
    output wire wait_is_shift_status,
    output wire loop_active_status, output wire [7:0] loop_remaining_status,
    output wire [7:0] loop_start_status, output wire [7:0] loop_end_status,
    output wire shift_active_status, output wire [2:0] shift_bits_done_status,
    output wire shift_msb_first_status, output wire [2:0] shift_tx_pin_status,
    output wire [2:0] shift_rx_pin_status, output wire [7:0] shift_tx_data_status,
    output wire [7:0] shift_rx_data_status,
    output wire shift_burst_status, output wire [15:0] shift_period_status,
    output wire shift_tx_slot_status,
    output wire shift_result_write, output wire [7:0] shift_result_data
);

m1_engine #(.COMPACT_PHASE(COMPACT_PHASE)) engine (.clk(clk), .rst_n(rst_n), .ena(ena), .instruction(instruction), .instruction_valid(instruction_valid), .sampled_inputs(sampled_inputs), .tx_payload(tx_payload), .tx_payload_alt(tx_payload_alt), .pc(pc), .state(state), .wait_left(wait_left), .gpio_value(gpio_value), .gpio_oe(gpio_oe), .wait_is_input_status(wait_is_input_status), .wait_pin_status(wait_pin_status), .wait_level_status(wait_level_status), .wait_timeout_skip_status(wait_timeout_skip_status), .wait_is_shift_status(wait_is_shift_status), .loop_active_status(loop_active_status), .loop_remaining_status(loop_remaining_status), .loop_start_status(loop_start_status), .loop_end_status(loop_end_status), .shift_active_status(shift_active_status), .shift_bits_done_status(shift_bits_done_status), .shift_msb_first_status(shift_msb_first_status), .shift_tx_pin_status(shift_tx_pin_status), .shift_rx_pin_status(shift_rx_pin_status), .shift_tx_data_status(shift_tx_data_status), .shift_rx_data_status(shift_rx_data_status), .shift_burst_status(shift_burst_status), .shift_period_status(shift_period_status), .shift_tx_slot_status(shift_tx_slot_status), .shift_result_write(shift_result_write), .shift_result_data(shift_result_data));
endmodule
