import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'build/g2-sram-regression-02'
OUT=ROOT/'evidence/E0042-sram-prefetch-screen/regression'
OUT.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result=json.loads((BASE/'result.json').read_bytes())
assert result['status']=='PASS_SRAM_CURRENT_BOTH_SIMULATORS'
files={}
for path in BASE.rglob('*'):
    if not path.is_file() or {'sim','__pycache__'} & set(path.relative_to(BASE).parts):
        continue
    files['run/'+path.relative_to(BASE).as_posix()]=path.read_bytes()
for name,expected in result['verification_inputs'].items():
    assert sha(files['run/inputs/'+name])==expected==sha((ROOT/name).read_bytes())
references=[
    'architecture/combined/icarus/records/cases.jsonl.gz',
    'od128/protocols/icarus/records/cases.jsonl.gz',
    'architecture/boundaries/od128-icarus/records/boundaries.jsonl.gz',
    'architecture/aborts/od128-icarus/records/aborts.jsonl.gz',
]
for name in references:
    files['references/ci/'+name]=(ROOT/'evidence/E0036-g2-store-and-ci/ci'/name).read_bytes()
# The completed --rm container disappeared before image inspection. Do not
# turn a current tag observation into a claimed identity of that past run.
files['runtime-limit.json']=(json.dumps({
    'status':'EXACT_LOCAL_CONTAINER_IMAGE_ID_NOT_CAPTURED',
    'observed_running_container_id':'9eb553e65e035785e496eb90b395a77e71945357218d3401b547df36214a8007',
    'observed_configured_image':'protocol-emulator-asic-workbench:2026-07-29',
    'inspect_result':'Container had completed and was removed before inspection.',
    'limit':'Logs identify actual simulator versions; clean CI retains same-job image/build/tool identity separately.'},indent=2)+'\n').encode()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size,entry.mode,entry.mtime=len(raw),0o644,0
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(OUT/'regression.tar.gz').write_bytes(packed)
(OUT/'archive.json').write_bytes((json.dumps({'sha256':sha(packed),'bytes':len(packed),
    'files':{n:sha(raw) for n,raw in sorted(files.items())}},indent=2)+'\n').encode())
(OUT/'result.json').write_bytes((BASE/'result.json').read_bytes())
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines=[sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
       if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files),'retained regression files;',len(packed),'archive bytes')
