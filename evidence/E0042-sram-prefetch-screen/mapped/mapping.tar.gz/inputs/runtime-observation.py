import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

out=Path(__file__).resolve().parent/'g2-sram-mapped-01'
expected='sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
ids=subprocess.check_output(['docker','ps','--filter','ancestor='+expected,'--format','{{.ID}}'],text=True).splitlines()
containers=[json.loads(subprocess.check_output(['docker','inspect',x]))[0] for x in ids]
matches=[c for c in containers if '/workspace/experiments/i2c/run_sram_mapping.py' in c['Config']['Cmd']]
assert len(matches)==1
c=matches[0]
assert c['Image']==expected and c['State']['Running']
image=json.loads(subprocess.check_output(['docker','image','inspect',expected]))[0]
result={'status':'OBSERVED_ACTIVE_MAPPING_CONTAINER','observed_utc':datetime.now(timezone.utc).isoformat(),
        'id':c['Id'],'image_id':c['Image'],'configured_image':c['Config']['Image'],
        'command':c['Config']['Cmd'],'started_at':c['State']['StartedAt'],
        'repo_digests':image['RepoDigests'],
        'pdk_volume_mounts':[m for m in c['Mounts'] if m['Destination']=='/pdk']}
(out/'runtime-observation.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(out/'inputs/runtime-observation.py').write_bytes(Path(__file__).read_bytes())
print(result['status'],result['image_id'])
