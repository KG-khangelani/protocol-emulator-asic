from collections import Counter
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT=Path('/workspace')
BASE=ROOT/'build/g2-sram-mapped-01'
NAME='RM_IHPSG13_1P_256x32_c2_bm_bist'
read=lambda p:json.loads(p.read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result=read(BASE/'result.json')
assert result['status']=='MAPPING_COMMANDS_SUCCEEDED_REQUIRES_AUDIT'
assert read(BASE/'runtime-observation.json')['image_id']=='sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
libraries=BASE/'libraries'
libraries.mkdir(exist_ok=True)
measurements={}
areas={}
library_files={}
for label in ('gold','sram'):
    step=BASE/label/'runs/mapped-screen/06-yosys-synthesis'
    extra=read(step/'extra.json')
    for name in extra['libs_synth']:
        path=Path(name)
        raw=path.read_bytes()
        library_files[name]={'sha256':sha(raw),'bytes':len(raw)}
        (libraries/(path.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
        text=raw.decode()
        cells=list(re.finditer(r'\bcell\s*\(\s*"?([^"\s)]+)"?\s*\)\s*\{',text))
        for i,cell in enumerate(cells):
            body=text[cell.end():cells[i+1].start() if i+1<len(cells) else len(text)]
            values=re.findall(r'\barea\s*:\s*([^;]+);',body)
            assert len(values)==1,cell[1]
            area=Decimal(values[0].strip())
            assert cell[1] not in areas or areas[cell[1]]==area
            areas[cell[1]]=area
    model=read(step/'tt_um_khangelani_protocol_emulator.nl.v.json')['modules']['tt_um_khangelani_protocol_emulator']
    counts=Counter(c['type'] for c in model['cells'].values())
    metrics=read(step/'state_out.json')['metrics']
    assert all(metrics[k]==0 for k in ('design__lint_error__count','design__lint_timing_construct__count',
        'design__inferred_latch__count','design__instance_unmapped__count','synthesis__check_error__count'))
    assert sum(counts.values())==metrics['design__instance__count']
    assert all(name in areas or name==NAME for name in counts)
    standard=sum(areas[n]*count for n,count in counts.items() if n!=NAME)
    assert standard==Decimal(str(metrics['design__instance__area']))
    macro_count=counts.get(NAME,0)
    assert macro_count==(1 if label=='sram' else 0)
    macro_area=Decimal('49488.4992')*macro_count
    warnings=Counter(re.findall(r'^%Warning-([^:]+):',(BASE/label/'runs/mapped-screen/01-verilator-lint/verilator-lint.log').read_text(),re.M))
    assert warnings==({'TIMESCALEMOD':106} if label=='sram' else {'UNUSEDSIGNAL':1})
    assert sum(warnings.values())==metrics['design__lint_warning__count']
    observations={'clock_is_public':None,'bist_all_zero':None,'delay_and_read_enable_high':None}
    if label=='sram':
        macro=model['cells']['store.program_memory']
        assert macro['type']==NAME and macro['connections']['A_CLK']==model['ports']['clk']['bits']
        assert macro['connections']['A_MEN']==model['ports']['rst_n']['bits']
        constants={'0':0,'1':1}
        for cell in model['cells'].values():
            if cell['type'] in ('sg13cmos5l_tiehi','sg13cmos5l_tielo'):
                val=int(cell['type']=='sg13cmos5l_tiehi')
                for port,bits in cell['connections'].items():
                    if cell['port_directions'][port]=='output':
                        for bit in bits:
                            assert bit not in constants
                            constants[bit]=val
        for port,bits in macro['connections'].items():
            if port.startswith('A_BIST'):
                assert all(constants.get(b)==0 for b in bits),port
        for port in ('A_DLY','A_REN'):
            assert all(constants.get(b)==1 for b in macro['connections'][port]),port
        assert len(macro['connections']['A_DOUT'])==len(set(macro['connections']['A_DOUT']))==32
        assert len(macro['connections']['A_ADDR'])==8 and len(macro['connections']['A_BM'])==32
        assert counts['sg13cmos5l_dfrbpq_1']==353
        observations={'clock_is_public':True,'bist_all_zero':True,'delay_and_read_enable_high':True,
                      'memory_enable_is_reset_not':True,'outputs_retained':32,'address_bits':8,'mask_bits':32}
    else:
        assert standard==Decimal('477788.2578') and sum(counts.values())==34683
        assert counts['sg13cmos5l_dfrbpq_1']==4278
    log=(step/'yosys-synthesis.log').read_text()
    assert 'Yosys 0.69' in log and '9f75ca1f9834a39a863915b5dae0c7b1e33533bc' in log
    sequential=Decimal(re.findall(r'of which used for sequential elements: ([\d.]+)',log)[-1])
    assert sequential==counts['sg13cmos5l_dfrbpq_1']*areas['sg13cmos5l_dfrbpq_1']
    measurements[label]={'metrics':metrics,'cell_types':dict(counts),'standard_cells':sum(counts.values())-macro_count,
                         'standard_area_um2':float(standard),'macro_count':macro_count,'macro_area_um2':float(macro_area),
                         'complete_mapped_footprint_um2':float(standard+macro_area),'sequential_cells':counts['sg13cmos5l_dfrbpq_1'],
                         'sequential_area_um2':float(sequential),'macro_connections':observations,'lint_warning_types':dict(warnings),
                         'netlist_sha256':sha((step/'tt_um_khangelani_protocol_emulator.nl.v').read_bytes())}
for name,item in result['macro_views'].items():
    if name.endswith('.lib'):
        path=Path(name)
        raw=path.read_bytes()
        assert sha(raw)==item['sha256']
        (libraries/(path.name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
        assert re.findall(r'\barea\s*:\s*([^;]+);',raw.decode())==['49488.4992 ']
library_files.update({n:v for n,v in result['macro_views'].items() if n.endswith('.lib')})
saving=(1-measurements['sram']['complete_mapped_footprint_um2']/measurements['gold']['complete_mapped_footprint_um2'])*100
assert saving>=20
report={'status':'PASS_MATCHED_SRAM_MAPPED_SCREEN','measurements':measurements,'libraries':library_files,
        'mapped_footprint_reduction_percent':saving,'advance':'PHYSICAL_INTEGRATION_TRIAL_REQUIRED',
        'lint_boundary':'The SRAM black-box header inherits a timescale; all 106 warnings are TIMESCALEMOD on other modules. No timing constructs, latches, width, mapping or synthesis errors. Remove the irrelevant header timescale before the separate physical trial.',
        'physical':'NOT_EVALUATED','production':'NOT_PROMOTED'}
(BASE/'verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
(BASE/'inputs/audit_g2_sram_mapping.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'status':report['status'],'footprint':{n:v['complete_mapped_footprint_um2'] for n,v in measurements.items()},'saving_percent':saving},indent=2))
