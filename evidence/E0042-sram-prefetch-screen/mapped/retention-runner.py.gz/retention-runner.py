import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'build/g2-sram-mapped-01'
OUT=ROOT/'evidence/E0042-sram-prefetch-screen/mapped'
OUT.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert json.loads((BASE/'verification.json').read_bytes())['status']=='PASS_MATCHED_SRAM_MAPPED_SCREEN'
files={}
for path in BASE.rglob('*'):
    if not path.is_file() or {'final','__pycache__'} & set(path.relative_to(BASE).parts):
        continue
    if path.suffix in ('.json','.v','.vh','.log','.abc','.sdc','.txt','.py','.md','.rpt','.gz') or path.name=='COMMANDS':
        files[path.relative_to(BASE).as_posix()]=path.read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size,entry.mode,entry.mtime=len(raw),0o644,0
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(OUT/'mapping.tar.gz').write_bytes(packed)
(OUT/'archive.json').write_bytes((json.dumps({'sha256':sha(packed),'bytes':len(packed),
    'files':{n:sha(raw) for n,raw in sorted(files.items())}},indent=2)+'\n').encode())
(OUT/'verification.json').write_bytes((BASE/'verification.json').read_bytes())
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines=[sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
       if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files),'mapped input/output files;',len(packed),'archive bytes')
