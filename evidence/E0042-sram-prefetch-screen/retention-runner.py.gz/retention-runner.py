import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/E0042-sram-prefetch-screen'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda path:json.loads(path.read_bytes())
groups={
    'candidate':ROOT/'build/g2-sram-candidate-01',
    'engine':ROOT/'build/g2-prefetch-core-proof-02',
    'store-controls':ROOT/'build/g2-sram-store-controls-01',
    'store-formal':ROOT/'build/g2-sram-store-formal-02',
    'legacy':ROOT/'build/g2-legacy-harness-02',
    'failures/full-chip-simple-first':ROOT/'build/g2-prefetch-engine-proof-01',
    'failures/full-chip-induction-first':ROOT/'build/g2-prefetch-engine-proof-02',
    'failures/engine-port-removal':ROOT/'build/g2-prefetch-core-proof-01',
    'failures/unflattened-vendor-clock':ROOT/'build/g2-sram-store-formal-01',
    'failures/regression-environment':ROOT/'build/g2-sram-regression-01',
}
assert read(groups['engine']/'result.json')['status']=='PASS_COMPOSITIONAL_NEXT_STATE_ENGINE_EQUIVALENCE'
assert read(groups['store-controls']/'result.json')['status']=='PASS_SRAM_STORE_PORTS_AND_FOUR_CHECKED_CONTROLS'
assert read(groups['store-formal']/'result.json')['status']=='PASS_ARBITRARY_LOGICAL_STORE_AND_REAL_MODEL_CONTROL'
assert read(groups['legacy']/'result.json')['status']=='PASS_HISTORICAL_DEFAULT_SUITE_BOTH_SIMULATORS'
files,omitted={},{}
suffixes={'.json','.jsonl','.v','.sv','.vh','.ys','.il','.log','.txt','.py','.md','.sby','.vcd','.smt2','.yw','.xml'}
for label,base in groups.items():
    for path in base.rglob('*'):
        if not path.is_file() or 'sim' in path.relative_to(base).parts or '__pycache__' in path.parts:
            continue
        if path.suffix not in suffixes and path.name not in ('status','PASS','FAIL','ERROR'):
            continue
        name=label+'/'+path.relative_to(base).as_posix()
        raw=path.read_bytes()
        if label.startswith('failures/full-chip') and path.suffix in ('.il','.json') and path.name!='result.json':
            omitted[name]={'sha256':sha(raw),'bytes':len(raw)}
            continue
        files[name]=raw
for name in ('experiments/i2c/run_sram_store_controls.py','test/sram_program_store.sv',
             'experiments/i2c/build_sram_candidate.py','experiments/i2c/sram_program_store.v',
             'experiments/i2c/sram_prefetch.py'):
    files['inputs/'+Path(name).name]=(ROOT/name).read_bytes()
files['legacy/runner.py']=(ROOT/'build/check_g2_legacy_sram_harness.py').read_bytes()
for name,expected in read(groups['legacy']/'result.json')['sources'].items():
    raw=(ROOT/'src'/name).read_bytes()
    assert sha(raw)==expected
    files['legacy/src/'+name]=raw
# These inputs were frozen by the SRAM regression before the historical run;
# retain them explicitly and reject any subsequent change before collection.
regression=read(ROOT/'build/g2-sram-regression-02/result.json')
for name,expected in regression['verification_inputs'].items():
    raw=(ROOT/'build/g2-sram-regression-02/inputs'/name).read_bytes()
    assert sha(raw)==expected==sha((ROOT/name).read_bytes())
    files['legacy/inputs/'+name]=raw
files['legacy/input-retention.json']=(json.dumps({'status':'INPUTS_RETAINED_AFTER_RUN',
    'origin':'Pre-existing g2-sram-regression-02 input snapshots, unchanged at collection',
    'sha256':regression['verification_inputs']},indent=2)+'\n').encode()
# Successful frozen runners bind their own input snapshots. Failed monolithic
# models are reproducible from retained sources/scripts; keep bulk hashes explicit.
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size,entry.mode,entry.mtime=len(raw),0o644,0
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(OUT/'screen.tar.gz').write_bytes(packed)
(OUT/'archive.json').write_bytes((json.dumps({'sha256':sha(packed),'bytes':len(packed),
    'files':{n:sha(v) for n,v in sorted(files.items())},'omitted_incomplete_bulk_models':omitted},indent=2)+'\n').encode())
for target,source in [('candidate.json',groups['candidate']/'manifest.json'),('engine-proof.json',groups['engine']/'result.json'),
                      ('store-controls.json',groups['store-controls']/'result.json'),('store-formal.json',groups['store-formal']/'result.json')]:
    (OUT/target).write_bytes(source.read_bytes())
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines=[sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
       if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files),'exact screen files,',len(packed),'archive bytes;',len(omitted),'incomplete bulk models indexed')
