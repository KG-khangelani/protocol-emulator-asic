from pathlib import Path
import gzip
import hashlib
import json
import subprocess
from datetime import datetime, timezone
root=Path(__file__).resolve().parents[1]
base=root/'evidence/E0046-program-toolchain'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
old_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
repairs=[]
names=['audit-runtime.json','distribution-smoke.json','packaging-platform-identity.json','retention.json']
for name in names:
    path=base/'publication'/name
    original=path.read_bytes()
    normalized=original.replace(b'\r\n',b'\n')
    assert original!=normalized and json.loads(original)==json.loads(normalized)
    committed=subprocess.check_output(['git','show',old_head+':'+path.relative_to(root).as_posix()],cwd=root)
    assert committed==normalized
    repairs.append({'path':path.relative_to(root).as_posix(),'old_working_bytes_sha256':sha(original),
                    'canonical_git_bytes_sha256':sha(normalized),'json_data_unchanged':True})
    path.write_bytes(normalized)
for name in ('run_g3_publication_audit.py','g3_distribution_smoke.py','retain_g3_publication.py','complete_g3.py','check_g3_closure.py'):
    path=root/'build'/name
    text=path.read_text(encoding='utf-8')
    text=text.replace(", encoding='utf-8')", ", encoding='utf-8', newline='\\n')")
    text=text.replace(",encoding='utf-8')", ",encoding='utf-8',newline='\\n')")
    if name=='retain_g3_publication.py':
        marker="for source, name in ((base / 'current-job.log'"
        insertion="""# Canonicalize only our Windows-generated metadata before Git seals it.
for generated_name in ('audit-runtime.json', 'distribution-smoke.json', 'packaging-platform-identity.json'):
    generated = target / generated_name
    generated.write_bytes(generated.read_bytes().replace(b'\\r\\n', b'\\n'))
"""
        assert marker in text
        text=text.replace(marker,insertion+marker)
    path.write_text(text,encoding='utf-8',newline='\n')
# Keep the exact revised producers alongside their generated records.
for source,name in (('run_g3_publication_audit.py','audit-linux-runner.py.gz'),
                    ('g3_distribution_smoke.py','distribution-smoke.py.gz'),
                    ('retain_g3_publication.py','retention-runner.py.gz')):
    (base/'publication'/name).write_bytes(gzip.compress((root/'build'/source).read_bytes(),mtime=0))
path=base/'publication/README.md'
text=path.read_text(encoding='utf-8')
text+='\nFour repository-only Windows JSON records are normalized to LF before sealing.\nTheir data is unchanged; original CI ZIPs, release assets and registry bodies\nretain their original bytes. The pre-push Git normalization issue and repair\nare recorded in ../completion-newline-correction.json.\n'
path.write_text(text,encoding='utf-8',newline='\n')
folder=base/'publication'
files=sorted(p for p in folder.iterdir() if p.name!='SHA256SUMS')
(folder/'SHA256SUMS').write_bytes(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in files).encode('utf-8'))
path=base/'completion-audit.json'
value=json.loads(path.read_bytes())
for requirement in value['requirements']:
    for reference in requirement['evidence']:
        reference['sha256']=sha((root/reference['path']).read_bytes())
path.write_bytes((json.dumps(value,indent=2)+'\n').encode('utf-8'))
(base/'completion-producer.py.gz').write_bytes(gzip.compress((root/'build/complete_g3.py').read_bytes(),mtime=0))
correction={'schema':'protocol-emulator-g3-evidence-newline-correction-v1',
            'status':'CORRECTED_BEFORE_PUSH','observed_utc':datetime.now(timezone.utc).isoformat(),
            'affected_local_commit':old_head,'records':repairs,
            'cause':'Windows text-mode JSON output used CRLF; Git normalized it to LF after working-tree checksum checks.',
            'repair':'Normalize only repository-generated metadata to LF, update dependent checksums/references and verify committed Git bytes.',
            'original_ci_and_published_assets_unchanged':True}
(base/'completion-newline-correction.json').write_bytes((json.dumps(correction,indent=2)+'\n').encode('utf-8'))
print('NORMALIZED_G3_METADATA',len(repairs),'records; original assets unchanged')

