import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
clone = Path('H:/CodexArtifacts/g3-clean-0297655')
out = ROOT / 'build/g3-ci-0297655'
source = '0297655e22ded931baae483b6deff81b7c9ccffd'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=clone).decode().strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=clone)
result = json.loads((clone / 'build/g3-clean/result.json').read_bytes())
assert result['status'] == 'PASS_ASSEMBLER_AND_BOTH_PUBLIC_SIMULATORS'
assert result['source_commit'] == source
zip_path = out / 'clean-checkout.zip'
assert not zip_path.exists()
members = {}
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    base = clone / 'build/g3-clean'
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if not path.is_file() or 'sim' in relative.parts or 'models' in relative.parts:
            continue
        raw = path.read_bytes()
        z.writestr(relative.as_posix(), raw)
        members[relative.as_posix()] = hashlib.sha256(raw).hexdigest()
inspect = subprocess.check_output(['docker', 'image', 'inspect', 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'])
(out / 'clean-image-inspect.json').write_bytes(inspect)
record = {'status': 'PASS_CLEAN_COMMITTED_CHECKOUT', 'source_commit': source,
          'clone_command': ['git', 'clone', '--no-hardlinks', '--single-branch', '--branch', 'main', str(ROOT), str(clone)],
          'clean_before_and_after': True, 'shared_git_objects': False,
          'command': 'docker run --rm --pull=never --ulimit core=0 --mount type=bind,source=H:\\CodexArtifacts\\g3-clean-0297655,target=/workspace --workdir /workspace protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909 python3 tools/run_program_examples.py --out build/g3-clean',
          'original_zip_sha256': hashlib.sha256(zip_path.read_bytes()).hexdigest(), 'members': members}
(out / 'clean-checkout.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
print(record['status'], len(members), 'retained members')
