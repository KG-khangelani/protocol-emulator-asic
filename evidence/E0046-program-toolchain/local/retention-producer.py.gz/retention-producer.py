"""Retain the original local G3 outputs, including every normalized pin trace."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / 'evidence/E0046-program-toolchain/local'
assert not out.exists()
native = ROOT / 'build/g3-public-pair'
windows = ROOT / 'build/g3-windows-artifacts'
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
result = read(native / 'result.json')
assert result['status'] == 'PASS_ASSEMBLER_AND_BOTH_PUBLIC_SIMULATORS'
assert result['icarus']['records'] == result['verilator']['records']
assert result['icarus']['cases'] == 55 and result['icarus']['expected_rejections'] == 15
assert read(windows / 'manifest.json') == read(native / 'examples/manifest.json')
compared = {}
for path in windows.rglob('*'):
    if path.is_file():
        relative = path.relative_to(windows).as_posix()
        assert path.read_bytes() == (native / 'examples' / relative).read_bytes()
        compared[relative] = sha(path.read_bytes())
assert len(compared) == 53
receipt_path = ROOT / 'build/g3-software-check/receipts/check.json'
receipt = read(receipt_path)
assert receipt['status'] == 'PASS'
check_log = (ROOT / receipt['directory'] / 'run.log').read_bytes()
count = sum(map(int, re.findall(rb'^Ran (\d+) tests? in ', check_log, flags=re.MULTILINE)))
assert count == 147
out.mkdir(parents=True)
members = {}
for name, folder in (('public-pair', native), ('windows-artifacts', windows)):
    packed = out / (name + '.zip')
    members[name] = {}
    with zipfile.ZipFile(packed, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(folder.rglob('*')):
            relative = path.relative_to(folder)
            if not path.is_file() or 'sim' in relative.parts or 'models' in relative.parts:
                continue
            raw = path.read_bytes()
            archive.writestr(relative.as_posix(), raw)
            members[name][relative.as_posix()] = sha(raw)
(out / 'check.json').write_bytes(receipt_path.read_bytes())
(out / 'check.log.gz').write_bytes(gzip.compress(check_log, mtime=0))
(out / 'archive-members.json').write_bytes((json.dumps(members, indent=2) + '\n').encode())
(out / 'platform-artifact-equality.json').write_bytes((json.dumps(compared, indent=2) + '\n').encode())
(out / 'retention-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
report = {'status': 'PASS_LOCAL_G3_TOOLCHAIN', 'repository_tests': count,
          'assembler_tests': 20, 'examples': 13, 'public_cases_per_simulator': 55,
          'expected_rejections_per_simulator': 15, 'all_simulator_records_identical': True,
          'windows_linux_identical_artifact_files': len(compared),
          'production_guard_status': result['production']['status'],
          'scope': 'Local working-tree implementation before its cohesive commit. Original byte-bound inputs and complete outputs retained; clean committed checkout/CI qualification is a separate required gate.'}
(out / 'result.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
files = sorted(out.iterdir())
(out / 'SHA256SUMS').write_text(''.join(sha(path.read_bytes()) + '  ' + path.name + '\n' for path in files), encoding='utf-8', newline='\n')
print(report['status'],count,'repository tests,',sum(len(v) for v in members.values()),'retained archive members')
