# SPDX-License-Identifier: Apache-2.0
"""Run only the standalone assembler and sources extracted from the release ZIP."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
source = '33e5e9b286d63317c24eec85ffb0d9ea75f0f8ad'
archive_path = root / 'build/g3-release-assets' / source / 'g3-program-toolchain.zip'
base = root / 'build/g3-distribution-smoke'
assert not base.exists()
base.mkdir()
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for entry in archive.infolist():
        path = (base / entry.filename).resolve()
        assert path.is_relative_to(base) and not entry.is_dir()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(archive.read(entry))
catalog = json.loads((base / 'programs/od128-sram-v1/examples.json').read_bytes())
cases = []
for example in catalog['examples']:
    name = example['name']
    command = [sys.executable, 'tools/assembler.py', 'programs/od128-sram-v1/' + example['file'], '--out', 'build/' + name]
    result = subprocess.run(command, cwd=base, capture_output=True, encoding='utf-8', newline='\n')
    assert result.returncode == 0, result.stderr
    actual = {p.name: p.read_bytes() for p in (base / 'build' / name).iterdir()}
    expected = {p.name: p.read_bytes() for p in (base / 'compiled' / name).iterdir()}
    assert actual == expected and len(actual) == 4
    cases.append({'name': name, 'command': command, 'returncode': result.returncode,
                  'stdout': result.stdout, 'stderr': result.stderr,
                  'identical_files_sha256': {n: hashlib.sha256(raw).hexdigest() for n, raw in actual.items()}})
invalid = base / 'invalid.asm'
invalid.write_text('.target od128-sram-v2\nHALT\n', encoding='utf-8', newline='\n')
command = [sys.executable, 'tools/assembler.py', 'invalid.asm', '--out', 'build/rejected']
bad = subprocess.run(command, cwd=base, capture_output=True, encoding='utf-8', newline='\n')
assert bad.returncode == 2 and 'invalid.asm:1: error:' in bad.stderr
assert not (base / 'build/rejected').exists()
record = {'schema': 'protocol-emulator-g3-distribution-smoke-v1',
          'status': 'PASS_STANDALONE_DISTRIBUTION', 'source_commit': source,
          'observed_utc': datetime.now(timezone.utc).isoformat(),
          'archive_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(),
          'python': sys.version, 'examples': len(cases), 'identical_generated_files': len(cases) * 4,
          'cases': cases, 'invalid_target_control': {'command': command, 'returncode': bad.returncode, 'stderr': bad.stderr,
                                                   'output_directory_absent': True},
          'scope': 'Standalone CLI rebuild from only released ZIP members; no repository imports or simulator qualification.'}
(root / 'build/g3-distribution-smoke.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(record['status'], record['examples'], 'examples', record['identical_generated_files'], 'identical files')

