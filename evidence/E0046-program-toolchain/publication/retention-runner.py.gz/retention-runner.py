# SPDX-License-Identifier: Apache-2.0
"""Retain original alpha.7 audit inputs and independently obtained publication results."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--directory', type=Path, required=True)
args = parser.parse_args()
base = args.directory.resolve()
assert base.is_relative_to((ROOT / 'build').resolve())
target = ROOT / 'evidence/E0046-program-toolchain/publication'
assert not target.exists()
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
result = read(base / 'release-verification.json')
assert result['status'] == 'PASS_G3_RELEASE_AND_PACKAGE'
assert result['source_commit'] == '33e5e9b286d63317c24eec85ffb0d9ea75f0f8ad'
assert len(result['assets']) == 23 and len(result['tag_workflows']) == 9
platform = read(ROOT / 'build/g3-package-platform-identity.json')
smoke = read(ROOT / 'build/g3-distribution-smoke.json')
assert platform['status'] == 'PASS_WINDOWS_LINUX_PACKAGE_IDENTITY'
assert smoke['status'] == 'PASS_STANDALONE_DISTRIBUTION'
assert platform['source_commit'] == smoke['source_commit'] == result['source_commit']
assert smoke['examples'] == 13 and smoke['identical_generated_files'] == 52
for name, meta in platform['files'].items():
    assert result['assets'][name]['sha256'] == meta['sha256']
assert smoke['archive_sha256'] == result['assets']['g3-program-toolchain.zip']['sha256']
target.mkdir()
files = ['run.json', 'jobs.json', 'artifacts.json', 'release.json', 'tag-ref.json', 'tag-object.json',
         'tag-commit.json', 'tag-workflows.json', 'registry-manifest.json', 'registry-config.json',
         'release-verification.json', 'zip-files.json', 'audit-runtime.json']
for optional in ('registry-linux-amd64.json',):
    if (base / optional).exists():
        files.append(optional)
files.append(str(result['publication_artifact_id']) + '.zip')
for name in files:
    shutil.copyfile(base / name, target / name)
for path in sorted((base / 'downloaded').iterdir()):
    if path.name.startswith('g3-') or path.name in ('publication.json', 'production-profile.json'):
        shutil.copyfile(path, target / path.name)
shutil.copyfile(base / 'downloaded/SHA256SUMS', target / 'workbench-SHA256SUMS')
shutil.copyfile(ROOT / 'build/g3-package-platform-identity.json', target / 'packaging-platform-identity.json')
shutil.copyfile(ROOT / 'build/g3-distribution-smoke.json', target / 'distribution-smoke.json')
# Canonicalize only our Windows-generated metadata before Git seals it.
for generated_name in ('audit-runtime.json', 'distribution-smoke.json', 'packaging-platform-identity.json'):
    generated = target / generated_name
    generated.write_bytes(generated.read_bytes().replace(b'\r\n', b'\n'))
for source, name in ((base / 'current-job.log', 'current-job.log.gz'),
                     (base / 'audit-linux.log', 'audit-linux.log.gz'),
                     (ROOT / 'build/g3_distribution_smoke.py', 'distribution-smoke.py.gz'),
                     (ROOT / 'build/prepare_g3_publication_audit.py', 'prepare-auditor.py.gz'),
                     (ROOT / 'build/run_g3_publication_audit.py', 'audit-linux-runner.py.gz'),
                     (Path(__file__), 'retention-runner.py.gz')):
    (target / name).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
identity = {'schema': 'protocol-emulator-g3-publication-retention-v1',
            'status': 'PASS_RETAINED_PUBLICATION',
            'observed_utc': datetime.now(timezone.utc).isoformat(),
            'release_source_commit': result['source_commit'],
            'publication_verification_sha256': sha(target / 'release-verification.json'),
            'auditor_sha256': sha(ROOT / 'evidence/E0046-program-toolchain/release-tools/verify_publication.py'),
            'packager_sha256': sha(ROOT / 'evidence/E0046-program-toolchain/release-tools/package.py'),
            'tag_workflows': len(result['tag_workflows']),
            'tag_jobs': sum(len(r['jobs']) for r in result['tag_workflows'].values()),
            'assets_verified': len(result['assets']),
            'bundle_members_verified': result['bundle_members_verified'],
            'scope': 'Post-publication verification; separate from the immutable release commit.'}
(target / 'retention.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
(target / 'README.md').write_text(f"""# Alpha.7 publication verification

Release {result['tag']} uses source {result['source_commit']}.
All nine tag workflows and their {identity['tag_jobs']} jobs pass. The original
publication ZIP contains {result['publication_original_zip_files']} members;
all 351 producing inputs match the clean G3 qualification. Its eight default
stages, both thirty-group public suites, current/historical formal checks and
two fresh 147-test repository checks pass semantic/source audit. The preserved
historical SPI gates also pass; their generic P selection does not supersede
G1's separate physical rejection.

All 23 actual release assets were downloaded anonymously into a new directory.
GitHub sizes/digests, both checksum lists and the prepared/original CI bytes
agree. The toolchain ZIP has 73 checked members: eighteen committed source
files, 53 identical Windows/Linux/clean-clone compiled artifacts, its README
and internal manifest. Both original G3 CI ZIPs are byte-identical. Windows
and Linux packaging produce identical five-file downloads. Running only the
extracted distribution reassembles all thirteen examples into the same 52
per-example files and rejects an invalid target without creating output.

The public registry manifest and configuration bodies match their digests.
Version/source tags, Linux amd64 configuration and actual tested image identity
match the release. Every layer accepts anonymous HEAD with the expected size.
Layer bodies were not downloaded; no new physical run is claimed.

The [auditor](../release-tools/verify_publication.py) is identified by
retention.json. To repeat, copy these API files and the original publication ZIP
to a new directory under build/, decompress current-job.log.gz there, preserve
or reproduce the five package assets under build/g3-release-assets/<source>,
then run the auditor in the pinned Linux workbench with --directory pointing
to that fresh directory. It refuses existing extraction/download directories.
The auditor needs Git history containing the release and G3 qualification.
It rechecks source/semantic identities and live anonymous downloads/registry
access. audit-runtime.json records the actual immutable local image used.

This is a separate follow-up to the immutable release, which cannot contain its
own completed publication proof. G2's twenty physical inputs, alpha.6 archives,
G1/P/M0 history and protocol/electrical/owner-learning limits remain unchanged.
G4 submission readiness is separate.
""", encoding='utf-8', newline='\n')
files = sorted(p for p in target.iterdir() if p.is_file())
(target / 'SHA256SUMS').write_text(''.join(sha(p) + '  ' + p.name + '\n' for p in files), encoding='utf-8', newline='\n')
print('RETAINED_G3_PUBLICATION', len(files), 'sealed files', identity['tag_jobs'], 'jobs')

