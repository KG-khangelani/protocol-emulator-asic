# SPDX-License-Identifier: Apache-2.0
"""Run the release audit in the pinned workbench, retaining its exact invocation."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--directory', type=Path, required=True)
args = parser.parse_args()
base = args.directory.resolve()
assert base.is_relative_to((root / 'build').resolve())
image = 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
relative = base.relative_to(root).as_posix()
command = ['docker', 'run', '--rm', '--pull=never', '--init', '--env', 'HOME=/tmp',
           '--mount', 'type=bind,source=' + str(root) + ',target=/workspace',
           '--workdir', '/workspace', image, 'python3',
           'evidence/E0046-program-toolchain/release-tools/verify_publication.py',
           '--directory', relative]
log = base / 'audit-linux.log'
assert not log.exists()
inspected = json.loads(subprocess.check_output(['docker', 'image', 'inspect', image], cwd=root))
assert len(inspected) == 1
started = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
record = {'schema': 'protocol-emulator-g3-publication-audit-runtime-v1',
          'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
          'elapsed_seconds': time.monotonic() - start, 'command': command,
          'returncode': result.returncode, 'image': image,
          'image_id': inspected[0]['Id'], 'os': inspected[0]['Os'],
          'architecture': inspected[0]['Architecture'],
          'repo_digests': inspected[0]['RepoDigests'],
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
(base / 'audit-runtime.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(log.read_text(encoding='utf-8')[-7000:])
raise SystemExit(result.returncode)

