from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / 'evidence/E0045-g2-sram-qualification/release-tools/verify_publication.py').read_text(encoding='utf-8')
source = '# SPDX-License-Identifier: Apache-2.0\n' + source
source = source.replace('import gzip\n', 'import gzip\nimport importlib.util\nimport io\n')
source = source.replace("TAG = 'v0.1.0-alpha.6'", "TAG = 'v0.1.0-alpha.7'")
source = source.replace("'build/g2-release-assets'", "'build/g3-release-assets'")
start, end = source.index("g2 = read(local"), source.index("sys.path.insert(0, str(inputs))")
source = source[:start] + """g3 = read(local / 'g3-toolchain.json')
assert g3['release_source_commit'] == SOURCE and g3['tag'] == TAG
frozen = ROOT / 'evidence/E0046-program-toolchain/ci-0297655'
spec = importlib.util.spec_from_file_location('g3_frozen_audit', frozen / 'verify.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
checked = audit.audit(frozen)
assert checked == read(frozen / 'verification.json')
assert sha(frozen / 'verification.json') == g3['qualification_record_sha256']
public = audit.zip_files(frozen / '14022181491.zip')
windows = audit.zip_files(frozen / '14022515054.zip')
assert g3['qualification_source_commit'] == audit.SOURCE and g3['qualification_run_id'] == audit.RUN
index = {'files': json.loads(public['result.json'])['inputs_sha256']}
assert len(index['files']) == g3['verification_inputs_unchanged'] == 351
inputs = base / 'inputs'
assert not inputs.exists()
names = sorted(index['files'])
# Extract the release's canonical Git bytes, comparing each with qualified G3 inputs.
for offset in range(0, len(names), 100):
    selected = names[offset:offset + 100]
    packed = git('archive', '--format=tar', SOURCE, '--', *selected)
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(packed)) as archive:
        for entry in archive:
            if entry.isdir():
                continue
            assert entry.isfile() and entry.name in selected and entry.name not in seen
            seen.add(entry.name)
            path = (inputs / entry.name).resolve()
            assert path.is_relative_to(inputs)
            raw = archive.extractfile(entry).read()
            assert raw_sha(raw) == index['files'][entry.name], entry.name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
    assert seen == set(selected)
""" + source[end:]
source = source.replace("production == normal['production'] == g2['production']", "production == checked['production'] == g3['production']")
source = source.replace('== 127', '== 147').replace("'metadata_tests_each': 127", "'metadata_tests_each': 147")
source = source.replace("'g2-sram-SHA256SUMS'", "'g3-SHA256SUMS'")
start, end = source.index("assert sha(files / 'production-profile.json')"), source.index("source_hashes = {}")
source = source[:start] + """assert sha(files / 'production-profile.json') == production['profile_sha256']
assert read(files / 'g3-toolchain.json') == g3
for name, asset in g3['artifacts'].items():
    assert sha(files / name) == asset['sha256'] and (files / name).stat().st_size == asset['bytes']
assert (files / 'g3-public-programs.zip').read_bytes() == (frozen / '14022181491.zip').read_bytes()
assert (files / 'g3-windows-programs.zip').read_bytes() == (frozen / '14022515054.zip').read_bytes()
bundle = audit.zip_files(files / 'g3-program-toolchain.zip')
assert {name: raw_sha(raw) for name, raw in bundle.items()} == g3['bundle_members_sha256']
assert len(bundle) == 73 and len(g3['source_members_sha256']) == 18
assert len(g3['compiled_members_sha256']) == len(windows) == 53
for name, digest in g3['source_members_sha256'].items():
    assert raw_sha(bundle[name]) == digest == raw_sha(git('show', SOURCE + ':' + name))
for name, digest in g3['compiled_members_sha256'].items():
    assert bundle['compiled/' + name] == windows[name] and raw_sha(windows[name]) == digest
internal = json.loads(bundle['g3-toolchain.json'])
assert internal == {k: v for k, v in g3.items() if k not in ('artifacts', 'bundle_members_sha256')}
physical = read(inputs / 'tools/production-profile.json')['qualification']
""" + source[end:]
start = source.index("result = {'schema':")
source = source[:start] + """tag_records = read(base / 'tag-workflows.json')
tag_runs = tag_records['runs']
expected_workflows = {'test', 'docs', 'atlas', 'i2c-general', 'sram-candidate',
                      'spi-program-sensitivity', 'spi-timed-gpio', 'program-tools', 'publish'}
assert len(tag_runs) == len(expected_workflows) and {r['name'] for r in tag_runs} == expected_workflows
tag_jobs = {}
for tagged in tag_runs:
    assert tagged['head_sha'] == SOURCE and tagged['head_branch'] == TAG and tagged['event'] == 'push'
    assert tagged['status'] == 'completed' and tagged['conclusion'] == 'success'
    items = tag_records['jobs'][str(tagged['id'])]['jobs']
    assert items and all(j['run_id'] == tagged['id'] and j['run_attempt'] == tagged['run_attempt'] for j in items)
    assert all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in items)
    assert all(s['conclusion'] in ('success', 'skipped') for j in items for s in j['steps'])
    tag_jobs[tagged['name']] = {'run_id': tagged['id'], 'jobs': {j['name']: j['id'] for j in items},
                               'conclusion': 'success'}
assert tag_jobs['publish']['run_id'] == run['id']
result = {'schema': 'protocol-emulator-g3-release-verification-v1', 'status': 'PASS_G3_RELEASE_AND_PACKAGE',
          'observed_utc': datetime.now(timezone.utc).isoformat(), 'tag': TAG, 'release_id': release['id'],
          'url': release['html_url'], 'source_commit': SOURCE, 'physical_source_commit': physical['source_commit'],
          'publish_run': run['id'], 'publication_job_id': job['id'], 'publication_artifact_id': meta['id'],
          'publication_original_zip_sha256': sha(original), 'publication_original_zip_files': len(zip_members),
          'assets': downloaded, 'g3_original_ci_archives_verified': 2,
          'source_bundle_files_identical_to_release_git_blobs': 18,
          'compiled_artifacts_identical_to_original_windows_linux_and_clean_clone': 53,
          'bundle_members_verified': len(bundle),
          'verification_input_files_unchanged_from_clean_G3_CI': len(index['files']),
          'qualification_source_commit': audit.SOURCE, 'qualification_run_id': audit.RUN,
          'publication': publication, 'production_stages': stages, 'metadata_check_executions': 2, 'metadata_tests_each': 147,
          'verified_spi_input_hashes': source_hashes, 'prior_spi_gates': prior, 'timed_gate_count': len(timed['gates']),
          'timed_generic_selection': 'P', 'timed_measurements_and_record_hashes_match_e0030': True,
          'image': publication['image'], 'verified_tag_digests': tag_digests, 'manifest_digest': digest,
          'linux_amd64_manifest_digest': child_digest, 'config_digest': manifest['config']['digest'],
          'anonymous_layer_heads': layers, 'tag_workflows': tag_jobs,
          'registry_verification_scope': 'Manifest/config bodies downloaded and hashed; all layer read permissions and sizes checked by anonymous HEAD, without downloading layer bodies.',
          'scope': 'Alpha.7 assets, standalone toolchain, exact version/source/image identity, complete normal-command release verification and preserved historical gates. Physical qualification remains the original G2 E0045 run with identical production inputs. No silicon, analog compliance, measured Fmax, unrestricted interoperability, final-submission or owner-fluency claim.'}
write(base / 'release-verification.json', result)
print(json.dumps({'status': result['status'], 'assets': len(downloaded), 'bundle_members': len(bundle),
                  'publication_files': len(zip_members), 'image': publication['image'], 'layer_heads': len(layers),
                  'tag_workflows': len(tag_jobs)}, indent=2))
"""
assert 'g2[' not in source and 'normal[' not in source
target = root / 'evidence/E0046-program-toolchain/release-tools/verify_publication.py'
assert not target.exists()
compile(source, str(target), 'exec')
target.write_text(source, encoding='utf-8', newline='\n')
print('Created', target.name, len(source.splitlines()), 'lines')

