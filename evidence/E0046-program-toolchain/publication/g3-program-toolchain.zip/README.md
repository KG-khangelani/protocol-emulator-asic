# G3 program toolchain (v0.1.0-alpha.7)

Source: 33e5e9b286d63317c24eec85ffb0d9ea75f0f8ad
Qualified interface: 0x22 / od128-sram-v1 / 128 words.

`compiled/` contains thirteen ready-to-inspect program binaries, JSON images,
timing listings and public load/readback plans. `programs/` contains readable
sources and their frozen reference words. Compile a source with Python 3.11+:

```
python tools/assembler.py programs/od128-sram-v1/uart_tx.asm --out build/my-uart
```

Use a new output directory. See `docs/programming.md` and the example README
for pin ownership, UART host service, SPI input hold and I2C assumptions. This
small download contains the standalone assembler and prepared artifacts; full
simulation uses a checkout of the repository and its pinned workbench:

https://github.com/KG-khangelani/protocol-emulator-asic/tree/33e5e9b286d63317c24eec85ffb0d9ea75f0f8ad

The original Windows and Linux CI ZIPs are separate release assets. All 351
producing inputs are unchanged from qualified source 0297655e22ded931baae483b6deff81b7c9ccffd; compiled
files match both CI platforms and the clean-checkout replay. Hardware remains
the G2-qualified alpha.6 core, with its original physical archives retained at:

https://github.com/KG-khangelani/protocol-emulator-asic/releases/tag/v0.1.0-alpha.6

This ZIP stores uncompressed entries with fixed metadata for deterministic
packaging. Its internal manifest identifies every source and compiled member;
the separate release manifest/checksums bind the actual downloadable ZIPs.
