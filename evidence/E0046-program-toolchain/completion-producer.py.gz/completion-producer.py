# SPDX-License-Identifier: Apache-2.0
"""Close G3 only after its original qualification and publication audits pass."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence/E0046-program-toolchain'
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
ci = read(EVIDENCE / 'ci-0297655/verification.json')
publication = read(EVIDENCE / 'publication/release-verification.json')
retention = read(EVIDENCE / 'publication/retention.json')
assert ci['status'] == 'PASS_G3_CLEAN_CHECKOUT_AND_CI'
assert publication['status'] == 'PASS_G3_RELEASE_AND_PACKAGE'
assert retention['status'] == 'PASS_RETAINED_PUBLICATION'
assert ci['source_commit'] == publication['qualification_source_commit']
assert ci['run_id'] == publication['qualification_run_id']
assert ci['examples'] == 13 and ci['public_cases_each'] == 55 and ci['expected_rejections_each'] == 15
assert ci['assembler_tests'] == 20 and len(publication['assets']) == 23
assert len(publication['tag_workflows']) == 9 and publication['metadata_tests_each'] == 147
for folder in (EVIDENCE / 'ci-0297655', EVIDENCE / 'publication'):
    for line in (folder / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        path = (folder / name).resolve()
        assert path.is_relative_to(folder) and sha(path.read_bytes()) == digest
with zipfile.ZipFile(EVIDENCE / 'ci-0297655/14022181491.zip') as archive:
    inputs = json.loads(archive.read('result.json'))['inputs_sha256']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
names = sorted(inputs)
for offset in range(0, len(names), 100):
    selected = names[offset:offset + 100]
    packed = subprocess.check_output(['git', 'archive', '--format=tar', head, '--', *selected], cwd=ROOT)
    seen = {}
    with tarfile.open(fileobj=io.BytesIO(packed)) as archive:
        for entry in archive:
            if entry.isdir():
                continue
            assert entry.isfile() and entry.name in selected and entry.name not in seen
            seen[entry.name] = sha(archive.extractfile(entry).read())
    assert seen == {name: inputs[name] for name in selected}
assert len(inputs) == 351
def refs(*paths):
    return [{'path': path, 'sha256': sha((ROOT / path).read_bytes())} for path in paths]
requirements = [
    {'requirement': 'Small versioned assembler: readable instructions, symbols, capacity checks, deterministic encoding and useful diagnostics.',
     'status': 'PASS', 'evidence': refs('tools/assembler.py', 'test/test_program_tools.py',
                                       'evidence/E0046-program-toolchain/ci-0297655/verification.json',
                                       'evidence/E0046-program-toolchain/publication/distribution-smoke.json'),
     'detail': '20 acceptance tests cover fixed words, invalid input, CLI behavior and boundary cases. 13 independent reference programs match; 53 generated files agree across Windows, Linux CI and a clean clone. Standalone distribution rebuild matches all 52 per-example files and rejects an invalid target.'},
    {'requirement': 'Inspectable cycle/schedule listing with explicit timing assumptions.',
     'status': 'PASS', 'evidence': refs('docs/programming.md', 'docs/specs/g3-program-toolchain.md',
                                       'test/test_program_tools.py',
                                       'evidence/E0046-program-toolchain/publication/g3-toolchain.json'),
     'detail': 'Named operand/source listings expose instruction spacing, fixed loop dispatch positions, loaded destinations and conditional waits. Independent UART/SPI timing checks pass. Input-dependent and backward branches do not invent a finite total; host-service, input-hold and digital I2C assumptions remain explicit.'},
    {'requirement': 'Documented public-pin loading, readback and execution plus versioned UART, SPI and I2C examples.',
     'status': 'PASS', 'evidence': refs('docs/programming.md', 'programs/od128-sram-v1/README.md',
                                       'programs/od128-sram-v1/examples.json', 'test/test_program_examples_public.py',
                                       'evidence/E0046-program-toolchain/ci-0297655/verification.json'),
     'detail': 'Actual interface 0x22 loading/readback covers bank boundaries and 128 words, expected interface/readback rejection before run, payloads, disabled flush and reload. Thirteen examples preserve G2 words: UART TX/bounded RX, four SPI modes in both orders and three I2C transaction types.'},
    {'requirement': 'From a clean clone, build examples and reproduce public-pin traces with pinned tools and independent oracles.',
     'status': 'PASS', 'evidence': refs('evidence/E0046-program-toolchain/ci-0297655/clean-checkout.json',
                                       'evidence/E0046-program-toolchain/ci-0297655/verification.json',
                                       'evidence/E0046-program-toolchain/ci-0297655/verify.py',
                                       '.github/workflows/program-tools.yaml'),
     'detail': 'Independent no-hardlinks clone starts and ends clean. Both local clone simulators and clean committed-source CI reproduce 55 cases each with 15 expected rejections and identical normalized observations. Original archives, JUnit/logs, all 351 inputs and actual image identities pass retained audit.'},
    {'requirement': 'Publish the warranted milestone, verify public downloads and image identity, preserve qualified hardware and history.',
     'status': 'PASS', 'evidence': refs('evidence/E0046-program-toolchain/publication/release-verification.json',
                                       'evidence/E0046-program-toolchain/publication/retention.json',
                                       'evidence/E0046-program-toolchain/publication/packaging-platform-identity.json',
                                       'tools/production-profile.json'),
     'detail': 'Alpha.7: 23 anonymous downloads, 73 verified bundle members, both original G3 CI ZIPs, byte-identical Windows/Linux packages, all nine tag workflows, complete production stages and immutable public image/source/version identity. Twenty G2 physical inputs and original alpha.6 hardware adoption remain unchanged.'}
]
result = {'schema': 'protocol-emulator-g3-completion-audit-v1', 'status': 'PASS_G3_COMPLETION_REQUIREMENTS',
          'observed_utc': datetime.now(timezone.utc).isoformat(), 'qualification_source_commit': ci['source_commit'],
          'release_source_commit': publication['source_commit'], 'closure_baseline_commit': head,
          'producing_inputs_unchanged': len(inputs), 'production': ci['production'], 'requirements': requirements,
          'release': publication['url'], 'image': publication['image'],
          'qualified_protocol_scope': 'UART TX and bounded RX, held-input SPI in four modes/both orders, digital Standard-mode I2C write/read/repeated-START with declared cleanup and input conditions.',
          'explicit_nonclaims': ['No new physical qualification', 'No hardware transport adapter',
                                 'No analog or fabricated-silicon validation', 'No maximum-frequency or minimum-ISA proof',
                                 'No unrestricted protocol interoperability', 'No owner-fluency sign-off',
                                 'No G4 final-submission readiness'],
          'next_engineering_goal': 'G4 remains queued; G5 is a separate optional bounded experiment.',
          'owner_learning': 'M0 teach-back remains pending; no inferred progress.'}
path = EVIDENCE / 'completion-audit.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
(EVIDENCE / 'completion-producer.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(result['status'], len(requirements), 'requirements', len(inputs), 'unchanged inputs')

