from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tools.production_sram import verify
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base=root/'evidence/E0046-program-toolchain'
complete=json.loads((base/'completion-audit.json').read_bytes())
assert complete['status']=='PASS_G3_COMPLETION_REQUIREMENTS'
references={}
for requirement in complete['requirements']:
    assert requirement['status']=='PASS'
    for reference in requirement['evidence']:
        path=(root/reference['path']).resolve()
        assert path.is_relative_to(root) and sha(path.read_bytes())==reference['sha256']
        references[reference['path']]=reference['sha256']
sealed=0
for folder in (base/'ci-0297655',base/'publication'):
    for line in (folder/'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest,name=line.split('  ',1)
        path=(folder/name).resolve()
        assert path.is_relative_to(folder) and sha(path.read_bytes())==digest
        sealed+=1
retention=json.loads((base/'publication/retention.json').read_bytes())
assert sha((base/'release-tools/verify_publication.py').read_bytes())==retention['auditor_sha256']
assert sha((base/'release-tools/package.py').read_bytes())==retention['packager_sha256']
assert verify(root)==complete['production']
unrelated=root/'.devcontainer/devcontainer-lock.json'
assert sha(unrelated.read_bytes())=='41b8de31d8c52979a6a6624e594fdab2e57512383c7f690bc91f92078af653c2'
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root).decode().splitlines()
allowed={'README.md','docs/backlog.md','docs/goals.md','docs/research-ledger.md','docs/state.md','evidence/README.md'}
assert all(name in allowed or name.startswith('evidence/E0046-program-toolchain/') for name in changed)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
result={'schema':'protocol-emulator-g3-completion-check-v1','status':'PASS_G3_FINAL_RECORD_CHECK',
        'observed_utc':datetime.now(timezone.utc).isoformat(),'completion_audit_sha256':sha((base/'completion-audit.json').read_bytes()),
        'references':references,'sealed_qualification_and_publication_files':sealed,
        'production_files_unchanged':len(complete['production']['files_sha256']),
        'unrelated_devcontainer_lock_preserved':True,'tracked_changes_limited_to_goal_docs_and_evidence':True}
(base/'completion-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(result['status'],len(references),'references',sealed,'sealed files')

