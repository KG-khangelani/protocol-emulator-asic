from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tools.production_sram import verify
sha=lambda raw:hashlib.sha256(raw).hexdigest()
base=root/'evidence/E0046-program-toolchain'
git_ref = sys.argv[1] if len(sys.argv) == 2 else None
def contents(path):
    if git_ref:
        relative=path.relative_to(root).as_posix()
        return subprocess.check_output(['git','show',git_ref+':'+relative],cwd=root)
    return path.read_bytes()
complete=json.loads(contents(base/'completion-audit.json'))
assert complete['status']=='PASS_G3_COMPLETION_REQUIREMENTS'
references={}
for requirement in complete['requirements']:
    assert requirement['status']=='PASS'
    for reference in requirement['evidence']:
        path=(root/reference['path']).resolve()
        assert path.is_relative_to(root) and sha(contents(path))==reference['sha256']
        references[reference['path']]=reference['sha256']
sealed=0
for folder in (base/'ci-0297655',base/'publication'):
    for line in contents(folder/'SHA256SUMS').decode('utf-8').splitlines():
        digest,name=line.split('  ',1)
        path=(folder/name).resolve()
        assert path.is_relative_to(folder) and sha(contents(path))==digest
        sealed+=1
retention=json.loads(contents(base/'publication/retention.json'))
assert sha(contents(base/'release-tools/verify_publication.py'))==retention['auditor_sha256']
assert sha(contents(base/'release-tools/package.py'))==retention['packager_sha256']
assert verify(root)==complete['production']
unrelated=root/'.devcontainer/devcontainer-lock.json'
assert sha(unrelated.read_bytes())=='41b8de31d8c52979a6a6624e594fdab2e57512383c7f690bc91f92078af653c2'
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root).decode().splitlines()
allowed={'README.md','docs/backlog.md','docs/goals.md','docs/research-ledger.md','docs/state.md','evidence/README.md'}
assert all(name in allowed or name.startswith('evidence/E0046-program-toolchain/') for name in changed)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
result={'schema':'protocol-emulator-g3-completion-check-v1','status':'PASS_G3_FINAL_RECORD_CHECK',
        'observed_utc':datetime.now(timezone.utc).isoformat(),'completion_audit_sha256':sha(contents(base/'completion-audit.json')),
        'references':references,'sealed_qualification_and_publication_files':sealed,
        'production_files_unchanged':len(complete['production']['files_sha256']),
        'unrelated_devcontainer_lock_preserved':True,'tracked_changes_limited_to_goal_docs_and_evidence':True}
if git_ref:
    committed=json.loads(contents(base/'completion-check.json'))
    for key in ('status','completion_audit_sha256','references','sealed_qualification_and_publication_files','production_files_unchanged'):
        assert committed[key]==result[key],key
    print('PASS_COMMITTED_G3_CLOSURE',git_ref,len(references),'references',sealed,'sealed files')
else:
    (base/'completion-check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(result['status'],len(references),'references',sealed,'sealed files')

