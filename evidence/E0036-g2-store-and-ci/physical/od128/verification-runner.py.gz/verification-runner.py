"""Retain the first od128 routing failure without turning intermediate metrics into signoff."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.physical_candidate import candidate_lock, verify_run_configuration
from tools.physical_runtime import inspect_runtime

BASE = ROOT / 'build/g2-physical-od128'
OUT = ROOT / 'evidence/E0036-g2-store-and-ci/physical/od128'
OUT.mkdir(parents=True, exist_ok=True)
FLOW = BASE / '13952155051/runs/wokwi'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path): return json.loads(path.read_bytes())
def save(path, value): path.write_bytes((json.dumps(value, indent=2) + '\n').encode())

run, jobs = read(BASE / 'run.json'), read(BASE / 'jobs.json')['jobs']
assert run['id'] == 43224847282 and run['status'] == 'completed' and run['conclusion'] == 'failure'
by_name = {j['name']: j for j in jobs}
assert by_name['gds']['conclusion'] == 'failure'
assert all(by_name[k]['conclusion'] == 'skipped' for k in ('precheck', 'gl_test'))
artifacts = read(BASE / 'artifacts.json')
assert {a['name'] for a in artifacts['artifacts']} == {'GDS_logs', 'g2-physical-candidate'}
for item in artifacts['artifacts']:
    path = BASE / (str(item['id']) + '.zip')
    assert path.stat().st_size == item['size_in_bytes']
    assert 'sha256:' + sha(path.read_bytes()) == item['digest']
    assert item['workflow_run']['id'] == run['id']
    assert item['workflow_run']['head_sha'] == run['head_sha']
inputs_path = BASE / '13951955303/od128/inputs.json'
inputs = read(inputs_path)
expected = read(ROOT / 'evidence/E0035-general-i2c/sources/current/source-manifest.json')['od128']['source_sha256']
assert inputs['workflow_source_commit'] == run['head_sha'] == 'e2ff52e54a69a5285cc0c9343d91088b49481307'
assert inputs['source_sha256'] == expected == {n: sha((BASE / '13952155051/src' / n).read_bytes()) for n in expected}
for name, digest in inputs['provenance_sha256_lf'].items():
    assert sha(subprocess.check_output(['git', 'show', run['head_sha'] + ':' + name], cwd=ROOT)) == digest
lock = candidate_lock()
assert inputs['flow_lock'] == lock
assert sha((BASE / '13952155051/src/config.json').read_bytes()) == lock['config_sha256_lf']
resolved = read(FLOW / 'resolved.json')
verify_run_configuration(resolved, lock)
assert resolved['STD_CELL_LIBRARY'] == 'sg13cmos5l_stdcell' and lock['pdk_commit'] in json.dumps(resolved)
runtime = inspect_runtime((BASE / 'gds-job.log').read_bytes(), run['head_sha'], lock, by_name['gds']['id'])
routing = (FLOW / '39-openroad-globalrouting/openroad-globalrouting.log').read_text()
failure = '[ERROR GRT-0228] Horizontal edge usage exceeds the maximum allowed. (92, 97) usage=1717 limit=1700'
assert failure in routing
mapped = read(FLOW / '06-yosys-synthesis/state_out.json')['metrics']
assert mapped['design__instance__count'] == 39806 and mapped['design__instance__area'] == 564744.3984
stats = (FLOW / '06-yosys-synthesis/reports/stat.rpt').read_text()
assert '4278' in stats and '209574.086400' in stats
copies = {
    'run.json': BASE / 'run.json', 'jobs.json': BASE / 'jobs.json', 'artifacts.json': BASE / 'artifacts.json',
    'inputs.json': inputs_path, 'resolved.json': FLOW / 'resolved.json',
    'mapped-state.json': FLOW / '06-yosys-synthesis/state_out.json',
    'synthesis-stats.txt': FLOW / '06-yosys-synthesis/reports/stat.rpt',
    'placement-metrics.json': FLOW / '28-openroad-globalplacement/or_metrics_out.json',
    'pre-routing-metrics.json': FLOW / '38-openroad-stamidpnr-2/or_metrics_out.json',
    'routing-metrics.json': FLOW / '39-openroad-globalrouting/or_metrics_out.json',
    'routing.log': FLOW / '39-openroad-globalrouting/openroad-globalrouting.log',
    'placement.log': FLOW / '28-openroad-globalplacement/openroad-globalplacement.log',
    'synthesis.log': FLOW / '06-yosys-synthesis/yosys-synthesis.log',
    'gds-job.log': BASE / 'gds-job.log', 'flow.log': FLOW / 'flow.log', 'error.log': FLOW / 'error.log',
}
retained = {}
for name, path in copies.items():
    raw = path.read_bytes()
    count = 0
    if path.suffix == '.log':
        raw, count = re.subn(rb'(https?://[^\s<>"\x27?]+)\?[^\s<>"\x27]+', rb'\1?REDACTED', raw)
    target = OUT / (name + '.gz' if Path(name).suffix in ('.log', '.txt') else name)
    target.write_bytes(gzip.compress(raw, mtime=0) if target.suffix == '.gz' else raw)
    retained[name] = {'original_sha256': sha(path.read_bytes()), 'retained_file': target.name,
                      'retained_sha256': sha(target.read_bytes()), 'decoded_sha256': sha(raw),
                      'url_query_strings_redacted': count}
save(OUT / 'result.json', {
    'status': 'FAIL_GLOBAL_ROUTING_CONGESTION', 'variant': 'od128', 'run_id': run['id'],
    'workflow_source_commit': run['head_sha'], 'source_sha256': expected,
    'archive_digests_verified': True, 'resolved_fixed_conditions_verified': True,
    'runtime_identities': runtime,
    'tool_identity_evidence': 'Runtime image/action/compiler identities and resolved PDK paths; no final pdk.json was emitted',
    'mapped_cell_area_um2': mapped['design__instance__area'], 'mapped_instance_count': mapped['design__instance__count'],
    'sequential_cells': 4278, 'sequential_area_um2': 209574.0864,
    'placement_total_instance_area_um2': 564813.648,
    'failure': failure, 'routing_edge': [92, 97], 'horizontal_edge_usage': 1717, 'horizontal_edge_limit': 1700,
    'routed_metrics': 'NOT_REACHED', 'precheck': 'SKIPPED', 'netlist_protocols': 'SKIPPED',
    'retained_files': retained,
    'scope': 'Measured rejection under the frozen 8x4 flow. Intermediate placement/timing is not routed signoff; the internal router edge limit is not a one-percent design shortfall estimate.'
})
(OUT / 'verification-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('PASS: exact archives, source, runtime and fixed conditions; od128 routing failure retained')
