import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'experiments/i2c'))
from tools import physical_candidate, physical_g2
from audit_store_proofs import audit
BASE=ROOT/'build/g2-ci-d3c340f'
OUT=ROOT/'evidence/E0036-g2-store-and-ci/ci-d3'
OUT.mkdir(exist_ok=True)
REV='d3c340fc28166201e8c1085ae4f8b729e8c4b9d2'
def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p): return [json.loads(s) for s in p.read_text().splitlines()]
def frozen_sha(name): return hashlib.sha256(subprocess.check_output(['git','show',REV+':'+name],cwd=ROOT)).hexdigest()
expected=read(ROOT/'evidence/E0035-general-i2c/sources/current/source-manifest.json')
artifacts=read(BASE/'artifacts.json')['artifacts']
verified=[]
for artifact in artifacts:
    if not artifact['name'].startswith('i2c-general-'): continue
    name=artifact['name'][len('i2c-general-'):].removesuffix('-'+REV)
    number=artifact['id']
    assert artifact['workflow_run']['head_sha']==REV
    assert 'sha256:'+sha(BASE/f'{number}.zip')==artifact['digest']
    data=BASE/str(number)
    variants=data/('protocols/variants' if name in ('od128','literal255') else 'variants')
    assert read(variants/'source-manifest.json')==expected
    for variant,record in expected.items():
        for file,digest in record['source_sha256'].items():
            assert sha(variants/variant/'src'/file)==digest
    details={}
    if name in ('od128','literal255'):
        result=read(data/'protocols/result.json')
        assert result['status']=='PASS_I2C_PUBLIC_MATRIX' and not result['smoke']
        assert result['parent_revision']==REV
        a,b=[rows(data/f'protocols/{sim}/records/cases.jsonl') for sim in ('icarus','verilator')]
        assert a==b and len(a)==1160 and sum(r['accepted'] for r in a)==1154
        retained=physical_g2.records(ROOT/f'evidence/E0036-g2-store-and-ci/ci/{name}/protocols/icarus/records/cases.jsonl.gz')
        assert a==retained
        for file,digest in result['input_sha256'].items(): assert frozen_sha(file)==digest,file
        assert all(s['status']=='PASS' and s['returncode']==0 and s['observed_identity'] for s in result['stages'])
        details={'public_records':len(a),'equal_to_previous':True}
    elif name=='architecture':
        result=read(data/'result.json')
        assert result['status']=='PASS_SCOPED_ARCHITECTURE_GATE'
        statuses={'boundaries':'PASS_PUBLIC_BOUNDARIES','aborts':'PASS_PUBLIC_ABORT_AND_RELOAD','formal':'PASS_SCOPED_INSTRUCTION_PROOFS','cost':'PASS_GENERIC_COST_ONLY','combined':'PASS_LEGACY_PUBLIC_MATRIX'}
        for sub,status in statuses.items(): assert read(data/sub/'result.json')['status']==status
        for variant in expected:
            for sub in ('boundaries','cost'):
                assert read(data/sub/'result.json')['sources'][variant]==expected[variant]['source_sha256']
            assert read(data/'formal/result.json')['sources'][variant]==expected[variant]['source_sha256']['m1_engine.v']
            a,b=[rows(data/f'boundaries/{variant}-{sim}/records/boundaries.jsonl') for sim in ('icarus','verilator')]
            assert a==b and len(a)==4
        a,b=[rows(data/f'aborts/od128-{sim}/records/aborts.jsonl') for sim in ('icarus','verilator')]
        assert a==b and len(a)==36 and all(not r['errors'] for r in a)
        for sim in ('icarus','verilator'):
            physical_candidate.check_tests(SimpleNamespace(variant='compact10',junit=data/f'combined/{sim}/results.xml',records=data/f'combined/{sim}/records/cases.jsonl',output=BASE/f'{sim}-combined-audit.json',require_netlist=False))
    elif name=='physical-selection':
        result=read(data/'selection/result.json')
        assert result['status']=='PASS_G2_PHYSICAL_SELECTION_ON_BOTH_RTL_SIMULATORS'
        for sim in ('icarus','verilator'):
            physical_g2.check_tests(SimpleNamespace(junit=data/f'selection/{sim}/results.xml',records=data/f'selection/{sim}/records',output=BASE/f'{sim}-selection-audit.json',require_netlist=False))
        details={'groups':18,'unchanged_records':True}
    elif name=='store':
        result=read(data/'result.json')
        assert result['status']=='PASS_AUDITED_STORE_GATE'
        raw=read(data/'store/result.json')
        assert raw['status']=='PASS_ALL_WORD_STORE_PROOFS_WITH_CHECKED_CONTROLS'
        assert raw['runner_sha256']==frozen_sha('experiments/i2c/run_store_local_proof.py')
        # Uploaded sources are deduplicated; recreate SBY's exact source copies.
        for task in raw['tasks']:
            directory=data/'store'/task['directory']
            dest=directory/'proof/src'
            dest.mkdir(parents=True,exist_ok=True)
            model=data/'store'/(task['variant']+'-model')
            source=model/'prepared.il' if task['name'] in ('state','read') else directory/'store.v'
            shutil.copyfile(source,dest/source.name)
        for variant in ('od128','literal255'):
            saved=read(data/'audit'/f'{variant}.json')
            checked=audit(data/'store',data/'store',variant,(data/'audit'/saved['positive_checkpoint']).read_bytes())
            assert checked=={k:v for k,v in saved.items() if k!='positive_checkpoint'}
        checker=read(data/'audit/auditor-controls.json')
        assert checker['status']=='PASS_AUDITOR_NEGATIVE_CONTROLS' and len(checker['controls'])==9
        assert all(c['rejected'] for c in checker['controls'])
        details={'assertions':{v:result['audits'][v]['assertions'] for v in ('od128','literal255')},'task_count':len(raw['tasks']),'full_combined_run':raw['status'],'checker_controls':9}
    else:
        raise AssertionError(name)
    target=OUT/name
    target.mkdir(exist_ok=True)
    (target/'result.json.gz').write_bytes(gzip.compress(json.dumps(result,indent=2).encode()+b'\n',mtime=0))
    verified.append({'name':name,'artifact_id':number,'zip_sha256':sha(BASE/f'{number}.zip'),'status':result['status'],**details})
assert sorted(r['name'] for r in verified)==['architecture','literal255','od128','physical-selection','store']
report={'status':'PASS_ALL_FIVE_G2_CI_GATES_AUDITED','run_id':43229238795,'source_revision':REV,'artifacts':verified,
 'source_sha256':expected,'scope':'All five clean G2 gates; no physical or production promotion',
 'store_proof_replay':'Actual models/configurations/status/logs/witnesses audited again after download; duplicated source copies restored from hashed inputs'}
(OUT/'verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
shutil.copyfile(BASE/'artifacts.json',OUT/'artifacts.json')
print(report['status'])
