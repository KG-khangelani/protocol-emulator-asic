/* SPDX-License-Identifier: Apache-2.0 */
`default_nettype none
module m1_program_store (
    input wire clk, input wire rst_n, input wire ena,
    input wire load_mode, input wire load_write, input wire load_length, input wire load_bank,
    input wire [4:0] byte_address, input wire [7:0] data_in,
    input wire [7:0] pc,
    output reg [7:0] data_out, output reg [7:0] program_length,
    output reg program_ready, output reg [3:0] program_bank,
    output reg [31:0] instruction, output wire instruction_valid
);
    reg [31:0] word0;
    reg [31:0] word1;
    reg [31:0] word2;
    reg [31:0] word3;
    reg [31:0] word4;
    reg [31:0] word5;
    reg [31:0] word6;
    reg [31:0] word7;
    reg [31:0] word8;
    reg [31:0] word9;
    reg [31:0] word10;
    reg [31:0] word11;
    reg [31:0] word12;
    reg [31:0] word13;
    reg [31:0] word14;
    reg [31:0] word15;
    reg [31:0] word16;
    reg [31:0] word17;
    reg [31:0] word18;
    reg [31:0] word19;
    reg [31:0] word20;
    reg [31:0] word21;
    reg [31:0] word22;
    reg [31:0] word23;
    reg [31:0] word24;
    reg [31:0] word25;
    reg [31:0] word26;
    reg [31:0] word27;
    reg [31:0] word28;
    reg [31:0] word29;
    reg [31:0] word30;
    reg [31:0] word31;
    reg [31:0] word32;
    reg [31:0] word33;
    reg [31:0] word34;
    reg [31:0] word35;
    reg [31:0] word36;
    reg [31:0] word37;
    reg [31:0] word38;
    reg [31:0] word39;
    reg [31:0] word40;
    reg [31:0] word41;
    reg [31:0] word42;
    reg [31:0] word43;
    reg [31:0] word44;
    reg [31:0] word45;
    reg [31:0] word46;
    reg [31:0] word47;
    reg [31:0] word48;
    reg [31:0] word49;
    reg [31:0] word50;
    reg [31:0] word51;
    reg [31:0] word52;
    reg [31:0] word53;
    reg [31:0] word54;
    reg [31:0] word55;
    reg [31:0] word56;
    reg [31:0] word57;
    reg [31:0] word58;
    reg [31:0] word59;
    reg [31:0] word60;
    reg [31:0] word61;
    reg [31:0] word62;
    reg [31:0] word63;
    reg [31:0] word64;
    reg [31:0] word65;
    reg [31:0] word66;
    reg [31:0] word67;
    reg [31:0] word68;
    reg [31:0] word69;
    reg [31:0] word70;
    reg [31:0] word71;
    reg [31:0] word72;
    reg [31:0] word73;
    reg [31:0] word74;
    reg [31:0] word75;
    reg [31:0] word76;
    reg [31:0] word77;
    reg [31:0] word78;
    reg [31:0] word79;
    reg [31:0] word80;
    reg [31:0] word81;
    reg [31:0] word82;
    reg [31:0] word83;
    reg [31:0] word84;
    reg [31:0] word85;
    reg [31:0] word86;
    reg [31:0] word87;
    reg [31:0] word88;
    reg [31:0] word89;
    reg [31:0] word90;
    reg [31:0] word91;
    reg [31:0] word92;
    reg [31:0] word93;
    reg [31:0] word94;
    reg [31:0] word95;
    reg [31:0] word96;
    reg [31:0] word97;
    reg [31:0] word98;
    reg [31:0] word99;
    reg [31:0] word100;
    reg [31:0] word101;
    reg [31:0] word102;
    reg [31:0] word103;
    reg [31:0] word104;
    reg [31:0] word105;
    reg [31:0] word106;
    reg [31:0] word107;
    reg [31:0] word108;
    reg [31:0] word109;
    reg [31:0] word110;
    reg [31:0] word111;
    reg [31:0] word112;
    reg [31:0] word113;
    reg [31:0] word114;
    reg [31:0] word115;
    reg [31:0] word116;
    reg [31:0] word117;
    reg [31:0] word118;
    reg [31:0] word119;
    reg [31:0] word120;
    reg [31:0] word121;
    reg [31:0] word122;
    reg [31:0] word123;
    reg [31:0] word124;
    reg [31:0] word125;
    reg [31:0] word126;
    reg [31:0] word127;
    wire [8:0] bank_address = {program_bank, byte_address};
    wire length_valid = (data_in >= 8'd1) && (data_in <= 8'd128);
    always @(posedge clk) begin
        if (!rst_n) begin
            word0 <= 32'd0;
            word1 <= 32'd0;
            word2 <= 32'd0;
            word3 <= 32'd0;
            word4 <= 32'd0;
            word5 <= 32'd0;
            word6 <= 32'd0;
            word7 <= 32'd0;
            word8 <= 32'd0;
            word9 <= 32'd0;
            word10 <= 32'd0;
            word11 <= 32'd0;
            word12 <= 32'd0;
            word13 <= 32'd0;
            word14 <= 32'd0;
            word15 <= 32'd0;
            word16 <= 32'd0;
            word17 <= 32'd0;
            word18 <= 32'd0;
            word19 <= 32'd0;
            word20 <= 32'd0;
            word21 <= 32'd0;
            word22 <= 32'd0;
            word23 <= 32'd0;
            word24 <= 32'd0;
            word25 <= 32'd0;
            word26 <= 32'd0;
            word27 <= 32'd0;
            word28 <= 32'd0;
            word29 <= 32'd0;
            word30 <= 32'd0;
            word31 <= 32'd0;
            word32 <= 32'd0;
            word33 <= 32'd0;
            word34 <= 32'd0;
            word35 <= 32'd0;
            word36 <= 32'd0;
            word37 <= 32'd0;
            word38 <= 32'd0;
            word39 <= 32'd0;
            word40 <= 32'd0;
            word41 <= 32'd0;
            word42 <= 32'd0;
            word43 <= 32'd0;
            word44 <= 32'd0;
            word45 <= 32'd0;
            word46 <= 32'd0;
            word47 <= 32'd0;
            word48 <= 32'd0;
            word49 <= 32'd0;
            word50 <= 32'd0;
            word51 <= 32'd0;
            word52 <= 32'd0;
            word53 <= 32'd0;
            word54 <= 32'd0;
            word55 <= 32'd0;
            word56 <= 32'd0;
            word57 <= 32'd0;
            word58 <= 32'd0;
            word59 <= 32'd0;
            word60 <= 32'd0;
            word61 <= 32'd0;
            word62 <= 32'd0;
            word63 <= 32'd0;
            word64 <= 32'd0;
            word65 <= 32'd0;
            word66 <= 32'd0;
            word67 <= 32'd0;
            word68 <= 32'd0;
            word69 <= 32'd0;
            word70 <= 32'd0;
            word71 <= 32'd0;
            word72 <= 32'd0;
            word73 <= 32'd0;
            word74 <= 32'd0;
            word75 <= 32'd0;
            word76 <= 32'd0;
            word77 <= 32'd0;
            word78 <= 32'd0;
            word79 <= 32'd0;
            word80 <= 32'd0;
            word81 <= 32'd0;
            word82 <= 32'd0;
            word83 <= 32'd0;
            word84 <= 32'd0;
            word85 <= 32'd0;
            word86 <= 32'd0;
            word87 <= 32'd0;
            word88 <= 32'd0;
            word89 <= 32'd0;
            word90 <= 32'd0;
            word91 <= 32'd0;
            word92 <= 32'd0;
            word93 <= 32'd0;
            word94 <= 32'd0;
            word95 <= 32'd0;
            word96 <= 32'd0;
            word97 <= 32'd0;
            word98 <= 32'd0;
            word99 <= 32'd0;
            word100 <= 32'd0;
            word101 <= 32'd0;
            word102 <= 32'd0;
            word103 <= 32'd0;
            word104 <= 32'd0;
            word105 <= 32'd0;
            word106 <= 32'd0;
            word107 <= 32'd0;
            word108 <= 32'd0;
            word109 <= 32'd0;
            word110 <= 32'd0;
            word111 <= 32'd0;
            word112 <= 32'd0;
            word113 <= 32'd0;
            word114 <= 32'd0;
            word115 <= 32'd0;
            word116 <= 32'd0;
            word117 <= 32'd0;
            word118 <= 32'd0;
            word119 <= 32'd0;
            word120 <= 32'd0;
            word121 <= 32'd0;
            word122 <= 32'd0;
            word123 <= 32'd0;
            word124 <= 32'd0;
            word125 <= 32'd0;
            word126 <= 32'd0;
            word127 <= 32'd0;
            program_bank <= 4'd0;
            program_length <= 8'd0;
            program_ready <= 1'b0;
        end else if (ena && load_mode && load_write) begin
            if (load_bank) begin
                program_bank <= (data_in < 8'd16) ? data_in[3:0] : 4'd0;
                program_length <= 8'd0;
                program_ready <= 1'b0;
            end else if (load_length) begin
                program_bank <= 4'd0;
                program_length <= length_valid ? data_in : 8'd0;
                program_ready <= length_valid;
            end else begin
                program_ready <= 1'b0;
                case (bank_address[8:2])
                    7'd0: word0[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd1: word1[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd2: word2[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd3: word3[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd4: word4[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd5: word5[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd6: word6[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd7: word7[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd8: word8[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd9: word9[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd10: word10[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd11: word11[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd12: word12[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd13: word13[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd14: word14[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd15: word15[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd16: word16[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd17: word17[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd18: word18[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd19: word19[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd20: word20[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd21: word21[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd22: word22[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd23: word23[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd24: word24[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd25: word25[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd26: word26[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd27: word27[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd28: word28[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd29: word29[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd30: word30[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd31: word31[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd32: word32[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd33: word33[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd34: word34[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd35: word35[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd36: word36[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd37: word37[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd38: word38[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd39: word39[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd40: word40[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd41: word41[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd42: word42[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd43: word43[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd44: word44[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd45: word45[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd46: word46[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd47: word47[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd48: word48[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd49: word49[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd50: word50[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd51: word51[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd52: word52[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd53: word53[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd54: word54[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd55: word55[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd56: word56[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd57: word57[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd58: word58[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd59: word59[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd60: word60[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd61: word61[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd62: word62[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd63: word63[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd64: word64[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd65: word65[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd66: word66[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd67: word67[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd68: word68[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd69: word69[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd70: word70[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd71: word71[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd72: word72[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd73: word73[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd74: word74[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd75: word75[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd76: word76[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd77: word77[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd78: word78[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd79: word79[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd80: word80[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd81: word81[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd82: word82[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd83: word83[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd84: word84[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd85: word85[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd86: word86[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd87: word87[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd88: word88[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd89: word89[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd90: word90[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd91: word91[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd92: word92[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd93: word93[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd94: word94[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd95: word95[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd96: word96[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd97: word97[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd98: word98[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd99: word99[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd100: word100[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd101: word101[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd102: word102[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd103: word103[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd104: word104[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd105: word105[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd106: word106[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd107: word107[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd108: word108[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd109: word109[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd110: word110[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd111: word111[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd112: word112[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd113: word113[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd114: word114[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd115: word115[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd116: word116[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd117: word117[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd118: word118[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd119: word119[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd120: word120[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd121: word121[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd122: word122[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd123: word123[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd124: word124[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd125: word125[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd126: word126[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    7'd127: word127[8*(byte_address[1:0] ^ 2'b01) +: 8] <= data_in;
                    default: begin end
                endcase
            end
        end
    end
    // verilog_lint: waive always-comb
    always @(*) begin
        case (bank_address[8:2])
            7'd0: data_out = word0[8*byte_address[1:0] +: 8];
            7'd1: data_out = word1[8*byte_address[1:0] +: 8];
            7'd2: data_out = word2[8*byte_address[1:0] +: 8];
            7'd3: data_out = word3[8*byte_address[1:0] +: 8];
            7'd4: data_out = word4[8*byte_address[1:0] +: 8];
            7'd5: data_out = word5[8*byte_address[1:0] +: 8];
            7'd6: data_out = word6[8*byte_address[1:0] +: 8];
            7'd7: data_out = word7[8*byte_address[1:0] +: 8];
            7'd8: data_out = word8[8*byte_address[1:0] +: 8];
            7'd9: data_out = word9[8*byte_address[1:0] +: 8];
            7'd10: data_out = word10[8*byte_address[1:0] +: 8];
            7'd11: data_out = word11[8*byte_address[1:0] +: 8];
            7'd12: data_out = word12[8*byte_address[1:0] +: 8];
            7'd13: data_out = word13[8*byte_address[1:0] +: 8];
            7'd14: data_out = word14[8*byte_address[1:0] +: 8];
            7'd15: data_out = word15[8*byte_address[1:0] +: 8];
            7'd16: data_out = word16[8*byte_address[1:0] +: 8];
            7'd17: data_out = word17[8*byte_address[1:0] +: 8];
            7'd18: data_out = word18[8*byte_address[1:0] +: 8];
            7'd19: data_out = word19[8*byte_address[1:0] +: 8];
            7'd20: data_out = word20[8*byte_address[1:0] +: 8];
            7'd21: data_out = word21[8*byte_address[1:0] +: 8];
            7'd22: data_out = word22[8*byte_address[1:0] +: 8];
            7'd23: data_out = word23[8*byte_address[1:0] +: 8];
            7'd24: data_out = word24[8*byte_address[1:0] +: 8];
            7'd25: data_out = word25[8*byte_address[1:0] +: 8];
            7'd26: data_out = word26[8*byte_address[1:0] +: 8];
            7'd27: data_out = word27[8*byte_address[1:0] +: 8];
            7'd28: data_out = word28[8*byte_address[1:0] +: 8];
            7'd29: data_out = word29[8*byte_address[1:0] +: 8];
            7'd30: data_out = word30[8*byte_address[1:0] +: 8];
            7'd31: data_out = word31[8*byte_address[1:0] +: 8];
            7'd32: data_out = word32[8*byte_address[1:0] +: 8];
            7'd33: data_out = word33[8*byte_address[1:0] +: 8];
            7'd34: data_out = word34[8*byte_address[1:0] +: 8];
            7'd35: data_out = word35[8*byte_address[1:0] +: 8];
            7'd36: data_out = word36[8*byte_address[1:0] +: 8];
            7'd37: data_out = word37[8*byte_address[1:0] +: 8];
            7'd38: data_out = word38[8*byte_address[1:0] +: 8];
            7'd39: data_out = word39[8*byte_address[1:0] +: 8];
            7'd40: data_out = word40[8*byte_address[1:0] +: 8];
            7'd41: data_out = word41[8*byte_address[1:0] +: 8];
            7'd42: data_out = word42[8*byte_address[1:0] +: 8];
            7'd43: data_out = word43[8*byte_address[1:0] +: 8];
            7'd44: data_out = word44[8*byte_address[1:0] +: 8];
            7'd45: data_out = word45[8*byte_address[1:0] +: 8];
            7'd46: data_out = word46[8*byte_address[1:0] +: 8];
            7'd47: data_out = word47[8*byte_address[1:0] +: 8];
            7'd48: data_out = word48[8*byte_address[1:0] +: 8];
            7'd49: data_out = word49[8*byte_address[1:0] +: 8];
            7'd50: data_out = word50[8*byte_address[1:0] +: 8];
            7'd51: data_out = word51[8*byte_address[1:0] +: 8];
            7'd52: data_out = word52[8*byte_address[1:0] +: 8];
            7'd53: data_out = word53[8*byte_address[1:0] +: 8];
            7'd54: data_out = word54[8*byte_address[1:0] +: 8];
            7'd55: data_out = word55[8*byte_address[1:0] +: 8];
            7'd56: data_out = word56[8*byte_address[1:0] +: 8];
            7'd57: data_out = word57[8*byte_address[1:0] +: 8];
            7'd58: data_out = word58[8*byte_address[1:0] +: 8];
            7'd59: data_out = word59[8*byte_address[1:0] +: 8];
            7'd60: data_out = word60[8*byte_address[1:0] +: 8];
            7'd61: data_out = word61[8*byte_address[1:0] +: 8];
            7'd62: data_out = word62[8*byte_address[1:0] +: 8];
            7'd63: data_out = word63[8*byte_address[1:0] +: 8];
            7'd64: data_out = word64[8*byte_address[1:0] +: 8];
            7'd65: data_out = word65[8*byte_address[1:0] +: 8];
            7'd66: data_out = word66[8*byte_address[1:0] +: 8];
            7'd67: data_out = word67[8*byte_address[1:0] +: 8];
            7'd68: data_out = word68[8*byte_address[1:0] +: 8];
            7'd69: data_out = word69[8*byte_address[1:0] +: 8];
            7'd70: data_out = word70[8*byte_address[1:0] +: 8];
            7'd71: data_out = word71[8*byte_address[1:0] +: 8];
            7'd72: data_out = word72[8*byte_address[1:0] +: 8];
            7'd73: data_out = word73[8*byte_address[1:0] +: 8];
            7'd74: data_out = word74[8*byte_address[1:0] +: 8];
            7'd75: data_out = word75[8*byte_address[1:0] +: 8];
            7'd76: data_out = word76[8*byte_address[1:0] +: 8];
            7'd77: data_out = word77[8*byte_address[1:0] +: 8];
            7'd78: data_out = word78[8*byte_address[1:0] +: 8];
            7'd79: data_out = word79[8*byte_address[1:0] +: 8];
            7'd80: data_out = word80[8*byte_address[1:0] +: 8];
            7'd81: data_out = word81[8*byte_address[1:0] +: 8];
            7'd82: data_out = word82[8*byte_address[1:0] +: 8];
            7'd83: data_out = word83[8*byte_address[1:0] +: 8];
            7'd84: data_out = word84[8*byte_address[1:0] +: 8];
            7'd85: data_out = word85[8*byte_address[1:0] +: 8];
            7'd86: data_out = word86[8*byte_address[1:0] +: 8];
            7'd87: data_out = word87[8*byte_address[1:0] +: 8];
            7'd88: data_out = word88[8*byte_address[1:0] +: 8];
            7'd89: data_out = word89[8*byte_address[1:0] +: 8];
            7'd90: data_out = word90[8*byte_address[1:0] +: 8];
            7'd91: data_out = word91[8*byte_address[1:0] +: 8];
            7'd92: data_out = word92[8*byte_address[1:0] +: 8];
            7'd93: data_out = word93[8*byte_address[1:0] +: 8];
            7'd94: data_out = word94[8*byte_address[1:0] +: 8];
            7'd95: data_out = word95[8*byte_address[1:0] +: 8];
            7'd96: data_out = word96[8*byte_address[1:0] +: 8];
            7'd97: data_out = word97[8*byte_address[1:0] +: 8];
            7'd98: data_out = word98[8*byte_address[1:0] +: 8];
            7'd99: data_out = word99[8*byte_address[1:0] +: 8];
            7'd100: data_out = word100[8*byte_address[1:0] +: 8];
            7'd101: data_out = word101[8*byte_address[1:0] +: 8];
            7'd102: data_out = word102[8*byte_address[1:0] +: 8];
            7'd103: data_out = word103[8*byte_address[1:0] +: 8];
            7'd104: data_out = word104[8*byte_address[1:0] +: 8];
            7'd105: data_out = word105[8*byte_address[1:0] +: 8];
            7'd106: data_out = word106[8*byte_address[1:0] +: 8];
            7'd107: data_out = word107[8*byte_address[1:0] +: 8];
            7'd108: data_out = word108[8*byte_address[1:0] +: 8];
            7'd109: data_out = word109[8*byte_address[1:0] +: 8];
            7'd110: data_out = word110[8*byte_address[1:0] +: 8];
            7'd111: data_out = word111[8*byte_address[1:0] +: 8];
            7'd112: data_out = word112[8*byte_address[1:0] +: 8];
            7'd113: data_out = word113[8*byte_address[1:0] +: 8];
            7'd114: data_out = word114[8*byte_address[1:0] +: 8];
            7'd115: data_out = word115[8*byte_address[1:0] +: 8];
            7'd116: data_out = word116[8*byte_address[1:0] +: 8];
            7'd117: data_out = word117[8*byte_address[1:0] +: 8];
            7'd118: data_out = word118[8*byte_address[1:0] +: 8];
            7'd119: data_out = word119[8*byte_address[1:0] +: 8];
            7'd120: data_out = word120[8*byte_address[1:0] +: 8];
            7'd121: data_out = word121[8*byte_address[1:0] +: 8];
            7'd122: data_out = word122[8*byte_address[1:0] +: 8];
            7'd123: data_out = word123[8*byte_address[1:0] +: 8];
            7'd124: data_out = word124[8*byte_address[1:0] +: 8];
            7'd125: data_out = word125[8*byte_address[1:0] +: 8];
            7'd126: data_out = word126[8*byte_address[1:0] +: 8];
            7'd127: data_out = word127[8*byte_address[1:0] +: 8];
            default: data_out = 8'd0;
        endcase
        if (load_length)
            data_out = program_length;
        case (pc)
            8'd0: instruction = word0;
            8'd1: instruction = word1;
            8'd2: instruction = word2;
            8'd3: instruction = word3;
            8'd4: instruction = word4;
            8'd5: instruction = word5;
            8'd6: instruction = word6;
            8'd7: instruction = word7;
            8'd8: instruction = word8;
            8'd9: instruction = word9;
            8'd10: instruction = word10;
            8'd11: instruction = word11;
            8'd12: instruction = word12;
            8'd13: instruction = word13;
            8'd14: instruction = word14;
            8'd15: instruction = word15;
            8'd16: instruction = word16;
            8'd17: instruction = word17;
            8'd18: instruction = word18;
            8'd19: instruction = word19;
            8'd20: instruction = word20;
            8'd21: instruction = word21;
            8'd22: instruction = word22;
            8'd23: instruction = word23;
            8'd24: instruction = word24;
            8'd25: instruction = word25;
            8'd26: instruction = word26;
            8'd27: instruction = word27;
            8'd28: instruction = word28;
            8'd29: instruction = word29;
            8'd30: instruction = word30;
            8'd31: instruction = word31;
            8'd32: instruction = word32;
            8'd33: instruction = word33;
            8'd34: instruction = word34;
            8'd35: instruction = word35;
            8'd36: instruction = word36;
            8'd37: instruction = word37;
            8'd38: instruction = word38;
            8'd39: instruction = word39;
            8'd40: instruction = word40;
            8'd41: instruction = word41;
            8'd42: instruction = word42;
            8'd43: instruction = word43;
            8'd44: instruction = word44;
            8'd45: instruction = word45;
            8'd46: instruction = word46;
            8'd47: instruction = word47;
            8'd48: instruction = word48;
            8'd49: instruction = word49;
            8'd50: instruction = word50;
            8'd51: instruction = word51;
            8'd52: instruction = word52;
            8'd53: instruction = word53;
            8'd54: instruction = word54;
            8'd55: instruction = word55;
            8'd56: instruction = word56;
            8'd57: instruction = word57;
            8'd58: instruction = word58;
            8'd59: instruction = word59;
            8'd60: instruction = word60;
            8'd61: instruction = word61;
            8'd62: instruction = word62;
            8'd63: instruction = word63;
            8'd64: instruction = word64;
            8'd65: instruction = word65;
            8'd66: instruction = word66;
            8'd67: instruction = word67;
            8'd68: instruction = word68;
            8'd69: instruction = word69;
            8'd70: instruction = word70;
            8'd71: instruction = word71;
            8'd72: instruction = word72;
            8'd73: instruction = word73;
            8'd74: instruction = word74;
            8'd75: instruction = word75;
            8'd76: instruction = word76;
            8'd77: instruction = word77;
            8'd78: instruction = word78;
            8'd79: instruction = word79;
            8'd80: instruction = word80;
            8'd81: instruction = word81;
            8'd82: instruction = word82;
            8'd83: instruction = word83;
            8'd84: instruction = word84;
            8'd85: instruction = word85;
            8'd86: instruction = word86;
            8'd87: instruction = word87;
            8'd88: instruction = word88;
            8'd89: instruction = word89;
            8'd90: instruction = word90;
            8'd91: instruction = word91;
            8'd92: instruction = word92;
            8'd93: instruction = word93;
            8'd94: instruction = word94;
            8'd95: instruction = word95;
            8'd96: instruction = word96;
            8'd97: instruction = word97;
            8'd98: instruction = word98;
            8'd99: instruction = word99;
            8'd100: instruction = word100;
            8'd101: instruction = word101;
            8'd102: instruction = word102;
            8'd103: instruction = word103;
            8'd104: instruction = word104;
            8'd105: instruction = word105;
            8'd106: instruction = word106;
            8'd107: instruction = word107;
            8'd108: instruction = word108;
            8'd109: instruction = word109;
            8'd110: instruction = word110;
            8'd111: instruction = word111;
            8'd112: instruction = word112;
            8'd113: instruction = word113;
            8'd114: instruction = word114;
            8'd115: instruction = word115;
            8'd116: instruction = word116;
            8'd117: instruction = word117;
            8'd118: instruction = word118;
            8'd119: instruction = word119;
            8'd120: instruction = word120;
            8'd121: instruction = word121;
            8'd122: instruction = word122;
            8'd123: instruction = word123;
            8'd124: instruction = word124;
            8'd125: instruction = word125;
            8'd126: instruction = word126;
            8'd127: instruction = word127;
            default: instruction = 32'd0;
        endcase
    end
    assign instruction_valid = program_ready && (pc < program_length) && (pc < 8'd128);

// Independent specification: addressed byte replacement, all other bits held.
reg f_past_valid = 1'b0;
wire [7:0] f_address = {program_bank, byte_address[4:2]};
wire [4:0] f_shift = {byte_address[1:0], 3'b000};
wire [31:0] f_mask = 32'hff << f_shift;
wire [31:0] f_value = {24'd0, data_in} << f_shift;
wire f_write = ena && load_mode && load_write;
wire f_data_write = f_write && !load_bank && !load_length;
wire f_length_valid = data_in != 0 && {1'b0, data_in} <= 9'd128;

always @(*) begin
    if (f_past_valid) begin
    assert(instruction_valid == (program_ready && pc < program_length && pc < 8'd128));
    if (load_length) assert(data_out == program_length);
    if (pc >= 8'd128) assert(instruction == 0 && !instruction_valid);
    if (!load_length && f_address >= 8'd128) assert(data_out == 0);
    
        if (pc == 8'd0) assert(instruction == word0);
        if (!load_length && f_address == 8'd0)
            assert(data_out == ((word0 >> f_shift) & 32'hff));
        if (pc == 8'd1) assert(instruction == word1);
        if (!load_length && f_address == 8'd1)
            assert(data_out == ((word1 >> f_shift) & 32'hff));
        if (pc == 8'd2) assert(instruction == word2);
        if (!load_length && f_address == 8'd2)
            assert(data_out == ((word2 >> f_shift) & 32'hff));
        if (pc == 8'd3) assert(instruction == word3);
        if (!load_length && f_address == 8'd3)
            assert(data_out == ((word3 >> f_shift) & 32'hff));
        if (pc == 8'd4) assert(instruction == word4);
        if (!load_length && f_address == 8'd4)
            assert(data_out == ((word4 >> f_shift) & 32'hff));
        if (pc == 8'd5) assert(instruction == word5);
        if (!load_length && f_address == 8'd5)
            assert(data_out == ((word5 >> f_shift) & 32'hff));
        if (pc == 8'd6) assert(instruction == word6);
        if (!load_length && f_address == 8'd6)
            assert(data_out == ((word6 >> f_shift) & 32'hff));
        if (pc == 8'd7) assert(instruction == word7);
        if (!load_length && f_address == 8'd7)
            assert(data_out == ((word7 >> f_shift) & 32'hff));
        if (pc == 8'd8) assert(instruction == word8);
        if (!load_length && f_address == 8'd8)
            assert(data_out == ((word8 >> f_shift) & 32'hff));
        if (pc == 8'd9) assert(instruction == word9);
        if (!load_length && f_address == 8'd9)
            assert(data_out == ((word9 >> f_shift) & 32'hff));
        if (pc == 8'd10) assert(instruction == word10);
        if (!load_length && f_address == 8'd10)
            assert(data_out == ((word10 >> f_shift) & 32'hff));
        if (pc == 8'd11) assert(instruction == word11);
        if (!load_length && f_address == 8'd11)
            assert(data_out == ((word11 >> f_shift) & 32'hff));
        if (pc == 8'd12) assert(instruction == word12);
        if (!load_length && f_address == 8'd12)
            assert(data_out == ((word12 >> f_shift) & 32'hff));
        if (pc == 8'd13) assert(instruction == word13);
        if (!load_length && f_address == 8'd13)
            assert(data_out == ((word13 >> f_shift) & 32'hff));
        if (pc == 8'd14) assert(instruction == word14);
        if (!load_length && f_address == 8'd14)
            assert(data_out == ((word14 >> f_shift) & 32'hff));
        if (pc == 8'd15) assert(instruction == word15);
        if (!load_length && f_address == 8'd15)
            assert(data_out == ((word15 >> f_shift) & 32'hff));
        if (pc == 8'd16) assert(instruction == word16);
        if (!load_length && f_address == 8'd16)
            assert(data_out == ((word16 >> f_shift) & 32'hff));
        if (pc == 8'd17) assert(instruction == word17);
        if (!load_length && f_address == 8'd17)
            assert(data_out == ((word17 >> f_shift) & 32'hff));
        if (pc == 8'd18) assert(instruction == word18);
        if (!load_length && f_address == 8'd18)
            assert(data_out == ((word18 >> f_shift) & 32'hff));
        if (pc == 8'd19) assert(instruction == word19);
        if (!load_length && f_address == 8'd19)
            assert(data_out == ((word19 >> f_shift) & 32'hff));
        if (pc == 8'd20) assert(instruction == word20);
        if (!load_length && f_address == 8'd20)
            assert(data_out == ((word20 >> f_shift) & 32'hff));
        if (pc == 8'd21) assert(instruction == word21);
        if (!load_length && f_address == 8'd21)
            assert(data_out == ((word21 >> f_shift) & 32'hff));
        if (pc == 8'd22) assert(instruction == word22);
        if (!load_length && f_address == 8'd22)
            assert(data_out == ((word22 >> f_shift) & 32'hff));
        if (pc == 8'd23) assert(instruction == word23);
        if (!load_length && f_address == 8'd23)
            assert(data_out == ((word23 >> f_shift) & 32'hff));
        if (pc == 8'd24) assert(instruction == word24);
        if (!load_length && f_address == 8'd24)
            assert(data_out == ((word24 >> f_shift) & 32'hff));
        if (pc == 8'd25) assert(instruction == word25);
        if (!load_length && f_address == 8'd25)
            assert(data_out == ((word25 >> f_shift) & 32'hff));
        if (pc == 8'd26) assert(instruction == word26);
        if (!load_length && f_address == 8'd26)
            assert(data_out == ((word26 >> f_shift) & 32'hff));
        if (pc == 8'd27) assert(instruction == word27);
        if (!load_length && f_address == 8'd27)
            assert(data_out == ((word27 >> f_shift) & 32'hff));
        if (pc == 8'd28) assert(instruction == word28);
        if (!load_length && f_address == 8'd28)
            assert(data_out == ((word28 >> f_shift) & 32'hff));
        if (pc == 8'd29) assert(instruction == word29);
        if (!load_length && f_address == 8'd29)
            assert(data_out == ((word29 >> f_shift) & 32'hff));
        if (pc == 8'd30) assert(instruction == word30);
        if (!load_length && f_address == 8'd30)
            assert(data_out == ((word30 >> f_shift) & 32'hff));
        if (pc == 8'd31) assert(instruction == word31);
        if (!load_length && f_address == 8'd31)
            assert(data_out == ((word31 >> f_shift) & 32'hff));
        if (pc == 8'd32) assert(instruction == word32);
        if (!load_length && f_address == 8'd32)
            assert(data_out == ((word32 >> f_shift) & 32'hff));
        if (pc == 8'd33) assert(instruction == word33);
        if (!load_length && f_address == 8'd33)
            assert(data_out == ((word33 >> f_shift) & 32'hff));
        if (pc == 8'd34) assert(instruction == word34);
        if (!load_length && f_address == 8'd34)
            assert(data_out == ((word34 >> f_shift) & 32'hff));
        if (pc == 8'd35) assert(instruction == word35);
        if (!load_length && f_address == 8'd35)
            assert(data_out == ((word35 >> f_shift) & 32'hff));
        if (pc == 8'd36) assert(instruction == word36);
        if (!load_length && f_address == 8'd36)
            assert(data_out == ((word36 >> f_shift) & 32'hff));
        if (pc == 8'd37) assert(instruction == word37);
        if (!load_length && f_address == 8'd37)
            assert(data_out == ((word37 >> f_shift) & 32'hff));
        if (pc == 8'd38) assert(instruction == word38);
        if (!load_length && f_address == 8'd38)
            assert(data_out == ((word38 >> f_shift) & 32'hff));
        if (pc == 8'd39) assert(instruction == word39);
        if (!load_length && f_address == 8'd39)
            assert(data_out == ((word39 >> f_shift) & 32'hff));
        if (pc == 8'd40) assert(instruction == word40);
        if (!load_length && f_address == 8'd40)
            assert(data_out == ((word40 >> f_shift) & 32'hff));
        if (pc == 8'd41) assert(instruction == word41);
        if (!load_length && f_address == 8'd41)
            assert(data_out == ((word41 >> f_shift) & 32'hff));
        if (pc == 8'd42) assert(instruction == word42);
        if (!load_length && f_address == 8'd42)
            assert(data_out == ((word42 >> f_shift) & 32'hff));
        if (pc == 8'd43) assert(instruction == word43);
        if (!load_length && f_address == 8'd43)
            assert(data_out == ((word43 >> f_shift) & 32'hff));
        if (pc == 8'd44) assert(instruction == word44);
        if (!load_length && f_address == 8'd44)
            assert(data_out == ((word44 >> f_shift) & 32'hff));
        if (pc == 8'd45) assert(instruction == word45);
        if (!load_length && f_address == 8'd45)
            assert(data_out == ((word45 >> f_shift) & 32'hff));
        if (pc == 8'd46) assert(instruction == word46);
        if (!load_length && f_address == 8'd46)
            assert(data_out == ((word46 >> f_shift) & 32'hff));
        if (pc == 8'd47) assert(instruction == word47);
        if (!load_length && f_address == 8'd47)
            assert(data_out == ((word47 >> f_shift) & 32'hff));
        if (pc == 8'd48) assert(instruction == word48);
        if (!load_length && f_address == 8'd48)
            assert(data_out == ((word48 >> f_shift) & 32'hff));
        if (pc == 8'd49) assert(instruction == word49);
        if (!load_length && f_address == 8'd49)
            assert(data_out == ((word49 >> f_shift) & 32'hff));
        if (pc == 8'd50) assert(instruction == word50);
        if (!load_length && f_address == 8'd50)
            assert(data_out == ((word50 >> f_shift) & 32'hff));
        if (pc == 8'd51) assert(instruction == word51);
        if (!load_length && f_address == 8'd51)
            assert(data_out == ((word51 >> f_shift) & 32'hff));
        if (pc == 8'd52) assert(instruction == word52);
        if (!load_length && f_address == 8'd52)
            assert(data_out == ((word52 >> f_shift) & 32'hff));
        if (pc == 8'd53) assert(instruction == word53);
        if (!load_length && f_address == 8'd53)
            assert(data_out == ((word53 >> f_shift) & 32'hff));
        if (pc == 8'd54) assert(instruction == word54);
        if (!load_length && f_address == 8'd54)
            assert(data_out == ((word54 >> f_shift) & 32'hff));
        if (pc == 8'd55) assert(instruction == word55);
        if (!load_length && f_address == 8'd55)
            assert(data_out == ((word55 >> f_shift) & 32'hff));
        if (pc == 8'd56) assert(instruction == word56);
        if (!load_length && f_address == 8'd56)
            assert(data_out == ((word56 >> f_shift) & 32'hff));
        if (pc == 8'd57) assert(instruction == word57);
        if (!load_length && f_address == 8'd57)
            assert(data_out == ((word57 >> f_shift) & 32'hff));
        if (pc == 8'd58) assert(instruction == word58);
        if (!load_length && f_address == 8'd58)
            assert(data_out == ((word58 >> f_shift) & 32'hff));
        if (pc == 8'd59) assert(instruction == word59);
        if (!load_length && f_address == 8'd59)
            assert(data_out == ((word59 >> f_shift) & 32'hff));
        if (pc == 8'd60) assert(instruction == word60);
        if (!load_length && f_address == 8'd60)
            assert(data_out == ((word60 >> f_shift) & 32'hff));
        if (pc == 8'd61) assert(instruction == word61);
        if (!load_length && f_address == 8'd61)
            assert(data_out == ((word61 >> f_shift) & 32'hff));
        if (pc == 8'd62) assert(instruction == word62);
        if (!load_length && f_address == 8'd62)
            assert(data_out == ((word62 >> f_shift) & 32'hff));
        if (pc == 8'd63) assert(instruction == word63);
        if (!load_length && f_address == 8'd63)
            assert(data_out == ((word63 >> f_shift) & 32'hff));
        if (pc == 8'd64) assert(instruction == word64);
        if (!load_length && f_address == 8'd64)
            assert(data_out == ((word64 >> f_shift) & 32'hff));
        if (pc == 8'd65) assert(instruction == word65);
        if (!load_length && f_address == 8'd65)
            assert(data_out == ((word65 >> f_shift) & 32'hff));
        if (pc == 8'd66) assert(instruction == word66);
        if (!load_length && f_address == 8'd66)
            assert(data_out == ((word66 >> f_shift) & 32'hff));
        if (pc == 8'd67) assert(instruction == word67);
        if (!load_length && f_address == 8'd67)
            assert(data_out == ((word67 >> f_shift) & 32'hff));
        if (pc == 8'd68) assert(instruction == word68);
        if (!load_length && f_address == 8'd68)
            assert(data_out == ((word68 >> f_shift) & 32'hff));
        if (pc == 8'd69) assert(instruction == word69);
        if (!load_length && f_address == 8'd69)
            assert(data_out == ((word69 >> f_shift) & 32'hff));
        if (pc == 8'd70) assert(instruction == word70);
        if (!load_length && f_address == 8'd70)
            assert(data_out == ((word70 >> f_shift) & 32'hff));
        if (pc == 8'd71) assert(instruction == word71);
        if (!load_length && f_address == 8'd71)
            assert(data_out == ((word71 >> f_shift) & 32'hff));
        if (pc == 8'd72) assert(instruction == word72);
        if (!load_length && f_address == 8'd72)
            assert(data_out == ((word72 >> f_shift) & 32'hff));
        if (pc == 8'd73) assert(instruction == word73);
        if (!load_length && f_address == 8'd73)
            assert(data_out == ((word73 >> f_shift) & 32'hff));
        if (pc == 8'd74) assert(instruction == word74);
        if (!load_length && f_address == 8'd74)
            assert(data_out == ((word74 >> f_shift) & 32'hff));
        if (pc == 8'd75) assert(instruction == word75);
        if (!load_length && f_address == 8'd75)
            assert(data_out == ((word75 >> f_shift) & 32'hff));
        if (pc == 8'd76) assert(instruction == word76);
        if (!load_length && f_address == 8'd76)
            assert(data_out == ((word76 >> f_shift) & 32'hff));
        if (pc == 8'd77) assert(instruction == word77);
        if (!load_length && f_address == 8'd77)
            assert(data_out == ((word77 >> f_shift) & 32'hff));
        if (pc == 8'd78) assert(instruction == word78);
        if (!load_length && f_address == 8'd78)
            assert(data_out == ((word78 >> f_shift) & 32'hff));
        if (pc == 8'd79) assert(instruction == word79);
        if (!load_length && f_address == 8'd79)
            assert(data_out == ((word79 >> f_shift) & 32'hff));
        if (pc == 8'd80) assert(instruction == word80);
        if (!load_length && f_address == 8'd80)
            assert(data_out == ((word80 >> f_shift) & 32'hff));
        if (pc == 8'd81) assert(instruction == word81);
        if (!load_length && f_address == 8'd81)
            assert(data_out == ((word81 >> f_shift) & 32'hff));
        if (pc == 8'd82) assert(instruction == word82);
        if (!load_length && f_address == 8'd82)
            assert(data_out == ((word82 >> f_shift) & 32'hff));
        if (pc == 8'd83) assert(instruction == word83);
        if (!load_length && f_address == 8'd83)
            assert(data_out == ((word83 >> f_shift) & 32'hff));
        if (pc == 8'd84) assert(instruction == word84);
        if (!load_length && f_address == 8'd84)
            assert(data_out == ((word84 >> f_shift) & 32'hff));
        if (pc == 8'd85) assert(instruction == word85);
        if (!load_length && f_address == 8'd85)
            assert(data_out == ((word85 >> f_shift) & 32'hff));
        if (pc == 8'd86) assert(instruction == word86);
        if (!load_length && f_address == 8'd86)
            assert(data_out == ((word86 >> f_shift) & 32'hff));
        if (pc == 8'd87) assert(instruction == word87);
        if (!load_length && f_address == 8'd87)
            assert(data_out == ((word87 >> f_shift) & 32'hff));
        if (pc == 8'd88) assert(instruction == word88);
        if (!load_length && f_address == 8'd88)
            assert(data_out == ((word88 >> f_shift) & 32'hff));
        if (pc == 8'd89) assert(instruction == word89);
        if (!load_length && f_address == 8'd89)
            assert(data_out == ((word89 >> f_shift) & 32'hff));
        if (pc == 8'd90) assert(instruction == word90);
        if (!load_length && f_address == 8'd90)
            assert(data_out == ((word90 >> f_shift) & 32'hff));
        if (pc == 8'd91) assert(instruction == word91);
        if (!load_length && f_address == 8'd91)
            assert(data_out == ((word91 >> f_shift) & 32'hff));
        if (pc == 8'd92) assert(instruction == word92);
        if (!load_length && f_address == 8'd92)
            assert(data_out == ((word92 >> f_shift) & 32'hff));
        if (pc == 8'd93) assert(instruction == word93);
        if (!load_length && f_address == 8'd93)
            assert(data_out == ((word93 >> f_shift) & 32'hff));
        if (pc == 8'd94) assert(instruction == word94);
        if (!load_length && f_address == 8'd94)
            assert(data_out == ((word94 >> f_shift) & 32'hff));
        if (pc == 8'd95) assert(instruction == word95);
        if (!load_length && f_address == 8'd95)
            assert(data_out == ((word95 >> f_shift) & 32'hff));
        if (pc == 8'd96) assert(instruction == word96);
        if (!load_length && f_address == 8'd96)
            assert(data_out == ((word96 >> f_shift) & 32'hff));
        if (pc == 8'd97) assert(instruction == word97);
        if (!load_length && f_address == 8'd97)
            assert(data_out == ((word97 >> f_shift) & 32'hff));
        if (pc == 8'd98) assert(instruction == word98);
        if (!load_length && f_address == 8'd98)
            assert(data_out == ((word98 >> f_shift) & 32'hff));
        if (pc == 8'd99) assert(instruction == word99);
        if (!load_length && f_address == 8'd99)
            assert(data_out == ((word99 >> f_shift) & 32'hff));
        if (pc == 8'd100) assert(instruction == word100);
        if (!load_length && f_address == 8'd100)
            assert(data_out == ((word100 >> f_shift) & 32'hff));
        if (pc == 8'd101) assert(instruction == word101);
        if (!load_length && f_address == 8'd101)
            assert(data_out == ((word101 >> f_shift) & 32'hff));
        if (pc == 8'd102) assert(instruction == word102);
        if (!load_length && f_address == 8'd102)
            assert(data_out == ((word102 >> f_shift) & 32'hff));
        if (pc == 8'd103) assert(instruction == word103);
        if (!load_length && f_address == 8'd103)
            assert(data_out == ((word103 >> f_shift) & 32'hff));
        if (pc == 8'd104) assert(instruction == word104);
        if (!load_length && f_address == 8'd104)
            assert(data_out == ((word104 >> f_shift) & 32'hff));
        if (pc == 8'd105) assert(instruction == word105);
        if (!load_length && f_address == 8'd105)
            assert(data_out == ((word105 >> f_shift) & 32'hff));
        if (pc == 8'd106) assert(instruction == word106);
        if (!load_length && f_address == 8'd106)
            assert(data_out == ((word106 >> f_shift) & 32'hff));
        if (pc == 8'd107) assert(instruction == word107);
        if (!load_length && f_address == 8'd107)
            assert(data_out == ((word107 >> f_shift) & 32'hff));
        if (pc == 8'd108) assert(instruction == word108);
        if (!load_length && f_address == 8'd108)
            assert(data_out == ((word108 >> f_shift) & 32'hff));
        if (pc == 8'd109) assert(instruction == word109);
        if (!load_length && f_address == 8'd109)
            assert(data_out == ((word109 >> f_shift) & 32'hff));
        if (pc == 8'd110) assert(instruction == word110);
        if (!load_length && f_address == 8'd110)
            assert(data_out == ((word110 >> f_shift) & 32'hff));
        if (pc == 8'd111) assert(instruction == word111);
        if (!load_length && f_address == 8'd111)
            assert(data_out == ((word111 >> f_shift) & 32'hff));
        if (pc == 8'd112) assert(instruction == word112);
        if (!load_length && f_address == 8'd112)
            assert(data_out == ((word112 >> f_shift) & 32'hff));
        if (pc == 8'd113) assert(instruction == word113);
        if (!load_length && f_address == 8'd113)
            assert(data_out == ((word113 >> f_shift) & 32'hff));
        if (pc == 8'd114) assert(instruction == word114);
        if (!load_length && f_address == 8'd114)
            assert(data_out == ((word114 >> f_shift) & 32'hff));
        if (pc == 8'd115) assert(instruction == word115);
        if (!load_length && f_address == 8'd115)
            assert(data_out == ((word115 >> f_shift) & 32'hff));
        if (pc == 8'd116) assert(instruction == word116);
        if (!load_length && f_address == 8'd116)
            assert(data_out == ((word116 >> f_shift) & 32'hff));
        if (pc == 8'd117) assert(instruction == word117);
        if (!load_length && f_address == 8'd117)
            assert(data_out == ((word117 >> f_shift) & 32'hff));
        if (pc == 8'd118) assert(instruction == word118);
        if (!load_length && f_address == 8'd118)
            assert(data_out == ((word118 >> f_shift) & 32'hff));
        if (pc == 8'd119) assert(instruction == word119);
        if (!load_length && f_address == 8'd119)
            assert(data_out == ((word119 >> f_shift) & 32'hff));
        if (pc == 8'd120) assert(instruction == word120);
        if (!load_length && f_address == 8'd120)
            assert(data_out == ((word120 >> f_shift) & 32'hff));
        if (pc == 8'd121) assert(instruction == word121);
        if (!load_length && f_address == 8'd121)
            assert(data_out == ((word121 >> f_shift) & 32'hff));
        if (pc == 8'd122) assert(instruction == word122);
        if (!load_length && f_address == 8'd122)
            assert(data_out == ((word122 >> f_shift) & 32'hff));
        if (pc == 8'd123) assert(instruction == word123);
        if (!load_length && f_address == 8'd123)
            assert(data_out == ((word123 >> f_shift) & 32'hff));
        if (pc == 8'd124) assert(instruction == word124);
        if (!load_length && f_address == 8'd124)
            assert(data_out == ((word124 >> f_shift) & 32'hff));
        if (pc == 8'd125) assert(instruction == word125);
        if (!load_length && f_address == 8'd125)
            assert(data_out == ((word125 >> f_shift) & 32'hff));
        if (pc == 8'd126) assert(instruction == word126);
        if (!load_length && f_address == 8'd126)
            assert(data_out == ((word126 >> f_shift) & 32'hff));
        if (pc == 8'd127) assert(instruction == word127);
        if (!load_length && f_address == 8'd127)
            assert(data_out == ((word127 >> f_shift) & 32'hff));
    end
end

always @(posedge clk) begin
    f_past_valid <= 1'b1;
`ifdef REACHABLE
    if (!f_past_valid) assume(!rst_n);
`endif
    if (f_past_valid) begin
        
            if (!$past(rst_n)) assert(word0 == 0);
            else if ($past(f_data_write && f_address == 8'd0))
                assert(word0 == (($past(word0) & ~$past(f_mask)) | $past(f_value)));
            else assert(word0 == $past(word0));
            if (!$past(rst_n)) assert(word1 == 0);
            else if ($past(f_data_write && f_address == 8'd1))
                assert(word1 == (($past(word1) & ~$past(f_mask)) | $past(f_value)));
            else assert(word1 == $past(word1));
            if (!$past(rst_n)) assert(word2 == 0);
            else if ($past(f_data_write && f_address == 8'd2))
                assert(word2 == (($past(word2) & ~$past(f_mask)) | $past(f_value)));
            else assert(word2 == $past(word2));
            if (!$past(rst_n)) assert(word3 == 0);
            else if ($past(f_data_write && f_address == 8'd3))
                assert(word3 == (($past(word3) & ~$past(f_mask)) | $past(f_value)));
            else assert(word3 == $past(word3));
            if (!$past(rst_n)) assert(word4 == 0);
            else if ($past(f_data_write && f_address == 8'd4))
                assert(word4 == (($past(word4) & ~$past(f_mask)) | $past(f_value)));
            else assert(word4 == $past(word4));
            if (!$past(rst_n)) assert(word5 == 0);
            else if ($past(f_data_write && f_address == 8'd5))
                assert(word5 == (($past(word5) & ~$past(f_mask)) | $past(f_value)));
            else assert(word5 == $past(word5));
            if (!$past(rst_n)) assert(word6 == 0);
            else if ($past(f_data_write && f_address == 8'd6))
                assert(word6 == (($past(word6) & ~$past(f_mask)) | $past(f_value)));
            else assert(word6 == $past(word6));
            if (!$past(rst_n)) assert(word7 == 0);
            else if ($past(f_data_write && f_address == 8'd7))
                assert(word7 == (($past(word7) & ~$past(f_mask)) | $past(f_value)));
            else assert(word7 == $past(word7));
            if (!$past(rst_n)) assert(word8 == 0);
            else if ($past(f_data_write && f_address == 8'd8))
                assert(word8 == (($past(word8) & ~$past(f_mask)) | $past(f_value)));
            else assert(word8 == $past(word8));
            if (!$past(rst_n)) assert(word9 == 0);
            else if ($past(f_data_write && f_address == 8'd9))
                assert(word9 == (($past(word9) & ~$past(f_mask)) | $past(f_value)));
            else assert(word9 == $past(word9));
            if (!$past(rst_n)) assert(word10 == 0);
            else if ($past(f_data_write && f_address == 8'd10))
                assert(word10 == (($past(word10) & ~$past(f_mask)) | $past(f_value)));
            else assert(word10 == $past(word10));
            if (!$past(rst_n)) assert(word11 == 0);
            else if ($past(f_data_write && f_address == 8'd11))
                assert(word11 == (($past(word11) & ~$past(f_mask)) | $past(f_value)));
            else assert(word11 == $past(word11));
            if (!$past(rst_n)) assert(word12 == 0);
            else if ($past(f_data_write && f_address == 8'd12))
                assert(word12 == (($past(word12) & ~$past(f_mask)) | $past(f_value)));
            else assert(word12 == $past(word12));
            if (!$past(rst_n)) assert(word13 == 0);
            else if ($past(f_data_write && f_address == 8'd13))
                assert(word13 == (($past(word13) & ~$past(f_mask)) | $past(f_value)));
            else assert(word13 == $past(word13));
            if (!$past(rst_n)) assert(word14 == 0);
            else if ($past(f_data_write && f_address == 8'd14))
                assert(word14 == (($past(word14) & ~$past(f_mask)) | $past(f_value)));
            else assert(word14 == $past(word14));
            if (!$past(rst_n)) assert(word15 == 0);
            else if ($past(f_data_write && f_address == 8'd15))
                assert(word15 == (($past(word15) & ~$past(f_mask)) | $past(f_value)));
            else assert(word15 == $past(word15));
            if (!$past(rst_n)) assert(word16 == 0);
            else if ($past(f_data_write && f_address == 8'd16))
                assert(word16 == (($past(word16) & ~$past(f_mask)) | $past(f_value)));
            else assert(word16 == $past(word16));
            if (!$past(rst_n)) assert(word17 == 0);
            else if ($past(f_data_write && f_address == 8'd17))
                assert(word17 == (($past(word17) & ~$past(f_mask)) | $past(f_value)));
            else assert(word17 == $past(word17));
            if (!$past(rst_n)) assert(word18 == 0);
            else if ($past(f_data_write && f_address == 8'd18))
                assert(word18 == (($past(word18) & ~$past(f_mask)) | $past(f_value)));
            else assert(word18 == $past(word18));
            if (!$past(rst_n)) assert(word19 == 0);
            else if ($past(f_data_write && f_address == 8'd19))
                assert(word19 == (($past(word19) & ~$past(f_mask)) | $past(f_value)));
            else assert(word19 == $past(word19));
            if (!$past(rst_n)) assert(word20 == 0);
            else if ($past(f_data_write && f_address == 8'd20))
                assert(word20 == (($past(word20) & ~$past(f_mask)) | $past(f_value)));
            else assert(word20 == $past(word20));
            if (!$past(rst_n)) assert(word21 == 0);
            else if ($past(f_data_write && f_address == 8'd21))
                assert(word21 == (($past(word21) & ~$past(f_mask)) | $past(f_value)));
            else assert(word21 == $past(word21));
            if (!$past(rst_n)) assert(word22 == 0);
            else if ($past(f_data_write && f_address == 8'd22))
                assert(word22 == (($past(word22) & ~$past(f_mask)) | $past(f_value)));
            else assert(word22 == $past(word22));
            if (!$past(rst_n)) assert(word23 == 0);
            else if ($past(f_data_write && f_address == 8'd23))
                assert(word23 == (($past(word23) & ~$past(f_mask)) | $past(f_value)));
            else assert(word23 == $past(word23));
            if (!$past(rst_n)) assert(word24 == 0);
            else if ($past(f_data_write && f_address == 8'd24))
                assert(word24 == (($past(word24) & ~$past(f_mask)) | $past(f_value)));
            else assert(word24 == $past(word24));
            if (!$past(rst_n)) assert(word25 == 0);
            else if ($past(f_data_write && f_address == 8'd25))
                assert(word25 == (($past(word25) & ~$past(f_mask)) | $past(f_value)));
            else assert(word25 == $past(word25));
            if (!$past(rst_n)) assert(word26 == 0);
            else if ($past(f_data_write && f_address == 8'd26))
                assert(word26 == (($past(word26) & ~$past(f_mask)) | $past(f_value)));
            else assert(word26 == $past(word26));
            if (!$past(rst_n)) assert(word27 == 0);
            else if ($past(f_data_write && f_address == 8'd27))
                assert(word27 == (($past(word27) & ~$past(f_mask)) | $past(f_value)));
            else assert(word27 == $past(word27));
            if (!$past(rst_n)) assert(word28 == 0);
            else if ($past(f_data_write && f_address == 8'd28))
                assert(word28 == (($past(word28) & ~$past(f_mask)) | $past(f_value)));
            else assert(word28 == $past(word28));
            if (!$past(rst_n)) assert(word29 == 0);
            else if ($past(f_data_write && f_address == 8'd29))
                assert(word29 == (($past(word29) & ~$past(f_mask)) | $past(f_value)));
            else assert(word29 == $past(word29));
            if (!$past(rst_n)) assert(word30 == 0);
            else if ($past(f_data_write && f_address == 8'd30))
                assert(word30 == (($past(word30) & ~$past(f_mask)) | $past(f_value)));
            else assert(word30 == $past(word30));
            if (!$past(rst_n)) assert(word31 == 0);
            else if ($past(f_data_write && f_address == 8'd31))
                assert(word31 == (($past(word31) & ~$past(f_mask)) | $past(f_value)));
            else assert(word31 == $past(word31));
            if (!$past(rst_n)) assert(word32 == 0);
            else if ($past(f_data_write && f_address == 8'd32))
                assert(word32 == (($past(word32) & ~$past(f_mask)) | $past(f_value)));
            else assert(word32 == $past(word32));
            if (!$past(rst_n)) assert(word33 == 0);
            else if ($past(f_data_write && f_address == 8'd33))
                assert(word33 == (($past(word33) & ~$past(f_mask)) | $past(f_value)));
            else assert(word33 == $past(word33));
            if (!$past(rst_n)) assert(word34 == 0);
            else if ($past(f_data_write && f_address == 8'd34))
                assert(word34 == (($past(word34) & ~$past(f_mask)) | $past(f_value)));
            else assert(word34 == $past(word34));
            if (!$past(rst_n)) assert(word35 == 0);
            else if ($past(f_data_write && f_address == 8'd35))
                assert(word35 == (($past(word35) & ~$past(f_mask)) | $past(f_value)));
            else assert(word35 == $past(word35));
            if (!$past(rst_n)) assert(word36 == 0);
            else if ($past(f_data_write && f_address == 8'd36))
                assert(word36 == (($past(word36) & ~$past(f_mask)) | $past(f_value)));
            else assert(word36 == $past(word36));
            if (!$past(rst_n)) assert(word37 == 0);
            else if ($past(f_data_write && f_address == 8'd37))
                assert(word37 == (($past(word37) & ~$past(f_mask)) | $past(f_value)));
            else assert(word37 == $past(word37));
            if (!$past(rst_n)) assert(word38 == 0);
            else if ($past(f_data_write && f_address == 8'd38))
                assert(word38 == (($past(word38) & ~$past(f_mask)) | $past(f_value)));
            else assert(word38 == $past(word38));
            if (!$past(rst_n)) assert(word39 == 0);
            else if ($past(f_data_write && f_address == 8'd39))
                assert(word39 == (($past(word39) & ~$past(f_mask)) | $past(f_value)));
            else assert(word39 == $past(word39));
            if (!$past(rst_n)) assert(word40 == 0);
            else if ($past(f_data_write && f_address == 8'd40))
                assert(word40 == (($past(word40) & ~$past(f_mask)) | $past(f_value)));
            else assert(word40 == $past(word40));
            if (!$past(rst_n)) assert(word41 == 0);
            else if ($past(f_data_write && f_address == 8'd41))
                assert(word41 == (($past(word41) & ~$past(f_mask)) | $past(f_value)));
            else assert(word41 == $past(word41));
            if (!$past(rst_n)) assert(word42 == 0);
            else if ($past(f_data_write && f_address == 8'd42))
                assert(word42 == (($past(word42) & ~$past(f_mask)) | $past(f_value)));
            else assert(word42 == $past(word42));
            if (!$past(rst_n)) assert(word43 == 0);
            else if ($past(f_data_write && f_address == 8'd43))
                assert(word43 == (($past(word43) & ~$past(f_mask)) | $past(f_value)));
            else assert(word43 == $past(word43));
            if (!$past(rst_n)) assert(word44 == 0);
            else if ($past(f_data_write && f_address == 8'd44))
                assert(word44 == (($past(word44) & ~$past(f_mask)) | $past(f_value)));
            else assert(word44 == $past(word44));
            if (!$past(rst_n)) assert(word45 == 0);
            else if ($past(f_data_write && f_address == 8'd45))
                assert(word45 == (($past(word45) & ~$past(f_mask)) | $past(f_value)));
            else assert(word45 == $past(word45));
            if (!$past(rst_n)) assert(word46 == 0);
            else if ($past(f_data_write && f_address == 8'd46))
                assert(word46 == (($past(word46) & ~$past(f_mask)) | $past(f_value)));
            else assert(word46 == $past(word46));
            if (!$past(rst_n)) assert(word47 == 0);
            else if ($past(f_data_write && f_address == 8'd47))
                assert(word47 == (($past(word47) & ~$past(f_mask)) | $past(f_value)));
            else assert(word47 == $past(word47));
            if (!$past(rst_n)) assert(word48 == 0);
            else if ($past(f_data_write && f_address == 8'd48))
                assert(word48 == (($past(word48) & ~$past(f_mask)) | $past(f_value)));
            else assert(word48 == $past(word48));
            if (!$past(rst_n)) assert(word49 == 0);
            else if ($past(f_data_write && f_address == 8'd49))
                assert(word49 == (($past(word49) & ~$past(f_mask)) | $past(f_value)));
            else assert(word49 == $past(word49));
            if (!$past(rst_n)) assert(word50 == 0);
            else if ($past(f_data_write && f_address == 8'd50))
                assert(word50 == (($past(word50) & ~$past(f_mask)) | $past(f_value)));
            else assert(word50 == $past(word50));
            if (!$past(rst_n)) assert(word51 == 0);
            else if ($past(f_data_write && f_address == 8'd51))
                assert(word51 == (($past(word51) & ~$past(f_mask)) | $past(f_value)));
            else assert(word51 == $past(word51));
            if (!$past(rst_n)) assert(word52 == 0);
            else if ($past(f_data_write && f_address == 8'd52))
                assert(word52 == (($past(word52) & ~$past(f_mask)) | $past(f_value)));
            else assert(word52 == $past(word52));
            if (!$past(rst_n)) assert(word53 == 0);
            else if ($past(f_data_write && f_address == 8'd53))
                assert(word53 == (($past(word53) & ~$past(f_mask)) | $past(f_value)));
            else assert(word53 == $past(word53));
            if (!$past(rst_n)) assert(word54 == 0);
            else if ($past(f_data_write && f_address == 8'd54))
                assert(word54 == (($past(word54) & ~$past(f_mask)) | $past(f_value)));
            else assert(word54 == $past(word54));
            if (!$past(rst_n)) assert(word55 == 0);
            else if ($past(f_data_write && f_address == 8'd55))
                assert(word55 == (($past(word55) & ~$past(f_mask)) | $past(f_value)));
            else assert(word55 == $past(word55));
            if (!$past(rst_n)) assert(word56 == 0);
            else if ($past(f_data_write && f_address == 8'd56))
                assert(word56 == (($past(word56) & ~$past(f_mask)) | $past(f_value)));
            else assert(word56 == $past(word56));
            if (!$past(rst_n)) assert(word57 == 0);
            else if ($past(f_data_write && f_address == 8'd57))
                assert(word57 == (($past(word57) & ~$past(f_mask)) | $past(f_value)));
            else assert(word57 == $past(word57));
            if (!$past(rst_n)) assert(word58 == 0);
            else if ($past(f_data_write && f_address == 8'd58))
                assert(word58 == (($past(word58) & ~$past(f_mask)) | $past(f_value)));
            else assert(word58 == $past(word58));
            if (!$past(rst_n)) assert(word59 == 0);
            else if ($past(f_data_write && f_address == 8'd59))
                assert(word59 == (($past(word59) & ~$past(f_mask)) | $past(f_value)));
            else assert(word59 == $past(word59));
            if (!$past(rst_n)) assert(word60 == 0);
            else if ($past(f_data_write && f_address == 8'd60))
                assert(word60 == (($past(word60) & ~$past(f_mask)) | $past(f_value)));
            else assert(word60 == $past(word60));
            if (!$past(rst_n)) assert(word61 == 0);
            else if ($past(f_data_write && f_address == 8'd61))
                assert(word61 == (($past(word61) & ~$past(f_mask)) | $past(f_value)));
            else assert(word61 == $past(word61));
            if (!$past(rst_n)) assert(word62 == 0);
            else if ($past(f_data_write && f_address == 8'd62))
                assert(word62 == (($past(word62) & ~$past(f_mask)) | $past(f_value)));
            else assert(word62 == $past(word62));
            if (!$past(rst_n)) assert(word63 == 0);
            else if ($past(f_data_write && f_address == 8'd63))
                assert(word63 == (($past(word63) & ~$past(f_mask)) | $past(f_value)));
            else assert(word63 == $past(word63));
            if (!$past(rst_n)) assert(word64 == 0);
            else if ($past(f_data_write && f_address == 8'd64))
                assert(word64 == (($past(word64) & ~$past(f_mask)) | $past(f_value)));
            else assert(word64 == $past(word64));
            if (!$past(rst_n)) assert(word65 == 0);
            else if ($past(f_data_write && f_address == 8'd65))
                assert(word65 == (($past(word65) & ~$past(f_mask)) | $past(f_value)));
            else assert(word65 == $past(word65));
            if (!$past(rst_n)) assert(word66 == 0);
            else if ($past(f_data_write && f_address == 8'd66))
                assert(word66 == (($past(word66) & ~$past(f_mask)) | $past(f_value)));
            else assert(word66 == $past(word66));
            if (!$past(rst_n)) assert(word67 == 0);
            else if ($past(f_data_write && f_address == 8'd67))
                assert(word67 == (($past(word67) & ~$past(f_mask)) | $past(f_value)));
            else assert(word67 == $past(word67));
            if (!$past(rst_n)) assert(word68 == 0);
            else if ($past(f_data_write && f_address == 8'd68))
                assert(word68 == (($past(word68) & ~$past(f_mask)) | $past(f_value)));
            else assert(word68 == $past(word68));
            if (!$past(rst_n)) assert(word69 == 0);
            else if ($past(f_data_write && f_address == 8'd69))
                assert(word69 == (($past(word69) & ~$past(f_mask)) | $past(f_value)));
            else assert(word69 == $past(word69));
            if (!$past(rst_n)) assert(word70 == 0);
            else if ($past(f_data_write && f_address == 8'd70))
                assert(word70 == (($past(word70) & ~$past(f_mask)) | $past(f_value)));
            else assert(word70 == $past(word70));
            if (!$past(rst_n)) assert(word71 == 0);
            else if ($past(f_data_write && f_address == 8'd71))
                assert(word71 == (($past(word71) & ~$past(f_mask)) | $past(f_value)));
            else assert(word71 == $past(word71));
            if (!$past(rst_n)) assert(word72 == 0);
            else if ($past(f_data_write && f_address == 8'd72))
                assert(word72 == (($past(word72) & ~$past(f_mask)) | $past(f_value)));
            else assert(word72 == $past(word72));
            if (!$past(rst_n)) assert(word73 == 0);
            else if ($past(f_data_write && f_address == 8'd73))
                assert(word73 == (($past(word73) & ~$past(f_mask)) | $past(f_value)));
            else assert(word73 == $past(word73));
            if (!$past(rst_n)) assert(word74 == 0);
            else if ($past(f_data_write && f_address == 8'd74))
                assert(word74 == (($past(word74) & ~$past(f_mask)) | $past(f_value)));
            else assert(word74 == $past(word74));
            if (!$past(rst_n)) assert(word75 == 0);
            else if ($past(f_data_write && f_address == 8'd75))
                assert(word75 == (($past(word75) & ~$past(f_mask)) | $past(f_value)));
            else assert(word75 == $past(word75));
            if (!$past(rst_n)) assert(word76 == 0);
            else if ($past(f_data_write && f_address == 8'd76))
                assert(word76 == (($past(word76) & ~$past(f_mask)) | $past(f_value)));
            else assert(word76 == $past(word76));
            if (!$past(rst_n)) assert(word77 == 0);
            else if ($past(f_data_write && f_address == 8'd77))
                assert(word77 == (($past(word77) & ~$past(f_mask)) | $past(f_value)));
            else assert(word77 == $past(word77));
            if (!$past(rst_n)) assert(word78 == 0);
            else if ($past(f_data_write && f_address == 8'd78))
                assert(word78 == (($past(word78) & ~$past(f_mask)) | $past(f_value)));
            else assert(word78 == $past(word78));
            if (!$past(rst_n)) assert(word79 == 0);
            else if ($past(f_data_write && f_address == 8'd79))
                assert(word79 == (($past(word79) & ~$past(f_mask)) | $past(f_value)));
            else assert(word79 == $past(word79));
            if (!$past(rst_n)) assert(word80 == 0);
            else if ($past(f_data_write && f_address == 8'd80))
                assert(word80 == (($past(word80) & ~$past(f_mask)) | $past(f_value)));
            else assert(word80 == $past(word80));
            if (!$past(rst_n)) assert(word81 == 0);
            else if ($past(f_data_write && f_address == 8'd81))
                assert(word81 == (($past(word81) & ~$past(f_mask)) | $past(f_value)));
            else assert(word81 == $past(word81));
            if (!$past(rst_n)) assert(word82 == 0);
            else if ($past(f_data_write && f_address == 8'd82))
                assert(word82 == (($past(word82) & ~$past(f_mask)) | $past(f_value)));
            else assert(word82 == $past(word82));
            if (!$past(rst_n)) assert(word83 == 0);
            else if ($past(f_data_write && f_address == 8'd83))
                assert(word83 == (($past(word83) & ~$past(f_mask)) | $past(f_value)));
            else assert(word83 == $past(word83));
            if (!$past(rst_n)) assert(word84 == 0);
            else if ($past(f_data_write && f_address == 8'd84))
                assert(word84 == (($past(word84) & ~$past(f_mask)) | $past(f_value)));
            else assert(word84 == $past(word84));
            if (!$past(rst_n)) assert(word85 == 0);
            else if ($past(f_data_write && f_address == 8'd85))
                assert(word85 == (($past(word85) & ~$past(f_mask)) | $past(f_value)));
            else assert(word85 == $past(word85));
            if (!$past(rst_n)) assert(word86 == 0);
            else if ($past(f_data_write && f_address == 8'd86))
                assert(word86 == (($past(word86) & ~$past(f_mask)) | $past(f_value)));
            else assert(word86 == $past(word86));
            if (!$past(rst_n)) assert(word87 == 0);
            else if ($past(f_data_write && f_address == 8'd87))
                assert(word87 == (($past(word87) & ~$past(f_mask)) | $past(f_value)));
            else assert(word87 == $past(word87));
            if (!$past(rst_n)) assert(word88 == 0);
            else if ($past(f_data_write && f_address == 8'd88))
                assert(word88 == (($past(word88) & ~$past(f_mask)) | $past(f_value)));
            else assert(word88 == $past(word88));
            if (!$past(rst_n)) assert(word89 == 0);
            else if ($past(f_data_write && f_address == 8'd89))
                assert(word89 == (($past(word89) & ~$past(f_mask)) | $past(f_value)));
            else assert(word89 == $past(word89));
            if (!$past(rst_n)) assert(word90 == 0);
            else if ($past(f_data_write && f_address == 8'd90))
                assert(word90 == (($past(word90) & ~$past(f_mask)) | $past(f_value)));
            else assert(word90 == $past(word90));
            if (!$past(rst_n)) assert(word91 == 0);
            else if ($past(f_data_write && f_address == 8'd91))
                assert(word91 == (($past(word91) & ~$past(f_mask)) | $past(f_value)));
            else assert(word91 == $past(word91));
            if (!$past(rst_n)) assert(word92 == 0);
            else if ($past(f_data_write && f_address == 8'd92))
                assert(word92 == (($past(word92) & ~$past(f_mask)) | $past(f_value)));
            else assert(word92 == $past(word92));
            if (!$past(rst_n)) assert(word93 == 0);
            else if ($past(f_data_write && f_address == 8'd93))
                assert(word93 == (($past(word93) & ~$past(f_mask)) | $past(f_value)));
            else assert(word93 == $past(word93));
            if (!$past(rst_n)) assert(word94 == 0);
            else if ($past(f_data_write && f_address == 8'd94))
                assert(word94 == (($past(word94) & ~$past(f_mask)) | $past(f_value)));
            else assert(word94 == $past(word94));
            if (!$past(rst_n)) assert(word95 == 0);
            else if ($past(f_data_write && f_address == 8'd95))
                assert(word95 == (($past(word95) & ~$past(f_mask)) | $past(f_value)));
            else assert(word95 == $past(word95));
            if (!$past(rst_n)) assert(word96 == 0);
            else if ($past(f_data_write && f_address == 8'd96))
                assert(word96 == (($past(word96) & ~$past(f_mask)) | $past(f_value)));
            else assert(word96 == $past(word96));
            if (!$past(rst_n)) assert(word97 == 0);
            else if ($past(f_data_write && f_address == 8'd97))
                assert(word97 == (($past(word97) & ~$past(f_mask)) | $past(f_value)));
            else assert(word97 == $past(word97));
            if (!$past(rst_n)) assert(word98 == 0);
            else if ($past(f_data_write && f_address == 8'd98))
                assert(word98 == (($past(word98) & ~$past(f_mask)) | $past(f_value)));
            else assert(word98 == $past(word98));
            if (!$past(rst_n)) assert(word99 == 0);
            else if ($past(f_data_write && f_address == 8'd99))
                assert(word99 == (($past(word99) & ~$past(f_mask)) | $past(f_value)));
            else assert(word99 == $past(word99));
            if (!$past(rst_n)) assert(word100 == 0);
            else if ($past(f_data_write && f_address == 8'd100))
                assert(word100 == (($past(word100) & ~$past(f_mask)) | $past(f_value)));
            else assert(word100 == $past(word100));
            if (!$past(rst_n)) assert(word101 == 0);
            else if ($past(f_data_write && f_address == 8'd101))
                assert(word101 == (($past(word101) & ~$past(f_mask)) | $past(f_value)));
            else assert(word101 == $past(word101));
            if (!$past(rst_n)) assert(word102 == 0);
            else if ($past(f_data_write && f_address == 8'd102))
                assert(word102 == (($past(word102) & ~$past(f_mask)) | $past(f_value)));
            else assert(word102 == $past(word102));
            if (!$past(rst_n)) assert(word103 == 0);
            else if ($past(f_data_write && f_address == 8'd103))
                assert(word103 == (($past(word103) & ~$past(f_mask)) | $past(f_value)));
            else assert(word103 == $past(word103));
            if (!$past(rst_n)) assert(word104 == 0);
            else if ($past(f_data_write && f_address == 8'd104))
                assert(word104 == (($past(word104) & ~$past(f_mask)) | $past(f_value)));
            else assert(word104 == $past(word104));
            if (!$past(rst_n)) assert(word105 == 0);
            else if ($past(f_data_write && f_address == 8'd105))
                assert(word105 == (($past(word105) & ~$past(f_mask)) | $past(f_value)));
            else assert(word105 == $past(word105));
            if (!$past(rst_n)) assert(word106 == 0);
            else if ($past(f_data_write && f_address == 8'd106))
                assert(word106 == (($past(word106) & ~$past(f_mask)) | $past(f_value)));
            else assert(word106 == $past(word106));
            if (!$past(rst_n)) assert(word107 == 0);
            else if ($past(f_data_write && f_address == 8'd107))
                assert(word107 == (($past(word107) & ~$past(f_mask)) | $past(f_value)));
            else assert(word107 == $past(word107));
            if (!$past(rst_n)) assert(word108 == 0);
            else if ($past(f_data_write && f_address == 8'd108))
                assert(word108 == (($past(word108) & ~$past(f_mask)) | $past(f_value)));
            else assert(word108 == $past(word108));
            if (!$past(rst_n)) assert(word109 == 0);
            else if ($past(f_data_write && f_address == 8'd109))
                assert(word109 == (($past(word109) & ~$past(f_mask)) | $past(f_value)));
            else assert(word109 == $past(word109));
            if (!$past(rst_n)) assert(word110 == 0);
            else if ($past(f_data_write && f_address == 8'd110))
                assert(word110 == (($past(word110) & ~$past(f_mask)) | $past(f_value)));
            else assert(word110 == $past(word110));
            if (!$past(rst_n)) assert(word111 == 0);
            else if ($past(f_data_write && f_address == 8'd111))
                assert(word111 == (($past(word111) & ~$past(f_mask)) | $past(f_value)));
            else assert(word111 == $past(word111));
            if (!$past(rst_n)) assert(word112 == 0);
            else if ($past(f_data_write && f_address == 8'd112))
                assert(word112 == (($past(word112) & ~$past(f_mask)) | $past(f_value)));
            else assert(word112 == $past(word112));
            if (!$past(rst_n)) assert(word113 == 0);
            else if ($past(f_data_write && f_address == 8'd113))
                assert(word113 == (($past(word113) & ~$past(f_mask)) | $past(f_value)));
            else assert(word113 == $past(word113));
            if (!$past(rst_n)) assert(word114 == 0);
            else if ($past(f_data_write && f_address == 8'd114))
                assert(word114 == (($past(word114) & ~$past(f_mask)) | $past(f_value)));
            else assert(word114 == $past(word114));
            if (!$past(rst_n)) assert(word115 == 0);
            else if ($past(f_data_write && f_address == 8'd115))
                assert(word115 == (($past(word115) & ~$past(f_mask)) | $past(f_value)));
            else assert(word115 == $past(word115));
            if (!$past(rst_n)) assert(word116 == 0);
            else if ($past(f_data_write && f_address == 8'd116))
                assert(word116 == (($past(word116) & ~$past(f_mask)) | $past(f_value)));
            else assert(word116 == $past(word116));
            if (!$past(rst_n)) assert(word117 == 0);
            else if ($past(f_data_write && f_address == 8'd117))
                assert(word117 == (($past(word117) & ~$past(f_mask)) | $past(f_value)));
            else assert(word117 == $past(word117));
            if (!$past(rst_n)) assert(word118 == 0);
            else if ($past(f_data_write && f_address == 8'd118))
                assert(word118 == (($past(word118) & ~$past(f_mask)) | $past(f_value)));
            else assert(word118 == $past(word118));
            if (!$past(rst_n)) assert(word119 == 0);
            else if ($past(f_data_write && f_address == 8'd119))
                assert(word119 == (($past(word119) & ~$past(f_mask)) | $past(f_value)));
            else assert(word119 == $past(word119));
            if (!$past(rst_n)) assert(word120 == 0);
            else if ($past(f_data_write && f_address == 8'd120))
                assert(word120 == (($past(word120) & ~$past(f_mask)) | $past(f_value)));
            else assert(word120 == $past(word120));
            if (!$past(rst_n)) assert(word121 == 0);
            else if ($past(f_data_write && f_address == 8'd121))
                assert(word121 == (($past(word121) & ~$past(f_mask)) | $past(f_value)));
            else assert(word121 == $past(word121));
            if (!$past(rst_n)) assert(word122 == 0);
            else if ($past(f_data_write && f_address == 8'd122))
                assert(word122 == (($past(word122) & ~$past(f_mask)) | $past(f_value)));
            else assert(word122 == $past(word122));
            if (!$past(rst_n)) assert(word123 == 0);
            else if ($past(f_data_write && f_address == 8'd123))
                assert(word123 == (($past(word123) & ~$past(f_mask)) | $past(f_value)));
            else assert(word123 == $past(word123));
            if (!$past(rst_n)) assert(word124 == 0);
            else if ($past(f_data_write && f_address == 8'd124))
                assert(word124 == (($past(word124) & ~$past(f_mask)) | $past(f_value)));
            else assert(word124 == $past(word124));
            if (!$past(rst_n)) assert(word125 == 0);
            else if ($past(f_data_write && f_address == 8'd125))
                assert(word125 == (($past(word125) & ~$past(f_mask)) | $past(f_value)));
            else assert(word125 == $past(word125));
            if (!$past(rst_n)) assert(word126 == 0);
            else if ($past(f_data_write && f_address == 8'd126))
                assert(word126 == (($past(word126) & ~$past(f_mask)) | $past(f_value)));
            else assert(word126 == $past(word126));
            if (!$past(rst_n)) assert(word127 == 0);
            else if ($past(f_data_write && f_address == 8'd127))
                assert(word127 == (($past(word127) & ~$past(f_mask)) | $past(f_value)));
            else assert(word127 == $past(word127));
        if (!$past(rst_n)) begin
            assert(program_length == 0 && !program_ready && program_bank == 0);
        end else if ($past(f_write && load_bank)) begin
            assert(program_length == 0 && !program_ready);
            assert(program_bank == ($past(data_in) < 16 ? $past(data_in[3:0]) : 0));
        end else if ($past(f_write && load_length)) begin
            assert(program_bank == 0);
            assert(program_ready == $past(f_length_valid));
            assert(program_length == ($past(f_length_valid) ? $past(data_in) : 0));
        end else begin
            assert(program_length == $past(program_length) && program_bank == $past(program_bank));
            assert(program_ready == ($past(f_write) ? 0 : $past(program_ready)));
        end
        cover(program_ready && program_length == 128 && pc == 127 && instruction != 0);
        cover(rst_n && f_write && load_bank && data_in == 255);
        cover(rst_n && f_data_write && f_address == 127 && byte_address[1:0] == 3 && data_in == 165);
    end
end
endmodule
`default_nettype wire
