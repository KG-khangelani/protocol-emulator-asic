import hashlib
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_program_sensitivity import execute
OUT=ROOT/'build/g2-store-lanes-equivalence-01'
assert not OUT.exists()
OUT.mkdir()
result={'status':'RUNNING','tasks':[],'scope':'Store sequential equivalence from corresponding state, reset establishes equality; other four chip modules byte-identical'}
def save(): (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
save()
try:
    for variant in ('od128','literal255'):
        path=OUT/variant
        path.mkdir()
        old=ROOT/'evidence/E0035-general-i2c/sources/current'/variant/'m1_program_store.v'
        new=ROOT/'build/g2-store-lanes-01'/variant/'src/m1_program_store.v'
        for name in ('project.v','m1_engine.v','m1_data_store.v','m1_input_sync.v'):
            assert (old.parent/name).read_bytes()==(new.parent/name).read_bytes()
        script=f'read_verilog {old}; rename m1_program_store gold; read_verilog {new}; rename m1_program_store gate; '
        script+='proc; opt; equiv_make gold gate equivalence; hierarchy -top equivalence; equiv_simple; equiv_induct -seq 3; equiv_status -assert'
        (path/'proof.ys').write_text(script+'\n')
        run=execute(['yosys','-Q','-s',str(path/'proof.ys')],path/'run.log',240)
        passed=run['returncode']==0 and not run['timed_out'] and 'Equivalence successfully proven!' in (path/'run.log').read_text()
        result['tasks'].append({'variant':variant,'accepted':passed,'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),**run})
        save()
        print(variant,'PASS' if passed else 'INCONCLUSIVE_OR_FAIL',flush=True)
    result['status']='PASS_STORE_EQUIVALENCE' if all(t['accepted'] for t in result['tasks']) else 'NOT_QUALIFIED'
finally:
    save()
