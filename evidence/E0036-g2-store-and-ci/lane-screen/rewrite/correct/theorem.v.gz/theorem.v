module byte_lane_write(input [31:0] old_word, input [7:0] data_in,
    input [1:0] lane, output equal, output reg [31:0] variable_next, explicit_next);
always @(*) begin
    variable_next = old_word;
    variable_next[8*lane +: 8] = data_in;
    explicit_next = old_word;
    case (lane)
        2'd0: explicit_next[7:0] = data_in;
        2'd1: explicit_next[15:8] = data_in;
        2'd2: explicit_next[23:16] = data_in;
        2'd3: explicit_next[31:24] = data_in;
    endcase
end
assign equal = variable_next == explicit_next;
endmodule
