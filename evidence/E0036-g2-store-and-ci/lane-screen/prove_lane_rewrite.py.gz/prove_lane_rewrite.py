import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_program_sensitivity import execute, vcd_frames
OUT=ROOT/'build/g2-lane-rewrite-proof-02'
assert not OUT.exists()
OUT.mkdir()
source='''module byte_lane_write(input [31:0] old_word, input [7:0] data_in,
    input [1:0] lane, output equal, output reg [31:0] variable_next, explicit_next);
always @(*) begin
    variable_next = old_word;
    variable_next[8*lane +: 8] = data_in;
    explicit_next = old_word;
    case (lane)
        2'd0: explicit_next[7:0] = data_in;
        2'd1: explicit_next[15:8] = data_in;
        2'd2: explicit_next[23:16] = data_in;
        2'd3: explicit_next[31:24] = data_in;
    endcase
end
assign equal = variable_next == explicit_next;
endmodule
'''
result={'status':'RUNNING','tasks':[],'scope':'All values of a 32-bit word, eight-bit write data and two-bit lane; combinational local rewrite only'}
for mutant in (False,True):
    path=OUT/('wrong_lane' if mutant else 'correct')
    path.mkdir()
    actual=source.replace("2'd0: explicit_next[7:0]", "2'd0: explicit_next[15:8]") if mutant else source
    (path/'theorem.v').write_text(actual)
    script=f'read_verilog {path/"theorem.v"}; prep -top byte_lane_write; '
    script+=f'sat {"-falsify" if mutant else "-verify"} -prove equal 1 -show-all -dump_vcd {path/"witness.vcd"}'
    (path/'proof.ys').write_text(script+'\n')
    run=execute(['yosys','-Q','-s',str(path/'proof.ys')],path/'run.log',30)
    assert run['returncode']==0 and not run['timed_out']
    log=(path/'run.log').read_text()
    assert ('model found: FAIL' if mutant else 'no model found: SUCCESS') in log
    control=None
    if mutant:
        raw=(path/'witness.vcd').read_text()
        raw=raw.replace('$scope module \\byte_lane_write $end','$scope module public_spi $end')
        (path/'parsed.vcd').write_text(raw)
        rows=[{k.lstrip('\\'):v for k,v in row.items()} for row in vcd_frames(path/'parsed.vcd')]
        row=next(r for r in rows if 'old_word' in r)
        expected=(row['old_word']&~(255<<(8*row['lane'])))|(row['data_in']<<(8*row['lane']))
        assert row['variable_next']==expected and row['explicit_next']!=expected
        control=dict(row,expected=expected)
    result['tasks'].append({'mutant':mutant,'accepted':True,'source_sha256':hashlib.sha256((path/'theorem.v').read_bytes()).hexdigest(),'control':control,**run})
result['status']='PASS_LOCAL_REWRITE_AND_CHECKED_CONTROL'
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['status'])
