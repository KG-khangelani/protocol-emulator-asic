"""Bounded isolated screen: constant byte-lane writes, same store interface."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_comparison import cell_counts, TOP
OUT=ROOT/'build/g2-store-lanes-01'
assert not OUT.exists()
OUT.mkdir()
FILES=('project.v','m1_engine.v','m1_program_store.v','m1_data_store.v','m1_input_sync.v')
result={'status':'RUNNING','scope':'GENERIC_SCREEN_ONLY_NOT_MAPPED_OR_FUNCTIONALLY_QUALIFIED','measurements':{}}
def save(): (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
save()
try:
    for variant in ('od128','literal255'):
        src=OUT/variant/'src'
        src.mkdir(parents=True)
        original=ROOT/'evidence/E0035-general-i2c/sources/current'/variant
        for name in FILES:
            data=(original/name).read_text()
            if name=='m1_program_store.v':
                def replace(m):
                    indent,choice,index=m.groups()
                    body='\n'.join(f"{indent}        2'd{lane}: word{index}[{8*lane+7}:{8*lane}] <= data_in;" for lane in range(4))
                    return f'{indent}{choice}: begin\n{indent}    case (byte_address[1:0])\n{body}\n{indent}    endcase\n{indent}end'
                pattern=r"(?m)^( +)(\d+'d\d+): word(\d+)\[8\*byte_address\[1:0\] \+: 8\] <= data_in;"
                data,count=re.subn(pattern,replace,data)
                assert count==(128 if variant=='od128' else 255)
            (src/name).write_text(data)
        hashes={n:hashlib.sha256((src/n).read_bytes()).hexdigest() for n in FILES}
        netlist=src.parent/'synth.json'
        script='read_verilog '+' '.join(str(src/n) for n in FILES)
        script+=f'; hierarchy -check -top {TOP}; synth -top {TOP}; check -assert; stat; write_json {netlist}'
        (src.parent/'synth.ys').write_text(script+'\n')
        start=time.monotonic()
        with (src.parent/'synthesis.log').open('w') as log:
            completed=subprocess.run(['yosys','-Q','-s',str(src.parent/'synth.ys')],stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
        result['measurements'][variant]={'counts':cell_counts(netlist),'seconds':round(time.monotonic()-start,3),'source_sha256':hashes}
        save()
        print(variant,result['measurements'][variant]['counts'],flush=True)
    result['status']='PASS_GENERIC_SCREEN_ONLY'
except Exception as e:
    result.update(status='FAILED_OR_INCOMPLETE',error=str(e))
    raise
finally:
    save()
