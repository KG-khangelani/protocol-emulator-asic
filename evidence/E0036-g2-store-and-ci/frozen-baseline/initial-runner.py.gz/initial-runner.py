import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
sys.path.insert(0,str(ROOT/'experiments/i2c'))
import build_variants
import build_timed_gpio
import build_general
import run_formal
from legacy_baseline import baseline_sources, baseline_inputs
OUT=ROOT/'build/g2-frozen-baseline-01'
assert not OUT.exists()
OUT.mkdir()
raw_open=Path.open
def guarded_open(path,*args,**kwargs):
    assert path.resolve().parent != ROOT/'src', 'historical generator read current production: '+str(path)
    return raw_open(path,*args,**kwargs)
with patch.object(Path,'open',guarded_open):
    baseline=baseline_sources()
    phased=build_variants.build(OUT/'phase')
    timed=build_timed_gpio.build(OUT/'timed')
    general=build_general.build(OUT/'general')
    formal=run_formal.prepare(OUT/'formal')
reference=json.loads((ROOT/'build/i2c-general-08/variants/source-manifest.json').read_text())
for name in ('od128','literal255'):
    assert general[name]['source_sha256']==reference[name]['source_sha256']
legacy=json.loads((ROOT/'build/i2c-general-08/variants/legacy/source-manifest.json').read_text())
for name in legacy:
    assert timed[name]['source_sha256']==legacy[name]['source_sha256']
for name,record in phased.items():
    other='compact8' if name=='compact' else 'compact10' if name=='banked' else None
    if other:
        assert record['source_sha256']==timed[other]['source_sha256']
    else:
        assert record['source_sha256']=={n:hashlib.sha256(s.encode()).hexdigest() for n,s in baseline.items()}
result={'status':'PASS_FROZEN_BASELINE_AND_IDENTICAL_CANDIDATES','source_commit':'ae13f6bfcfd3fe21cd937768bc9e1151f441379c',
 'production_reads':'Forbidden by an active file-open guard during all four builders',
 'validated_builders':['build_variants','build_timed_gpio','build_general','run_formal.prepare'],
 'generated_hashes':{'phase':{n:r['source_sha256'] for n,r in phased.items()},'timed':{n:r['source_sha256'] for n,r in timed.items()},'general':{n:general[n]['source_sha256'] for n in ('od128','literal255')}},
 'baseline_inputs':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in baseline_inputs()},
 'scope':'Input-location/provenance change only; no new RTL or protocol behavior claimed'}
(OUT/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(result['status'])
