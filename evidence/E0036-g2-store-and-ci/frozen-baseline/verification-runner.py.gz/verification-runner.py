import hashlib
import json
from pathlib import Path
import sys
import subprocess
import types
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
sys.path.insert(0,str(ROOT/'experiments/i2c'))
import build_variants
import build_timed_gpio
import build_general
import run_formal
from legacy_baseline import baseline_sources, baseline_inputs
OUT=ROOT/'build/g2-frozen-baseline-02'
assert not OUT.exists()
OUT.mkdir()
raw_open=Path.open
def guarded_open(path,*args,**kwargs):
    assert path.resolve().parent != ROOT/'src', 'historical generator read current production: '+str(path)
    return raw_open(path,*args,**kwargs)
with patch.object(Path,'open',guarded_open):
    baseline=baseline_sources()
    phased=build_variants.build(OUT/'phase')
    timed=build_timed_gpio.build(OUT/'timed')
    general=build_general.build(OUT/'general')
    formal=run_formal.prepare(OUT/'formal')
reference=json.loads((ROOT/'build/i2c-general-08/variants/source-manifest.json').read_text())
for name in ('od128','literal255'):
    assert general[name]['source_sha256']==reference[name]['source_sha256']
legacy=json.loads((ROOT/'build/i2c-general-08/variants/legacy/source-manifest.json').read_text())
for name in legacy:
    assert timed[name]['source_sha256']==legacy[name]['source_sha256']
old_source=subprocess.check_output(['git','show','d3c340fc28166201e8c1085ae4f8b729e8c4b9d2:experiments/spi_phase/build_variants.py'],cwd=ROOT)
old_module=types.ModuleType('old_builder')
old_module.__file__=str(ROOT/'experiments/spi_phase/build_variants.py')
exec(compile(old_source,old_module.__file__,'exec'),old_module.__dict__)
old=old_module.build(OUT/'reference-phase')
for name,record in phased.items():
    assert record['source_sha256']==old[name]['source_sha256']
import legacy_baseline
bad=OUT/'corrupted-baseline'
bad.mkdir()
for path in legacy_baseline.BASELINE.iterdir():
    if path.is_file(): (bad/path.name).write_bytes(path.read_bytes())
(bad/'m1_program_store.v').write_bytes((bad/'m1_program_store.v').read_bytes()+b'\n// changed\n')
with patch.object(legacy_baseline,'BASELINE',bad):
    try:
        baseline_sources()
    except ValueError as error:
        assert str(error)=='frozen E0020 baseline drift: m1_program_store.v'
    else:
        raise AssertionError('changed frozen source was accepted')
result={'status':'PASS_FROZEN_BASELINE_AND_IDENTICAL_CANDIDATES','source_commit':'ae13f6bfcfd3fe21cd937768bc9e1151f441379c',
 'production_reads':'Forbidden by an active file-open guard during all four builders',
 'validated_builders':['build_variants','build_timed_gpio','build_general','run_formal.prepare'],
 'old_phase_builder_commit':'d3c340fc28166201e8c1085ae4f8b729e8c4b9d2',
 'old_phase_builder_sha256':hashlib.sha256(old_source).hexdigest(),
 'negative_control':'Changed frozen program-store bytes are rejected',
 'generated_hashes':{'phase':{n:r['source_sha256'] for n,r in phased.items()},'timed':{n:r['source_sha256'] for n,r in timed.items()},'general':{n:general[n]['source_sha256'] for n in ('od128','literal255')}},
 'baseline_inputs':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in baseline_inputs()},
 'scope':'Input-location/provenance change only; no new RTL or protocol behavior claimed'}
(OUT/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(result['status'])
