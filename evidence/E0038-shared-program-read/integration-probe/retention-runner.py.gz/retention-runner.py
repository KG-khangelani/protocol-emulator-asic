import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g2-integration-pilot-01'
OUT = ROOT / 'evidence/E0038-shared-program-read/integration-probe'
OUT.mkdir(parents=True, exist_ok=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
manifest = json.loads((BASE / 'pilot.json').read_bytes())
sources = json.loads((OUT.parent / 'sources/source-manifest.json').read_bytes())['od128']['source_sha256']
assert {n: sha((BASE / 'src' / n).read_bytes()) for n in sources} == sources
cases = ET.parse(BASE / 'test/integration-probe.xml').getroot().findall('.//testcase')
failed = [c.get('name') for c in cases if c.find('failure') is not None]
assert len(cases) == 22 and len(failed) == 4 and not any(c.find('skipped') is not None for c in cases)
retained = {}
for source, name in ((BASE / 'probe.log', 'run.log'), (BASE / 'test/integration-probe.xml', 'results.xml')):
    raw = source.read_bytes()
    (OUT / (name + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
    retained[name] = {'sha256': sha(raw), 'retained_file': name + '.gz'}
manifest.update(status='FAILED_LEGACY_DEFAULT_INTEGRATION_PROBE', source_sha256=sources,
                tests=22, passes=18, failed_tests=failed, retained=retained,
                harness_sha256={n: sha((BASE / n).read_bytes()) for n in ('test/Makefile', 'test/tb.v', 'test/test.py',
                    'test/test_uart_rx_public.py', 'test/test_spi_mode0_public.py')},
                interpretation='Four obsolete rejection/capacity assumptions and three direct-engine width warnings. D39 full public qualification is separate; this failed default integration probe is not a hardware pass.')
(OUT / 'result.json').write_bytes((json.dumps(manifest, indent=2) + '\n').encode())
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(manifest['status'], failed)
