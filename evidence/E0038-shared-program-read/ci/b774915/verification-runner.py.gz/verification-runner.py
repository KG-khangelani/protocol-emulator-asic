"""Audit the original CI ZIPs for the exact D39 source, one completed gate at a time."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'build/g2-ci-b774915'
OUT = ROOT / 'evidence/E0038-shared-program-read/ci/b774915'
OUT.mkdir(parents=True, exist_ok=True)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path): return json.loads(path.read_bytes())
def write(path, data): path.write_bytes((json.dumps(data, indent=2) + '\n').encode())
spec = importlib.util.spec_from_file_location('d39_audit', ROOT / 'evidence/E0038-shared-program-read/verify.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
run, jobs, artifacts = (read(BASE / (name + '.json')) for name in ('run', 'jobs', 'artifacts'))
assert run['head_sha'] == 'b774915f9612a9eb1ac9941974e8f774ae7e6fc0' and run['id'] == 43247666313
sources = read(ROOT / 'evidence/E0038-shared-program-read/sources/source-manifest.json')['od128']['source_sha256']
report = {'status': 'PARTIAL_CI_AUDIT', 'run_id': run['id'], 'source_commit': run['head_sha'],
          'source_sha256': sources, 'audited_gates': {}, 'all_jobs_observed': {j['name']: j['conclusion'] for j in jobs['jobs']},
          'scope': 'Only the listed new-candidate original archives are audited. Other job statuses are observations, not replayed artifacts.'}
for gate in ('shared-proof-controls', 'shared-selection'):
    name = 'i2c-general-' + gate + '-' + run['head_sha']
    entries = [a for a in artifacts['artifacts'] if a['name'] == name]
    if not entries: continue
    assert len(entries) == 1
    entry = entries[0]
    packed = BASE / (str(entry['id']) + '.zip')
    if not packed.exists(): continue
    job = next(j for j in jobs['jobs'] if j['name'] == 'qualify (' + gate + ')')
    assert job['status'] == 'completed' and job['conclusion'] == 'success' and job['run_id'] == run['id']
    assert entry['workflow_run']['id'] == run['id'] and entry['workflow_run']['head_sha'] == run['head_sha']
    assert packed.stat().st_size == entry['size_in_bytes'] and 'sha256:' + sha(packed.read_bytes()) == entry['digest']
    target = BASE / str(entry['id'])
    if not target.exists():
        target.mkdir()
        with zipfile.ZipFile(packed) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names))
            for item in archive.infolist():
                path = (target / item.filename).resolve()
                assert path.is_relative_to(target.resolve()) and not item.is_dir()
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(archive.read(item.filename))
    with zipfile.ZipFile(packed) as archive:
        for name in archive.namelist():
            assert (target / name).read_bytes() == archive.read(name)
    assert audit.physical.verify_sources(target / 'variants/od128/src', 'od128-shared') == sources
    root = read(target / 'result.json')
    assert root['sources']['od128']['source_sha256'] == sources and root['implementation'] == 'od128-shared'
    status = 'PASS_SHARED_CHIP_PROOF_AND_CONTROLS' if gate == 'shared-proof-controls' else 'PASS_SHARED_PUBLIC_SELECTION'
    assert root['status'] == status
    gate_report = {'job_id': job['id'], 'artifact_id': entry['id'], 'bytes': entry['size_in_bytes'], 'sha256': sha(packed.read_bytes())}
    style = read(target / 'style/result.json')
    assert style['status'] == 'PASS_SCOPED_STYLE_REVIEW' and style['sources'] == sources
    for stage in style['stages']:
        assert sha((target / 'style' / (stage['name'] + '.log')).read_bytes()) == stage['log_sha256']
    if gate == 'shared-proof-controls':
        gate_report['proof'] = audit.audit_proof(target / 'proof', sources)
        gate_report['controls'] = audit.audit_controls(target / 'controls', sources)
        negative = BASE / (str(entry['id']) + '-audit-controls')
        if not negative.exists():
            subprocess.run(['python', str(ROOT / 'experiments/i2c/falsify_shared_read_audit.py'),
                            '--proof', str(target / 'proof'), '--controls', str(target / 'controls'),
                            '--output', str(negative)], cwd=ROOT, check=True)
        checks = read(negative / 'result.json')
        assert checks['status'] == 'PASS_SHARED_AUDIT_NEGATIVE_CONTROLS' and len(checks['controls']) == 10
        gate_report['ten_audit_corruptions_replayed_locally'] = True
        shutil.copyfile(negative / 'result.json', OUT / 'auditor-controls.json')
    else:
        checks = BASE / (str(entry['id']) + '-public-checks')
        checks.mkdir(exist_ok=True)
        gate_report['public_simulators'] = audit.audit_selection(target / 'selection', sources, checks, require_sidecar=False)
        gate_report['omitted_redundant_check_files'] = 'The original workflow omitted both check.json sidecars. Recomputed checks from original JUnit and all records exactly match both embedded result.json checks. Local archive replay still requires its original sidecars; subsequent CI uploads include them.'
    shutil.copyfile(packed, OUT / packed.name)
    report['audited_gates'][gate] = gate_report
assert report['audited_gates']
if set(report['audited_gates']) == {'shared-proof-controls', 'shared-selection'}:
    report['status'] = 'PASS_AUDITED_SHARED_CANDIDATE_CI'
for name in ('run', 'jobs', 'artifacts'):
    shutil.copyfile(BASE / (name + '.json'), OUT / (name + '.json'))
write(OUT / 'verification.json', report)
(OUT / 'verification-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(report['status'], sorted(report['audited_gates']))
