"""Retain complete D39 inputs/results and every public witness, without simulator binaries."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0038-shared-program-read'
def sha(raw): return hashlib.sha256(raw).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('--gate', action='append', choices=('selection', 'proof', 'controls', 'style'))
args = parser.parse_args()
index = json.loads((OUT / 'archives.json').read_bytes()) if (OUT / 'archives.json').exists() else {}
for gate in args.gate or ('selection', 'proof', 'controls', 'style'):
    base = ROOT / ('build/g2-shared-' + gate + ('-02' if gate == 'style' else '-01'))
    report = json.loads((base / ('selection/result.json' if gate == 'selection' else 'result.json')).read_bytes())
    assert report['status'] == {
        'selection': 'PASS_G2_PHYSICAL_SELECTION_ON_BOTH_RTL_SIMULATORS',
        'proof': 'PASS_RESET_REACHABLE_COMPLETE_CHIP_EQUIVALENCE',
        'controls': 'PASS_PUBLIC_SHARED_READ_MUTATION_CONTROLS', 'style': 'PASS_SCOPED_STYLE_REVIEW'}[gate]
    files = {}
    for path in base.rglob('*'):
        if not path.is_file(): continue
        rel = path.relative_to(base)
        if 'sim' in rel.parts or '__pycache__' in rel.parts: continue
        files[rel.as_posix()] = path.read_bytes()
    script = {'selection': 'run_physical_selection.py', 'proof': 'run_shared_read_proof.py',
              'controls': 'run_shared_read_controls.py', 'style': 'lint_store_lanes.py'}[gate]
    files['runner.py'] = (ROOT / 'experiments/i2c' / script).read_bytes().replace(b'\r\n', b'\n')
    if gate == 'controls':
        files['test_shared_read_controls.py'] = (ROOT / 'test/test_shared_read_controls.py').read_bytes().replace(b'\r\n', b'\n')
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w') as archive:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(raw), 0o644
            archive.addfile(member, io.BytesIO(raw))
    packed = gzip.compress(stream.getvalue(), mtime=0)
    (OUT / (gate + '.tar.gz')).write_bytes(packed)
    index[gate] = {'archive_sha256': sha(packed), 'files': {n: sha(b) for n, b in sorted(files.items())}}
(OUT / 'archives.json').write_bytes((json.dumps(index, indent=2) + '\n').encode())
failed = OUT / 'initial-style-failure'
failed.mkdir(exist_ok=True)
for path in (ROOT / 'build/g2-shared-style-01').glob('*.log'):
    (failed / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
(failed / 'README.md').write_bytes(b'The initial D38-only style policy rejected D39\'s displaced always-comb waiver (129 warnings, expected 128). D39 explicitly restores that inherited single-block exception without changing the tested source. No simulation or proof failed in this attempt.\n')
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Retained', sum(len(e['files']) for e in index.values()), 'exact D39 files')
