DATA='AAAAAAAAAWcAAiIAAeUAAQAAAcAAAQAAAcEAAQAAAcIIAQAAAcMAAQAAAcRQAQAAAcUAAQAAAcY+AQAAAcfRAQAAAcgAAQAAAckAAQAAAcp8AQAAAcvBAQAAAcwCAQAAAc0AAQAAAc4AAQAAAc9oAQAAAdBQAQAAAdEAAQAAAdI+AQAAAdPFAQAAAdQAAQAAAdUAAQAAAdZ8AQAAAdfRAQAAAdgAAQAAAdkAAQAAAdp8AQAAAdvNAQAAAdxQAQAAAd0AAQAAAd4+AQAAAd/BAQAAAeUBAQAAAcBQAQAAAcEAAQAAAcI+AQAAAcPFAQAAAcQAAQAAAcUAAQAAAcZ8AQAAAcfRAQAAAcgAAQAAAckAAQAAAcp8AQAAAcvJAQAAAcxQAQAAAc0AAQAAAc4+AQAAAc/BAQAAAdBQAQAAAdEAAQAAAdI+AQAAAdPFAQAAAdQAAQAAAdUAAQAAAdZ8AQAAAdfRAQAAAdgAAQAAAdkAAQAAAdp8AQAAAdvJAQAAAdxQAQAAAd0AAQAAAd4+AQAAAd/BAQAAAeUCAQAAAcBQAQAAAcEAAQAAAcI+AQAAAcPFAQAAAcQAAQAAAcUAAQAAAcZ8AQAAAcfRAQAAAcgAAQAAAckAAQAAAcp8AQAAAcvNAQAAAcxQAQAAAc0AAQAAAc4+AQAAAc/BAQAAAdBQAQAAAdEAAQAAAdI+AQAAAdPFAQAAAdQAAQAAAdUAAQAAAdZ8AQAAAdfRAQAAAdgAAQAAAdkAAQAAAdp8AQAAAdvJAQAAAdxQAQAAAd0AAQAAAd4+AQAAAd/BAQAAAeUDAQAAAcBQAQAAAcEAAQAAAcI+AQAAAcPFAQAAAcQAAQAAAcUAAQAAAcZ8AQAAAcfRAQAAAcgAAQAAAckAAQAAAcoxAQAAAcvJAQAAAcxQAQAAAc0AAQAAAc4+AQAAAc/BAQAAAdAAAQAAAdEIAQAAAdIIAQAAAdMAAQAAAdQAAQAAAdUAAQAAAdYAAQAAAddjAQAAAdgAAQAAAdkAAQAAAdoAAQAAAdvRAQAAAdwAAQAAAd0AAQAAAd5KAQAAAd/ZAQAAAeUEAQAAAcAIAQAAAcEIAQAAAcIIAQAAAcMAAQAAAcQgAQAAAcUAAQAAAcYAAQAAAcdiAQAAAcgAAQAAAckAAQAAAcoAAQAAAcvRAQAAAcwAAQAAAc0AAQAAAc4lAQAAAc/BAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdN5AQAAAdQgAQAAAdUAAQAAAdYAAQAAAddiAQAAAdgAAQAAAdkAAQAAAdoAAQAAAdvRAQAAAdwAAQAAAd0AAQAAAd4pAQAAAd/FAQAAAeUFAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcN1AQAAAcQgAQAAAcUAAQAAAcYAAQAAAcdiAQAAAcgAAQAAAckAAQAAAcoAAQAAAcvRAQAAAcwAAQAAAc0AAQAAAc4tAQAAAc/BAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdNxAQAAAdQgAQAAAdUAAQAAAdYAAQAAAddiAQAAAdgAAQAAAdkAAQAAAdoAAQAAAdvRAQAAAdwAAQAAAd0AAQAAAd4eAQAAAd/FAQAAAeUGAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcNtAQAAAcRQAQAAAcUAAQAAAcY+AQAAAcfBAQAAAcgIAQAAAckIAQAAAcoIAQAAAcsAAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc9jAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdPRAQAAAdQAAQAAAdUAAQAAAdZAAQAAAdfdAQAAAdgAAQAAAdkIAQAAAdoIAQAAAdsAAQAAAdwgAQAAAd0AAQAAAd4AAQAAAd9iAQAAAeUHAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcPRAQAAAcQAAQAAAcUAAQAAAcY7AQAAAcfBAQAAAcgAAQAAAckAAQAAAcoAAQAAActjAQAAAcwgAQAAAc0AAQAAAc4AAQAAAc9iAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdPRAQAAAdQAAQAAAdUAAQAAAdY0AQAAAdfFAQAAAdgwAQAAAdkwAQAAAdo4AQAAAdsAAQAAAdwAAQAAAd0AAQAAAd4AAQAAAd+AAQAAAeUIAQAAAcAIAQAAAcEIAQAAAcIIAQAAAcMAAQAAAcQgAQAAAcUAAQAAAcYAAQAAAcdiAQAAAcgAAQAAAckAAQAAAcoAAQAAAcvRAQAAAcwAAQAAAc0AAQAAAc5FAQAAAc/BAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdN0AQAAAdQgAQAAAdUAAQAAAdYAAQAAAddiAQAAAdgAAQAAAdkAAQAAAdoAAQAAAdvRAQAAAdwAAQAAAd0AAQAAAd5JAQAAAd/FAQAAAeUJAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcNwAQAAAcQAAQAAAcUIAQAAAcYIAQAAAccAAQAAAcggAQAAAckAAQAAAcoAAQAAActiAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc/RAQAAAdAAAQAAAdEAAQAAAdJOAQAAAdPBAQAAAdQAAQAAAdUAAQAAAdYAAQAAAddrAQAAAdggAQAAAdkAAQAAAdoAAQAAAdtiAQAAAdwAAQAAAd0AAQAAAd4AAQAAAd/RAQAAAeUKAQAAAcAAAQAAAcEAAQAAAcJSAQAAAcPFAQAAAcQAAQAAAcUAAQAAAcYAAQAAAcdnAQAAAcggAQAAAckAAQAAAcoAAQAAActiAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc/RAQAAAdAAAQAAAdEAAQAAAdJWAQAAAdPBAQAAAdQAAQAAAdUAAQAAAdYAAQAAAddjAQAAAdggAQAAAdkAAQAAAdoAAQAAAdtiAQAAAdwAAQAAAd0AAQAAAd4AAQAAAd/RAQAAAeULAQAAAcAAAQAAAcEAAQAAAcJbAQAAAcPFAQAAAcQwAQAAAcUwAQAAAcY4AQAAAccAAQAAAcgAAQAAAckAAQAAAcoAAQAAAcuAAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc/RAQAAAdAAAQAAAdEAAQAAAdJmAQAAAdPZAQAAAdQIAQAAAdUIAQAAAdYIAQAAAdcAAQAAAdggAQAAAdkAAQAAAdoAAQAAAdtiAQAAAdwAAQAAAd0AAQAAAd4AAQAAAd/RAQAAAeUMAQAAAcAAAQAAAcEAAQAAAcJiAQAAAcPBAQAAAcQAAQAAAcUAAQAAAcYAAQAAAcd0AQAAAcggAQAAAckAAQAAAcoAAQAAActiAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc/RAQAAAdAAAQAAAdEAAQAAAdJnAQAAAdPFAQAAAdQAAQAAAdUAAQAAAdYAAQAAAddwAQAAAdgAAQAAAdkIAQAAAdoIAQAAAdsAAQAAAdwgAQAAAd0AAQAAAd4AAQAAAd9iAQAAAeUNAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcPRAQAAAcQAAQAAAcUAAQAAAcZrAQAAAcfBAQAAAcgAAQAAAckAAQAAAcoAAQAAActrAQAAAcwgAQAAAc0AAQAAAc4AAQAAAc9iAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdPRAQAAAdQAAQAAAdUAAQAAAdZvAQAAAdfFAQAAAdgAAQAAAdkAAQAAAdoAAQAAAdtnAQAAAdwgAQAAAd0AAQAAAd4AAQAAAd9iAQAAAeUOAQAAAcAAAQAAAcEAAQAAAcIAAQAAAcPRAQAAAcQAAQAAAcUAAQAAAcZzAQAAAcfBAQAAAcgAAQAAAckAAQAAAcoAAQAAActjAQAAAcwgAQAAAc0AAQAAAc4AAQAAAc9iAQAAAdAAAQAAAdEAAQAAAdIAAQAAAdPRAQAAAdQAAQAAAdUAAQAAAdZ4AQAAAdfFAQAAAdgwAQAAAdkwAQAAAdo4AQAAAdsAAQAAAdwAAQAAAd0AAQAAAd4AAQAAAd+AAQAAAeUPAQAAAcAAAQAAAcEAAQAAAcIIAQAAAcMAAQAAAcRQAQAAAcUAAQAAAcZ2AQAAAcfVAQAAAcgQAQAAAckwAQAAAcowAQAAAcsAAQAAAcwAAQAAAc0AAQAAAc4AAQAAAc+AAQAAAdAgAQAAAdEwAQAAAdI4AQAAAdMAAQAAAdQAAQAAAdUAAQAAAdYAAQAAAdeAAQAAAeUAAQAAAYAABAAAAYEABAAAAYIABAAIAYMABAAAAYQABABQAYUABAAAAYYABAA+AYcABADRAYgABAAAAYkABAAAAYoABAB8AYsABADBAYwABAACAY0ABAAAAY4ABAAAAY8ABABoAZAABABQAZEABAAAAZIABAA+AZMABADFAZQABAAAAZUABAAAAZYABAB8AZcABADRAZgABAAAAZkABAAAAZoABAB8AZsABADNAZwABABQAZ0ABAAAAZ4ABAA+AZ8ABADBAeUBAQAAAYAABABQAYEABAAAAYIABAA+AYMABADFAYQABAAAAYUABAAAAYYABAB8AYcABADRAYgABAAAAYkABAAAAYoABAB8AYsABADJAYwABABQAY0ABAAAAY4ABAA+AY8ABADBAZAABABQAZEABAAAAZIABAA+AZMABADFAZQABAAAAZUABAAAAZYABAB8AZcABADRAZgABAAAAZkABAAAAZoABAB8AZsABADJAZwABABQAZ0ABAAAAZ4ABAA+AZ8ABADBAeUCAQAAAYAABABQAYEABAAAAYIABAA+AYMABADFAYQABAAAAYUABAAAAYYABAB8AYcABADRAYgABAAAAYkABAAAAYoABAB8AYsABADNAYwABABQAY0ABAAAAY4ABAA+AY8ABADBAZAABABQAZEABAAAAZIABAA+AZMABADFAZQABAAAAZUABAAAAZYABAB8AZcABADRAZgABAAAAZkABAAAAZoABAB8AZsABADJAZwABABQAZ0ABAAAAZ4ABAA+AZ8ABADBAeUDAQAAAYAABABQAYEABAAAAYIABAA+AYMABADFAYQABAAAAYUABAAAAYYABAB8AYcABADRAYgABAAAAYkABAAAAYoABAAxAYsABADJAYwABABQAY0ABAAAAY4ABAA+AY8ABADBAZAABAAAAZEABAAIAZIABAAIAZMABAAAAZQABAAAAZUABAAAAZYABAAAAZcABABjAZgABAAAAZkABAAAAZoABAAAAZsABADRAZwABAAAAZ0ABAAAAZ4ABABKAZ8ABADZAeUEAQAAAYAABAAIAYEABAAIAYIABAAIAYMABAAAAYQABAAgAYUABAAAAYYABAAAAYcABABiAYgABAAAAYkABAAAAYoABAAAAYsABADRAYwABAAAAY0ABAAAAY4ABAAlAY8ABADBAZAABAAAAZEABAAAAZIABAAAAZMABAB5AZQABAAgAZUABAAAAZYABAAAAZcABABiAZgABAAAAZkABAAAAZoABAAAAZsABADRAZwABAAAAZ0ABAAAAZ4ABAApAZ8ABADFAeUFAQAAAYAABAAAAYEABAAAAYIABAAAAYMABAB1AYQABAAgAYUABAAAAYYABAAAAYcABABiAYgABAAAAYkABAAAAYoABAAAAYsABADRAYwABAAAAY0ABAAAAY4ABAAtAY8ABADBAZAABAAAAZEABAAAAZIABAAAAZMABABxAZQABAAgAZUABAAAAZYABAAAAZcABABiAZgABAAAAZkABAAAAZoABAAAAZsABADRAZwABAAAAZ0ABAAAAZ4ABAAeAZ8ABADFAeUGAQAAAYAABAAAAYEABAAAAYIABAAAAYMABABtAYQABABQAYUABAAAAYYABAA+AYcABADBAYgABAAIAYkABAAIAYoABAAIAYsABAAAAYwABAAAAY0ABAAAAY4ABAAAAY8ABABjAZAABAAAAZEABAAAAZIABAAAAZMABADRAZQABAAAAZUABAAAAZYABABAAZcABADdAZgABAAAAZkABAAIAZoABAAIAZsABAAAAZwABAAgAZ0ABAAAAZ4ABAAAAZ8ABABiAeUHAQAAAYAABAAAAYEABAAAAYIABAAAAYMABADRAYQABAAAAYUABAAAAYYABAA7AYcABADBAYgABAAAAYkABAAAAYoABAAAAYsABABjAYwABAAgAY0ABAAAAY4ABAAAAY8ABABiAZAABAAAAZEABAAAAZIABAAAAZMABADRAZQABAAAAZUABAAAAZYABAA0AZcABADFAZgABAAwAZkABAAwAZoABAA4AZsABAAAAZwABAAAAZ0ABAAAAZ4ABAAAAZ8ABACAAeUIAQAAAYAABAAIAYEABAAIAYIABAAIAYMABAAAAYQABAAgAYUABAAAAYYABAAAAYcABABiAYgABAAAAYkABAAAAYoABAAAAYsABADRAYwABAAAAY0ABAAAAY4ABABFAY8ABADBAZAABAAAAZEABAAAAZIABAAAAZMABAB0AZQABAAgAZUABAAAAZYABAAAAZcABABiAZgABAAAAZkABAAAAZoABAAAAZsABADRAZwABAAAAZ0ABAAAAZ4ABABJAZ8ABADFAeUJAQAAAYAABAAAAYEABAAAAYIABAAAAYMABABwAYQABAAAAYUABAAIAYYABAAIAYcABAAAAYgABAAgAYkABAAAAYoABAAAAYsABABiAYwABAAAAY0ABAAAAY4ABAAAAY8ABADRAZAABAAAAZEABAAAAZIABABOAZMABADBAZQABAAAAZUABAAAAZYABAAAAZcABABrAZgABAAgAZkABAAAAZoABAAAAZsABABiAZwABAAAAZ0ABAAAAZ4ABAAAAZ8ABADRAeUKAQAAAYAABAAAAYEABAAAAYIABABSAYMABADFAYQABAAAAYUABAAAAYYABAAAAYcABABnAYgABAAgAYkABAAAAYoABAAAAYsABABiAYwABAAAAY0ABAAAAY4ABAAAAY8ABADRAZAABAAAAZEABAAAAZIABABWAZMABADBAZQABAAAAZUABAAAAZYABAAAAZcABABjAZgABAAgAZkABAAAAZoABAAAAZsABABiAZwABAAAAZ0ABAAAAZ4ABAAAAZ8ABADRAeULAQAAAYAABAAAAYEABAAAAYIABABbAYMABADFAYQABAAwAYUABAAwAYYABAA4AYcABAAAAYgABAAAAYkABAAAAYoABAAAAYsABACAAYwABAAAAY0ABAAAAY4ABAAAAY8ABADRAZAABAAAAZEABAAAAZIABABmAZMABADZAZQABAAIAZUABAAIAZYABAAIAZcABAAAAZgABAAgAZkABAAAAZoABAAAAZsABABiAZwABAAAAZ0ABAAAAZ4ABAAAAZ8ABADRAeUMAQAAAYAABAAAAYEABAAAAYIABABiAYMABADBAYQABAAAAYUABAAAAYYABAAAAYcABAB0AYgABAAgAYkABAAAAYoABAAAAYsABABiAYwABAAAAY0ABAAAAY4ABAAAAY8ABADRAZAABAAAAZEABAAAAZIABABnAZMABADFAZQABAAAAZUABAAAAZYABAAAAZcABABwAZgABAAAAZkABAAIAZoABAAIAZsABAAAAZwABAAgAZ0ABAAAAZ4ABAAAAZ8ABABiAeUNAQAAAYAABAAAAYEABAAAAYIABAAAAYMABADRAYQABAAAAYUABAAAAYYABABrAYcABADBAYgABAAAAYkABAAAAYoABAAAAYsABABrAYwABAAgAY0ABAAAAY4ABAAAAY8ABABiAZAABAAAAZEABAAAAZIABAAAAZMABADRAZQABAAAAZUABAAAAZYABABvAZcABADFAZgABAAAAZkABAAAAZoABAAAAZsABABnAZwABAAgAZ0ABAAAAZ4ABAAAAZ8ABABiAeUOAQAAAYAABAAAAYEABAAAAYIABAAAAYMABADRAYQABAAAAYUABAAAAYYABABzAYcABADBAYgABAAAAYkABAAAAYoABAAAAYsABABjAYwABAAgAY0ABAAAAY4ABAAAAY8ABABiAZAABAAAAZEABAAAAZIABAAAAZMABADRAZQABAAAAZUABAAAAZYABAB4AZcABADFAZgABAAwAZkABAAwAZoABAA4AZsABAAAAZwABAAAAZ0ABAAAAZ4ABAAAAZ8ABACAAeUPAQAAAYAABAAAAYEABAAAAYIABAAIAYMABAAAAYQABABQAYUABAAAAYYABAB2AYcABADVAYgABAAQAYkABAAwAYoABAAwAYsABAAAAYwABAAAAY0ABAAAAY4ABAAAAY8ABACAAZAABAAgAZEABAAwAZIABAA4AZMABAAAAZQABAAAAZUABAAAAZYABAAAAZcABACAAeB+AQAAAaAABAB+AeE8AQAAAaEABAA8AeSnAQAAAaQABACnAQAECiAAAQAECiAA'
CASES={'a4-held': ('JAMAAJIEAADLAwAAyAMAAMkDAADKAwAAywMAAMgDAADJAwAAyAMAAMkDAADKAwAAywMAAMgDAADJAwAAyAMAAMkDAADIAwAAMQIAAIUsAAA=', 3692), 'a5-held': ('JAMAAJIEAADLAwAAyAMAAMkDAADKAwAAywMAAMgDAADJAwAAyAMAAMkDAADKAwAAywMAAMgDAADJAwAAygMAAMsDAADIAwAAMQIAAIUsAAA=', 3692)}
NAMES=['a4-held', 'a5-held']
BIAS=[(0, 0), (0, -1), (0, 1), (-1, -1), (1, 1)]
ORDER='clock-control'
import array
import binascii
import gc
import json
import machine
import micropython
import rp2
import time
from machine import Pin
from ttboard.demoboard import DemoBoard
from ttboard.mode import RPMode
from ttboard.util.platform import rp2350 as io
def report(**fields):
    print('SPILAB ' + json.dumps(fields))
@rp2.asm_pio(set_init=rp2.PIO.OUT_LOW)
def core_clock():
    set(pins, 1) [4]
    set(pins, 0) [4]
@rp2.asm_pio(out_init=(rp2.PIO.OUT_LOW, rp2.PIO.OUT_LOW, rp2.PIO.OUT_HIGH),
             out_shiftdir=rp2.PIO.SHIFT_RIGHT)
def requester():
    wait(1, gpio, 16)
    wrap_target()
    pull(block)
    out(pins, 3)
    out(x, 29)
    label('hold')
    jmp(x_dec, 'hold')
    wrap()
def pulse():
    io.write_clock(1)
    time.sleep_us(3)
    io.write_clock(0)
    time.sleep_us(3)
def load_program(damaged):
    Pin(32, Pin.OUT, value=0)
    io.write_uio_outputenable(0x80)
    run = Pin(32, Pin.OUT, value=0)
    stage = Pin(30, Pin.OUT, value=0)
    Pin(16, Pin.OUT, value=0)
    for i in range(17, 25):
        Pin(i, Pin.OUT, value=0)
    returned = bytearray()
    registers = []
    was_reset = -1
    for index in range(0, len(PLAN), 6):
        reset, select, value, flags, want_status, want_data = PLAN[index:index+6]
        if reset != was_reset:
            tt.reset_project(not reset)
            was_reset = reset
        if flags & 1:
            stage.value(1)
            io.write_ui_in_byte(value ^ int(damaged and index == 4*6))
            time.sleep_us(3)
            pulse()
            stage.value(0)
        io.write_ui_in_byte(0xe7 if flags & 8 else select)
        time.sleep_us(3)
        pulse()
        actual = io.read_uo_out_byte()
        if flags & 2 and actual != want_status:
            raise ValueError('loader status', index//6, select, want_status, actual)
        if flags & 4:
            if actual != want_data:
                report(event='readback_error', row=index//6, selector=select, expected=want_data, observed=actual)
                if damaged and select == 0x81 and actual == (want_data ^ 1):
                    return
                raise ValueError('loader data', index//6, want_data, actual)
            if select < 0xa0:
                returned.append(actual)
            else:
                registers.append([select, actual])
    assert not damaged and len(returned) == 504
    report(event='cold', image=binascii.hexlify(returned).decode(), registers=registers, rows=len(PLAN)//6)
    io.write_ui_in_byte(0)
    for gpio in (18, 19, 20, 28, 30, 31):
        Pin(gpio, Pin.IN, None)
    run.value(0)

import os
@rp2.asm_pio(in_shiftdir=rp2.PIO.SHIFT_RIGHT, autopush=True, push_thresh=32)
def branch_sampler():
    wait(1, gpio, 16)
    wrap_target()
    in_(pins, 16)  # GPIO20..31, plus four unused high bits. Two 16-bit samples per DMA word.
    wrap()
def physical_input(gpio, direction):
    pull = Pin.PULL_DOWN if direction < 0 else Pin.PULL_UP if direction > 0 else None
    Pin(gpio, Pin.IN, pull)
    pad = machine.mem32[0x40038004 + 4*gpio]
    status = machine.mem32[0x40028000 + 8*gpio]
    function = machine.mem32[0x40028004 + 8*gpio]
    expected = 4 if direction < 0 else 8 if direction > 0 else 0
    if pad & 12 != expected or status & 0x2000 or function & 31 != 5:
        raise ValueError("host pad is not in requested input state", gpio, pad, status, function)
    return [gpio, pad, function, status]

# SPDX-License-Identifier: Apache-2.0
# Independent uncompressed acquisition. GPIO20/28 are captured as separate bits of each DMA halfword.


@rp2.asm_pio(set_init=rp2.PIO.OUT_LOW)
def park_clock():
    pull(block)
    mov(x, osr)
    label("lead")
    set(pins, 1) [4]
    set(pins, 0) [3]
    jmp(x_dec, "lead")
    pull(block)
    mov(x, osr)
    label("park")
    jmp(x_dec, "park")
    wrap_target()
    set(pins, 1) [4]
    set(pins, 0) [4]
    wrap()


def control_capture(name, parked, repeat, ids):
    ck, tx, rx = ids
    program = park_clock if parked else core_clock
    command = binascii.a2b_base64(CASES[name][0])
    capture = bytearray(2*6400)
    run = Pin(32, Pin.OUT, value=0)
    Pin(16, Pin.OUT, value=0)
    for gpio, level in ((25, 0), (26, 0), (27, 1)):
        Pin(gpio, Pin.OUT, value=level)
    pads = [physical_input(20, 0), physical_input(28, -1)]
    pulse()
    pulse()
    clk = rp2.StateMachine(ck, program, freq=-1, set_base=Pin(16))
    tx_sm = rp2.StateMachine(tx, requester, freq=-1, out_base=Pin(25))
    rx_sm = rp2.StateMachine(rx, branch_sampler, freq=-1, in_base=Pin(20))
    if parked:
        clk.put(349)
        clk.put(999)
    tx_dma, rx_dma = rp2.DMA(), rp2.DMA()
    try:
        tx_dma.config(read=command, write=tx_sm, count=len(command)//4,
                      ctrl=tx_dma.pack_ctrl(size=2, inc_read=True, inc_write=False, treq_sel=tx), trigger=True)
        rx_dma.config(read=rx_sm, write=capture, count=len(capture)//4,
                      ctrl=rx_dma.pack_ctrl(size=2, inc_read=False, inc_write=True, treq_sel=4+rx), trigger=True)
        if machine.mem32[0xd0000030] & ((7 << 18) | (1 << 28) | (3 << 30)):
            raise ValueError("host drives a monitored or shared input")
        tx_sm.active(1)
        rx_sm.active(1)
        run.value(1)
        time.sleep_us(40)
        clk.active(1)
        start = time.ticks_us()
        while rx_dma.active():
            if time.ticks_diff(time.ticks_us(), start) > 40000:
                raise ValueError("raw capture stalled", name)
        status = io.read_uo_out_byte()
        if tx_dma.active():
            raise ValueError("held requester schedule incomplete")
    finally:
        clk.active(0)
        Pin(16, Pin.OUT, value=0)
        run.value(0)
        tx_sm.active(0)
        rx_sm.active(0)
        for dma in (rx_dma, tx_dma):
            dma.active(0)
            dma.close()
    for offset in range(0, len(capture), 512):
        report(event="raw", name=name, bias=[0,-1], offset=offset, data=binascii.hexlify(capture[offset:offset+512]).decode())
    report(event="trace", name=name, bias=[0,-1], packed=False, count=len(capture)//2, status=status,
           parked=parked, repeat=repeat, pads=pads)


def run_controls():
    global tt, PLAN
    tt = DemoBoard.get()
    hz, mode = machine.freq(), tt.mode
    free = [i for i in range(4) if not rp2.StateMachine(i).active()]
    if len(free) < 3 or rp2.PIO(0).gpio_base() != Pin(0):
        raise RuntimeError("three free PIO0 machines on bank 0 required")
    PLAN = binascii.a2b_base64(DATA)
    try:
        tt.clock_project_stop()
        tt.mode = RPMode.ASIC_RP_CONTROL
        machine.freq(125000000)
        if machine.freq() != 125000000:
            raise ValueError("125 MHz required")
        report(event="start", order=ORDER, original_hz=hz, system_hz=machine.freq(), samples_hz=125000000,
               core_divisor=10, host=os.uname().machine, micropython=os.uname().release)
        load_program(True)
        load_program(False)
        pairs = [("a4-held", False), ("a5-held", True), ("a4-held", True), ("a5-held", False)]
        for repeat in range(2):
            for name, parked in pairs:
                gc.collect()
                control_capture(name, parked, repeat, free[:3])
            pairs.reverse()
    finally:
        Pin(32, Pin.OUT, value=0)
        Pin(16, Pin.OUT, value=0)
        tt.reset_project(True)
        for gpio in [18, 19, 20] + list(range(25, 33)):
            Pin(gpio, Pin.IN, None)
        for program in (core_clock, park_clock, requester, branch_sampler):
            rp2.PIO(0).remove_program(program)
        machine.freq(hz)
        tt.mode = mode
    report(event="finish", restored_hz=machine.freq(), host_uio_oe=io.read_uio_outputenable())


try:
    run_controls()
finally:
    CASES.clear()
    PLAN = None
    gc.collect()
