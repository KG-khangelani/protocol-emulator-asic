__name__='sensor_reference'
CASES=('ext', 'par', 'swapped-high', 'swapped-low', 'silent', 'empty')
VECTORS={'ext': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAQAAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAAEAAAEAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQEBAAAAAQEBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAEAAAABAAEAAAEAAAABAAEAAAEAAAEAAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAEAAAABAAABAAEAAAABAAEAAAABAAEAAAEAAAEAAAEAAAABAAABAAABAAABAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAABAAEAAAEAAAABAAABAAABAAABAAEAAAABAAEAAAABAAABAAABAAABAAEAAAEAAAEAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEAAQABAAEAAQEBAQEAAAEAAQEAAQEAAAEBAQABAAAAAAAAAAEAAAAAAAAAAAEBAAABAQEBAQEBAQABAQEBAQAAAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=', 883), 'par': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAAEAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAAEAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQEBAAAAAQEBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQIAAAAAAAAAAAAAAAAAAAAAAQIAAAAAAAAAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAABAAEAAAABAAEAAAEAAAABAAABAAEAAAABAAABAAEAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAEAAAEAAAABAAEAAAEAAAABAAABAAABAAABAAEAAAEAAAEAAAEAAAABAAEAAAABAAABAAEAAAABAAABAAABAAABAAABAAEAAAABAAEAAAEAAAABAAABAAABAAABAAABAAEAAAEAAAABAAEAAAEAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEAAQABAAEAAQEBAQEAAAEAAQEAAQEAAAEBAQABAAAAAAAAAAEAAAAAAAAAAAEBAAABAQEBAQEBAQABAQEBAQAAAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE=', 883), 'bad-crc': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAQAAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAAEAAAEAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQABAAAAAQEB', 352), 'swapped-high': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAAEAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAAEAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQEBAAAAAQEBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAABAAEAAAABAAEAAAEAAAABAAABAAEAAAABAAABAAEAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAEAAAEAAAABAAEAAAEAAAABAAABAAABAAABAAEAAAEAAAEAAAEAAAABAAEAAAABAAABAAEAAAABAAABAAABAAABAAABAAEAAAABAAEAAAEAAAABAAABAAABAAABAAABAAEAAAEAAAABAAEAAAEAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEAAQABAAEAAQEBAQEAAAEAAQEAAQEAAAEBAQABAAAAAAAAAAEAAAAAAAAAAAEBAAABAQEBAQEBAQABAQEBAQAAAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=', 883), 'swapped-low': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAQAAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAAEAAAEAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQEBAAAAAQEBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQIAAAAAAAAAAAAAAAAAAAAAAQIAAAAAAAAAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAEAAAABAAEAAAEAAAABAAEAAAEAAAEAAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAEAAAABAAABAAEAAAABAAEAAAABAAEAAAEAAAEAAAEAAAABAAABAAABAAABAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAABAAEAAAEAAAABAAABAAABAAABAAEAAAABAAEAAAABAAABAAABAAABAAEAAAEAAAEAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEAAQABAAEAAQEBAQEAAAEAAQEAAQEAAAEBAQABAAAAAAAAAAEAAAAAAAAAAAEBAAABAQEBAQEBAQABAQEBAQAAAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE=', 883), 'silent': ('AgAAAAAAAAAAAQAAAQAAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAAEAAQAAAQAAAAEAAQAAAQAAAQAAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAQAAAAEAAAEAAQAAAAEAAQAAAAEAAQAAAQAAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAAEAAQAAAAEAAAEAAQAAAQAAAAEAAQAAAQAAAAEAAAEAAAEAAAEAAQAAAAEAAQAAAAEAAAEAAAEAAAEAAQAAAQAAAQAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAQABAAEAAQABAQEBAQAAAQABAQABAQAAAQEBAAEAAAAAAAAAAQAAAAAAAAAAAQEAAAEBAQEBAQEBAAEBAQEBAAAAAQEBAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAEAAAEAAAEAAAABAAEAAAABAAEAAAEAAAEAAAABAAEAAAEAAAABAAEAAAEAAAEAAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAEAAAABAAABAAEAAAABAAEAAAABAAEAAAEAAAEAAAEAAAABAAABAAABAAABAAEAAAEAAAABAAEAAAABAAABAAEAAAEAAAABAAEAAAEAAAABAAABAAABAAABAAEAAAABAAEAAAABAAABAAABAAABAAEAAAEAAAEAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQEAAQABAAEAAQEBAQEAAAEAAQEAAQEAAAEBAQABAAAAAAAAAAEAAAAAAAAAAAEBAAABAQEBAQEBAQABAQEBAQAAAAEBAQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=', 883)}
# SPDX-License-Identifier: Apache-2.0
"""Run directly with mpremote on a stock Pico. GP18 samples DQ at the sensor and GP19 is the master."""
import binascii
import json
import machine
import onewire
import os
import rp2
import time
from machine import Pin

SAMPLE_HZ = 2000000
SAMPLES = 16384


@rp2.asm_pio(in_shiftdir=rp2.PIO.SHIFT_RIGHT, autopush=True, push_thresh=32)
def sample_dq():
    in_(pins, 1)


def address(bus, rom, command):
    bus.reset(True)
    bus.writebyte(0x55)
    bus.write(rom)
    bus.writebyte(command)


def identification(bus):
    found = bus.scan()
    if len(found) != 1:
        raise ValueError("expected exactly one sensor", len(found))
    rom = found[0]
    if len(rom) != 8 or rom[0] != 0x28 or bus.crc8(rom):
        raise ValueError("invalid family or ROM CRC", binascii.hexlify(rom))
    scratch = bytearray(9)
    address(bus, rom, 0xbe)
    bus.readinto(scratch)
    if len(set(scratch)) == 1 or bus.crc8(scratch):
        raise ValueError("invalid scratchpad or CRC", binascii.hexlify(scratch))
    address(bus, rom, 0xb4)
    return dict(rom=binascii.hexlify(rom).decode(), scratchpad=binascii.hexlify(scratch).decode(),
                power=bus.readbit())


def broadcast(bus, tap, sm_id):
    buf = bytearray(SAMPLES // 8)
    receiver = rp2.StateMachine(sm_id, sample_dq, freq=SAMPLE_HZ, in_base=tap)
    channel = rp2.DMA()
    try:
        dreq = 8 * (sm_id // 4) + 4 + sm_id % 4
        channel.config(read=receiver, write=buf, count=len(buf)//4,
                       ctrl=channel.pack_ctrl(size=2, inc_read=False, inc_write=True, treq_sel=dreq), trigger=True)
        receiver.active(1)
        time.sleep_us(80)
        bus.reset(True)
        bus.writebyte(0xcc)
        bus.writebyte(0xb4)
        bit = bus.readbit()
        start = time.ticks_us()
        while channel.active():
            if time.ticks_diff(time.ticks_us(), start) > 30000:
                raise RuntimeError("DQ capture timed out")
    finally:
        receiver.active(0)
        channel.active(0)
        channel.close()
        rp2.PIO(sm_id // 4).remove_program(sample_dq)
    return bit, binascii.hexlify(buf).decode()


def observe(master, tap, sm_id, pull):
    if rp2.StateMachine(sm_id).active():
        raise RuntimeError("sampler is in use")
    if not master.value() or not tap.value():
        raise ValueError("DQ must be idle high at both inputs")
    bus = onewire.OneWire(master)
    try:
        # The library enables its own pull-up. The local sensor uses the measured external pull-up.
        master.init(Pin.OPEN_DRAIN, pull, value=1)
        before = identification(bus)
        bit, data = broadcast(bus, tap, sm_id)
        record = dict(before=before, power=bit, samples=SAMPLES, sample_hz=SAMPLE_HZ, dq_lsb_first=data)
        try:
            after = identification(bus)
            record["after"] = after
            if before["rom"] != after["rom"] or before["power"] != after["power"] or bit != before["power"]:
                raise ValueError("identity or power result changed")
        except Exception:
            # The waveform was acquired even if the device went away or its response changed later.
            print("SENSORREF_PARTIAL " + json.dumps(record))
            raise
        return record
    finally:
        master.init(Pin.IN, None)


def main():
    host = os.uname().machine
    if host != "Raspberry Pi Pico with RP2040":
        raise RuntimeError("this pin assignment requires the original Raspberry Pi Pico", host)
    master, tap = Pin(19, Pin.IN, None), Pin(18, Pin.IN, None)
    try:
        result = observe(master, tap, 4, None)
        result.update(fixture="local-pico", host=host, system_hz=machine.freq(), master_gpio=19, sensor_gpio=18)
        print("SENSORREF " + json.dumps(result))
    except Exception as exc:
        print("SENSORREF_ERROR " + json.dumps({"error": repr(exc)}))
        raise
    finally:
        master.init(Pin.IN, None)
        tap.init(Pin.IN, None)


if __name__ == "__main__":
    main()

# SPDX-License-Identifier: Apache-2.0
# The remote runner prepends pico.py. Each master slot is independently sampled by the peer.
from array import array
import gc
from ttboard.demoboard import DemoBoard
from ttboard.mode import RPMode
from ttboard.util.platform import rp2350 as io


def emit(**values):
    print("I2CLAB " + json.dumps(values))


@rp2.asm_pio(set_init=rp2.PIO.IN_LOW, in_shiftdir=rp2.PIO.SHIFT_LEFT)
def sensor_peer():
    wrap_target()
    label("next")
    pull(block)
    mov(x, osr)
    wait(0, pin, 0)
    jmp(not_x, "listen")
    jmp(x_dec, "active")
    label("active")
    jmp(not_x, "zero")
    wait(1, pin, 0)            # The reset has ended at the peer.
    nop() [22]
    set(pindirs, 1) [31]
    nop() [31]
    nop() [31]
    set(pindirs, 0)
    jmp("next")
    label("zero")
    set(pindirs, 1) [15]
    jmp("sample")
    label("listen")
    nop() [17]
    label("sample")
    mov(isr, null)
    in_(pins, 1)
    push(noblock)
    nop() [12]
    set(pindirs, 0)
    wait(1, pin, 0)
    wrap()


def run_case(name):
    master = Pin(27, Pin.IN, Pin.PULL_UP)
    tap = Pin(19, Pin.IN, Pin.PULL_UP)
    tx = rx = peer = None
    levels = array("I")
    try:
        if name != "empty":
            commands, expected_count = VECTORS[name]
            actions = array("I", list(binascii.a2b_base64(commands)))
            levels = array("I", [2] * expected_count)
            peer = rp2.StateMachine(9, sensor_peer, freq=1000000, in_base=tap, set_base=tap)
            tx, rx = rp2.DMA(), rp2.DMA()
            tx.config(read=actions, write=peer, count=len(actions),
                      ctrl=tx.pack_ctrl(size=2, inc_read=True, inc_write=False, treq_sel=17), trigger=True)
            rx.config(read=peer, write=levels, count=len(levels),
                      ctrl=rx.pack_ctrl(size=2, inc_read=False, inc_write=True, treq_sel=21), trigger=True)
            peer.active(1)
        time.sleep_us(100)
        result = {}
        try:
            result = observe(master, tap, 8, Pin.PULL_UP)
            result.update(fixture="scripted-peer", host=os.uname().machine, system_hz=machine.freq(),
                          master_gpio=27, sensor_gpio=19)
            error = ""
        except (ValueError, RuntimeError, onewire.OneWireError) as exc:
            error = repr(exc)
        # Drop any unused fill words from a deliberately interrupted acquisition.
        captured = bytes(v for v in levels if v != 2)
        emit(event="trace", name=name, result=result, error=error, peer_samples=binascii.hexlify(captured).decode(),
             planned=len(levels), received=len(captured))
    finally:
        if peer is not None:
            peer.active(0)
        for dma in (tx, rx):
            if dma is not None:
                dma.active(0)
                dma.close()
        master.init(Pin.IN, None)
        tap.init(Pin.IN, None)


def bench():
    tt = DemoBoard.get()
    bank = rp2.PIO(2)
    old_base, old_mode, old_hz = bank.gpio_base(), tt.mode, machine.freq()
    if any(rp2.StateMachine(i).active() for i in range(8, 12)):
        raise RuntimeError("PIO2 is in use")
    try:
        tt.clock_project_stop()
        tt.mode = RPMode.ASIC_RP_CONTROL
        tt.reset_project(True)
        Pin(32, Pin.OUT, value=0)  # Keep the E0059 bidirectional FPGA pins disabled.
        Pin(16, Pin.OUT, value=0)
        bank.gpio_base(16)
        machine.freq(125000000)
        emit(event="start", host=os.uname().machine, micropython=os.uname().release, initial_hz=old_hz,
             system_hz=machine.freq(), mode="scripted sensor fixture", peer_clock_hz=1000000)
        for name in CASES:
            gc.collect()
            run_case(name)
    finally:
        for gpio in (19, 27, 32):
            Pin(gpio, Pin.IN, None)
        bank.remove_program(sensor_peer)
        bank.gpio_base(old_base)
        machine.freq(old_hz)
        tt.mode = old_mode
    emit(event="finish", host_uio_oe=io.read_uio_outputenable(), restored_hz=machine.freq(),
         restored_bank=(bank.gpio_base() == old_base))


bench()
