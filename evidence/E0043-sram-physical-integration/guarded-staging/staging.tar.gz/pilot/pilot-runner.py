"""Exercise portable guarded staging with native discovery and fixed public pins."""
import copy
import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from tools import physical_sram as gate
import run_program_sensitivity as bounded
base = ROOT / 'build/g2-sram-guarded-staging-01'
workspace = base / 'workspace'
bounded.ROOT = workspace
inputs = gate.read(base / 'inputs.json')
config = gate.read(workspace / 'src/config.json')
reference = gate.read(ROOT / 'build/g2-sram-full-05/src/config_merged.json')
for name in ('DESIGN_NAME', 'DIE_AREA', 'FP_DEF_TEMPLATE', 'VDD_PIN', 'GND_PIN', 'RT_MAX_LAYER'):
    config[name] = reference[name]
config['VERILOG_FILES'] = ['dir::' + Path(name).name for name in reference['VERILOG_FILES']]
(workspace / 'src/config_merged.json').write_bytes((json.dumps(config, indent=2) + '\n').encode())
(workspace / 'runs/guarded-pilot').mkdir(parents=True)
(base / 'pilot-runner.py').write_bytes(Path(__file__).read_bytes())
command = [sys.executable, '-m', 'librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l',
           '--run-tag', 'guarded-pilot', '--force-run-dir', 'runs/guarded-pilot',
           '--to', 'Project.CheckPublicPinPower', 'src/config_merged.json']
env = dict(os.environ)
env.pop('PYTHONPATH', None)
result = bounded.execute(command, base / 'pilot.log', 300, env=env)
result['cwd'] = str(workspace)
(base / 'pilot-execution.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
assert result['returncode'] == 0 and not result['timed_out']
run = workspace / 'runs/guarded-pilot'
resolved = gate.read(run / 'resolved.json')
assert gate.inspect_resolved(resolved, inputs, workspace) == inputs['macro_views']
original = gate.read(ROOT / 'build/g2-sram-full-05/runs/integrated/resolved.json')
def normalized(value):
    if isinstance(value, str):
        return value.replace(str(workspace), '$DESIGN').replace('/workspace/build/g2-sram-full-05', '$DESIGN').replace('$DESIGN/src/sram-preparation.json', '$DESIGN/preparation.json')
    if isinstance(value, list):
        return [normalized(v) for v in value]
    if isinstance(value, dict):
        return {k: normalized(v) for k, v in value.items()}
    return value
new, old = normalized(resolved), normalized(original)
changes = {k: [old.get(k), new.get(k)] for k in old.keys() | new.keys() if old.get(k) != new.get(k)}
assert changes == {'DESIGN_DIR': ['$DESIGN', '$DESIGN/src']}, changes
controls = []
for name, mutate, expected in (
    ('missing_real_macro', lambda c: c['MACROS'].clear(), 'unexpected macro set'),
    ('wrong_fast_library', lambda c: c['MACROS'][gate.MACRO]['lib'].__setitem__('nom_fast_1p32V_m40C', c['MACROS'][gate.MACRO]['lib']['nom_typ_1p20V_25C']), 'corner mapping changed'),
    ('waived_drc', lambda c: c.__setitem__('RUN_MAGIC_DRC', False), 'required acceptance check disabled'),
    ('extra_source', lambda c: c['VERILOG_FILES'].append(c['VERILOG_FILES'][0]), 'resolved RTL paths differ'),
    ('removed_guard', lambda c: c['meta'].__setitem__('flow', 'SramBufferedClassic'), 'unexpected flow substitutions'),
    ('relaxed_clock', lambda c: c.__setitem__('CLOCK_PERIOD', 25), 'resolved CLOCK_PERIOD differs'),
    ('missing_vendor_import', lambda c: c.__setitem__('MAGIC_GDS_FLATGLOB', []), 'vendor SRAM import patterns changed'),
    ('broadened_vendor_import', lambda c: c['MAGIC_GDS_FLATGLOB'].append('*'), 'vendor SRAM import patterns changed'),
):
    changed = copy.deepcopy(resolved)
    mutate(changed)
    try:
        gate.inspect_resolved(changed, inputs, workspace)
    except ValueError as error:
        assert expected in str(error), str(error)
        controls.append({'fault': name, 'observed_rejection': str(error)})
    else:
        raise AssertionError('missed corruption: ' + name)
grid = gate.read(gate.one_stage(run, 'Project.CheckSramPower') / 'state_out.json')['metrics']
assert all(grid['design__power_grid_violation__count' + suffix] == 0 for suffix in ('', '__net:VPWR', '__net:VGND'))
guard = gate.one_stage(run, 'Project.CheckPublicPinPower')
pins = gate.read(guard / 'pin-power-audit/result.json')
assert pins['status'] == 'PASS_PUBLIC_PIN_POWER_GEOMETRY' and len(pins['pins']) == 43 and not pins['violations']
before, after = gate.read(guard / 'state_in.json'), gate.read(guard / 'state_out.json')
assert before['odb'] == after['odb'] and pins['odb_sha256'] == gate.digest(Path(before['odb']))
old_guard = ROOT / 'build/g2-sram-full-05/runs/integrated/30-project-checkpublicpinpower/pin-power-audit/result.json'
assert pins == gate.read(old_guard)
assert (workspace / 'src/sram_pdn.tcl').read_bytes() == (ROOT / 'build/g2-sram-full-05/src/sram_pdn.tcl').read_bytes()
report = {'status': 'PASS_PORTABLE_GUARDED_PILOT_AND_EIGHT_CONFIGURATION_CONTROLS',
          'execution': result, 'controls': controls, 'normalized_resolved_changes': changes,
          'fixed_public_pin_rectangles': 43, 'pin_power_violations': 0, 'actual_odb_sha256': pins['odb_sha256'],
          'guard_read_only': True, 'exact_full_trial_database_reproduced': True,
          'physical_qualification': 'SEPARATE_FULL_FLOW_GATE'}
(base / 'pilot-verification.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
print(report['status'])
