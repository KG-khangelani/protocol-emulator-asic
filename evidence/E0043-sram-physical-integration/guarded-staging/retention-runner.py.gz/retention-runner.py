"""Retain the portable D45 pilot, exact native database and source inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-guarded-staging-01'
out = root / 'evidence/E0043-sram-physical-integration/guarded-staging'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = json.loads((base / 'pilot-verification.json').read_bytes())
assert report['status'] == 'PASS_PORTABLE_GUARDED_PILOT_AND_EIGHT_CONFIGURATION_CONTROLS'
files = {}
for path in sorted(base.rglob('*')):
    name = path.relative_to(base).as_posix()
    if not path.is_file() or any(part in ('__pycache__', 'tmp', 'final') for part in path.relative_to(base).parts):
        continue
    if path.suffix in ('.odb', '.def') and not any('/' + stage + '/' in '/' + name for stage in (
        '23-project-connectsrampower', '24-project-checksrampower', '29-odb-applydeftemplate')):
        continue
    files['pilot/' + name] = path.read_bytes()
reference = root / 'build/g2-sram-full-05/runs/integrated'
for label, name in (('resolved.json', 'resolved.json'),
                    ('public-pin-audit.json', '30-project-checkpublicpinpower/pin-power-audit/result.json')):
    files['reference/' + label] = (reference / name).read_bytes()
runtime = json.loads(subprocess.check_output(['docker', 'inspect', 'g2-sram-guarded-staging-01']))[0]
assert runtime['Image'] == 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5' and runtime['State']['ExitCode'] == 0 and not runtime['State']['Running']
observation = {'image_id': runtime['Image'], 'configured_image': runtime['Config']['Image'],
               'command': runtime['Config']['Cmd'], 'state': runtime['State'],
               'mounts': [m for m in runtime['Mounts'] if m['Destination'] in ('/pdk', '/workspace')]}
files['runtime.json'] = (json.dumps(observation, indent=2) + '\n').encode()
out.mkdir()
with (out / 'staging.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
raw = (out / 'staging.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
    'files': {name: sha(raw) for name, raw in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'verification.json').write_bytes((base / 'pilot-verification.json').read_bytes())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_GUARDED_STAGING', len(files), len(raw))
