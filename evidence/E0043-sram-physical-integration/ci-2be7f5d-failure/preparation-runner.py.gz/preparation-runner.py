"""Freeze the exact producing inputs before auditing the rejected guarded run."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-ci-2be7f5d-failure'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = json.loads((base / 'run.json').read_bytes())
metadata = json.loads((base / 'artifacts.json').read_bytes())['artifacts']
for item in metadata:
    source = base / (item['name'] + '.zip')
    assert sha(source.read_bytes()) == item['digest'].split(':', 1)[1]
    shutil.copyfile(source, base / (str(item['id']) + '.zip'))
with zipfile.ZipFile(base / 'sram-physical-candidate.zip') as archive:
    inputs = json.loads(archive.read('build/sram-physical/inputs.json'))
names = set(inputs['provenance_sha256']) | {
    'evidence/E0042-sram-prefetch-screen/candidate.json',
    'evidence/E0042-sram-prefetch-screen/mapped/archive.json',
    'tools/audit_g2_physical.py', 'tools/physical_runtime.py'}
for name in sorted(names):
    raw = subprocess.check_output(['git', 'show', run['head_sha'] + ':' + name], cwd=root)
    if name in inputs['provenance_sha256']:
        assert sha(raw) == inputs['provenance_sha256'][name]
    target = base / 'inputs' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
old = root / 'evidence/E0043-sram-physical-integration/ci-2bd2688-failure'
shutil.copyfile(old / 'mapped-input-observation.json', base / 'mapped-input-observation.json')
support = (old / 'replay_support.py').read_text(encoding='utf-8')
support = support.replace('import json\n', 'import json\nimport math\n')
support = support.replace("'verify_run_configuration', 'SIGNOFF_CORNERS']", "'verify_run_configuration', 'inspect_physical_metrics', 'SIGNOFF_CORNERS']")
support = support.replace("'json': json, 'ROOT': inputs", "'json': json, 'math': math, 'ROOT': inputs")
support = support.replace("'candidate_lock', 'verify_run_configuration')", "'candidate_lock', 'verify_run_configuration', 'inspect_physical_metrics')")
support += "\nphysical_sram.SRAM_IMPORT_PATTERNS = selected('tools/physical_sram.py', ['SRAM_IMPORT_PATTERNS'], {})['SRAM_IMPORT_PATTERNS']\n"
(base / 'replay_support.py').write_bytes(support.encode())
shutil.copyfile(root / 'build/audit_sram_guarded_failure.py', base / 'audit.py')
subprocess.run(['python', str(base / 'audit.py'), str(base)], check=True, cwd=root)
