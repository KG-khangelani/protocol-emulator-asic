"""Keep original CI archives, frozen audit definitions and geometric diagnosis."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-ci-2be7f5d-failure'
out = root / 'evidence/E0043-sram-physical-integration/ci-2be7f5d-failure'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())
assert read(base / 'verification.json')['physical_qualification'] == 'REJECTED'
assert read(base / 'contact-geometry.json')['status'] == 'PASS_ALL_36_OFFICIAL_MARKERS_MATCH_32_ISOLATED_FOOTPRINTS'
out.mkdir()
for name in ('13994632526.zip', '13994288135.zip', 'run.json', 'jobs.json', 'artifacts.json',
             'verification.json', 'zip-files.json', 'mapped-input-observation.json', 'audit.py',
             'replay_support.py', 'contact-geometry.json'):
    shutil.copyfile(base / name, out / name)
(out / 'gds-job.log.gz').write_bytes(gzip.compress((base / 'gds-job.log').read_bytes(), mtime=0))

def pack(name, files):
    with (out / (name + '.tar.gz')).open('wb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for path, raw in sorted(files.items()):
                    item = tarfile.TarInfo(path)
                    item.size, item.mode, item.mtime = len(raw), 0o644, 0
                    archive.addfile(item, io.BytesIO(raw))
    raw = (out / (name + '.tar.gz')).read_bytes()
    (out / (name + '.json')).write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
        'files': {p: sha(r) for p, r in sorted(files.items())}}, indent=2) + '\n').encode())

pack('inputs', {p.relative_to(base / 'inputs').as_posix(): p.read_bytes()
                for p in (base / 'inputs').rglob('*') if p.is_file()})
state = read(root / 'build/g2-sram-full-05/runs/integrated/66-magic-drc/state_in.json')
local = root / Path(state['gds']).relative_to('/workspace')
pack('geometry-inputs', {
    'local-full05.gds': local.read_bytes(),
    'isolated-macro.rpt': (root / 'build/g2-sram-macro-drc-probe-05/reports/drc.magic.rpt').read_bytes(),
    'original-runner.py': (root / 'build/audit_sram_guarded_geometry.py').read_bytes()})
script = (root / 'build/audit_sram_guarded_geometry.py').read_text(encoding='utf-8')
script = script.replace('import re\n', 'import re\nimport sys\n')
script = script.replace("root = Path('/workspace')\nbase = root / 'build/g2-sram-ci-2be7f5d-failure'", "base = Path(sys.argv[1]).resolve()")
script = script.replace("base / 'GDS_logs.zip'", "base / '13994632526.zip'")
script = script.replace("root / 'build/g2-sram-macro-drc-probe-05/reports/drc.magic.rpt'", "base / 'geometry-inputs/isolated-macro.rpt'")
script = script.replace("local = root / 'build/g2-sram-full-05/runs/integrated/66-magic-drc/state_in.json'\nlocal_gds = Path(json.loads(local.read_bytes())['gds'])", "local_gds = base / 'geometry-inputs/local-full05.gds'")
(out / 'replay_geometry.py').write_bytes(script.encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
(out / 'preparation-runner.py.gz').write_bytes(gzip.compress((root / 'build/prepare_guarded_failure_audit.py').read_bytes(), mtime=0))
print('RETAINED', len(read(out / 'inputs.json')['files']), 'frozen inputs and 1027 original archive members')
