"""Run corrected routed netlist with the previously validated simulator setup."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

root = Path('/workspace')
base = root / 'build/g2-sram-guarded-netlist-pair-02'
workspace = base / 'workspace'
parser = argparse.ArgumentParser()
parser.add_argument('--simulator', choices=('icarus', 'verilator'), required=True)
simulator = parser.parse_args().simulator
out = workspace / 'build' / simulator
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
snapshot = read(base / 'snapshot.json')
assert all(sha((workspace / n).read_bytes()) == h for n, h in snapshot['files'].items())
physical = root / 'build/g2-sram-full-05'
state = read(physical / 'runs/integrated/59-openroad-stapostpnr/state_out.json')
netlist = Path(state['nl'])
assert sha(netlist.read_bytes()) == '2a0304aebbb2c9a287cc16ac0e61221116c4f2001420baa7df9c0ab1f035cd2e'
prior = read(root / 'build/g2-sram-netlist-verilator-05/result.json')
assert prior['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
assert all(sha(Path(n).read_bytes()) == h for n, h in prior['library_sha256'].items())
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'utc': datetime.now(timezone.utc).isoformat(),
    'simulator': simulator, 'wall_limit': 10800, 'outer_process_limit': 10900,
    'netlist_sha256': sha(netlist.read_bytes()), 'snapshot_sha256': sha((base / 'snapshot.json').read_bytes()),
    'physical_scope': 'Corrected trial 05 geometry; original-rule physical run is rejected for 36 contact findings. Corrected official run is separate and still pending.',
    'purpose': 'All eighteen unchanged public groups and exact reference records on the corrected routed netlist, before comparison to the fresh official submission.',
    'model_scope': 'Zero-delay functional simulation; timing and manufacturing remain separate.'}
env = dict(os.environ)
env.pop('COMPILE_ARGS', None)
if simulator == 'verilator':
    probe = root / 'build/g2-sram-reset-alias-probe-01'
    micro = read(probe / 'result.json')
    assert micro['status'] == 'PASS_ZERO_DELAY_RESET_ALIAS_WITH_UNMODIFIED_ICARUS_REFERENCE_AND_STUCK_RESET_CONTROL'
    assert [t['mismatches'] for t in micro['tasks']] == [0, 249, 0, 249]
    assert micro['tasks'][0]['samples_sha256'] == micro['tasks'][2]['samples_sha256']
    flops = re.findall(r'^\s*(sg13cmos5l_(?:dfr|df|dl[hl])[a-z0-9_]+)\s+', netlist.read_text(), re.M)
    assert len(flops) == 353 and set(flops) == {'sg13cmos5l_dfrbpq_1'}
    adapter = base / 'reset-alias.sv'
    raw = (probe / 'reset-alias.sv').read_bytes()
    assert sha(raw) == micro['adapter_sha256']
    adapter.write_bytes(raw)
    env['COMPILE_ARGS'] = '-Wno-SPECIFYIGN -Wno-PINMISSING ' + str(adapter)
    decision.update(adapter_sha256=sha(raw), qualified_probe_sha256=sha((probe / 'result.json').read_bytes()),
        actual_affected_flip_flops=353, flags=['-Wno-SPECIFYIGN', '-Wno-PINMISSING'],
        adapter_scope='Same separately validated delayed_RESET_B=RESET_B bind; netlist and vendor libraries unmodified. Not four-state or timing equivalence.')
decision_path = base / (simulator + '-declaration.json')
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
(base / (simulator + '-runner.py')).write_bytes(Path(__file__).read_bytes())
command = [sys.executable, str(workspace / 'experiments/i2c/run_sram_netlist.py'),
    '--physical', str(physical), '--candidate', str(root / 'build/g2-sram-candidate-01'),
    '--simulator', simulator, '--pdk-root', '/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008',
    '--output', str(out)]
completed = subprocess.run(command, cwd=workspace, env=env, timeout=10900)
result = read(out / 'result.json')
review = {'status': 'PASS_CORRECTED_ROUTED_NETLIST' if completed.returncode == 0 else 'FAILED_OR_INCOMPLETE',
          'returncode': completed.returncode, 'netlist_sha256': result['netlist_sha256'],
          'result_sha256': sha((out / 'result.json').read_bytes()), 'declaration_sha256': sha(decision_path.read_bytes())}
assert result['netlist_sha256'] == decision['netlist_sha256']
assert result['library_sha256'] == prior['library_sha256']
assert all(sha((workspace / n).read_bytes()) == h for n, h in snapshot['files'].items())
(base / (simulator + '-completion.json')).write_bytes((json.dumps(review, indent=2) + '\n').encode())
assert completed.returncode == 0 and result['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
print(review['status'], simulator)
