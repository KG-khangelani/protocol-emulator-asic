"""Freeze the test workspace so ongoing repository edits cannot change a run."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
out = root / 'build/g2-sram-guarded-netlist-pair-01'
workspace = out / 'workspace'
assert not out.exists()
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert source == 'ec5df14ce6965ece40118dd011c79f6b2084787a'
names = subprocess.check_output(['git', 'ls-files', '-z', 'tools', 'experiments', 'test'], cwd=root).decode().split('\0')
names = {n for n in names if n} | {
    'evidence/E0020-spi-mode0-feasibility/result.json',
    'evidence/E0042-sram-prefetch-screen/candidate.json', 'docs/specs/g2-sram-physical-integration.md'}
for name in ('architecture/combined/icarus/records/cases.jsonl.gz',
             'od128/protocols/icarus/records/cases.jsonl.gz',
             'architecture/boundaries/od128-icarus/records/boundaries.jsonl.gz',
             'architecture/aborts/od128-icarus/records/aborts.jsonl.gz'):
    names.add('evidence/E0036-g2-store-and-ci/ci/' + name)
manifest = {}
for name in sorted(names):
    raw = subprocess.check_output(['git', 'show', source + ':' + name], cwd=root)
    assert raw == (root / name).read_bytes(), name
    path = workspace / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    manifest[name] = hashlib.sha256(raw).hexdigest()
(out / 'snapshot.json').write_bytes((json.dumps({'source_commit': source, 'files': manifest,
    'purpose': 'Immutable public-netlist test inputs; no production adoption or physical acceptance.'}, indent=2) + '\n').encode())
(out / 'prepare.py').write_bytes(Path(__file__).read_bytes())
print('FROZEN_NETLIST_TEST_INPUTS', len(manifest))
