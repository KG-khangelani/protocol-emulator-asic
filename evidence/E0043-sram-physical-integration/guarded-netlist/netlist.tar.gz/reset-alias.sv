// Simulation-only zero-delay alias for the pinned cell's $recrem output.
// No cell implementation, circuit netlist, clock, data or timing limit changes.
module sram_dfrbpq_reset_alias(input wire reset_b, output wire delayed_reset_b);
  assign delayed_reset_b = reset_b;
endmodule
bind sg13cmos5l_dfrbpq_1 sram_dfrbpq_reset_alias reset_alias
  (.reset_b(RESET_B), .delayed_reset_b(delayed_RESET_B));
