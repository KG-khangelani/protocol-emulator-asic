"""Repository consistency checks only; not an HDL compiler or physical check."""
import ast
import hashlib
import json
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]

def require(condition, message):
    if not condition:
        raise SystemExit(message)

info = yaml.safe_load((ROOT / "info.yaml").read_text())
project = info["project"]
require(info["yaml_version"] == 6, "unexpected Tiny Tapeout metadata version")
require(project["tiles"] == "8x4", "current competition allocation must be 8x4")
top = project["top_module"]
require(top.startswith("tt_um_"), "invalid Tiny Tapeout top prefix")
require(set(info["pinout"]) == {f"{p}[{i}]" for p in ("ui", "uo", "uio") for i in range(8)}, "pinout differs from template")
sources = project["source_files"]
require(bool(sources) and len(set(sources)) == len(sources), "empty/duplicate source list")
for name in sources:
    require((ROOT / "src" / name).is_file(), f"missing RTL source: {name}")
rtl = "\n".join((ROOT / "src" / f).read_text() for f in sources)
require(re.search(r"\bmodule\s+" + re.escape(top) + r"\b", rtl), "top module missing")
require(top in (ROOT / "test/tb.v").read_text(), "testbench top mismatch")
listed = re.search(r"^PROJECT_SOURCES\s*=\s*(.+)$", (ROOT / "test/Makefile").read_text(), re.M)
require(listed and listed.group(1).split() == sources, "test/source list mismatch")
config = json.loads((ROOT / "src/config.json").read_text())
require(abs(1e9 / project["clock_hz"] - config["CLOCK_PERIOD"]) < 1e-9, "clock target mismatch")
for folder in ("tools", "test"):
    for file in (ROOT / folder).glob("*.py"):
        ast.parse(file.read_text(), filename=str(file.relative_to(ROOT)))
for workflow in (ROOT / ".github/workflows").glob("*.yaml"):
    require(isinstance(yaml.safe_load(workflow.read_text()), dict), f"invalid workflow: {workflow.name}")
lock = json.loads((ROOT / "tools/workbench/toolchain.lock.json").read_text())
fast_ci = lock["fast_ci"]
test_workflow = (ROOT / ".github/workflows/test.yaml").read_text()
require(f"runs-on: {fast_ci['runner']}" in test_workflow, "fast CI runner differs from toolchain lock")
for action, commit in fast_ci["actions"].items():
    require(f"uses: {action}@{commit}" in test_workflow, f"fast CI action differs from lock: {action}")
for workflow in (ROOT / ".github/workflows").glob("*.yaml"):
    workflow_text = workflow.read_text()
    for action_ref in re.findall(r"^\s*uses:\s*([^\s#]+)", workflow_text, re.M):
        if not action_ref.startswith("./"):
            require(re.search(r"@[0-9a-f]{40}$", action_ref), f"mutable action ref in {workflow.name}: {action_ref}")
physical = lock["official_cmos5l_8x4"]
baseline_config = ROOT / "experiments/physical/d34-config.json"
require(hashlib.sha256(baseline_config.read_bytes()).hexdigest() == physical["config_sha256_lf"],
        "archived D34 physical configuration differs from lock")
config_lf = (ROOT / "src/config.json").read_text(encoding="utf-8").encode()
require(hashlib.sha256(config_lf).hexdigest() == physical["config_sha256_lf"],
        "physical configuration hash differs from lock")
for name, value in physical["physical_constraints"].items():
    require(config.get(name) == value, f"physical constraint differs from lock: {name}")
gds_workflow = (ROOT / ".github/workflows/gds.yaml").read_text()
require(f"runs-on: {physical['runner']}" in gds_workflow, "physical runner differs from toolchain lock")
require(f"uses: actions/checkout@{physical['checkout_action_commit']}" in gds_workflow, "physical checkout action differs from lock")
for action_path in ("", "/precheck", "/gl_test"):
    expected = f"uses: {physical['outer_action_repository']}{action_path}@{physical['outer_action_commit']}"
    require(expected in gds_workflow, f"physical action differs from lock: {action_path or '/'}")
for expected in (
    f"tools-repo: {physical['support_tools_repository']}",
    f"tools-ref: {physical['support_tools_commit']}",
    f"librelane-version: {physical['librelane']}",
    f"pdk: {physical['pdk']}",
):
    require(expected in gds_workflow, f"physical workflow input differs from lock: {expected}")
require(physical["librelane_image"] in gds_workflow, "physical image digest differs from lock")
require("tools/physical_candidate.py prepare" in gds_workflow, "physical staging missing")
require("check-tests" in gds_workflow and "--require-netlist" in gds_workflow,
        "physical public-netlist verification missing")
qualification = physical["qualification"]
qualified_path = ROOT / qualification["result_path"]
require(qualified_path.resolve().is_relative_to(ROOT), "qualified result must stay in the repository")
require(hashlib.sha256(qualified_path.read_bytes()).hexdigest() == qualification["result_sha256"],
        "qualified physical result digest differs from lock")
qualified = json.loads(qualified_path.read_text(encoding="utf-8"))
require(qualified["status"] == "PASS_ALL_REQUIRED_PHYSICAL_GATES", "selected physical pilot is not qualified")
for field in ("variant", "workflow_source_commit", "run_id", "gds_sha256", "netlist_sha256"):
    require(qualified[field] == qualification[field], f"qualified physical identity differs from lock: {field}")
require(all(qualified["jobs"][name]["conclusion"] == "success" for name in ("gds", "precheck", "gl_test")),
        "qualified physical jobs did not all pass")
require(f"default: {qualification['variant']}" in gds_workflow, "manual GDS default differs from qualified pilot")
# The non-gating canary still watches the archived M0 qualified ref.
physical = lock["official_cmos5l_qualification"]
canary_workflow = (ROOT / ".github/workflows/upstream-canary.yaml").read_text()
require(f"runs-on: {physical['runner']}" in canary_workflow, "canary runner differs from physical lock")
require(
    f"uses: actions/checkout@{physical['checkout_action_commit']}" in canary_workflow,
    "canary checkout action differs from lock",
)
require(
    f"uses: actions/upload-artifact@{fast_ci['actions']['actions/upload-artifact']}" in canary_workflow,
    "canary upload action differs from lock",
)
require("tools/check_upstream_drift.py" in canary_workflow, "canary does not run the drift checker")
workbench_sh = (ROOT / "tools/workbench.sh").read_text()
require('--user "$(id -u):$(id -g)"' in workbench_sh, "Linux workbench must preserve host workspace ownership")
require("--env HOME=/tmp" in workbench_sh, "Linux workbench user needs a writable temporary home")
require(re.search(r"all\) inside=\(make .*test-verilator formal synth\)", workbench_sh), "Linux All command must include formal verification")
workbench_ps1 = (ROOT / "tools/workbench.ps1").read_text()
require(re.search(r"'All'.*'test-verilator', 'formal', 'synth'", workbench_ps1), "PowerShell All command must include formal verification")
require("'LearnM0'" in workbench_ps1 and "tools/m0_walkthrough.py" in workbench_ps1, "PowerShell wrapper must expose the M0 walkthrough")
require("'LearnWaveform'" in workbench_ps1 and "learn-waveform" in workbench_ps1, "PowerShell wrapper must expose the waveform walkthrough")
require("'LearnStatus'" in workbench_ps1 and "learn-status" in workbench_ps1, "PowerShell wrapper must expose learning status")
require(
    "HOST LEARNING MODE" in workbench_ps1
    and "Get-Command python" in workbench_ps1
    and "tools\\learning_status.py" in workbench_ps1,
    "read-only PowerShell lessons must expose the Docker-independent host-Python path",
)
require("learnm0|learn-m0" in workbench_sh and "tools/m0_walkthrough.py" in workbench_sh, "Linux wrapper must expose the M0 walkthrough")
require("learnwaveform|learn-waveform" in workbench_sh and "make learn-waveform" in workbench_sh, "Linux wrapper must expose the waveform walkthrough")
require("learnstatus|learn-status" in workbench_sh and "make learn-status" in workbench_sh, "Linux wrapper must expose learning status")
project_makefile = (ROOT / "Makefile").read_text()
testbench = (ROOT / "test/tb.v").read_text()
evidence_collector = (ROOT / "tools/collect_evidence.py").read_text()
require("learn-waveform:" in project_makefile and "tools/m0_waveform_walkthrough.py" in project_makefile, "Makefile must define the waveform walkthrough")
require("learn-status:" in project_makefile and "tools/learning_status.py" in project_makefile, "Makefile must define learning status")
require("formal/m1_engine.sby" in project_makefile, "active formal target must check the M1 engine")
require("formal/m1_program_store.sby" in project_makefile, "active formal target must check the program store")
require("formal/m1_data_store.sby" in project_makefile, "active formal target must check the data store")
require("formal/m1_input_sync.sby" in project_makefile, "active formal target must check the input synchronizer")
require("test_gate_harness_smoke" in project_makefile, "active test target must check the GL_TEST-shaped harness")
require("test-rtl-icarus:" in project_makefile, "full Icarus regression must have a distinct evidence target")
require("test-gl-harness:" in project_makefile, "GL-shaped smoke must have a distinct evidence target")
require("test-waveform-provenance:" in project_makefile, "waveform labels and checksums must be verified")
require("LEARNING_VCD" in testbench and "m0-learning.vcd" in testbench, "testbench must expose the readable learning waveform")
require(
    "GL_HARNESS_SMOKE" in testbench and "tb-gl-harness.fst" in testbench,
    "GL-shaped smoke must not overwrite the full RTL waveform",
)
test_makefile = (ROOT / "test/Makefile").read_text()
require(
    "M0_LEARNING" in test_makefile and "E0010-pinned-cmos5l-run" in test_makefile,
    "M0 waveform lesson must remain pinned to archived qualified RTL",
)
require('("learning_waveform", ["make", "learn-waveform"]' in evidence_collector, "evidence collector must exercise the waveform walkthrough")
require('("learning_status", [sys.executable, "tools/learning_status.py", "--verify"]' in evidence_collector, "evidence collector must retain learning-status validation")
require('("gl_harness_smoke", ["make", "test-gl-harness"]' in evidence_collector, "evidence collector must label the GL-shaped smoke separately")
require('"test/tb-gl-harness.fst": ("gl_harness_smoke"' in evidence_collector, "GL-shaped waveform must retain its producing-stage label")
require('"test/tb.fst": ("rtl_icarus"' in evidence_collector, "full RTL waveform must retain its producing-stage label")
for learning_file in ("map.md", "glossary.md", "labs.md", "checkpoints.md", "progress.json"):
    require((ROOT / "docs/learning" / learning_file).is_file(), f"missing learning-system file: {learning_file}")
for decision_file in (
    "0008-decouple-engineering-learning.md",
    "0009-m1-provisional-encoding.md",
    "0010-public-pin-program-store.md",
    "0011-synchronized-bounded-input-wait.md",
    "0012-k-input-wait-timeout-skip.md",
    "0013-bounded-block-before-shifter.md",
    "0014-distinct-waveform-provenance.md",
    "0015-composable-shift-step.md",
):
    require((ROOT / "docs/decisions" / decision_file).is_file(), f"missing M1 decision: {decision_file}")
research_sources = json.loads((ROOT / "docs/research/source-lock.json").read_text())
require(
    research_sources["schema"] == "protocol-emulator-research-sources-v1",
    "unexpected research source-lock schema",
)
require(
    re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z", research_sources["observed_at_utc"]),
    "invalid research source observation timestamp",
)
established = research_sources["established_references"]
standards = research_sources["standards"]
competition = research_sources["contemporary_competition_scan"]
require({source["id"] for source in established} == {"S9", "S10", "S11", "S12"}, "unexpected established research source set")
require({source["id"] for source in standards} == {"S13"}, "unexpected research standard set")
require({source["id"] for source in competition} == {"C1", "C2", "C3"}, "unexpected competition research source set")
for source in established:
    require(re.fullmatch(r"[0-9a-f]{40}", source["commit"]), f"invalid source commit: {source['id']}")
    require(bool(source["license_spdx"]), f"missing source license: {source['id']}")
    require(bool(source["documents"]), f"missing inspected documents: {source['id']}")
    for document in source["documents"]:
        require(re.fullmatch(r"[0-9a-f]{40}", document["git_blob_sha"]), f"invalid document blob: {source['id']}")
for source in competition:
    require(re.fullmatch(r"[0-9a-f]{40}", source["commit"]), f"invalid competition commit: {source['id']}")
    require(re.fullmatch(r"[0-9a-f]{40}", source["readme_git_blob_sha"]), f"invalid competition README blob: {source['id']}")
evaluation = json.loads((ROOT / "docs/research/evaluation-contract.json").read_text())
require(
    evaluation["schema"] == "protocol-emulator-evaluation-contract-v1",
    "unexpected architecture evaluation schema",
)
require(evaluation["physical_configuration"]["tiles"] == project["tiles"], "evaluation allocation mismatch")
require(evaluation["clock_target_hz"] == project["clock_hz"], "evaluation clock mismatch")
require(evaluation["physical_configuration"]["flow_lock_key"] == "official_cmos5l_8x4", "evaluation flow mismatch")
require(evaluation["physical_configuration"]["decision"] == lock["official_cmos5l_8x4"]["configuration_decision"],
        "evaluation physical decision differs from lock")
for field, locked in (("qualification", "status"), ("qualified_variant", "variant"),
                      ("qualification_decision", "decision"), ("qualification_source_commit", "workflow_source_commit")):
    require(evaluation["physical_configuration"][field] == qualification[locked],
            f"evaluation physical qualification differs from lock: {field}")
require(evaluation["primary_boundary"]["id"] == "CHIP_COMPLETE", "complete-chip boundary must remain primary")
require(evaluation["secondary_boundary"]["id"] == "CORE_ATTRIBUTION", "unexpected attribution boundary")
require(
    {status["id"] for status in evaluation["execution_statuses"]}
    == {"PASS", "FAIL", "BLOCKED", "NOT_EVALUATED", "NOT_APPLICABLE"},
    "unexpected architecture execution-status vocabulary",
)
require(
    {status["id"] for status in evaluation["value_provenance"]}
    == {"MEASURED", "DERIVED", "UPSTREAM_OTHER_TECH"},
    "unexpected architecture value-provenance vocabulary",
)
require(len(evaluation["mandatory_workloads"]) == len(set(evaluation["mandatory_workloads"])), "duplicate architecture workload")
print("PASS: metadata, pinout, source list, top module, clock target, Python syntax, immutable direct workflow refs, locked CI/physical inputs, research source/evaluation identities, learning entrypoint and Linux workspace ownership")
print("LIMIT: no RTL simulation, HDL elaboration, IHP synthesis or physical verification performed by this check")
