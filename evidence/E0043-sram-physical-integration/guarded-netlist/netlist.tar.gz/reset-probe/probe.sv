
`timescale 1ns/1ps
module cell_probe;
reg clk=0, d=0, reset_b=0;
reg [15:0] stream=16'h2713;
reg expected=0;
wire actual_q, direct_q;
integer count=0, errors=0;
wire reset_active = !reset_b;
sg13cmos5l_dfrbpq_1 actual (.Q(actual_q), .CLK(clk), .D(d), .RESET_B(reset_b));
ihp_dff_r direct (direct_q, 1'b0, clk, d, reset_active, 1'b0);
task sample;
  $display("CELL_SAMPLE %0d %b %b %b %b %b %b %b %b %b", count, expected,
    actual_q, direct_q, clk, d, reset_b, actual.delayed_CLK, actual.delayed_D, actual.delayed_RESET_B);
  if (actual_q !== expected || direct_q !== expected) errors=errors+1;
  count=count+1;
endtask
initial begin
  #2; sample;
  for (integer i=0; i<256; i=i+1) begin
    stream={stream[14:0], stream[15]^stream[13]^stream[12]^stream[10]};
    clk=0; #1;
    reset_b=stream[0]; d=stream[1]; if (!reset_b) expected=0;
    #1; sample;
    clk=1; expected=reset_b ? d : 0;
    #1; sample;
    d=stream[2]; #1; sample;
    reset_b=stream[3]; if (!reset_b) expected=0;
    #1; sample;
  end
  $display("CELL_RESULT %0d %0d", count, errors);
  $finish;
end
endmodule
