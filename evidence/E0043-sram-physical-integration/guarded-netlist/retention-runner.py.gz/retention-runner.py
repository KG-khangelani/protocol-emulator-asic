"""Retain the corrected netlist pair and the exact frozen test workspace."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-guarded-netlist-pair-02'
out = root / 'evidence/E0043-sram-physical-integration/guarded-netlist'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
files = {}
snapshot = read(base / 'snapshot.json')
assert snapshot['source_commit'] == 'ec5df14ce6965ece40118dd011c79f6b2084787a'
assert len(snapshot['files']) == 194
git_bytes = subprocess.check_output(['git', 'archive', snapshot['source_commit'], *snapshot['files']], cwd=root)
with tarfile.open(fileobj=io.BytesIO(git_bytes)) as archive:
    for name, expected in snapshot['files'].items():
        raw = (base / 'workspace' / name).read_bytes()
        assert sha(raw) == expected and raw == archive.extractfile(name).read()
        files['snapshot/' + name] = raw
for name in ('snapshot.json', 'prepare.py', 'runtime-launch.json', 'reset-alias.sv'):
    files[name] = (base / name).read_bytes()
for simulator in ('icarus', 'verilator'):
    directory = base / 'workspace/build' / simulator
    result = read(directory / 'result.json')
    completion = read(base / (simulator + '-completion.json'))
    assert result['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
    assert completion['status'] == 'PASS_CORRECTED_ROUTED_NETLIST' and completion['returncode'] == 0
    assert completion['result_sha256'] == sha((directory / 'result.json').read_bytes())
    for path in sorted(directory.rglob('*')):
        relative = path.relative_to(directory)
        if path.is_file() and not any(part in ('sim', '__pycache__') for part in relative.parts):
            files[simulator + '/' + relative.as_posix()] = path.read_bytes()
    for suffix in ('declaration.json', 'completion.json', 'runner.py'):
        files[simulator + '/' + suffix] = (base / (simulator + '-' + suffix)).read_bytes()
    runtime = json.loads(subprocess.check_output(['docker', 'inspect', 'g2-sram-guarded-netlist-' + simulator + '-01']))[0]
    assert runtime['Image'] == 'sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
    assert runtime['State']['Status'] == 'exited' and runtime['State']['ExitCode'] == 0
    assert any(m['Destination'] == '/pdk' and not m['RW'] for m in runtime['Mounts'])
    observed = {k: runtime[k] for k in ('Id', 'Name', 'Image', 'State', 'Mounts')}
    observed['configured_image'] = runtime['Config']['Image']
    observed['command'] = runtime['Config']['Cmd']
    files[simulator + '/completed-runtime.json'] = (json.dumps(observed, indent=2) + '\n').encode()
physical = root / 'build/g2-sram-full-05'
files['physical/post-pnr-state.json'] = (physical / 'runs/integrated/59-openroad-stapostpnr/state_out.json').read_bytes()
files['physical/original-rule-completion.json'] = (root / 'evidence/E0043-sram-physical-integration/guarded-completion/completion-review.json').read_bytes()
files['candidate.json'] = (root / 'evidence/E0042-sram-prefetch-screen/candidate.json').read_bytes()
for path in (root / 'build/g2-sram-candidate-01/src').glob('*.v'):
    files['source/' + path.name] = path.read_bytes()
reference = root / 'evidence/E0043-sram-physical-integration/local-netlist'
index = read(reference / 'archive.json')
archive = reference / 'netlist.tar.gz'
assert sha(archive.read_bytes()) == index['sha256']
with tarfile.open(archive) as stream:
    for entry in stream.getmembers():
        if entry.isfile() and entry.name.startswith('reset-probe/'):
            raw = stream.extractfile(entry).read()
            assert sha(raw) == index['files'][entry.name]
            files[entry.name] = raw
with zipfile.ZipFile(root / 'evidence/E0043-sram-physical-integration/ci-232ee20-pin-failure/14000422018.zip') as z:
    raw = z.read('tt_submission/tt_um_khangelani_protocol_emulator.v')
    assert raw == files['icarus/netlist.v'] == files['verilator/netlist.v']
    files['physical/submission-binding.json'] = (json.dumps({
        'status': 'PASS_IDENTICAL_SUBMITTED_NETLIST', 'run_id': 43337581691,
        'source_commit': '232ee20e1eb35726f785225ecfc1a2641e10af33', 'netlist_sha256': sha(raw),
        'physical_qualification': 'REJECTED_POWER_PORT_PRECHECK; fresh D47 qualification remains separate',
        'scope': 'The corrected physical netlist, unchanged in both simulators; zero-delay functional results do not qualify the earlier layout.'}, indent=2) + '\n').encode()
first = root / 'build/g2-sram-guarded-netlist-pair-01'
for path in first.iterdir():
    if path.is_file():
        files['preparation-failure/' + path.name] = path.read_bytes()
out.mkdir()
with (out / 'netlist.tar.gz').open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as stream:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                stream.addfile(entry, io.BytesIO(raw))
(out / 'archive.json').write_bytes((json.dumps({'sha256': sha((out / 'netlist.tar.gz').read_bytes()),
    'bytes': (out / 'netlist.tar.gz').stat().st_size, 'files': {n: sha(r) for n, r in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_CORRECTED_ACTUAL_NETLIST_PAIR', len(files), (out / 'netlist.tar.gz').stat().st_size)
