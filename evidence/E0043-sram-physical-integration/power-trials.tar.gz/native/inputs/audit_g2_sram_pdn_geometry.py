import json
from pathlib import Path
import odb

BASE=Path('/workspace/build/g2-sram-pdn-01')
matches=list((BASE/'runs/native-pdn').glob('*-openroad-generatepdn/*.odb'))
assert len(matches)==1
db=odb.dbDatabase.create()
odb.read_db(db,str(matches[0]))
block=db.getChip().getBlock()
scale=block.getDbUnitsPerMicron()
inst=block.findInst('store.program_memory')
assert inst and inst.getMaster().getName()=='RM_IHPSG13_1P_256x32_c2_bm_bist'
box=inst.getBBox()
bounds=[box.xMin(),box.yMin(),box.xMax(),box.yMax()]
assert bounds==[20160,302400,436800,421180] and str(inst.getOrient()) in ('MX','FS')
rectangles=json.loads((BASE/'preparation.json').read_bytes())['power_rectangles']
wires={}
for net_name in ('VPWR','VGND'):
    net=block.findNet(net_name)
    shapes=[]
    for wire in net.getSWires():
        for shape in wire.getWires():
            if not shape.isVia() and shape.getTechLayer().getName()=='Metal4':
                shapes.append([shape.xMin(),shape.yMin(),shape.xMax(),shape.yMax()])
    wires[net_name]=sorted(shapes)
def overlaps(a,b):
    return min(a[2],b[2])>max(a[0],b[0]) and min(a[3],b[3])>max(a[1],b[1])
observations=[]
for pin,rows in rectangles.items():
    expected='VGND' if pin=='VSS!' else 'VPWR'
    actual=inst.findITerm(pin).getNet().getName()
    assert actual==expected
    for row in rows:
        local=[round(float(v)*scale) for v in row]
        world=[bounds[0]+local[0],bounds[3]-local[3],bounds[0]+local[2],bounds[3]-local[1]]
        same=[r for r in wires[expected] if overlaps(world,r)]
        other=[r for r in wires['VGND' if expected=='VPWR' else 'VPWR'] if overlaps(world,r)]
        assert not other
        observations.append({'pin':pin,'net':expected,'rectangle_dbu':world,'same_net_overlaps':same,'opposite_net_overlaps':other})
missing=[o for o in observations if not o['same_net_overlaps']]
sample=[r for r in wires['VPWR'] if r[0]<25825<r[2]]
result={'status':'FAIL_UNPOWERED_SRAM' if missing else 'GEOMETRY_OVERLAPS_PRESENT_GRID_CHECK_REQUIRED',
        'database':str(matches[0]),'dbu_per_micron':scale,'macro_bounds_dbu':bounds,
        'macro_orientation':str(inst.getOrient()),'supply_rectangles':len(observations),
        'missing_overlaps':len(missing),'observations':observations,
        'first_vdd_column_external_shapes_dbu':sample,'power_wires_dbu':wires,
        'physical_qualification':'NOT_ACCEPTED'}
(BASE/'geometry.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(BASE/'inputs/audit_g2_sram_pdn_geometry.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items() if k not in ('observations','power_wires_dbu')}))
