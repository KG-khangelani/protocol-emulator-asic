import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT=Path('/workspace')
BASE=ROOT/'build/g2-sram-pdn-01'
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_program_sensitivity import execute

assert not (BASE/'run-result.json').exists()
result={'status':'RUNNING_NATIVE_PDN_TRIAL','started_utc':datetime.now(timezone.utc).isoformat(),
        'physical_qualification':'NOT_EVALUATED'}
save=lambda:(BASE/'run-result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
save()
(BASE/'inputs/run_g2_sram_pdn.py').write_bytes(Path(__file__).read_bytes())
command=['librelane','--pdk-root','/pdk','--pdk','ihp-sg13cmos5l','--to','OpenROAD.GeneratePDN',
         '--run-tag','native-pdn','--design-dir',str(BASE),str(BASE/'src/config_merged.json')]
try:
    result['execution']=execute(command,BASE/'run.log',300)
    assert result['execution']['returncode']==0 and not result['execution']['timed_out']
    result['status']='COMMAND_SUCCEEDED_REQUIRES_GEOMETRY_AUDIT'
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE',error=str(error))
    raise
finally:
    save()
print(result['status'])
