import hashlib
import json
from pathlib import Path
import sys
import odb

ROOT=Path('/workspace')
BASE=ROOT/'build/g2-sram-pdn-01'
OUT=ROOT/'build/g2-sram-pdn-bridges-01'
assert not OUT.exists()
(OUT/'inputs').mkdir(parents=True)
sys.path.insert(0,str(ROOT/'experiments/i2c'))
from connect_sram_power import connect

source=next((BASE/'runs/native-pdn').glob('*-openroad-generatepdn/*.odb'))
raw=source.read_bytes()
(OUT/'before.odb').write_bytes(raw)
result={'status':'RUNNING_GEOMETRY_REPAIR','input_database_sha256':hashlib.sha256(raw).hexdigest()}
save=lambda:(OUT/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
save()
for path in (Path(__file__),ROOT/'experiments/i2c/connect_sram_power.py',ROOT/'docs/specs/g2-sram-physical-integration.md',BASE/'preparation.json'):
    (OUT/'inputs'/path.name).write_bytes(path.read_bytes())
try:
    db=odb.dbDatabase.create()
    odb.read_db(db,str(source))
    result.update(connect(db,json.loads((BASE/'preparation.json').read_bytes())))
    odb.write_db(db,str(OUT/'after.odb'))
    result['output_database_sha256']=hashlib.sha256((OUT/'after.odb').read_bytes()).hexdigest()
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE',error=str(error))
    raise
finally:
    save()
print(result['status'])
