import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('/workspace')
OUT=ROOT/'build/g2-sram-pdn-bridges-01'
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_program_sensitivity import execute

assert not (OUT/'gridcheck.json').exists()
command=['openroad','-no_init','-exit',str(OUT/'check-grid.tcl')]
execution=execute(command,OUT/'gridcheck.log',120)
log=(OUT/'gridcheck.log').read_text()
accepted=execution['returncode']==0 and not execution['timed_out'] and all('PASS_SRAM_GRID '+net in log for net in ('VPWR','VGND'))
result={'status':'PASS_BOTH_POWER_GRIDS' if accepted else 'FAILED_OR_INCOMPLETE',
        'execution':execution,'database_sha256':hashlib.sha256((OUT/'after.odb').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256((OUT/'check-grid.tcl').read_bytes()).hexdigest(),
        'log_sha256':hashlib.sha256((OUT/'gridcheck.log').read_bytes()).hexdigest(),
        'physical_qualification':'NOT_EVALUATED'}
(OUT/'gridcheck.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(OUT/'inputs/check_g2_sram_power.py').write_bytes(Path(__file__).read_bytes())
print(result['status'])
assert accepted
