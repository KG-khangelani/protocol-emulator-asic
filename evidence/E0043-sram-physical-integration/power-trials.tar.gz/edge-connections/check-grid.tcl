set pdk /pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l
read_liberty $pdk/libs.ref/sg13cmos5l_stdcell/lib/sg13cmos5l_stdcell_typ_1p20V_25C.lib
read_liberty $pdk/libs.ref/sg13cmos5l_sram/lib/RM_IHPSG13_1P_256x32_c2_bm_bist_typ_1p20V_25C.lib
read_db /workspace/build/g2-sram-pdn-bridges-01/after.odb
set failures 0
foreach net {VPWR VGND} {
    if {[catch {check_power_grid -net $net -error_file /workspace/build/g2-sram-pdn-bridges-01/$net-grid-errors.rpt} message]} {
        puts "FAIL_SRAM_GRID $net $message"
        incr failures
    } else {
        puts "PASS_SRAM_GRID $net"
    }
}
if {$failures} {exit 1}
exit 0
