import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/official-staging'
out.mkdir(exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
for label, folder in [('initial', 'g2-sram-official-staging-01'), ('pilot', 'g2-sram-official-staging-02')]:
    base = root / 'build' / folder
    for path in sorted(base.rglob('*')):
        name = path.relative_to(base).as_posix()
        if not path.is_file() or any(p in path.parts for p in ('__pycache__', 'tmp', 'final')):
            continue
        if path.suffix in ('.odb', '.def') and not any('/' + stage + '/' in '/' + name for stage in (
                '21-openroad-generatepdn', '22-odb-removepdnobstructions',
                '23-project-connectsrampower', '24-project-checksrampower')):
            continue
        files[label + '/' + name] = path.read_bytes()
files['repo-check.log'] = (root / 'build/g2-sram-official-repo-check.log').read_bytes()
for name in ('tools/physical_sram.py', '.github/workflows/gds-sram.yaml', 'docs/specs/g2-sram-official-qualification.md'):
    files['current-inputs/' + name] = (root / name).read_bytes()
reference = root / 'build/g2-sram-full-03/runs/integrated'
files['reference/resolved.json'] = (reference / 'resolved.json').read_bytes()
for path in sorted((reference / '58-openroad-stapostpnr').rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.rpt', '.log'):
        files['reference/post-pnr/' + path.relative_to(reference / '58-openroad-stapostpnr').as_posix()] = path.read_bytes()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for name, raw in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(raw), 0o644, 0
        archive.addfile(member, io.BytesIO(raw))
packed = gzip.compress(buffer.getvalue(), mtime=0)
(out / 'staging.tar.gz').write_bytes(packed)
index = {'sha256': sha(packed), 'bytes': len(packed), 'files': {n: sha(v) for n, v in sorted(files.items())}}
(out / 'archive.json').write_text(json.dumps(index, indent=2) + '\n', newline='\n')
(out / 'verification.json').write_bytes((root / 'build/g2-sram-official-staging-02/pilot-verification.json').read_bytes())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_PORTABLE_SRAM_STAGING', len(files), len(packed))
