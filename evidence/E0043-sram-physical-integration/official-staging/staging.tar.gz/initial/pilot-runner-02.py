import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute

base = ROOT / 'build/g2-sram-official-staging-01'
workspace = base / 'workspace'
inputs = json.loads((base / 'inputs.json').read_bytes())
config = json.loads((workspace / 'src/config.json').read_bytes())
reference = json.loads((ROOT / 'build/g2-sram-full-03/src/config_merged.json').read_bytes())
# These are exactly the support tool's generated fields, using the same frozen template.
for name in ('DESIGN_NAME', 'DIE_AREA', 'FP_DEF_TEMPLATE', 'VDD_PIN', 'GND_PIN', 'RT_MAX_LAYER'):
    config[name] = reference[name]
config['VERILOG_FILES'] = ['dir::' + name for name in inputs['candidate']['source_sha256']]
(workspace / 'src/config_merged.json').write_text(json.dumps(config, indent=2) + '\n')
os.chdir(workspace)
command = [sys.executable, '-m', 'librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l',
           '--run-tag', 'portable-pilot', '--design-dir', str(workspace),
           '--to', 'Project.CheckSramPower', str(workspace / 'src/config_merged.json')]
result = execute(command, base / 'pilot-02.log', 300, env=dict(os.environ, PYTHONPATH=str(workspace)))
(base / 'pilot-execution-02.json').write_text(json.dumps(result, indent=2) + '\n')
assert result['returncode'] == 0 and not result['timed_out']
resolved = json.loads((workspace / 'runs/portable-pilot/resolved.json').read_bytes())
old = json.loads((ROOT / 'build/g2-sram-full-03/runs/integrated/resolved.json').read_bytes())
def normalize(value):
    if isinstance(value, str):
        return value.replace(str(workspace), '$DESIGN').replace('/workspace/build/g2-sram-full-03', '$DESIGN').replace('$DESIGN/src/sram-preparation.json', '$DESIGN/preparation.json')
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, dict):
        return {k: normalize(v) for k, v in value.items()}
    return value
new, old = normalize(resolved), normalize(old)
changes = {k: [old.get(k), new.get(k)] for k in old.keys() | new.keys() if old.get(k) != new.get(k)}
assert not changes, changes
state = json.loads(next((workspace / 'runs/portable-pilot').glob('*-project-checksrampower/state_out.json')).read_bytes())
assert state['metrics']['design__power_grid_violation__count'] == 0
result.update(status='PASS_PORTABLE_CONFIG_MATCHES_FULL_03_AND_FRESH_POWER_PILOT', normalized_resolved_changes=changes)
(base / 'pilot-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(result['status'])
