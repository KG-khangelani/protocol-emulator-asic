import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
for name, folder, expected in (
    ('g2-sram-netlist-verilator-03', 'g2-sram-netlist-verilator-03', 'sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'),
    ('g2-sram-official-staging-05', 'g2-sram-official-staging-02', 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'),
    ('g2-sram-official-staging-04', 'g2-sram-official-staging-01', 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'),
):
    item = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert item['Image'] == item['Config']['Image'] == expected
    image = json.loads(subprocess.check_output(['docker', 'image', 'inspect', expected]))[0]
    result = {'status': 'OBSERVED_IDENTIFIED_CONTAINER', 'observed_utc': datetime.now(timezone.utc).isoformat(),
              'name': name, 'id': item['Id'], 'image_id': item['Image'], 'configured_image': item['Config']['Image'],
              'command': item['Config']['Cmd'], 'started_at': item['State']['StartedAt'],
              'state': item['State']['Status'], 'exit_code': item['State']['ExitCode'],
              'repo_digests': image['RepoDigests'],
              'mounts': [m for m in item['Mounts'] if m['Destination'] in ('/pdk', '/workspace')]}
    assert any(m['Destination'] == '/pdk' and not m['RW'] for m in result['mounts'])
    base = root / 'build' / folder
    (base / 'runtime-observation.json').write_text(json.dumps(result, indent=2) + '\n', newline='\n')
    (base / 'inputs/runtime-observation.py').write_bytes(Path(__file__).read_bytes())
    print(name, result['state'], expected)

for folder, script in [('g2-sram-netlist-verilator-03', 'run_sram_netlist_verilator_followup.py'),
                       ('g2-sram-official-staging-02', 'rehearse_sram_official_staging_02.py'),
                       ('g2-sram-official-staging-02', 'audit_sram_official_staging.py')]:
    (root / 'build' / folder / 'inputs' / script).write_bytes((root / 'build' / script).read_bytes())
