import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
import run_program_sensitivity as bounded
base = ROOT / 'build/g2-sram-official-staging-02'
workspace = base / 'workspace'
bounded.ROOT = workspace
inputs = json.loads((base / 'inputs.json').read_bytes())
config = json.loads((workspace / 'src/config.json').read_bytes())
reference = json.loads((ROOT / 'build/g2-sram-full-03/src/config_merged.json').read_bytes())
for name in ('DESIGN_NAME', 'DIE_AREA', 'FP_DEF_TEMPLATE', 'VDD_PIN', 'GND_PIN', 'RT_MAX_LAYER'):
    config[name] = reference[name]
config['VERILOG_FILES'] = ['dir::' + Path(name).name for name in reference['VERILOG_FILES']]
(workspace / 'src/config_merged.json').write_text(json.dumps(config, indent=2) + '\n')
(workspace / 'runs/portable-pilot').mkdir(parents=True)
command = [sys.executable, '-m', 'librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l',
           '--run-tag', 'portable-pilot', '--force-run-dir', 'runs/portable-pilot',
           '--to', 'Project.CheckSramPower', 'src/config_merged.json']
env = dict(os.environ)
env.pop('PYTHONPATH', None)
result = bounded.execute(command, base / 'pilot.log', 300, env=env)
result['cwd'] = str(workspace)
(base / 'pilot-execution.json').write_text(json.dumps(result, indent=2) + '\n')
assert result['returncode'] == 0 and not result['timed_out']
print('PASS_PORTABLE_NATIVE_PILOT_COMMAND')
