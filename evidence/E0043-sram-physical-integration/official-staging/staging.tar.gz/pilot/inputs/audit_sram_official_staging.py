import copy
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT))
from tools import physical_sram as gate

base = ROOT / 'build/g2-sram-official-staging-02'
workspace = base / 'workspace'
run = workspace / 'runs/portable-pilot'
inputs = gate.read(base / 'inputs.json')
execution = gate.read(base / 'pilot-execution.json')
assert execution['returncode'] == 0 and not execution['timed_out']
resolved = gate.read(run / 'resolved.json')
original = gate.read(ROOT / 'build/g2-sram-full-03/runs/integrated/resolved.json')
def normalized(value):
    if isinstance(value, str):
        return value.replace(str(workspace), '$DESIGN').replace('/workspace/build/g2-sram-full-03', '$DESIGN').replace('$DESIGN/src/sram-preparation.json', '$DESIGN/preparation.json')
    if isinstance(value, list):
        return [normalized(v) for v in value]
    if isinstance(value, dict):
        return {k: normalized(v) for k, v in value.items()}
    return value
new, old = normalized(resolved), normalized(original)
changes = {k: [old.get(k), new.get(k)] for k in old.keys() | new.keys() if old.get(k) != new.get(k)}
assert changes == {'DESIGN_DIR': ['$DESIGN', '$DESIGN/src']}, changes
assert gate.inspect_resolved(resolved, inputs, workspace) == inputs['macro_views']
controls = []
for name, mutate, expected in (
    ('missing_real_macro', lambda c: c['MACROS'].clear(), 'unexpected macro set'),
    ('wrong_fast_library', lambda c: c['MACROS'][gate.MACRO]['lib'].__setitem__('nom_fast_1p32V_m40C', c['MACROS'][gate.MACRO]['lib']['nom_typ_1p20V_25C']), 'corner mapping changed'),
    ('waived_drc', lambda c: c.__setitem__('RUN_MAGIC_DRC', False), 'required acceptance check disabled'),
    ('extra_source', lambda c: c['VERILOG_FILES'].append(c['VERILOG_FILES'][0]), 'resolved RTL paths differ'),
    ('substituted_flow', lambda c: c['meta'].__setitem__('flow', 'Classic'), 'unexpected flow substitutions'),
    ('relaxed_clock', lambda c: c.__setitem__('CLOCK_PERIOD', 25), 'resolved CLOCK_PERIOD differs'),
):
    changed = copy.deepcopy(resolved)
    mutate(changed)
    try:
        gate.inspect_resolved(changed, inputs, workspace)
    except ValueError as error:
        assert expected in str(error), str(error)
        controls.append({'fault': name, 'observed_rejection': str(error)})
    else:
        raise AssertionError('missed corruption: ' + name)
state = gate.read(gate.one_stage(run, 'Project.CheckSramPower') / 'state_out.json')
assert state['metrics']['design__power_grid_violation__count'] == 0
odb = Path(state['odb'])
assert gate.digest(odb) == 'db9b16aa65fb52722a7de25efe81aacc2e6a4ddf7c9634ef1a5e3f8ccc916995'
result = dict(status='PASS_PORTABLE_STAGING_POWER_AND_SIX_RESOLVED_CORRUPTION_CONTROLS',
              execution=execution, normalized_resolved_changes=changes,
              directory_boundary='Official configuration resolves relative to src; the earlier local trial used an explicit design root. All physical settings and resolved input identities match.',
              final_odb_sha256=gate.digest(odb), controls=controls,
              resolved_sha256=gate.digest(run / 'resolved.json'),
              gate_sha256=gate.digest(ROOT / 'tools/physical_sram.py'),
              audit_sha256=gate.digest(Path(__file__)), physical='NOT_QUALIFIED')
gate.write(base / 'pilot-verification.json', result)
print(result['status'])
