import json, os, sys
from pathlib import Path

ROOT=Path('/workspace')
BASE=ROOT/'build/g2-sram-transition-screen-01'
SOURCE=ROOT/'build/g2-sram-full-02'
sys.path.insert(0,str(ROOT/'experiments/spi_phase'))
from run_program_sensitivity import execute
sys.path.insert(0,str(ROOT/'experiments/i2c'))
from sram_prefetch import digest

assert not BASE.exists()
(BASE/'inputs').mkdir(parents=True)
state=SOURCE/'runs/integrated/42-openroad-checkantennas/state_out.json'
raw=state.read_bytes()
initial=json.loads(raw)
config=json.loads((SOURCE/'src/config_merged.json').read_bytes())
assert config['RUN_POST_GRT_DESIGN_REPAIR'] is True and 'MAX_TRANSITION_CONSTRAINT' not in config
config['MAX_TRANSITION_CONSTRAINT']=0.4
(BASE/'config.json').write_bytes((json.dumps(config,indent=2)+'\n').encode())
(BASE/'inputs/state.json').write_bytes(raw)
for path in (Path(__file__), ROOT/'docs/specs/g2-sram-physical-integration.md'):
    (BASE/'inputs'/path.name).write_bytes(path.read_bytes())
for name in ('librelane_plugin_sram.py','sram_power_step.py','connect_sram_power.py','check_sram_power.tcl'):
    (BASE/'inputs'/name).write_bytes((SOURCE/name).read_bytes())
result={'status':'RUNNING','constraint_ns':0.4,'input_state_sha256':digest(raw),
        'input_odb_sha256':digest(Path(initial['odb']).read_bytes()),
        'input_netlist_sha256':digest(Path(initial['nl']).read_bytes()),
        'input_config_sha256':digest((SOURCE/'src/config_merged.json').read_bytes()),
        'config_sha256':digest((BASE/'config.json').read_bytes()),'physical_qualification':'NOT_EVALUATED'}
save=lambda:(BASE/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
save()
command=['librelane','--pdk-root','/pdk','--pdk','ihp-sg13cmos5l',
         '--from','OpenROAD.RepairDesignPostGRT','--to','OpenROAD.STAMidPNR-3',
         '--with-initial-state',str(BASE/'inputs/state.json'),
         '--run-tag','screen','--design-dir',str(BASE),str(BASE/'config.json')]
try:
    result['execution']=execute(command,BASE/'run.log',300,env=dict(os.environ,PYTHONPATH=str(SOURCE)))
    assert result['execution']['returncode']==0 and not result['execution']['timed_out']
    result['status']='COMMAND_SUCCEEDED_REQUIRES_ARTIFACT_AUDIT'
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE',error=str(error))
    raise
finally:
    save()
print(result['status'])
