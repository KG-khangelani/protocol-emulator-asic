import hashlib, json, subprocess, time
from pathlib import Path
import odb

ROOT=Path('/workspace')
base=ROOT/'build/g2-sram-buffer-screen-01'
out=base/'controls'
out.mkdir(exist_ok=False)
before=ROOT/'build/g2-sram-full-01/runs/integrated/41-openroad-globalrouting/tt_um_khangelani_protocol_emulator.odb'
after=base/'runs/screen/01-project-buffersraminputs/tt_um_khangelani_protocol_emulator.odb'
script=ROOT/'experiments/i2c/audit_sram_input_buffers.py'
(out/'auditor.py').write_bytes(script.read_bytes())
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
rows=[]
for name in ('baseline','crossed-address-loads','wrong-buffer-input'):
    directory=out/name;directory.mkdir()
    target=after
    if name!='baseline':
        db=odb.dbDatabase.create();odb.read_db(db,str(after));block=db.getChip().getBlock()
        macro=block.findInst('store.program_memory')
        a,b=macro.findITerm('A_ADDR[0]'),macro.findITerm('A_ADDR[1]')
        if name=='crossed-address-loads':
            na,nb=a.getNet(),b.getNet();a.connect(nb);b.connect(na)
        else:
            buffer0=next(t.getInst() for t in a.getNet().getITerms() if t.getInst().getName().startswith('sram_input_buffer_0'))
            buffer1=next(t.getInst() for t in b.getNet().getITerms() if t.getInst().getName().startswith('sram_input_buffer_1'))
            buffer0.findITerm('A').connect(buffer1.findITerm('A').getNet())
        target=directory/'mutated.odb';odb.write_db(db,str(target))
    command=['openroad','-no_init','-exit','-python',str(out/'auditor.py'),
             '--before',str(before),'--after',str(target),'--output',str(directory/'result.json')]
    start=time.monotonic()
    with (directory/'run.log').open('w') as log:
        proc=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    log=(directory/'run.log').read_text()
    if name=='baseline':
        assert proc.returncode==0 and 'PASS_NINE_NATIVE_BUFFERS_COLLAPSE_TO_ORIGINAL_CONNECTIVITY' in log
    else:
        expected='TARGET_NET_IDENTITY_CHANGED' if name=='crossed-address-loads' else 'BUFFER_INPUT_CHANGED'
        assert proc.returncode!=0 and 'AssertionError' in log and expected in log
    rows.append({'name':name,'returncode':proc.returncode,'seconds':round(time.monotonic()-start,3),
                 'wall_limit':60,'database_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                 'log_sha256':hashlib.sha256((directory/'run.log').read_bytes()).hexdigest()})
result={'status':'PASS_BUFFER_AUDITOR_BASELINE_AND_TWO_REAL_WIRING_FAULTS','runs':rows,
        'auditor_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(result['status'])
