import odb, json, hashlib
from pathlib import Path

root=Path('/workspace')
base=root/'build/g2-sram-full-01'
path=base/'runs/integrated/55-odb-cellfrequencytables/tt_um_khangelani_protocol_emulator.odb'
db=odb.dbDatabase.create();odb.read_db(db,str(path))
block=db.getChip().getBlock();macro=block.findInst('store.program_memory')
rows=[]
for name in [*(f'A_ADDR[{i}]' for i in range(7)),'A_WEN','A_DIN[15]']:
    pin=macro.findITerm(name);net=pin.getNet()
    drivers=[p for p in net.getITerms() if str(p.getIoType())=='OUTPUT']
    row={'pin':name,'pin_xy':pin.getAvgXY(),'net':net.getName(),'fanout':len(net.getITerms())-len(drivers),
         'drivers':[{'name':p.getInst().getName(),'master':p.getInst().getMaster().getName(),
                     'pin':p.getMTerm().getName(),'xy':p.getAvgXY()} for p in drivers]}
    rows.append(row)
result={'source_odb_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pins':rows}
(base/'pin-driver-observations.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(base/'inputs/inspect_g2_sram_pin_paths.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(result))
