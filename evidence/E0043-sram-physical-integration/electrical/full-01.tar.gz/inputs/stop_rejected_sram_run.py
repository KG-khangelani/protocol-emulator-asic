import hashlib, json, os, signal, sys
from datetime import datetime, timezone
from pathlib import Path
import psutil

name=sys.argv[1]
assert name in ('g2-sram-full-01','g2-sram-full-02')
base=Path('/workspace/build')/name
state_paths=list((base/'runs/integrated').glob('*-openroad-stapostpnr/state_out.json'))
assert len(state_paths)==1
raw=state_paths[0].read_bytes();metrics=json.loads(raw)['metrics']
assert metrics['design__max_slew_violation__count']==9
assert all(metrics['design__max_slew_violation__count__corner:'+c]>0 for c in (
    'nom_typ_1p20V_25C','nom_slow_1p08V_125C','nom_fast_1p32V_m40C'))
assert json.loads((base/'run-result.json').read_bytes())['status']=='RUNNING'
config=str(base/'src/config_merged.json')
matches=[p for p in psutil.process_iter(['pid','cmdline']) if config in (p.info['cmdline'] or [])]
assert len(matches)==1
process=matches[0]
assert os.getpgid(process.pid)==process.pid
decision={'status':'REJECTED_EXTRACTED_SLEW_STOP_REMAINING_CHECKS',
          'observed_utc':datetime.now(timezone.utc).isoformat(),
          'reason':'Nine extracted slew violations already fail the unchanged acceptance gate; stop remaining checks to prioritize the separately screened local-buffer repair.',
          'state_sha256':hashlib.sha256(raw).hexdigest(),
          'slew_violations':9,'process_group':process.pid,'command':process.cmdline(),
          'unfinished_checks':'Magic DRC still running; subsequent extraction/LVS/electrical checker stages not completed. No GDS qualification.'}
(base/'stop-decision.json').write_bytes((json.dumps(decision,indent=2)+'\n').encode())
(base/'inputs/stop_rejected_sram_run.py').write_bytes(Path(__file__).read_bytes())
os.killpg(process.pid,signal.SIGTERM)
print(decision['status'],name)
