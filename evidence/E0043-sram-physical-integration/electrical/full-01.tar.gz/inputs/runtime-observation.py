import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

name=sys.argv[1]
out=Path(__file__).resolve().parent/name
c=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
expected='sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
assert c['Image']==expected
image=json.loads(subprocess.check_output(['docker','image','inspect',expected]))[0]
result={'status':'OBSERVED_IDENTIFIED_PHYSICAL_CONTAINER','observed_utc':datetime.now(timezone.utc).isoformat(),
        'id':c['Id'],'image_id':c['Image'],'configured_image':c['Config']['Image'],
        'command':c['Config']['Cmd'],'started_at':c['State']['StartedAt'],
        'finished_at':c['State']['FinishedAt'],'state':c['State']['Status'],'exit_code':c['State']['ExitCode'],
        'repo_digests':image['RepoDigests'],
        'pdk_volume_mounts':[m for m in c['Mounts'] if m['Destination']=='/pdk']}
(out/'runtime-observation.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(out/'inputs/runtime-observation.py').write_bytes(Path(__file__).read_bytes())
print(result['status'],result['state'])
