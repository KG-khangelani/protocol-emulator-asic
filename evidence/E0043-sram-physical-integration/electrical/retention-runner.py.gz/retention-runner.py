import gzip, hashlib, io, json, tarfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
out=root/'evidence/E0043-sram-physical-integration/electrical'
out.mkdir(exist_ok=True)
assert not (out/'archives.json').exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
cases={}
for label,name in [('full-01','g2-sram-full-01'),('full-02','g2-sram-full-02'),
                   ('transition-screen','g2-sram-transition-screen-01'),('buffer-screen','g2-sram-buffer-screen-01')]:
    base=root/'build'/name
    files={};omitted={}
    for path in sorted(base.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        relative=path.relative_to(base)
        if 'tmp' in relative.parts or 'final' in relative.parts: continue
        rel=relative.as_posix()
        retain=True
        if path.suffix=='.mag': retain=False
        if path.suffix in ('.odb','.def') and label.startswith('full-'):
            retain=any('/'+s+'/' in '/'+rel for s in (
                '41-openroad-globalrouting','55-odb-cellfrequencytables','56-odb-cellfrequencytables'))
        if path.suffix=='.gds':
            retain='klayout-streamout' in rel
        if path.suffix in ('.lib','.sdf') and 'stapostpnr' not in rel:
            retain=False
        raw=path.read_bytes()
        if retain: files[rel]=raw
        else: omitted[rel]={'sha256':sha(raw),'bytes':len(raw)}
    if label=='buffer-screen':
        files['inputs/audit_sram_input_buffers.py']=(root/'experiments/i2c/audit_sram_input_buffers.py').read_bytes()
    buf=io.BytesIO()
    with tarfile.open(fileobj=buf,mode='w') as archive:
        for name,raw in sorted(files.items()):
            entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0
            archive.addfile(entry,io.BytesIO(raw))
    packed=gzip.compress(buf.getvalue(),mtime=0)
    (out/(label+'.tar.gz')).write_bytes(packed)
    cases[label]={'sha256':sha(packed),'bytes':len(packed),'files':{n:sha(v) for n,v in sorted(files.items())},
                  'omitted_bulk_views':omitted}
    print(label,len(files),len(packed))
(out/'archives.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
(out/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
