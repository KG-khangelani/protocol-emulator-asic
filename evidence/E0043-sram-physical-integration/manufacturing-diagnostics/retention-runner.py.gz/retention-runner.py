"""Retain import controls, actual pin/power failure and the native corrected-grid pilot."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/manufacturing-diagnostics'
assert not out.exists()
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
labels = {
    'macro-preflight-01': 'g2-sram-macro-drc-probe-01',
    'macro-wrong-target': 'g2-sram-macro-drc-probe-02',
    'macro-original-timeout': 'g2-sram-macro-drc-probe-03',
    'macro-vendor-timeout': 'g2-sram-macro-drc-probe-04',
    'import-pair': 'g2-sram-import-pair-01',
    'actual-pin-overlaps': 'g2-sram-pin-power-audit-01',
    'old-clearance-control': 'g2-sram-old-pdn-clearance-control-01',
    'fixed-pins': 'g2-sram-fixed-pin-pilot-01',
    'corrected-clearance': 'g2-sram-core-pdn-clearance-02',
}
for label, folder in labels.items():
    base = root / 'build' / folder
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if path.is_file() and '__pycache__' not in relative.parts and path.suffix in ('.py', '.json', '.log', '.tcl', '.rpt'):
            files[label + '/' + relative.as_posix()] = path.read_bytes()
pilot = root / 'build/g2-sram-core-pdn-pilot-01'
kept_odb = {
    'runs/integrated/22-odb-removepdnobstructions/tt_um_khangelani_protocol_emulator.odb',
    'runs/integrated/23-project-connectsrampower/tt_um_khangelani_protocol_emulator.odb',
    'runs/integrated/24-project-checksrampower/tt_um_khangelani_protocol_emulator.odb',
    'runs/fixed-pins/05-odb-applydeftemplate/tt_um_khangelani_protocol_emulator.odb',
}
for path in sorted(pilot.rglob('*')):
    relative = path.relative_to(pilot)
    if not path.is_file() or '__pycache__' in relative.parts:
        continue
    name = relative.as_posix()
    if path.suffix in ('.py', '.tcl', '.json', '.rpt', '.log') or relative.parts[0] in ('src', 'inputs') or name in kept_odb:
        files['core-grid/' + name] = path.read_bytes()
bad_state = read(root / 'build/g2-sram-full-03/runs/integrated/58-openroad-stapostpnr/state_out.json')
odb = root / Path(bad_state['odb']).relative_to('/workspace')
files['original-routed.odb'] = odb.read_bytes()
for label in ('g2-sram-full-03', 'g2-sram-full-04'):
    base = root / 'build' / label
    for name in ('deliberate-stop.json', 'preparation.json', 'run-result.json', 'runtime-observation.json', 'src/config_merged.json', 'src/sram_pdn.tcl'):
        files['stopped/' + label + '/' + name] = (base / name).read_bytes()
for name in ('probe_sram_macro_drc.py', 'probe_sram_macro_flatglob.py', 'probe_sram_import_pair.py',
             'audit_sram_top_pin_power.py', 'audit_sram_pin_clearance.py', 'run_sram_core_grid_pilot.py',
             'run_sram_fixed_pin_pilot.py', 'run_sram_vendor_import_flow.py', 'stage_sram_guarded_flow.py',
             'stop_rejected_sram_flows.py', 'g2-sram-macro-flatglob-decision.json',
             'g2-sram-vendor-import-flow-decision.json', 'g2-sram-core-grid-decision.json', 'g2-sram-guarded-flow-decision.json'):
    files['helpers/' + name] = (root / 'build' / name).read_bytes()
files['native-pin-check.py'] = (root / 'build/g2-sram-full-05/audit_sram_pin_power.py').read_bytes()
containers = sorted(set(name for name in labels.values() if name != 'g2-sram-core-pdn-clearance-02') | {'g2-sram-core-pdn-pilot-01', 'g2-sram-core-pdn-clearance-01', 'g2-sram-full-03', 'g2-sram-full-04'})
for name in containers:
    item = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert item['Image'] == 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
    assert not item['State']['Running']
    runtime = {'name': name, 'image_id': item['Image'], 'configured_image': item['Config']['Image'],
               'command': item['Config']['Cmd'], 'state': item['State'],
               'mounts': [m for m in item['Mounts'] if m['Destination'] in ('/pdk', '/workspace')]}
    files['runtime/' + name + '.json'] = (json.dumps(runtime, indent=2) + '\n').encode()
    if name == 'g2-sram-core-pdn-clearance-01':
        result = subprocess.run(['docker', 'logs', name], capture_output=True, check=True)
        files['runtime/' + name + '.log'] = result.stdout + result.stderr
out.mkdir()
with (out / 'diagnostics.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
raw = (out / 'diagnostics.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
    'files': {name: sha(raw) for name, raw in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_MANUFACTURING_DIAGNOSTICS', len(files), len(raw))
