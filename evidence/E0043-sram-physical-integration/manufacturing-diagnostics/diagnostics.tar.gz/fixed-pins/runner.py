"""Continue the successful core-grid pilot through placement of all fixed public pins."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute
base = root / 'build/g2-sram-core-pdn-pilot-01'
out = root / 'build/g2-sram-fixed-pin-pilot-01'
assert not out.exists()
out.mkdir()
initial = base / 'runs/integrated/24-project-checksrampower/state_out.json'
run = json.loads((base / 'run-result.json').read_bytes())
assert run['status'] == 'COMMAND_SUCCEEDED_REQUIRES_ARTIFACT_AUDIT'
result = {'status': 'DECLARED_BEFORE_EXECUTION', 'wall_limit': 300,
    'scope': 'Continue the unchanged native sequence from the successful grid to ApplyDEFTemplate. Fixed signal pins do not exist as geometry at the earlier power-only stop. This is a bounded integration pilot, not complete physical qualification.',
    'initial_state_sha256': hashlib.sha256(initial.read_bytes()).hexdigest()}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
command = ['librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l', '--run-tag', 'fixed-pins',
    '--design-dir', str(base), '--with-initial-state', str(initial),
    '--from', 'Odb.AddRoutingObstructions', '--to', 'Odb.ApplyDEFTemplate',
    str(base / 'src/config_merged.json')]
result['execution'] = execute(command, out / 'run.log', 300, env=dict(os.environ, PYTHONPATH=str(base)))
save()
assert result['execution']['returncode'] == 0 and not result['execution']['timed_out']
states = list((base / 'runs/fixed-pins').glob('*-odb-applydeftemplate/state_out.json'))
assert len(states) == 1
result['final_state'] = str(states[0])
result['final_state_sha256'] = hashlib.sha256(states[0].read_bytes()).hexdigest()
result['status'] = 'NATIVE_FIXED_PIN_PLACEMENT_COMPLETED_GEOMETRY_CHECK_REQUIRED'
save()
command = ['openroad', '-exit', '-python', str(root / 'build/audit_sram_pin_clearance.py'),
    '--state', str(states[0]), '--output', str(root / 'build/g2-sram-core-pdn-clearance-02')]
result['geometry_execution'] = execute(command, out / 'geometry.log', 120)
result['status'] = 'PASS_NATIVE_CORE_GRID_AND_FIXED_PUBLIC_PIN_CLEARANCE' if result['geometry_execution']['returncode'] == 0 else 'REJECTED_FIXED_PIN_GEOMETRY'
save()
print(json.dumps(result, indent=2))
assert result['geometry_execution']['returncode'] == 0
