"""Observe actual geometric overlaps between public signal pins and power shapes."""
import hashlib
import json
from pathlib import Path
import odb

root = Path('/workspace')
out = root / 'build/g2-sram-pin-power-audit-01'
assert not out.exists()
out.mkdir()
state = json.loads((root / 'build/g2-sram-full-03/runs/integrated/58-openroad-stapostpnr/state_out.json').read_bytes())
path = Path(state['odb'])
db = odb.dbDatabase.create()
odb.read_db(db, str(path))
block = db.getChip().getBlock()
rect = lambda b: (b.xMin(), b.yMin(), b.xMax(), b.yMax())
overlaps = lambda a, b: min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1])
power = {}
for name in ('VPWR', 'VGND'):
    for wire in block.findNet(name).getSWires():
        for shape in wire.getWires():
            if not shape.isVia():
                power.setdefault(shape.getTechLayer().getName(), []).append((name, rect(shape)))
hits, pins = [], []
for term in sorted(block.getBTerms(), key=lambda t: t.getName()):
    if str(term.getSigType()) in ('POWER', 'GROUND'):
        continue
    for pin in term.getBPins():
        for box in pin.getBoxes():
            layer, bounds = box.getTechLayer().getName(), rect(box)
            pins.append({'pin': term.getName(), 'layer': layer, 'rectangle_dbu': bounds})
            for net, pwr in power.get(layer, []):
                if overlaps(bounds, pwr):
                    hits.append({'pin': term.getName(), 'pin_net': term.getNet().getName(), 'layer': layer,
                                 'pin_rectangle_dbu': bounds, 'power_net': net, 'power_rectangle_dbu': pwr})
result = {'status': 'REJECTED_ACTUAL_PUBLIC_PIN_POWER_OVERLAPS' if hits else 'NO_PUBLIC_PIN_POWER_OVERLAP_OBSERVED',
          'odb': str(path), 'odb_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
          'dbu_per_micron': block.getDbUnitsPerMicron(), 'pins': pins, 'overlaps': hits,
          'scope': 'Strict positive-area same-layer overlaps from the actual routed database, independent of logical net assignments or the grid continuity checker. No clearance or other geometry claim.'}
(out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
print(result['status'], len(hits))
for hit in hits:
    print(hit)
