"""Fresh full-flow comparison adding only the pinned vendor SRAM import patterns."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace')
baseline = root / 'build/g2-sram-full-03'
out = root / 'build/g2-sram-full-04'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())
config0 = read(baseline / 'src/config_merged.json')
setup = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.tech/magic/read_sram_gds.tcl')
assert sha(setup.read_bytes()) == '5a818473a3ffad96d84e1f72331fbb94c46cc1df24a01bc9d8367ac3a7211cd7'
patterns = [line.split()[2] for line in setup.read_text().splitlines() if line.startswith('gds flatglob ')]
probe = read(root / 'build/g2-sram-import-pair-01/result.json')
assert [task['count'] for task in probe['tasks']] == [232, 0, 1]
assert all(task['execution']['returncode'] == 0 and not task['execution']['timed_out'] for task in probe['tasks'])
decision = {
    'status': 'DECLARED_BEFORE_EXECUTION', 'baseline': str(baseline),
    'wall_limit': 10800, 'flow': 'All 80 original Classic steps, the two D43 power steps and the same nine-buffer step.',
    'sole_configuration_change': {'MAGIC_GDS_FLATGLOB': patterns},
    'vendor_setup_sha256': sha(setup.read_bytes()),
    'evidence': 'Exact vendor SRAM subcell: 232 ambiguous-overlap reports become zero with the pinned vendor import patterns; an added undersized Metal2 shape still produces the M2.d violation.',
    'scope': 'Fresh full-chip trial. No DRC/LVS rule, electrical limit, clock target, footprint, RTL, macro view, acceptance checker or timeout is relaxed. Both 120-second macro-only timeouts and the original full-chip run are preserved.',
    'acceptance': 'Require all original physical checks, then official precheck and actual-netlist evidence. Subcell success alone does not qualify the macro or chip.',
}
decision_path = root / 'build/g2-sram-vendor-import-flow-decision.json'
assert not decision_path.exists()
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
subprocess.run([sys.executable, str(root / 'experiments/i2c/prepare_sram_physical.py'),
                '--candidate', str(root / 'build/g2-sram-candidate-01'),
                '--template', config0['FP_DEF_TEMPLATE'], '--output', str(out),
                '--integrated', '--input-buffers'], check=True)
config_path = out / 'src/config_merged.json'
original = config_path.read_bytes()
config = json.loads(original)
expected = json.loads(json.dumps(config0).replace(str(baseline), str(out)))
assert config == expected and 'MAGIC_GDS_FLATGLOB' not in config
(out / 'inputs/config-before-vendor-import.json').write_bytes(original)
config['MAGIC_GDS_FLATGLOB'] = patterns
config_path.write_bytes((json.dumps(config, indent=2) + '\n').encode())
preparation = read(out / 'preparation.json')
preparation['config_sha256'] = sha(config_path.read_bytes())
preparation['vendor_sram_import'] = decision
(out / 'preparation.json').write_bytes((json.dumps(preparation, indent=2) + '\n').encode())
(out / 'inputs/read_sram_gds.tcl').write_bytes(setup.read_bytes())
(out / 'inputs/vendor-import-decision.json').write_bytes(decision_path.read_bytes())
(out / 'inputs/vendor-import-runner.py').write_bytes(Path(__file__).read_bytes())
subprocess.run([sys.executable, str(root / 'experiments/i2c/run_sram_physical.py'), '--directory', str(out), '--full'], check=True)
