"""Retain explicit stops after a real public-pin/power short is established."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
audit = json.loads((root / 'build/g2-sram-pin-power-audit-01/result.json').read_bytes())
assert audit['status'] == 'REJECTED_ACTUAL_PUBLIC_PIN_POWER_OVERLAPS' and len(audit['overlaps']) == 17
for name in ('g2-sram-full-03', 'g2-sram-full-04'):
    base = root / 'build' / name
    control = base / 'deliberate-stop.json'
    assert not control.exists()
    source = (base / 'src/sram_pdn.tcl').read_bytes()
    assert source == (root / 'build/g2-sram-full-03/src/sram_pdn.tcl').read_bytes()
    state = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert state['Image'] == 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
    decision = {'status': 'DECLARED_STOP_OF_KNOWN_INVALID_POWER_GEOMETRY',
                'declared_utc': datetime.now(timezone.utc).isoformat(),
                'reason': 'The actual original routed ODB has 17 public-signal pin overlaps with power stripes. Official run43303867849 reports the corresponding LVS shorts. This trial uses the identical PDN geometry; continuing cannot qualify it. Preserve all completed stages and original incomplete run-result.',
                'pdn_script_sha256': hashlib.sha256(source).hexdigest(),
                'pin_geometry_audit_sha256': hashlib.sha256((root / 'build/g2-sram-pin-power-audit-01/result.json').read_bytes()).hexdigest(),
                'before': state['State'], 'image_id': state['Image'], 'command': state['Config']['Cmd']}
    control.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
    if state['State']['Running']:
        subprocess.run(['docker', 'stop', '--time', '5', name], check=True)
    after = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert not after['State']['Running']
    decision['after'] = after['State']
    control.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
    print(name, 'REJECTED_AND_STOPPED', after['State']['ExitCode'])
