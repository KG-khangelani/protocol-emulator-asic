"""Bounded paired SRAM subcell import diagnostic with the unmodified full DRC deck."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute
out = root / 'build/g2-sram-import-pair-01'
assert not out.exists()
out.mkdir()
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
gds = pdk / 'libs.ref/sg13cmos5l_sram/gds/RM_IHPSG13_1P_256x32_c2_bm_bist.gds'
setup = pdk / 'libs.tech/magic/read_sram_gds.tcl'
rc = pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc'
original = (root / 'build/g2-sram-macro-drc-probe-03/_env.tcl').read_text()
assert hashlib.sha256(gds.read_bytes()).hexdigest() == 'e77a4d177e02541fe6c58351008455f9a05a715b504f8e318599f3d41bf5f959'
patterns = [line.split()[2] for line in setup.read_text().splitlines() if line.startswith('gds flatglob ')]
assert len(patterns) == 7
target = 'RM_IHPSG13_1P_BITKIT_16x2_SRAM'
result = {'status': 'DECLARED_BEFORE_EXECUTION', 'wall_limit_each': 120,
          'target': target, 'patterns': patterns,
          'scope': 'Diagnostic on one genuine SRAM subcell read from the unchanged whole-macro GDS. Full chip and whole macro remain unqualified.',
          'hypothesis': 'The vendor-specified import resolves layer ambiguity while the unchanged full rule deck still finds deliberately narrow metal.',
          'inputs': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (gds, setup, rc, scripts / 'drc.tcl', scripts / 'wrapper.tcl')},
          'tasks': []}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'read_sram_gds.tcl').write_bytes(setup.read_bytes())
for label, flatten, control in [('original', False, False), ('vendor-import', True, False), ('narrow-metal-control', True, True)]:
    stage = out / label
    stage.mkdir()
    (stage / 'reports').mkdir()
    text, count = re.subn(r'^set ::env\(DESIGN_NAME\) .*$', 'set ::env(DESIGN_NAME) ' + target, original, flags=re.M)
    assert count == 1
    text += '\nset ::env(STEP_DIR) ' + str(stage) + '\n'
    if flatten:
        text += 'set ::env(MAGIC_GDS_FLATGLOB) {' + ' '.join(patterns) + '}\n'
    (stage / '_env.tcl').write_text(text)
    drc = (scripts / 'drc.tcl').read_text()
    if control:
        anchor = 'select top cell\ndrc euclidean on'
        assert drc.count(anchor) == 1
        drc = drc.replace(anchor, 'select top cell\nbox values 1000um 1000um 1000.05um 1000.05um\npaint metal2\ndrc euclidean on')
    (stage / 'drc.tcl').write_text(drc)
    env = dict(os.environ, _TCL_ENV_IN=str(stage / '_env.tcl'), _MAGIC_SCRIPT=str(stage / 'drc.tcl'))
    command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'sram-import-pair', str(stage),
               'magic', '-dnull', '-noconsole', '-rcfile', str(rc), str(scripts / 'wrapper.tcl')]
    execution = execute(command, stage / 'run.log', 120, env=env)
    report = stage / 'reports/drc.magic.rpt'
    counts = re.findall(r'\[INFO\] COUNT: (\d+)', report.read_text()) if report.exists() else []
    item = {'label': label, 'flatten': flatten, 'injected_narrow_metal': control,
            'execution': execution, 'drc_script_sha256': hashlib.sha256((stage / 'drc.tcl').read_bytes()).hexdigest(),
            'count': int(counts[-1]) if counts else None}
    result['tasks'].append(item)
    save()
result['status'] = 'DIAGNOSTIC_FINISHED_REQUIRES_REVIEW'
save()
print(json.dumps(result, indent=2))
