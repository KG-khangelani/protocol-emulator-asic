"""Compare the pinned vendor SRAM GDS import settings, without changing DRC rules."""
import hashlib
import json
from pathlib import Path
import runpy

root = Path('/workspace')
base = root / 'build/probe_sram_macro_drc.py'
original = base.read_text()
assert "out = root / 'build/g2-sram-macro-drc-probe-03'" in original
setup = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.tech/magic/read_sram_gds.tcl')
patterns = [line.split()[2] for line in setup.read_text().splitlines() if line.startswith('gds flatglob ')]
assert patterns == ['lvsres_*', '*_CELL_SUB', 'VIA_M1_*', 'VIA_M2_*', 'RSC_*', '*_CELL_CORNER', '*_BITKIT_CORNER']
decision = {
    'status': 'DECLARED_BEFORE_EXECUTION', 'wall_limit': 120,
    'hypothesis': 'The pinned vendor import flattening settings resolve ambiguous SRAM subcell layers. This may remove false overlap reports; runtime and any verdict must be measured.',
    'baseline': 'g2-sram-macro-drc-probe-03 reached 120 seconds without a verdict.',
    'sole_change': 'Set MAGIC_GDS_FLATGLOB to the seven exact patterns from the same pinned PDK read_sram_gds.tcl, consumed by the existing LibreLane drc.tcl.',
    'unchanged': 'Exact macro GDS, pinned image and PDK, full DRC style, rule deck, original checker Tcl and 120-second wall bound.',
    'acceptance': 'Diagnostic only. Full-chip DRC, LVS, official precheck and boundary integration remain required.',
    'patterns': patterns,
    'vendor_setup_sha256': hashlib.sha256(setup.read_bytes()).hexdigest(),
    'baseline_runner_sha256': hashlib.sha256(base.read_bytes()).hexdigest(),
}
decision_path = root / 'build/g2-sram-macro-flatglob-decision.json'
assert not decision_path.exists()
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
modified = original.replace("out = root / 'build/g2-sram-macro-drc-probe-03'", "out = root / 'build/g2-sram-macro-drc-probe-04'")
anchor = "(out / '_env.tcl').write_text(text)"
assert modified.count(anchor) == 1
modified = modified.replace(anchor, "text += '\\nset ::env(MAGIC_GDS_FLATGLOB) {" + ' '.join(patterns) + "}\\n'\n" + anchor)
anchor = "(out / 'reports').mkdir()"
assert modified.count(anchor) == 1
modified = modified.replace(anchor, anchor + "\n(out / 'baseline-runner.py').write_bytes(Path('/workspace/build/probe_sram_macro_drc.py').read_bytes())\n(out / 'declared-decision.json').write_bytes(Path('/workspace/build/g2-sram-macro-flatglob-decision.json').read_bytes())\n(out / 'read_sram_gds.tcl').write_bytes(Path(" + repr(str(setup)) + ").read_bytes())")
runner = root / 'build/g2-sram-macro-flatglob-runner.py'
assert not runner.exists()
runner.write_text(modified)
runpy.run_path(str(runner), run_name='__main__')
