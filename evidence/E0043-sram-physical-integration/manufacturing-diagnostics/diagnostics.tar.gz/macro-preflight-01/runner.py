"""Bound a macro-only diagnostic; leave the full-chip manufacturing run untouched."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

out = root / 'build/g2-sram-macro-drc-probe-01'
out.mkdir()
(out / 'reports').mkdir()
macro = 'RM_IHPSG13_1P_256x32_c2_bm_bist'
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
gds = pdk / 'libs.ref/sg13cmos5l_sram/gds' / (macro + '.gds')
scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
original_env = root / 'build/g2-sram-full-03/runs/integrated/65-magic-drc/_env.tcl'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(gds) == 'e77a4d177e02541fe6c58351008455f9a05a715b504f8e318599f3d41bf5f959'
text = original_env.read_text()
assert text.count('set ::env(DESIGN_NAME) ') == text.count('set ::env(CURRENT_GDS) ') == 1
text = re.sub(r'^set ::env(DESIGN_NAME) .*$', 'set ::env(DESIGN_NAME) ' + macro, text, flags=re.M)
text = re.sub(r'^set ::env(CURRENT_GDS) .*$', 'set ::env(CURRENT_GDS) ' + str(gds), text, flags=re.M)
text += '\nset ::env(STEP_DIR) ' + str(out) + '\n'
(out / '_env.tcl').write_text(text)
(out / 'original-env.tcl').write_bytes(original_env.read_bytes())
inputs = {str(p): sha(p) for p in (gds, original_env, scripts / 'drc.tcl', scripts / 'wrapper.tcl',
                                 pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc',
                                 pdk / 'libs.tech/magic/ihp-sg13cmos5l.tech')}
result = {'status': 'RUNNING_MACRO_ONLY_DIAGNOSTIC', 'inputs': inputs, 'wall_limit': 120,
          'scope': 'Unmodified vendor macro in isolation under the exact full-chip Magic DRC script/deck. Diagnose runtime/errors only; this cannot qualify full-chip layout, boundary integration or official precheck.'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
env = dict(os.environ, _TCL_ENV_IN=str(out / '_env.tcl'), _MAGIC_SCRIPT=str(scripts / 'drc.tcl'))
command = ['magic', '-dnull', '-noconsole', '-rcfile', str(pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc'), str(scripts / 'wrapper.tcl')]
result['execution'] = execute(command, out / 'run.log', 120, cwd=out, env=env)
result['status'] = 'COMMAND_COMPLETED_REQUIRES_DIAGNOSTIC_REVIEW' if result['execution']['returncode'] == 0 else 'INCOMPLETE_OR_FAILED_MACRO_DIAGNOSTIC'
report = out / 'reports/drc.magic.rpt'
if report.exists():
    matches = re.findall(r'\[INFO\] COUNT: (\d+)', report.read_text())
    if matches:
        result['reported_count'] = int(matches[-1])
save()
print(json.dumps(result, indent=2))
