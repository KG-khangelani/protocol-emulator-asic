"""Test native core-bounded stripes while preserving the fixed public pins."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace')
baseline = root / 'build/g2-sram-full-03'
out = root / 'build/g2-sram-core-pdn-pilot-01'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda path: json.loads(path.read_bytes())
config0 = read(baseline / 'src/config_merged.json')
audit = read(root / 'build/g2-sram-pin-power-audit-01/result.json')
assert audit['status'] == 'REJECTED_ACTUAL_PUBLIC_PIN_POWER_OVERLAPS' and len(audit['overlaps']) == 17
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'wall_limit': 300,
    'sole_pdn_change': 'Remove -extend_to_boundary only from standard-cell-grid Metal4 stripes; let native PDN generation bound these to the core. Keep all stripe X positions, widths, pitch, macro stripes, existing edge bridges, supply identities and fixed public pins.',
    'hypothesis': 'Native core endpoints preserve access to standard-cell rails and SRAM bridges while avoiding the public signal pins at the die boundary.',
    'acceptance': 'Both original fresh power-grid checks must pass. Independently verify no public-pin/power overlaps and full Metal4 minimum spacing before any full-route trial. All original physical gates remain required.',
    'baseline_overlaps': 17, 'physical_qualification': 'NOT_EVALUATED'}
decision_path = root / 'build/g2-sram-core-grid-decision.json'
assert not decision_path.exists()
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
subprocess.run([sys.executable, str(root / 'experiments/i2c/prepare_sram_physical.py'),
    '--candidate', str(root / 'build/g2-sram-candidate-01'), '--template', config0['FP_DEF_TEMPLATE'],
    '--output', str(out), '--integrated', '--input-buffers'], check=True)
path = out / 'src/sram_pdn.tcl'
original = path.read_bytes()
assert original == (baseline / 'src/sram_pdn.tcl').read_bytes()
(out / 'inputs/original-pdn.tcl').write_bytes(original)
lines, count = [], 0
for line in original.decode().splitlines():
    if line.startswith('add_pdn_stripe -grid stdcell_grid -layer Metal4 '):
        assert line.endswith(' -extend_to_boundary')
        line = line.removesuffix(' -extend_to_boundary')
        count += 1
    lines.append(line)
assert count > 72
path.write_bytes(('\n'.join(lines) + '\n').encode())
decision['changed_stripe_commands'] = count
decision['before_pdn_sha256'] = sha(original)
decision['after_pdn_sha256'] = sha(path.read_bytes())
preparation = read(out / 'preparation.json')
preparation['pdn_script_sha256'] = sha(path.read_bytes())
preparation['core_grid_trial'] = decision
(out / 'preparation.json').write_bytes((json.dumps(preparation, indent=2) + '\n').encode())
(out / 'inputs/core-grid-decision.json').write_bytes((json.dumps(decision, indent=2) + '\n').encode())
(out / 'inputs/core-grid-runner.py').write_bytes(Path(__file__).read_bytes())
subprocess.run([sys.executable, str(root / 'experiments/i2c/run_sram_physical.py'), '--directory', str(out)], check=True)
