import json, subprocess
from datetime import datetime, timezone
from pathlib import Path

root=Path(__file__).resolve().parents[1]
expected='sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
for name in ('g2-sram-netlist-icarus-01','g2-sram-netlist-verilator-01'):
    base=root/'build'/name
    item=json.loads(subprocess.check_output(['docker','inspect',name]))[0]
    assert item['Image']==expected and item['Config']['Image']==expected
    assert 'experiments/i2c/run_sram_netlist.py' in item['Config']['Cmd']
    image=json.loads(subprocess.check_output(['docker','image','inspect',expected]))[0]
    result={'status':'OBSERVED_IDENTIFIED_NETLIST_CONTAINER','observed_utc':datetime.now(timezone.utc).isoformat(),
            'id':item['Id'],'image_id':item['Image'],'configured_image':item['Config']['Image'],
            'command':item['Config']['Cmd'],'started_at':item['State']['StartedAt'],
            'state':item['State']['Status'],'exit_code':item['State']['ExitCode'],
            'repo_digests':image['RepoDigests'],
            'mounts':[m for m in item['Mounts'] if m['Destination'] in ('/pdk','/workspace')]}
    assert any(m['Destination']=='/pdk' and not m['RW'] for m in result['mounts'])
    (base/'runtime-observation.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
    (base/'inputs/runtime-observation.py').write_bytes(Path(__file__).read_bytes())
    print(name,result['state'],result['image_id'])
