import json
import hashlib
from pathlib import Path
import sys
ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute
out = ROOT / 'build/g2-sram-cell-model-probe-01'
out.mkdir()
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.ref/sg13cmos5l_stdcell/verilog')
models = [pdk / 'sg13cmos5l_udp.v', pdk / 'sg13cmos5l_stdcell.v']
text = r'''
`timescale 1ns/1ps
module cell_probe;
reg clk=0, d=0, reset_b=0;
wire actual_q, direct_q;
wire reset_active = !reset_b;
sg13cmos5l_dfrbpq_1 actual (.Q(actual_q), .CLK(clk), .D(d), .RESET_B(reset_b));
ihp_dff_r direct (direct_q, 1'b0, clk, d, reset_active, 1'b0);
task sample(input integer label, input integer expected);
  $display("CELL_SAMPLE %0d %0d %b %b %b %b %b", label, expected, actual_q, direct_q,
           actual.delayed_CLK, actual.delayed_D, actual.delayed_RESET_B);
endtask
initial begin
  #2; sample(0,0);
  reset_b=1; d=1; #2; clk=1; #2; sample(1,1);
  clk=0; #2; d=0; #2; sample(2,1);
  clk=1; #2; sample(3,0);
  clk=0; d=1; #2; clk=1; #2; sample(4,1);
  reset_b=0; #2; sample(5,0);
  $finish;
end
endmodule
'''
(out / 'probe.sv').write_text(text)
result = {'status': 'RUNNING', 'models': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in models}, 'runs': {}}
save = lambda: (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
save()
for simulator, command in (
    ('icarus', ['iverilog', '-g2012', '-DFUNCTIONAL', '-DSYNTHESIS', '-s', 'cell_probe', '-o', str(out / 'probe.vvp'), *map(str, models), str(out / 'probe.sv')]),
    ('verilator', ['verilator', '--binary', '--timing', '-Wno-SPECIFYIGN', '--top-module', 'cell_probe',
                   '-DFUNCTIONAL', '-DSYNTHESIS', '--Mdir', str(out / 'verilator'), '-o', 'probe', *map(str, models), str(out / 'probe.sv')]),
):
    compile_result = execute(command, out / (simulator + '-compile.log'), 120)
    result['runs'][simulator] = {'compile': compile_result}
    save()
    assert compile_result['returncode'] == 0 and not compile_result['timed_out']
    run = execute(['vvp', str(out / 'probe.vvp')] if simulator == 'icarus' else [str(out / 'verilator/probe')], out / (simulator + '.log'), 30)
    result['runs'][simulator]['run'] = run
    save()
    assert run['returncode'] == 0 and not run['timed_out']
    print(simulator, (out / (simulator + '.log')).read_text())
result['status'] = 'CELL_MODEL_PROBE_COMMANDS_COMPLETED_REQUIRES_ANALYSIS'
save()
