import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_bytes())
probe = ROOT / 'build/g2-sram-reset-alias-probe-01'
prior = ROOT / 'build/g2-sram-netlist-verilator-03'
out = ROOT / 'build/g2-sram-netlist-verilator-04'
assert not out.exists()
micro = read(probe / 'result.json')
assert micro['status'] == 'PASS_ZERO_DELAY_RESET_ALIAS_WITH_UNMODIFIED_ICARUS_REFERENCE_AND_STUCK_RESET_CONTROL'
assert [t['mismatches'] for t in micro['tasks']] == [0, 249, 0, 249]
assert micro['tasks'][0]['samples_sha256'] == micro['tasks'][2]['samples_sha256']
record = read(prior / 'result.json')
assert record['status'] == 'FAILED_OR_INCOMPLETE' and record['execution']['returncode'] == 2
assert not record['execution']['timed_out']
assert all(record['library_sha256'][name] == expected for name, expected in micro['library_sha256'].items())
text = (prior / 'netlist.v').read_text()
flops = re.findall(r'^\s*(sg13cmos5l_(?:dfr|df|dl)[a-z0-9_]+)\s+', text, re.M)
assert len(flops) == 353 and set(flops) == {'sg13cmos5l_dfrbpq_1'}
adapter = probe / 'reset-alias.sv'
assert sha(adapter) == micro['adapter_sha256']
assert sha(prior / 'netlist.v') == record['netlist_sha256']
decision = {
    'status': 'DECLARED_PINNED_ZERO_DELAY_RESET_ALIAS_FOLLOWUP',
    'netlist_sha256': record['netlist_sha256'], 'library_sha256': record['library_sha256'],
    'adapter_path': str(adapter), 'adapter_sha256': sha(adapter),
    'microprobe_sha256': sha(probe / 'result.json'), 'actual_affected_flip_flops': 353,
    'flags': ['-Wno-SPECIFYIGN', '-Wno-PINMISSING'],
    'correction': 'The preceding claim that ignored specify constructs had no functional role was false. Pinned Verilator leaves delayed_RESET_B at zero when ignoring the vendor $recrem alias, holding all actual flip-flops in reset.',
    'boundary': 'A separate SystemVerilog bind supplies only delayed_RESET_B=RESET_B for the exact vendor dfrbpq_1 model. 1025 binary observations match the unmodified Icarus cell and direct vendor UDP; a stuck-reset control yields 249 mismatches. The actual circuit netlist and all vendor models remain byte-identical. This is zero-delay functional evidence, not timing or four-state equivalence. Extracted timing/manufacturing remain separate gates.',
}
decision_path = ROOT / 'build/g2-sram-netlist-reset-alias-decision.json'
decision_path.write_text(json.dumps(decision, indent=2) + '\n')
env = dict(os.environ, COMPILE_ARGS=' '.join([*decision['flags'], str(adapter)]))
command = [sys.executable, str(ROOT / 'experiments/i2c/run_sram_netlist.py'),
           '--physical', str(ROOT / 'build/g2-sram-full-03'),
           '--candidate', str(ROOT / 'build/g2-sram-candidate-01'), '--simulator', 'verilator',
           '--pdk-root', '/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008',
           '--output', str(out)]
completed = subprocess.run(command, cwd=ROOT, env=env, timeout=10900)
assert sha(adapter) == decision['adapter_sha256']
assert all(sha(Path(p)) == digest for p, digest in record['library_sha256'].items())
assert sha(prior / 'netlist.v') == sha(out / 'netlist.v') == decision['netlist_sha256']
(out / 'reset-alias.sv').write_bytes(adapter.read_bytes())
decision['actual_returncode'] = completed.returncode
after = read(out / 'result.json')
decision['actual_status'] = after['status']
decision['status'] = 'PASS_IDENTICAL_NETLIST_WITH_EXPLICIT_ZERO_DELAY_RESET_ALIAS' if completed.returncode == 0 else 'FAILED_OR_INCOMPLETE_RESET_ALIAS_FOLLOWUP'
(out / 'reset-alias-review.json').write_text(json.dumps(decision, indent=2) + '\n')
assert completed.returncode == 0
assert after['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
assert after['library_sha256'] == record['library_sha256']
assert str(adapter) in (out / 'run.log').read_text()
assert '%Warning-' not in (out / 'run.log').read_text()
print(decision['status'])
