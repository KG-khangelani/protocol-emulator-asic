from collections import Counter
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace')
prior = ROOT / 'build/g2-sram-netlist-verilator-01'
out = ROOT / 'build/g2-sram-netlist-verilator-03'
assert not out.exists()
record = json.loads((prior / 'result.json').read_bytes())
assert record['status'] == 'FAILED_OR_INCOMPLETE'
assert record['execution']['returncode'] == 2 and not record['execution']['timed_out']
log = (prior / 'run.log').read_text()
assert Counter(re.findall(r'%Warning-([^:]+):', log)) == {'SPECIFYIGN': 84, 'PINMISSING': 28}
assert re.findall(r'^%Error: (.*)$', log, re.M) == ['Exiting due to 112 warning(s)']
lines = (prior / 'netlist.v').read_text().splitlines()
warning_ports = []
for path, lineno, port in re.findall(r"%Warning-PINMISSING: ([^:\n]+):(\d+):\d+: Instance has missing pin: '([^']+)'", log):
    assert Path(path) == prior / 'netlist.v'
    actual = lines[int(lineno) - 1]
    match = re.fullmatch(r'\s*sg13cmos5l_(inv|buf)_\d+ (clkload\d+) \(\.A\((clknet_[^)]+)\)\);', actual)
    assert match and port == ('Y' if match[1] == 'inv' else 'X')
    warning_ports.append(match[2])
assert set(warning_ports) == {'clkload' + str(i) for i in range(28)}
specify = Counter(Path(path).name for path in re.findall(r'%Warning-SPECIFYIGN: ([^:\n]+):', log))
assert specify == {'sg13cmos5l_stdcell.v': 74, 'sg13cmos5l_io.v': 10}
for path in re.findall(r'%Warning-SPECIFYIGN: ([^:\n]+):', log):
    assert path in record['library_sha256']
decision = {
    'status': 'DECLARED_WARNING_SCOPED_RETRY', 'previous_seconds': record['execution']['seconds'],
    'netlist_sha256': record['netlist_sha256'], 'library_sha256': record['library_sha256'],
    'warning_counts': {'SPECIFYIGN': 84, 'PINMISSING': 28},
    'missing_outputs': sorted(warning_ports),
    'flags': ['-Wno-SPECIFYIGN', '-Wno-PINMISSING'],
    'boundary': 'Zero-delay digital protocol test. Ignored cell-model specify constructs have no role in this functional evaluation; the 28 unloaded clock dummy outputs are verified against the identical netlist. Actual extracted timing remains a separate unsuppressed gate.',
}
(ROOT / 'build/g2-sram-netlist-verilator-followup-decision.json').write_text(json.dumps(decision, indent=2) + '\n')
env = dict(os.environ, COMPILE_ARGS=' '.join(decision['flags']))
command = [sys.executable, str(ROOT / 'experiments/i2c/run_sram_netlist.py'),
           '--physical', str(ROOT / 'build/g2-sram-full-03'),
           '--candidate', str(ROOT / 'build/g2-sram-candidate-01'), '--simulator', 'verilator',
           '--pdk-root', '/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008',
           '--output', str(out)]
completed = subprocess.run(command, cwd=ROOT, env=env, timeout=10900)
assert completed.returncode == 0
after = json.loads((out / 'result.json').read_bytes())
assert after['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
assert after['netlist_sha256'] == decision['netlist_sha256']
assert after['library_sha256'] == decision['library_sha256']
assert '%Warning-' not in (out / 'run.log').read_text()
decision['status'] = 'PASS_IDENTICAL_NETLIST_WITH_TWO_EXPLICIT_WARNING_CATEGORIES'
(out / 'warning-review.json').write_text(json.dumps(decision, indent=2) + '\n')
print(decision['status'])
