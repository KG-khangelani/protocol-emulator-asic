import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute

out = ROOT / 'build/g2-sram-reset-alias-probe-01'
out.mkdir()
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.ref/sg13cmos5l_stdcell/verilog')
models = [pdk / 'sg13cmos5l_udp.v', pdk / 'sg13cmos5l_stdcell.v']
adapter = '''// Simulation-only zero-delay alias for the pinned cell's $recrem output.
// No cell implementation, circuit netlist, clock, data or timing limit changes.
module sram_dfrbpq_reset_alias(input wire reset_b, output wire delayed_reset_b);
  assign delayed_reset_b = reset_b;
endmodule
bind sg13cmos5l_dfrbpq_1 sram_dfrbpq_reset_alias reset_alias
  (.reset_b(RESET_B), .delayed_reset_b(delayed_RESET_B));
'''
(out / 'reset-alias.sv').write_text(adapter)
(out / 'wrong-reset-alias.sv').write_text(adapter.replace('= reset_b;', "= 1'b0;"))
bench = r'''
`timescale 1ns/1ps
module cell_probe;
reg clk=0, d=0, reset_b=0;
reg [15:0] stream=16'h2713;
reg expected=0;
wire actual_q, direct_q;
integer count=0, errors=0;
wire reset_active = !reset_b;
sg13cmos5l_dfrbpq_1 actual (.Q(actual_q), .CLK(clk), .D(d), .RESET_B(reset_b));
ihp_dff_r direct (direct_q, 1'b0, clk, d, reset_active, 1'b0);
task sample;
  $display("CELL_SAMPLE %0d %b %b %b %b %b %b %b %b %b", count, expected,
    actual_q, direct_q, clk, d, reset_b, actual.delayed_CLK, actual.delayed_D, actual.delayed_RESET_B);
  if (actual_q !== expected || direct_q !== expected) errors=errors+1;
  count=count+1;
endtask
initial begin
  #2; sample;
  for (integer i=0; i<256; i=i+1) begin
    stream={stream[14:0], stream[15]^stream[13]^stream[12]^stream[10]};
    clk=0; #1;
    reset_b=stream[0]; d=stream[1]; if (!reset_b) expected=0;
    #1; sample;
    clk=1; expected=reset_b ? d : 0;
    #1; sample;
    d=stream[2]; #1; sample;
    reset_b=stream[3]; if (!reset_b) expected=0;
    #1; sample;
  end
  $display("CELL_RESULT %0d %0d", count, errors);
  $finish;
end
endmodule
'''
(out / 'probe.sv').write_text(bench)
result = {'status': 'RUNNING', 'library_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in models},
          'adapter_sha256': hashlib.sha256(adapter.encode()).hexdigest(), 'tasks': []}
save = lambda: (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
save()
for name, simulator, fix, expected_errors in (
    ('original-icarus', 'icarus', None, False),
    ('original-verilator', 'verilator', None, True),
    ('reset-alias-verilator', 'verilator', 'reset-alias.sv', False),
    ('wrong-reset-alias-verilator', 'verilator', 'wrong-reset-alias.sv', True),
):
    base = out / name
    base.mkdir()
    sources = [*map(str, models), str(out / 'probe.sv'), *([str(out / fix)] if fix else [])]
    if simulator == 'icarus':
        command = ['iverilog', '-g2012', '-DFUNCTIONAL', '-DSYNTHESIS', '-s', 'cell_probe', '-o', str(base / 'probe.vvp'), *sources]
    else:
        command = ['verilator', '--binary', '--timing', '-Wno-SPECIFYIGN', '--top-module', 'cell_probe',
                   '-DFUNCTIONAL', '-DSYNTHESIS', '--Mdir', str(base / 'sim'), '-o', 'probe', *sources]
    task = {'name': name, 'expected_failure': expected_errors, 'compile': execute(command, base / 'compile.log', 120)}
    result['tasks'].append(task)
    save()
    assert task['compile']['returncode'] == 0 and not task['compile']['timed_out']
    task['run'] = execute(['vvp', str(base / 'probe.vvp')] if simulator == 'icarus' else [str(base / 'sim/probe')], base / 'run.log', 30)
    save()
    assert task['run']['returncode'] == 0 and not task['run']['timed_out']
    log = (base / 'run.log').read_text()
    counts = re.findall(r'^CELL_RESULT (\d+) (\d+)$', log, re.M)
    assert len(counts) == 1 and int(counts[0][0]) == 1025
    task['observations'], task['mismatches'] = map(int, counts[0])
    assert bool(task['mismatches']) == expected_errors
    samples = re.findall(r'^CELL_SAMPLE (.*)$', log, re.M)
    assert len(samples) == 1025
    fields = [line.split() for line in samples]
    assert all(row[1] == row[3] for row in fields), 'direct UDP does not match reference'
    task['samples_sha256'] = hashlib.sha256(('\n'.join(samples) + '\n').encode()).hexdigest()
    if name == 'original-icarus':
        reference = samples
    if name == 'reset-alias-verilator':
        assert reference == samples, 'adapted cell differs from unmodified Icarus cell'
    if expected_errors:
        assert all(row[2] == '0' and row[9] == '0' for row in fields)
    task['accepted'] = True
    save()
assert {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in models} == result['library_sha256']
result['status'] = 'PASS_ZERO_DELAY_RESET_ALIAS_WITH_UNMODIFIED_ICARUS_REFERENCE_AND_STUCK_RESET_CONTROL'
save()
print(result['status'])
