
`timescale 1ns/1ps
module cell_probe;
reg clk=0, d=0, reset_b=0;
wire actual_q, direct_q;
wire reset_active = !reset_b;
sg13cmos5l_dfrbpq_1 actual (.Q(actual_q), .CLK(clk), .D(d), .RESET_B(reset_b));
ihp_dff_r direct (direct_q, 1'b0, clk, d, reset_active, 1'b0);
task sample(input integer label, input integer expected);
  $display("CELL_SAMPLE %0d %0d %b %b %b %b %b", label, expected, actual_q, direct_q,
           actual.delayed_CLK, actual.delayed_D, actual.delayed_RESET_B);
endtask
initial begin
  #2; sample(0,0);
  reset_b=1; d=1; #2; clk=1; #2; sample(1,1);
  clk=0; #2; d=0; #2; sample(2,1);
  clk=1; #2; sample(3,0);
  clk=0; d=1; #2; clk=1; #2; sample(4,1);
  reset_b=0; #2; sample(5,0);
  $finish;
end
endmodule
