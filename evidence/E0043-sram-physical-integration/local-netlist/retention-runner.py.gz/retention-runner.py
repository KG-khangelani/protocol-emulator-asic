"""Retain completed local actual-netlist results and the model compatibility diagnosis."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
out = ROOT / 'evidence/E0043-sram-physical-integration/local-netlist'
assert not out.exists()
image_id = 'sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
locations = [
    ('icarus', 'g2-sram-netlist-icarus-01'),
    ('verilator-warning-failure', 'g2-sram-netlist-verilator-01'),
    ('verilator-reset-failure', 'g2-sram-netlist-verilator-03'),
    ('verilator', 'g2-sram-netlist-verilator-05'),
    ('cell-probe', 'g2-sram-cell-model-probe-01'),
    ('reset-probe', 'g2-sram-reset-alias-probe-01'),
]
for label in ('icarus', 'verilator'):
    folder = dict(locations)[label]
    assert read(ROOT / 'build' / folder / 'result.json')['status'] == 'PASS_SRAM_ACTUAL_NETLIST_PUBLIC_SELECTION'
files = {}
for label, folder in locations:
    base = ROOT / 'build' / folder
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if not path.is_file() or any(part in ('sim', '__pycache__') for part in relative.parts):
            continue
        if label == 'cell-probe' and relative.parts[0] == 'verilator':
            continue
        if path.suffix in ('.vvp', '.o', '.a', '.so', '.d'):
            continue
        files[label + '/' + relative.as_posix()] = path.read_bytes()
    item = json.loads(subprocess.check_output(['docker', 'inspect', folder]))[0]
    assert item['Image'] == item['Config']['Image'] == image_id and item['State']['Status'] == 'exited'
    runtime = {'name': folder, 'id': item['Id'], 'image_id': item['Image'], 'configured_image': item['Config']['Image'],
               'command': item['Config']['Cmd'], 'state': item['State'],
               'mounts': [m for m in item['Mounts'] if m['Destination'] in ('/pdk', '/workspace')]}
    assert any(m['Destination'] == '/pdk' and not m['RW'] for m in runtime['mounts'])
    files[label + '/completed-runtime.json'] = (json.dumps(runtime, indent=2) + '\n').encode()
for name in ('probe_sram_netlist_cell_models.py', 'probe_sram_reset_alias.py',
             'run_sram_netlist_verilator_followup.py', 'run_sram_netlist_reset_alias.py',
             'g2-sram-netlist-verilator-followup-preflight-01.py',
             'g2-sram-netlist-reset-alias-preflight-01.py',
             'g2-sram-netlist-verilator-followup-decision.json', 'g2-sram-netlist-reset-alias-decision.json'):
    files['helpers/' + name] = (ROOT / 'build' / name).read_bytes()
for folder in ('g2-sram-netlist-verilator-02', 'g2-sram-netlist-verilator-04'):
    item = json.loads(subprocess.check_output(['docker', 'inspect', folder]))[0]
    assert item['Image'] == image_id and item['State']['Status'] == 'exited' and item['State']['ExitCode'] != 0
    files['preflight/' + folder + '.json'] = (json.dumps({
        'image_id': item['Image'], 'command': item['Config']['Cmd'], 'state': item['State'],
    }, indent=2) + '\n').encode()
    log = subprocess.run(['docker', 'logs', folder], capture_output=True, check=True)
    files['preflight/' + folder + '.log'] = log.stdout + log.stderr
physical = ROOT / 'build/g2-sram-full-03'
for name in ('preparation.json', 'runtime-observation.json', 'deliberate-stop.json'):
    files['physical/' + name] = (physical / name).read_bytes()
stop = read(physical / 'deliberate-stop.json')
assert stop['status'] == 'DECLARED_STOP_OF_KNOWN_INVALID_POWER_GEOMETRY'
files['physical/pin-geometry-audit.json'] = (ROOT / 'build/g2-sram-pin-power-audit-01/result.json').read_bytes()
assert sha(files['physical/pin-geometry-audit.json']) == stop['pin_geometry_audit_sha256']
files['physical/scope.json'] = (json.dumps({
    'physical_trial': 'g2-sram-full-03', 'physical_status': 'REJECTED_PUBLIC_PIN_POWER_SHORTS',
    'known_public_pin_power_overlaps': 17,
    'functional_scope': 'The same unchanged routed netlist in both simulators; the rejected layout does not qualify for manufacture.',
    'corrected_trial': 'g2-sram-full-05',
    'corrected_trial_netlist': 'NOT_QUALIFIED_BY_THIS_ARCHIVE; test the actual submitted netlist separately.',
}, indent=2) + '\n').encode()
files['physical/post-pnr-state.json'] = (physical / 'runs/integrated/58-openroad-stapostpnr/state_out.json').read_bytes()
files['physical/resolved.json'] = (physical / 'runs/integrated/resolved.json').read_bytes()
files['candidate.json'] = (ROOT / 'evidence/E0042-sram-prefetch-screen/candidate.json').read_bytes()
for path in (ROOT / 'build/g2-sram-candidate-01/src').glob('*.v'):
    files['source/' + path.name] = path.read_bytes()
for name in (
    'architecture/combined/icarus/records/cases.jsonl.gz',
    'od128/protocols/icarus/records/cases.jsonl.gz',
    'architecture/boundaries/od128-icarus/records/boundaries.jsonl.gz',
    'architecture/aborts/od128-icarus/records/aborts.jsonl.gz',
):
    files['references/ci/' + name] = (ROOT / 'evidence/E0036-g2-store-and-ci/ci' / name).read_bytes()
out.mkdir(parents=True)
with (out / 'netlist.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
packed = (out / 'netlist.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({
    'sha256': sha(packed), 'bytes': len(packed), 'files': {n: sha(v) for n, v in sorted(files.items())},
}, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_COMPLETED_ACTUAL_NETLIST_PAIR', len(files), len(packed))
