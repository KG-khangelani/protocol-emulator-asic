import gzip, hashlib, io, json, tarfile
from pathlib import Path

root=Path(__file__).resolve().parents[1]
base=root/'build/g2-sram-integrated-pdn-01'
out=root/'evidence/E0043-sram-physical-integration/integrated'
out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for path in sorted(base.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or 'tmp' in path.relative_to(base).parts:
        continue
    name=path.relative_to(base).as_posix()
    if '/final/' in '/'+name: continue
    if path.suffix in ('.odb','.def') and not any('/'+stage+'/' in '/'+name for stage in (
        '21-openroad-generatepdn','22-odb-removepdnobstructions','23-project-connectsrampower','24-project-checksrampower')):
        continue
    files['pilot/'+name]=path.read_bytes()
files['pilot/inputs/audit_sram_power_pilot.py']=(root/'experiments/i2c/audit_sram_power_pilot.py').read_bytes()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as archive:
    for name,raw in files.items():
        entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0
        archive.addfile(entry,io.BytesIO(raw))
raw=gzip.compress(buf.getvalue(),mtime=0)
(out/'pilot.tar.gz').write_bytes(raw)
index={'sha256':sha(raw),'bytes':len(raw),'files':{n:sha(v) for n,v in files.items()}}
(out/'archive.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
(out/'verification.json').write_bytes((base/'verification.json').read_bytes())
(out/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('RETAINED_INTEGRATED_POWER_PILOT',len(files),len(raw))
