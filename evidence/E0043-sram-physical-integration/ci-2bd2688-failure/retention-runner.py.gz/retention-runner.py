"""Retain the original failed physical archives and source-bound replay inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import zipfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-physical-ci-failure-01'
out = root / 'evidence/E0043-sram-physical-integration/ci-2bd2688-failure'
assert not out.exists()
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = read(base / 'verification.json')
assert report['status'] == 'PASS_AUDIT_OF_REJECTED_SRAM_PHYSICAL_RUN' and report['physical_qualification'] == 'REJECTED'
out.mkdir()
for name in ('13986867590.zip', '13985889229.zip', 'run.json', 'jobs.json', 'artifacts.json', 'verification.json', 'zip-files.json'):
    (out / name).write_bytes((base / name).read_bytes())
for name in ('gds-job.log', 'audit-attempt-01.py', 'audit-attempt-02.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress((base / name).read_bytes(), mtime=0))
with zipfile.ZipFile(base / '13986867590.zip') as archive:
    inputs = json.loads(archive.read('build/sram-physical/inputs.json'))
names = set(inputs['provenance_sha256']) | {
    'evidence/E0042-sram-prefetch-screen/candidate.json',
    'evidence/E0042-sram-prefetch-screen/mapped/archive.json',
    'tools/workbench/toolchain.lock.json', 'tools/physical_candidate.py',
    'tools/audit_g2_physical.py', 'tools/physical_runtime.py',
}
files = {}
for name in sorted(names):
    files[name] = subprocess.check_output(['git', 'show', report['source_commit'] + ':' + name], cwd=root)
    if name in inputs['provenance_sha256']:
        assert sha(files[name]) == inputs['provenance_sha256'][name]
mapped_index = json.loads(files['evidence/E0042-sram-prefetch-screen/mapped/archive.json'])
mapped_path = root / 'evidence/E0042-sram-prefetch-screen/mapped/mapping.tar.gz'
assert sha(mapped_path.read_bytes()) == mapped_index['sha256']
with tarfile.open(mapped_path) as archive:
    mapped = archive.extractfile('result.json').read()
assert sha(mapped) == mapped_index['files']['result.json']
(out / 'mapped-input-observation.json').write_bytes(mapped)
with (out / 'inputs.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
packed = (out / 'inputs.tar.gz').read_bytes()
(out / 'inputs.json').write_bytes((json.dumps({'sha256': sha(packed), 'bytes': len(packed),
    'files': {name: sha(raw) for name, raw in sorted(files.items())}}, indent=2) + '\n').encode())
audit = (root / 'build/audit_sram_physical_failure.py').read_text()
old = "ROOT = Path(__file__).resolve().parents[1]\nsys.path.insert(0, str(ROOT))\nfrom tools import physical_candidate as common, physical_sram\nfrom tools.audit_g2_physical import Archive, frozen\nfrom tools.physical_runtime import inspect_runtime\n\nbase = ROOT / 'build/g2-sram-physical-ci-failure-01'"
assert old in audit
audit = audit.replace(old, "ROOT = Path(__file__).resolve().parents[3]\nbase = Path(sys.argv[1]).resolve()\nsys.path.insert(0, str(Path(__file__).resolve().parent))\nfrom replay_support import common, physical_sram, Archive, frozen, inspect_runtime")
(out / 'audit.py').write_bytes(audit.encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_REJECTED_OFFICIAL_RUN', sum(report['artifact_files'].values()), len(files))
