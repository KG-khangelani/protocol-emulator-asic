"""Stage the validated core endpoints, vendor import and a mandatory public-pin guard."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/workspace')
baseline = root / 'build/g2-sram-full-03'
pilot = root / 'build/g2-sram-core-pdn-pilot-01'
out = root / 'build/g2-sram-full-05'
assert not out.exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
assert read(root / 'build/g2-sram-fixed-pin-pilot-01/result.json')['status'] == 'PASS_NATIVE_CORE_GRID_AND_FIXED_PUBLIC_PIN_CLEARANCE'
clearance = read(root / 'build/g2-sram-core-pdn-clearance-02/result.json')
assert clearance['status'] == 'PASS_PUBLIC_PIN_POWER_GEOMETRY' and len(clearance['pins']) == 43
original = read(root / 'build/g2-sram-old-pdn-clearance-control-01/result.json')
assert len(original['violations']) == 24 and sum(v['overlap'] for v in original['violations']) == 17
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'wall_limit': 10800,
    'changes': ['Use the successful native core-bounded standard-cell grid; preserve macro stripes, 144 edge bridges and fixed pins.',
                'Use the seven unchanged pinned vendor SRAM GDS import patterns.',
                'Add a mandatory read-only public-pin/power geometry checker immediately after applying the fixed DEF template.'],
    'prior_evidence': {'bad_geometry': '24 Metal4 clearance violations, including 17 overlaps, rejected.',
                       'corrected_pilot': 'Both power grids pass; all 43 fixed public pin rectangles pass overlap and Metal4 clearance checks.',
                       'vendor_import': '232 ambiguous subcell reports become zero; injected undersized metal remains detected.'},
    'unchanged': 'All 80 original Classic stages in order, the existing three project stages, 8x4, 50MHz, exact RTL/macro views, nine buffers, setup/hold/slew/cap/fanout limits, DRC, LVS and precheck requirements.',
    'physical_qualification': 'NOT_EVALUATED'}
decision_path = root / 'build/g2-sram-guarded-flow-decision.json'
assert not decision_path.exists()
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
subprocess.run([sys.executable, str(root / 'experiments/i2c/prepare_sram_physical.py'),
    '--candidate', str(root / 'build/g2-sram-candidate-01'), '--template', read(baseline / 'src/config_merged.json')['FP_DEF_TEMPLATE'],
    '--output', str(out), '--integrated', '--input-buffers'], check=True)
(out / 'inputs/original-pdn.tcl').write_bytes((out / 'src/sram_pdn.tcl').read_bytes())
(out / 'src/sram_pdn.tcl').write_bytes((pilot / 'src/sram_pdn.tcl').read_bytes())
guard = (root / 'build/audit_sram_pin_clearance.py').read_text()
guard = guard.replace("parser.add_argument('--state', type=Path, required=True)", "parser.add_argument('--odb', type=Path, required=True)")
guard = guard.replace("path = Path(json.loads(args.state.read_bytes())['odb'])", "path = args.odb.resolve()")
guard = guard.replace(", 'state_sha256': hashlib.sha256(args.state.read_bytes()).hexdigest()", '')
assert 'args.state' not in guard
(out / 'audit_sram_pin_power.py').write_bytes(guard.encode())
plugin = out / 'librelane_plugin_sram.py'
addition = '''

@Step.factory.register()
class CheckPublicPinPower(Step):
    id = 'Project.CheckPublicPinPower'
    name = 'Check public pins against power geometry'
    long_name = 'Reject public signal pin shorts and insufficient Metal4 clearance'
    inputs = [DesignFormat.ODB]
    outputs = []

    def run(self, state_in, **kwargs):
        self.run_subprocess([
            'openroad', '-no_init', '-exit', '-python', str(HERE / 'audit_sram_pin_power.py'),
            '--odb', str(state_in[DesignFormat.ODB]), '--output', str(Path(self.step_dir) / 'pin-power-audit'),
        ], log_to=Path(self.step_dir) / 'pin-power-audit.log')
        return {}, {'design__public_pin_power__violations': 0}


@Flow.factory.register()
class SramGuardedClassic(SramBufferedClassic):
    Substitutions = [('+Odb.ApplyDEFTemplate', CheckPublicPinPower)]


assert len(SramGuardedClassic.Steps) == 84
assert [s for s in SramGuardedClassic.Steps if not s.id.startswith('Project.')] == Classic.Steps
'''
plugin.write_bytes(plugin.read_bytes() + addition.encode())
config_path = out / 'src/config_merged.json'
config = read(config_path)
config['meta']['flow'] = 'SramGuardedClassic'
setup = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.tech/magic/read_sram_gds.tcl')
assert sha(setup.read_bytes()) == '5a818473a3ffad96d84e1f72331fbb94c46cc1df24a01bc9d8367ac3a7211cd7'
config['MAGIC_GDS_FLATGLOB'] = [line.split()[2] for line in setup.read_text().splitlines() if line.startswith('gds flatglob ')]
config_path.write_bytes((json.dumps(config, indent=2) + '\n').encode())
preparation = read(out / 'preparation.json')
preparation.update(config_sha256=sha(config_path.read_bytes()), pdn_script_sha256=sha((out / 'src/sram_pdn.tcl').read_bytes()), guarded_flow=decision)
for name in ('librelane_plugin_sram.py', 'audit_sram_pin_power.py'):
    preparation['plugin_sha256'][name] = sha((out / name).read_bytes())
(out / 'preparation.json').write_bytes((json.dumps(preparation, indent=2) + '\n').encode())
(out / 'inputs/read_sram_gds.tcl').write_bytes(setup.read_bytes())
(out / 'inputs/guarded-flow-runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'inputs/guarded-flow-decision.json').write_bytes(decision_path.read_bytes())
print('PREPARED_GUARDED_FULL_FLOW_WITH_UNCHANGED_ORIGINAL_GATES')
subprocess.run([sys.executable, str(root / 'experiments/i2c/run_sram_physical.py'), '--directory', str(out), '--full'], check=True)
