"""Keep the completed native guarded flow's reports and unchanged failure."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tools import physical_candidate as common
base = root / 'build/g2-sram-full-05'
out = root / 'evidence/E0043-sram-physical-integration/guarded-completion'
assert not out.exists()
read = lambda path: json.loads(path.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = base / 'runs/integrated'
receipt = read(base / 'run-result.json')
assert receipt['status'] == 'FAILED_OR_INCOMPLETE' and not receipt['execution']['timed_out']
assert receipt['execution']['returncode'] == 2 and receipt['execution']['wall_limit'] == 10800
assert receipt['execution']['seconds'] == 9381.393
review = common.inspect_physical_metrics(read(run / 'final/metrics.json'))
official = read(root / 'evidence/E0043-sram-physical-integration/ci-2be7f5d-failure/verification.json')
assert review == official['physical_metrics']
drc = (run / '66-magic-drc/reports/drc.magic.rpt').read_bytes()
assert sha(drc) == official['drc_report_sha256']
assert 'Final result: Circuits match uniquely.' in (run / '70-netgen-lvs/reports/lvs.netgen.rpt').read_text()
resolved = read(run / 'resolved.json')
assert resolved['meta']['flow'] == 'SramGuardedClassic'
assert resolved['MAGICRC'].startswith('/pdk/')
assert 'sram-magic-aligned' not in (run / '66-magic-drc/COMMANDS').read_text()
files, omitted = {}, {}
large_views = {'.odb', '.gds', '.mag', '.sdf', '.spef', '.lib', '.png', '.csv', '.html'}
for path in base.rglob('*'):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    name, raw = path.relative_to(base).as_posix(), path.read_bytes()
    if path.suffix in large_views:
        omitted[name] = {'sha256': sha(raw), 'bytes': len(raw)}
    else:
        files[name] = raw
files['review-inputs/physical_candidate.py'] = (root / 'tools/physical_candidate.py').read_bytes()
files['review-inputs/official-verification.json'] = (root / 'evidence/E0043-sram-physical-integration/ci-2be7f5d-failure/verification.json').read_bytes()
files['retention-runner.py'] = Path(__file__).read_bytes()
summary = {'status': 'COMPLETED_REJECTED_GUARDED_FLOW', 'physical_qualification': 'REJECTED',
    'execution': receipt['execution'], 'final_physical_metrics': review,
    'original_report_identical_to_official': True, 'official_run_id': official['run_id'],
    'drc_report_sha256': sha(drc), 'netlist_sha256': sha((run / 'final/nl/tt_um_khangelani_protocol_emulator.nl.v').read_bytes()),
    'lvs': 'CIRCUITS_MATCH_UNIQUELY', 'all_84_stages_reached': 'SramGuardedClassic - Stage 84 - Report Manufacturability' in (base / 'run.log').read_text(encoding='utf-8'),
    'retention_scope': 'Complete native text reports/configurations/states/inputs. Large generated views are indexed by digest; the exact checked GDS is retained in ci-2be7f5d-failure/geometry-inputs.tar.gz and routed database/netlist in guarded-lvs/diagnostic.tar.gz.',
    'production': 'NOT_PROMOTED'}
assert summary['all_84_stages_reached'] and summary['netlist_sha256'] == official['netlist_sha256']
files['completion-review.json'] = (json.dumps(summary, indent=2) + '\n').encode()
out.mkdir()
with (out / 'reports.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
raw = (out / 'reports.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
    'files': {n: sha(r) for n, r in sorted(files.items())}, 'omitted_generated_views': omitted}, indent=2) + '\n').encode())
(out / 'completion-review.json').write_bytes(files['completion-review.json'])
print('RETAINED_COMPLETED_NATIVE_REJECTION', len(files), len(omitted), len(raw))
