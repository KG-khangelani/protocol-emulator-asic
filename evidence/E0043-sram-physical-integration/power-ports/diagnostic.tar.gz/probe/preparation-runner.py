"""Freeze original submitted views and the pinned port checker for a bounded probe."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-ci-232ee20'
out = root / 'build/g2-sram-power-port-probe-01'
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
top = 'tt_um_khangelani_protocol_emulator'
files = {}
for archive, expected in [('14000880025.zip', '600d201c57c2719a97254c5a85e13ad0705d496b10c1e131d72fd8e5acadabc0'),
        ('14000422018.zip', 'a3e5ff3b6e23c4e44a4b6c676cca47749b0b53f12d47d61df0ec1ce339703c34')]:
    assert sha((base / archive).read_bytes()) == expected
    with zipfile.ZipFile(base / archive) as z:
        names = ['runs/wokwi/57-odb-cellfrequencytables/' + top + '.odb',
                 'runs/wokwi/57-odb-cellfrequencytables/' + top + '.def', 'runs/wokwi/resolved.json'] if archive.startswith('140008') else [
                     'tt_submission/' + top + extension for extension in ('.gds', '.lef', '.v')]
        for name in names:
            raw = z.read(name)
            target = out / 'original' / Path(name).name
            target.parent.mkdir(exist_ok=True)
            target.write_bytes(raw)
            files[name] = {'archive': archive, 'sha256': sha(raw), 'saved_as': target.relative_to(out).as_posix()}
template = root / 'build/g1-upstream/support/tt_block_8x4_pgvdd.def'
assert sha(template.read_bytes()) == '64b52f2150f699edc7fb500c2f486a51eca66fd91d3efb7347200bd2cf83a2ee'
shutil.copyfile(template, out / 'template.def')
record = {'status': 'DECLARED_POWER_PORT_METADATA_PROBE', 'source_commit': '232ee20e1eb35726f785225ecfc1a2641e10af33',
          'run_id': 43337581691, 'files': files, 'native_wall_limit_seconds': 600, 'pin_check_wall_limit_seconds': 120,
          'scope': 'Select existing full-height power ports in a copied routed database; preserve all conductors, devices, signal pins and netlist. Run the unchanged pinned pin checker. Complete renewed official qualification remains required.'}
(out / 'declaration.json').write_bytes((json.dumps(record, indent=2) + '\n').encode())
(out / 'preparation-runner.py').write_bytes(Path(__file__).read_bytes())
print(record['status'])
