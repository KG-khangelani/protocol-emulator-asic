"""Bound native port selection and unmodified Magic LEF generation."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

base = root / 'build/g2-sram-power-port-probe-01'
source = root / 'build/g2-sram-full-05'
out = base / 'native-01'
assert not out.exists()
out.mkdir()
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
top = 'tt_um_khangelani_protocol_emulator'
inputs = {str(p.relative_to(base)): sha(p) for p in (base / 'original').iterdir()}
result = {'status': 'DECLARED_BEFORE_EXECUTION', 'declared_utc': datetime.now(timezone.utc).isoformat(),
          'native_wall_limit_seconds': 600, 'input_sha256': inputs, 'stages': []}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'selector.py').write_bytes((root / 'build/select_sram_power_ports.py').read_bytes())
command = ['openroad', '-no_init', '-exit', '-python', str(out / 'selector.py'), '--odb',
           str(base / 'original' / (top + '.odb')), '--output', str(out / 'selection')]
r = execute(command, out / 'selection.log', 120)
result['stages'].append({'name': 'select-existing-power-ports', **r})
save()
assert r['returncode'] == 0 and not r['timed_out']
state = read(source / 'runs/integrated/64-magic-writelef/state_in.json')
state['odb'] = str(out / 'selection/selected.odb')
state['def'] = str(out / 'selection/after.def')
state['gds'] = str(base / 'original' / (top + '.gds'))
(out / 'initial-state.json').write_bytes((json.dumps(state, indent=2) + '\n').encode())
command = ['librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l', '--run-tag', 'power-port-lef',
           '--force-run-dir', str(out / 'lef'), '--design-dir', str(source),
           '--with-initial-state', str(out / 'initial-state.json'), '--from', 'Magic.WriteLEF',
           '--to', 'Magic.WriteLEF', str(source / 'src/config_merged.json')]
r = execute(command, out / 'lef.log', 600, env=dict(os.environ, PYTHONPATH=str(source)))
result['stages'].append({'name': 'original-magic-lef', **r})
save()
assert r['returncode'] == 0 and not r['timed_out']
command = ['openroad', '-no_init', '-exit', '-python', str(root / 'experiments/i2c/audit_sram_pin_power.py'),
           '--odb', str(out / 'selection/selected.odb'), '--output', str(out / 'signal-pin-audit')]
r = execute(command, out / 'signal-pin-audit.log', 120)
result['stages'].append({'name': 'unchanged-public-pin-clearance', **r})
save()
assert r['returncode'] == 0 and not r['timed_out']
command = ['librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l', '--run-tag', 'power-port-grid',
           '--force-run-dir', str(out / 'grid'), '--design-dir', str(source),
           '--with-initial-state', str(out / 'initial-state.json'), '--from', 'Project.CheckSramPower',
           '--to', 'Project.CheckSramPower', str(source / 'src/config_merged.json')]
r = execute(command, out / 'grid.log', 120, env=dict(os.environ, PYTHONPATH=str(source)))
result['stages'].append({'name': 'fresh-both-power-grid-checks', **r})
save()
assert r['returncode'] == 0 and not r['timed_out']
assert inputs == {name: sha(base / name) for name in inputs}
result.update(status='PASS_NATIVE_POWER_PORT_SELECTION_AND_GRID_PIN_DIAGNOSTICS',
              selection=read(out / 'selection/selection.json'), physical_qualification='OPEN')
save()
print(result['status'])
