"""Reject physically malformed supply-port inputs before changing the database."""
import hashlib
import json
from pathlib import Path
import sys
import odb

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/i2c'))
from select_sram_power_ports import select_ports, rectangle

base = root / 'build/g2-sram-power-port-probe-01'
out = base / 'native-controls'
assert not out.exists()
out.mkdir()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'selector.py').write_bytes((root / 'experiments/i2c/select_sram_power_ports.py').read_bytes())
rows = []
for label, expected in [('narrow', 'undersized supply port'), ('wrong-layer', 'wrong supply port layer'),
                        ('missing-conductor', 'supply port lacks its real conductor'),
                        ('missing-external-straps', 'expected 27 full-height straps')]:
    db = odb.dbDatabase.create()
    odb.read_db(db, str(base / 'original/tt_um_khangelani_protocol_emulator.odb'))
    block = db.getChip().getBlock()
    pin = list(block.findBTerm('VPWR').getBPins())[0]
    boxes = [b for b in pin.getBoxes() if b.yMin() <= 10000 and 710640 - b.yMax() <= 10000]
    assert len(boxes) == 27
    selected = boxes if label == 'missing-external-straps' else boxes[:1]
    for box in selected:
        r = rectangle(box)
        odb.dbBox.destroy(box)
        if label == 'missing-external-straps':
            continue
        coords = (r[0], r[1], r[0] + 2099, r[3]) if label == 'narrow' else (
                  (r[0] + 1000, r[1], r[2] + 1000, r[3]) if label == 'missing-conductor' else r)
        odb.dbBox_create(pin, db.getTech().findLayer('Metal3' if label == 'wrong-layer' else 'Metal4'), *coords)
    before = out / (label + '-input.def')
    after = out / (label + '-after-rejection.def')
    odb.write_def(block, str(before))
    try:
        select_ports(db, out / label)
    except AssertionError as error:
        assert expected in str(error), str(error)
        odb.write_def(block, str(after))
        assert before.read_bytes() == after.read_bytes(), 'rejected input was edited'
        rows.append({'case': label, 'rejection': str(error), 'unchanged_input_sha256': hashlib.sha256(before.read_bytes()).hexdigest()})
    else:
        raise AssertionError('invalid port accepted: ' + label)
(out / 'result.json').write_bytes((json.dumps({'status': 'PASS_FOUR_NATIVE_PORT_CONTROLS_WITHOUT_PARTIAL_EDIT', 'cases': rows}, indent=2) + '\n').encode())
print('PASS_FOUR_NATIVE_PORT_CONTROLS_WITHOUT_PARTIAL_EDIT')
