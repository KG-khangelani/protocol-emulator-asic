"""Exercise the original pinned precheck on the original and selected-port LEFs."""
import hashlib
import json
import logging
from pathlib import Path
import sys

root = Path('/workspace')
reference = root / 'build/g2-sram-power-port-reference-01'
sys.path[:0] = [str(reference), str(reference / 'python')]
import gdstk
import numpy
from pin_check import pin_check
from precheck_failure import PrecheckFailure

base = root / 'build/g2-sram-power-port-probe-01'
top = 'tt_um_khangelani_protocol_emulator'
records = []
logging.basicConfig(level=logging.INFO)
for label, path, expected in [('original', base / 'original' / (top + '.lef'), '148 LEF errors'),
        ('selected', base / 'native-02/lef/final/lef' / (top + '.lef'), None)]:
    print('CHECK', label, flush=True)
    try:
        pin_check(str(base / 'original' / (top + '.gds')), str(path), str(base / 'template.def'), top, False, 'ihp-sg13cmos5l')
    except PrecheckFailure as error:
        assert expected and expected in str(error), str(error)
        records.append({'case': label, 'outcome': 'EXPECTED_REJECTION', 'error': str(error)})
    else:
        assert expected is None, 'original invalid ports were accepted'
        records.append({'case': label, 'outcome': 'PASS'})
result = {'status': 'PASS_ORIGINAL_REJECTION_AND_SELECTED_POWER_PORTS', 'records': records,
          'gdstk': gdstk.__version__, 'numpy': numpy.__version__,
          'checker_sha256': {name: hashlib.sha256((reference / name).read_bytes()).hexdigest()
                             for name in ('pin_check.py', 'tech_data.py', 'precheck_failure.py')},
          'scope': 'Unchanged pinned pin checker on the exact submitted GDS; only native regenerated LEF power-port membership differs. Complete new official qualification remains required.'}
(base / 'pin-check.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(result['status'])
