"""Exercise portable staging, the native ODB step and real port corruption controls."""
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path('/workspace')
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from tools import physical_sram as gate
import run_program_sensitivity as bounded

base = root / 'build/g2-sram-ports-staging-01'
workspace = base / 'workspace'
bounded.ROOT = workspace
inputs = gate.read(base / 'inputs.json')
config = gate.read(workspace / 'src/config.json')
reference = gate.read(root / 'build/g2-sram-full-05/src/config_merged.json')
for name in ('DESIGN_NAME', 'DIE_AREA', 'FP_DEF_TEMPLATE', 'VDD_PIN', 'GND_PIN', 'RT_MAX_LAYER'):
    config[name] = reference[name]
config['VERILOG_FILES'] = ['dir::' + Path(name).name for name in reference['VERILOG_FILES']]
(workspace / 'src/config_merged.json').write_bytes((json.dumps(config, indent=2) + '\n').encode())
(workspace / 'runs/port-step').mkdir(parents=True)
initial = root / 'build/g2-sram-full-05/runs/integrated/57-odb-cellfrequencytables/state_out.json'
(base / 'runner.py').write_bytes(Path(__file__).read_bytes())
command = [sys.executable, '-m', 'librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l',
    '--run-tag', 'port-step', '--force-run-dir', 'runs/port-step', '--with-initial-state', str(initial),
    '--from', 'Project.SelectSramPowerPorts', '--to', 'Project.SelectSramPowerPorts', 'src/config_merged.json']
env = dict(os.environ)
env.pop('PYTHONPATH', None)
execution = bounded.execute(command, base / 'step.log', 120, env=env)
gate.write(base / 'execution.json', execution)
assert execution['returncode'] == 0 and not execution['timed_out']
run = workspace / 'runs/port-step'
resolved = gate.read(run / 'resolved.json')
assert gate.inspect_resolved(resolved, inputs, workspace) == inputs['macro_views']
stage = gate.one_stage(run, 'Project.SelectSramPowerPorts')
before, after = gate.read(stage / 'state_in.json'), gate.read(stage / 'state_out.json')
receipt = gate.read(stage / 'power-port-audit/selection.json')
assert gate.digest(Path(before['odb'])) == receipt['input_odb_sha256'] == '97e65b674230e713f313aa17a27702590eff0aa12b023f34a41b53b8f1729bab'
for side, state in (('before', before), ('after', after)):
    assert gate.digest(Path(state['def'])) == receipt[side + '_def_sha256']
assert Path(after['def']).read_bytes() == (root / 'build/g2-sram-power-port-probe-01/native-02/selection/after.def').read_bytes()
assert Path(after['odb']).read_bytes() == (root / 'build/g2-sram-power-port-probe-01/native-02/selection/selected.odb').read_bytes()
original = gate.read(root / 'build/g2-sram-power-port-probe-01/native-02/selection/selection.json')
assert {k: v for k, v in receipt.items() if k != 'input_odb_sha256'} == original
checks = []
for name, mutate, message in (
        ('missing-selection-step', lambda r: r['meta'].__setitem__('flow', 'SramGuardedClassic'), 'unexpected flow substitutions'),
        ('wrong-port-contract', lambda r: r['power_port_selection'].__setitem__('remaining_external_rectangles', 1), 'power-port selection contract differs')):
    import copy
    r, i = copy.deepcopy(resolved), copy.deepcopy(inputs)
    mutate(i if name == 'wrong-port-contract' else r)
    try:
        gate.inspect_resolved(r, i, workspace)
    except ValueError as error:
        assert message in str(error)
        checks.append({'fault': name, 'rejection': str(error)})
    else:
        raise AssertionError('corrupt staging accepted')
gate.write(base / 'verification.json', {'status': 'PASS_PORTABLE_NATIVE_POWER_PORT_STEP', 'execution': execution,
    'configuration_controls': checks, 'input_odb_sha256': receipt['input_odb_sha256'],
    'output_odb_sha256': gate.digest(Path(after['odb'])), 'after_def_sha256': receipt['after_def_sha256'],
    'matches_passing_original_pin_checker_probe': True, 'stage': stage.relative_to(workspace).as_posix(),
    'physical_qualification': 'OPEN'})
print('PASS_PORTABLE_NATIVE_POWER_PORT_STEP')
