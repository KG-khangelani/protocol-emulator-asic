"""Retain exact diagnostic reports; bind bulky unchanged views to original ZIPs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/power-ports'
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
write = lambda p, v: p.write_bytes((json.dumps(v, indent=2) + '\n').encode())
probe = root / 'build/g2-sram-power-port-probe-01'
staging = root / 'build/g2-sram-ports-staging-01'
assert read(probe / 'native-02/result.json')['status'] == 'PASS_NATIVE_POWER_PORT_SELECTION_AND_GRID_PIN_DIAGNOSTICS'
assert read(probe / 'pin-check.json')['status'] == 'PASS_ORIGINAL_REJECTION_AND_SELECTED_POWER_PORTS'
assert read(probe / 'native-controls/result.json')['status'] == 'PASS_FOUR_NATIVE_PORT_CONTROLS_WITHOUT_PARTIAL_EDIT'
assert read(staging / 'verification.json')['status'] == 'PASS_PORTABLE_NATIVE_POWER_PORT_STEP'
files, omitted = {}, {}
for prefix, directory in [('probe', probe), ('staging', staging)]:
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        name = prefix + '/' + path.relative_to(directory).as_posix()
        if '/final/' in name or path.suffix in ('.odb', '.gds', '.mag', '.spef', '.sdf'):
            omitted[name] = {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
        else:
            files[name] = path.read_bytes()
reference = root / 'build/g2-sram-power-port-reference-01'
for name in ('pin_check.py', 'tech_data.py', 'precheck_failure.py'):
    raw = (reference / name).read_bytes()
    expected = read(probe / 'pin-check.json')['checker_sha256'][name]
    assert sha(raw) == expected
    files['references/' + name] = raw
for name in ('select_sram_power_ports.py', 'sram_power_ports_step.py', 'librelane_plugin_sram.py'):
    files['current/' + name] = (root / 'experiments/i2c' / name).read_bytes()
for name in ('check_sram_power_ports.py', 'probe_sram_power_ports.py', 'rehearse_sram_power_port_step.py'):
    files['runners/' + name] = (root / 'build' / name).read_bytes()
files['repository-check.log'] = (root / 'build/g2-sram-power-port-repository-check-01.log').read_bytes()
with (out / 'diagnostic.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
write(out / 'archive.json', {'sha256': sha((out / 'diagnostic.tar.gz').read_bytes()),
    'bytes': (out / 'diagnostic.tar.gz').stat().st_size, 'files': {n: sha(r) for n, r in sorted(files.items())},
    'omitted_generated_views': omitted,
    'original_view_source': '../ci-232ee20-pin-failure/14000880025.zip and 14000422018.zip; native replay regenerates the selected ODB.'})
for source, target in [(probe / 'native-02/result.json', 'native.json'), (probe / 'pin-check.json', 'pin-check.json'),
                       (probe / 'native-controls/result.json', 'controls.json'), (staging / 'verification.json', 'staging.json')]:
    shutil.copyfile(source, out / target)
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED', len(files), 'files', len(omitted), 'indexed generated views', (out / 'diagnostic.tar.gz').stat().st_size, 'archive bytes')
