"""Retain the passing physical job and the independent rejected pin precheck."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import tarfile
import zipfile
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-ci-232ee20'
review = root / 'build/g2-sram-ci-232ee20-physical-audit-02'
out = root / 'evidence/E0043-sram-physical-integration/ci-232ee20-pin-failure'
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
write = lambda p, v: p.write_bytes((json.dumps(v, indent=2) + '\n').encode())
physical = read(review / 'result.json')
assert physical['status'] == 'PASS_SRAM_GDS_CHECKS_REMAINING_GATES_PENDING'
metadata = read(base / 'artifacts-precheck.json')
files = {}
for a in metadata['artifacts']:
    if a['name'] not in ('GDS_logs', 'tt_submission', 'sram-physical-candidate', 'precheck_reports'):
        continue
    name = str(a['id']) + '.zip'
    path = base / name
    assert path.stat().st_size == a['size_in_bytes'] and 'sha256:' + sha(path.read_bytes()) == a['digest']
    shutil.copyfile(path, out / name)
    with zipfile.ZipFile(path) as z:
        files[a['name']] = {n: sha(z.read(n)) for n in z.namelist() if not n.endswith('/')}
write(out / 'zip-files.json', files)
for src, target in [('run-precheck.json', 'run.json'), ('jobs-precheck.json', 'jobs.json'),
                    ('artifacts-precheck.json', 'artifacts.json')]:
    write(out / target, read(base / src))
for name in ('gds-job', 'precheck-job'):
    (out / (name + '.log.gz')).write_bytes(gzip.compress((base / (name + '.log')).read_bytes(), mtime=0))
write(out / 'physical-review.json', physical)
raw = (base / 'precheck-job.log').read_bytes()
text = raw.decode()
submission = next(a for a in metadata['artifacts'] if a['name'] == 'tt_submission')
expected = f'- tt_submission (ID: {submission["id"]}, Size: {submission["size_in_bytes"]}, Expected Digest: {submission["digest"]})'
assert expected in text and 'SHA256 digest of downloaded artifact is ' + submission['digest'].split(':')[1] in text
assert 'Artifact download completed successfully.' in text
assert re.search(r'^\S+Z 9d13ff3e3e6202090740110438c6a10c1d62ca0f\s*$', text, re.M)
assert 'Precheck failed for ' in text and '148 LEF errors' in text
with zipfile.ZipFile(out / '13999164903.zip') as z:
    junit = ET.fromstring(z.read('results.xml'))
    tests = [{'name': c.get('name'), 'failed': bool(c.findall('failure') or c.findall('error')),
              'message': [f.get('message') for f in c if f.tag in ('failure', 'error')]}
             for c in junit.findall('.//testcase')]
assert len(tests) == 10 and sum(c['failed'] for c in tests) == 1
assert next(c for c in tests if c['failed'])['name'] == 'Pin check'
write(out / 'verification.json', {'status': 'REJECTED_OFFICIAL_POWER_PORT_PRECHECK',
    'source_commit': physical['source_commit'], 'run_id': physical['run_id'],
    'physical_job': 'PASS', 'precheck': tests, 'pin_lef_errors': 148,
    'consumed_submission_sha256': submission['digest'].split(':')[1], 'precheck_log_sha256': sha(raw),
    'original_archive_members': sum(len(v) for v in files.values()),
    'netlist_testing': 'IN_PROGRESS_AT_THIS_SNAPSHOT', 'production': 'NOT_PROMOTED',
    'scope': 'Original physical build passes all required metrics, original complete Magic DRC and LVS. Independent precheck rejects exported supply-port spans; nine other checks pass. This candidate remains rejected.'})
inputs = {p.relative_to(review / 'producer').as_posix(): p.read_bytes()
          for p in (review / 'producer').rglob('*') if p.is_file()}
with (out / 'producer.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(inputs.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
write(out / 'producer.json', {'source_commit': physical['source_commit'],
    'sha256': sha((out / 'producer.tar.gz').read_bytes()), 'files': {n: sha(r) for n, r in sorted(inputs.items())}})
support = (root / 'build/sram_official_frozen_support.py').read_text(encoding='utf-8')
support = support.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path(__file__).resolve().parents[3]\nHERE = Path(__file__).resolve().parent')
old = "            raw = subprocess.check_output(['git', 'show', source + ':' + name], cwd=ROOT)"
assert support.count(old) == 1
new = '''            index = json.loads((HERE / 'producer.json').read_bytes())
            assert source == index['source_commit']
            archive = HERE / 'producer.tar.gz'
            assert hashlib.sha256(archive.read_bytes()).hexdigest() == index['sha256']
            with tarfile.open(archive) as stream:
                raw = stream.extractfile(name).read()
            assert hashlib.sha256(raw).hexdigest() == index['files'][name]'''
support = support.replace(old, new)
(out / 'sram_official_frozen_support.py').write_bytes(support.encode())
audit = (root / 'build/audit_sram_physical_ci.py').read_text(encoding='utf-8')
audit = audit.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path(__file__).resolve().parents[3]')
(out / 'audit.py').write_bytes(audit.encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED', sum(len(v) for v in files.values()), 'original archive files and', len(inputs), 'producing inputs')
