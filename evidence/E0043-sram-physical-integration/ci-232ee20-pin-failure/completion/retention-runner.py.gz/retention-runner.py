import gzip
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-ci-232ee20'
out = root / 'evidence/E0043-sram-physical-integration/ci-232ee20-pin-failure/completion'
assert not out.exists()
out.mkdir()
sha = lambda b: hashlib.sha256(b).hexdigest()
index = {}
metadata = json.loads((base / 'final-artifacts.json').read_bytes())
for a in metadata['artifacts']:
    if a['name'] not in ('gatelevel_test_results', 'sram-netlist-check'):
        continue
    path = base / (str(a['id']) + '.zip')
    assert path.stat().st_size == a['size_in_bytes'] and 'sha256:' + sha(path.read_bytes()) == a['digest']
    shutil.copyfile(path, out / path.name)
    with zipfile.ZipFile(path) as z:
        index[a['name']] = {n: sha(z.read(n)) for n in z.namelist() if not n.endswith('/')}
for name in ('run', 'jobs', 'artifacts'):
    shutil.copyfile(base / ('final-' + name + '.json'), out / (name + '.json'))
(out / 'gl_test-job.log.gz').write_bytes(gzip.compress((base / 'gl-job.log').read_bytes(), mtime=0))
(out / 'zip-files.json').write_bytes((json.dumps(index, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_FINAL_NETLIST_ARCHIVES', sum(map(len, index.values())))
