"""Retain the D46 portable rehearsal and actual input-rejection checks."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
base = root/'build/g2-sram-aligned-staging-01'
out = root/'evidence/E0043-sram-physical-integration/aligned-staging'
assert not out.exists()
files = {}
sha = lambda raw:hashlib.sha256(raw).hexdigest()
report = json.loads((base/'pilot-verification.json').read_bytes())
assert report['status']=='PASS_PORTABLE_ALIGNED_PILOT_AND_TWELVE_CONFIGURATION_CONTROLS'
for path in sorted(base.rglob('*')):
    name = path.relative_to(base).as_posix()
    if not path.is_file() or any(p in ('__pycache__','tmp','final') for p in path.relative_to(base).parts):
        continue
    if path.suffix in ('.odb','.def') and not any('/'+stage+'/' in '/'+name for stage in ('23-project-connectsrampower','24-project-checksrampower','29-odb-applydeftemplate')):
        continue
    files['pilot/'+name] = path.read_bytes()
for label,dirname in [('wrapper','g2-sram-magic-wrapper-03'),('rejections','g2-sram-alignment-rejections-01')]:
    source = root/'build'/dirname
    for path in sorted(source.rglob('*')):
        relative = path.relative_to(source)
        if not path.is_file() or 'changed-pdk' in relative.parts:
            continue
        if 'sram-magic-aligned' in relative.parts and path.name not in ('alignment.json','native-drc.tcl'):
            continue
        files[label+'/'+relative.as_posix()] = path.read_bytes()
    runtime = json.loads(subprocess.check_output(['docker','inspect',dirname]))[0]
    assert runtime['State']['Status']=='exited' and runtime['State']['ExitCode']==0
    files[label+'/runtime.json'] = (json.dumps({'image_id':runtime['Image'],'configured_image':runtime['Config']['Image'],'state':runtime['State'],'command':runtime['Config']['Cmd']},indent=2)+'\n').encode()
reference = root/'build/g2-sram-full-05/runs/integrated'
for label,name in [('resolved.json','resolved.json'),('public-pin-audit.json','30-project-checkpublicpinpower/pin-power-audit/result.json')]:
    files['reference/'+label] = (reference/name).read_bytes()
for name in ('drc.tcl','wrapper.tcl'):
    files['reference/native/'+name] = (root/'build/g2-sram-contact-rule-reference-01/native'/name).read_bytes()
files['reference/controls.gds'] = (root/'build/g2-sram-contact-controls-02/controls.gds').read_bytes()
runtime = json.loads(subprocess.check_output(['docker','inspect','g2-sram-aligned-staging-01']))[0]
assert runtime['Image']=='sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5' and runtime['State']['Status']=='exited' and runtime['State']['ExitCode']==0
files['runtime.json'] = (json.dumps({'image_id':runtime['Image'],'configured_image':runtime['Config']['Image'],'command':runtime['Config']['Cmd'],'state':runtime['State'],'mounts':[m for m in runtime['Mounts'] if m['Destination'] in ('/pdk','/workspace')]},indent=2)+'\n').encode()
out.mkdir()
with (out/'staging.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size,item.mode,item.mtime=len(raw),0o644,0
                archive.addfile(item,io.BytesIO(raw))
raw=(out/'staging.tar.gz').read_bytes()
(out/'archive.json').write_bytes((json.dumps({'sha256':sha(raw),'bytes':len(raw),'files':{n:sha(r) for n,r in sorted(files.items())}},indent=2)+'\n').encode())
(out/'verification.json').write_bytes((base/'pilot-verification.json').read_bytes())
(out/'tt_block_8x4_pgvdd.def.gz').write_bytes((out.parent/'guarded-staging/tt_block_8x4_pgvdd.def.gz').read_bytes())
(out/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('RETAINED_ALIGNED_STAGING',len(files),len(raw))
