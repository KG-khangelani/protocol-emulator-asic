"""Check the portable setup against both retained native contact-control reports."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute
out = root / 'build/g2-sram-magic-wrapper-03'
assert not out.exists()
out.mkdir()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
for name in ('align_sram_magic.py', 'sram_magicrc.tcl'):
    shutil.copyfile(root / 'experiments/i2c' / name, out / name)
controls = root / 'build/g2-sram-contact-controls-02'
# Use the producing command's exact native scripts directory.
scripts = Path(json.loads((controls / 'result.json').read_bytes())['runs']['original']['execution']['command'][-1]).parent
def findings(text):
    category, result = '', []
    for line in text.splitlines()[1:]:
        if not line or line.startswith(('-', '[INFO]')):
            continue
        if line.startswith(' '):
            result.append((category, line.strip()))
        else:
            category = line
    return sorted(result)
result = {'status': 'RUNNING', 'cases': {}, 'source_sha256': {n: hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ('align_sram_magic.py','sram_magicrc.tcl')}}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
for label, step in [('proposed', 'Magic.DRC'), ('original', 'Magic.StreamOut')]:
    work = out / label
    work.mkdir()
    (work / 'reports').mkdir()
    text = (controls / label / '_env.tcl').read_text()
    for setting, value in [('STEP_DIR', str(work)), ('STEP_ID', step)]:
        text, count = re.subn(r'^set ::env\(' + setting + r'\) .*$', 'set ::env(' + setting + ') ' + value, text, flags=re.M)
        assert count == 1
    (work / '_env.tcl').write_text(text)
    command = ['magic', '-dnull', '-noconsole', '-rcfile', str(out / 'sram_magicrc.tcl'), str(scripts / 'wrapper.tcl')]
    command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'wrapper-rehearsal', str(work), *command]
    execution = execute(command, work / 'run.log', 60, env=dict(os.environ, _TCL_ENV_IN=str(work / '_env.tcl'), _MAGIC_SCRIPT=str(scripts / 'drc.tcl')))
    result['cases'][label] = {'execution': execution}
    save()
    assert execution['returncode'] == 0 and not execution['timed_out']
    report = (work / 'reports/drc.magic.rpt').read_text()
    expected = (controls / label / 'reports/drc.magic.rpt').read_text()
    assert findings(report) == findings(expected)
    assert (work / 'sram-magic-aligned/alignment.json').exists() == (label == 'proposed')
    result['cases'][label].update(status='PASS_EXACT_NATIVE_FINDINGS', total_findings=len(findings(report)))
    save()
result['status'] = 'PASS_PORTABLE_MAGIC_WRAPPER'
save()
print(result['status'])
