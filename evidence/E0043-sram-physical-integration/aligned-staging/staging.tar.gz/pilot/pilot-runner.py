"""Exercise D46 portable staging while retaining the native 84-stage flow."""
import copy
import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from tools import physical_sram as gate
import run_program_sensitivity as bounded

base = ROOT / 'build/g2-sram-aligned-staging-01'
workspace = base / 'workspace'
bounded.ROOT = workspace
inputs = gate.read(base / 'inputs.json')
config = gate.read(workspace / 'src/config.json')
reference = gate.read(ROOT / 'build/g2-sram-full-05/src/config_merged.json')
for name in ('DESIGN_NAME','DIE_AREA','FP_DEF_TEMPLATE','VDD_PIN','GND_PIN','RT_MAX_LAYER'):
    config[name] = reference[name]
config['VERILOG_FILES'] = ['dir::' + Path(name).name for name in reference['VERILOG_FILES']]
(workspace / 'src/config_merged.json').write_bytes((json.dumps(config,indent=2)+'\n').encode())
(workspace / 'runs/aligned-pilot').mkdir(parents=True)
(base / 'pilot-runner.py').write_bytes(Path(__file__).read_bytes())
command = [sys.executable,'-m','librelane','--pdk-root','/pdk','--pdk','ihp-sg13cmos5l',
           '--run-tag','aligned-pilot','--force-run-dir','runs/aligned-pilot',
           '--to','Project.CheckPublicPinPower','src/config_merged.json']
env = dict(os.environ)
env.pop('PYTHONPATH',None)
execution = bounded.execute(command,base/'pilot.log',300,env=env)
execution['cwd'] = str(workspace)
(base/'pilot-execution.json').write_bytes((json.dumps(execution,indent=2)+'\n').encode())
assert execution['returncode'] == 0 and not execution['timed_out']
run = workspace / 'runs/aligned-pilot'
resolved = gate.read(run/'resolved.json')
assert gate.inspect_resolved(resolved,inputs,workspace) == inputs['macro_views']
old = gate.read(ROOT/'build/g2-sram-full-05/runs/integrated/resolved.json')
def normalized(value):
    if isinstance(value,str):
        return value.replace(str(workspace),'$DESIGN').replace('/workspace/build/g2-sram-full-05','$DESIGN').replace('$DESIGN/src/sram-preparation.json','$DESIGN/preparation.json')
    if isinstance(value,list):
        return [normalized(v) for v in value]
    if isinstance(value,dict):
        return {k:normalized(v) for k,v in value.items()}
    return value
new, old = normalized(resolved), normalized(old)
changes = {k:[old.get(k),new.get(k)] for k in old.keys()|new.keys() if old.get(k)!=new.get(k)}
assert set(changes) == {'DESIGN_DIR','MAGICRC'} and changes['DESIGN_DIR'] == ['$DESIGN','$DESIGN/src'], changes
controls = []
for name, mutate, expected in (
    ('missing_real_macro',lambda c:c['MACROS'].clear(),'unexpected macro set'),
    ('wrong_fast_library',lambda c:c['MACROS'][gate.MACRO]['lib'].__setitem__('nom_fast_1p32V_m40C',c['MACROS'][gate.MACRO]['lib']['nom_typ_1p20V_25C']),'corner mapping changed'),
    ('waived_drc',lambda c:c.__setitem__('RUN_MAGIC_DRC',False),'required acceptance check disabled'),
    ('extra_source',lambda c:c['VERILOG_FILES'].append(c['VERILOG_FILES'][0]),'resolved RTL paths differ'),
    ('removed_guard',lambda c:c['meta'].__setitem__('flow','SramBufferedClassic'),'unexpected flow substitutions'),
    ('relaxed_clock',lambda c:c.__setitem__('CLOCK_PERIOD',25),'resolved CLOCK_PERIOD differs'),
    ('missing_vendor_import',lambda c:c.__setitem__('MAGIC_GDS_FLATGLOB',[]),'vendor SRAM import patterns changed'),
    ('broadened_vendor_import',lambda c:c['MAGIC_GDS_FLATGLOB'].append('*'),'vendor SRAM import patterns changed'),
    ('abstract_macro_drc',lambda c:c.__setitem__('MAGIC_DRC_MAGLEFS',['dummy.mag']),'abstract macro views cannot replace complete GDS DRC'),
    ('wrong_magic_startup',lambda c:c.__setitem__('MAGICRC',str(reference['MAGICRC']) if 'MAGICRC' in reference else str(Path(c['MAGIC_TECH']).with_suffix('.magicrc'))),'resolved Magic startup differs'),
    ('wrong_original_technology',lambda c:c.__setitem__('MAGIC_TECH',c['MAGICRC']),'original Magic technology differs'),
):
    changed = copy.deepcopy(resolved)
    mutate(changed)
    try:
        gate.inspect_resolved(changed,inputs,workspace)
    except ValueError as error:
        assert expected in str(error),str(error)
        controls.append({'fault':name,'observed_rejection':str(error)})
    else:
        raise AssertionError('missed corruption: '+name)
bad_inputs = copy.deepcopy(inputs)
bad_inputs['magic_contact_alignment']['changed_files']['ihp-sg13cmos5l-drc.tech'] = '0'*64
try:
    gate.inspect_resolved(resolved,bad_inputs,workspace)
except ValueError as error:
    assert str(error) == 'Magic alignment contract differs'
    controls.append({'fault':'changed_rule_contract','observed_rejection':str(error)})
else:
    raise AssertionError('changed alignment contract accepted')
assert len(controls) == 12
grid = gate.read(gate.one_stage(run,'Project.CheckSramPower')/'state_out.json')['metrics']
assert all(grid['design__power_grid_violation__count'+suffix] == 0 for suffix in ('','__net:VPWR','__net:VGND'))
guard = gate.one_stage(run,'Project.CheckPublicPinPower')
pins = gate.read(guard/'pin-power-audit/result.json')
assert pins == gate.read(ROOT/'build/g2-sram-full-05/runs/integrated/30-project-checkpublicpinpower/pin-power-audit/result.json')
before,after = gate.read(guard/'state_in.json'),gate.read(guard/'state_out.json')
assert before['odb'] == after['odb'] and pins['odb_sha256'] == gate.digest(Path(before['odb']))
report = {'status':'PASS_PORTABLE_ALIGNED_PILOT_AND_TWELVE_CONFIGURATION_CONTROLS','execution':execution,
          'controls':controls,'normalized_resolved_changes':changes,'fixed_public_pin_rectangles':43,
          'pin_power_violations':0,'actual_odb_sha256':pins['odb_sha256'],
          'exact_full_trial_database_reproduced':True,'physical_qualification':'OPEN'}
(base/'pilot-verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(report['status'])
