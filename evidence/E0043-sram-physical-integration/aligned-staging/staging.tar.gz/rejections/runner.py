"""Reject unguarded staging and changes to actual checker/reference inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

root = Path('/workspace')
sys.path.insert(0,str(root))
from tools import physical_sram as gate
from experiments.i2c import align_sram_magic as aligner
out = root/'build/g2-sram-alignment-rejections-01'
assert not out.exists()
out.mkdir()
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
drc = root/'build/g2-sram-contact-rule-reference-01/native/drc.tcl'
assert aligner.digest(drc) == aligner.NATIVE_DRC_SHA256
bad_drc = out/'changed-drc.tcl'
bad_drc.write_bytes(drc.read_bytes()+b'\n# deliberate source change\n')
bad_pdk = out/'changed-pdk'
shutil.copytree(pdk/'libs.tech/magic',bad_pdk/'libs.tech/magic')
for name in aligner.REFERENCE_SHA256:
    if not name.startswith('libs.tech/magic/'):
        target = bad_pdk/name
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(pdk/name,target)
bad_gds = bad_pdk/'libs.tech/magic/ihp-sg13cmos5l-GDS.tech'
bad_gds.write_bytes(bad_gds.read_bytes()+b'\n# deliberate unchecked-tree-file change\n')
controls = []
for name, call, expected in (
    ('unguarded_alignment',lambda:gate.portable_config('header.vh',aligned=True),'Magic alignment requires the guarded construction'),
    ('changed_complete_drc_script',lambda:aligner.align(pdk/'libs.tech/magic/ihp-sg13cmos5l.tech',out/'rejected-script',bad_drc),'original complete DRC script changed'),
    ('changed_other_magic_file',lambda:aligner.align(bad_pdk/'libs.tech/magic/ihp-sg13cmos5l.tech',out/'rejected-tree',drc),'pinned Magic source tree changed'),
):
    try:
        call()
    except ValueError as error:
        assert str(error) == expected,str(error)
        controls.append({'fault':name,'rejection':str(error)})
    else:
        raise AssertionError('missed corruption: '+name)
assert not (out/'rejected-script').exists() and not (out/'rejected-tree').exists()
report = {'status':'PASS_THREE_ALIGNMENT_REJECTION_CONTROLS','controls':controls,
    'inputs':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'tools/physical_sram.py',root/'experiments/i2c/align_sram_magic.py']}}
(out/'result.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(report['status'])
