import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/E0043-sram-physical-integration'
OUT.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
groups={'native':ROOT/'build/g2-sram-pdn-01','edge-connections':ROOT/'build/g2-sram-pdn-bridges-01'}
assert json.loads((groups['native']/'geometry.json').read_bytes())['status']=='FAIL_UNPOWERED_SRAM'
assert json.loads((groups['edge-connections']/'gridcheck.json').read_bytes())['status']=='PASS_BOTH_POWER_GRIDS'
files={}
for label,base in groups.items():
    for path in base.rglob('*'):
        if not path.is_file() or {'final','__pycache__'} & set(path.relative_to(base).parts):
            continue
        if path.suffix in ('.odb','.def') and label=='native' and '21-openroad-generatepdn' not in path.parts:
            continue
        if path.suffix in ('.json','.v','.vh','.log','.abc','.sdc','.txt','.py','.md','.rpt','.tcl','.odb','.def') or path.name=='COMMANDS':
            files[label+'/'+path.relative_to(base).as_posix()]=path.read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size,entry.mode,entry.mtime=len(raw),0o644,0
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(OUT/'power-trials.tar.gz').write_bytes(packed)
(OUT/'archive.json').write_bytes((json.dumps({'sha256':sha(packed),'bytes':len(packed),
    'files':{n:sha(raw) for n,raw in sorted(files.items())}},indent=2)+'\n').encode())
(OUT/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines=[sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
       if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(len(files),'power trial files;',len(packed),'archive bytes')
