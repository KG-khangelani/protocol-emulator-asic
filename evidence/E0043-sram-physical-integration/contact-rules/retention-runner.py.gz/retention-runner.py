"""Retain completed contact-rule diagnostics and their unsuccessful controls."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/contact-rules'
assert not out.exists() or {p.name for p in out.iterdir()} == {'verify.py'}
files = {}
cases = [('original-macro', 'g2-sram-macro-drc-probe-05')]
cases += [('correction-' + str(n), 'g2-sram-contact-rule-probe-' + str(n).zfill(2)) for n in range(1, 5)]
cases += [('controls-' + str(n), 'g2-sram-contact-controls-' + str(n).zfill(2)) for n in (1, 2)]
cases += [('wrapper-' + str(n), 'g2-sram-magic-wrapper-' + str(n).zfill(2)) for n in (1, 2)]
image = 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
for label, name in cases:
    base = root / 'build' / name
    for path in sorted(base.rglob('*')):
        if path.is_file() and not {'magic', 'sram-magic-aligned'} & set(path.relative_to(base).parts):
            files[label + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
    runtime = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert runtime['Image'] == runtime['Config']['Image'] == image
    assert runtime['State']['Status'] == 'exited'
    files[label + '/runtime.json'] = (json.dumps({'image_id': runtime['Image'], 'configured_image': runtime['Config']['Image'],
        'state': runtime['State'], 'command': runtime['Config']['Cmd'],
        'mounts': [m for m in runtime['Mounts'] if m['Destination'] in ('/workspace', '/pdk')]}, indent=2) + '\n').encode()
    files[label + '/container.log'] = subprocess.run(['docker', 'logs', name], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True).stdout
reference = root / 'build/g2-sram-contact-rule-reference-01'
for path in sorted(reference.rglob('*')):
    if path.is_file():
        files['reference/' + path.relative_to(reference).as_posix()] = path.read_bytes()
for name in ('ihp-sg13cmos5l-cifin.tech', 'ihp-sg13cmos5l-drc.tech'):
    files['aligned/' + name] = (root / 'build/g2-sram-contact-rule-probe-04/magic' / name).read_bytes()
for name in ('align_sram_magic.py', 'sram_magicrc.tcl'):
    files['portable/' + name] = (root / 'experiments/i2c' / name).read_bytes()
files['geometry/result.json'] = (root / 'build/g2-sram-contact-geometry-02.json').read_bytes()
files['geometry/runner.py'] = (root / 'build/audit_sram_contact_geometry.py').read_bytes()
files['geometry/sample-inspection.json'] = (root / 'build/g2-sram-macro-contact-geometry-01.json').read_bytes()
files['helpers/execute.py'] = (root / 'experiments/spi_phase/run_program_sensitivity.py').read_bytes()
files['helpers/macro-followup.py'] = (root / 'build/probe_sram_macro_longer.py').read_bytes()
files['helpers/gds-command-diagnosis.tcl'] = (root / 'build/inspect_magic_gds_dispatch.tcl').read_bytes()
out.mkdir(exist_ok=True)
with (out / 'diagnostic.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
raw = (out / 'diagnostic.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'bytes': len(raw), 'sha256': sha(raw), 'files': {n: sha(v) for n,v in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_CONTACT_RULE_DIAGNOSIS', len(files), len(raw))
