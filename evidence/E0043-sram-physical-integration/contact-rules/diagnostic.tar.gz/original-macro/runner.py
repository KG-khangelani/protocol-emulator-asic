"""Bound a macro-only diagnostic; leave the full-chip manufacturing run untouched."""
import hashlib
import json
import os
from pathlib import Path
import re
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

out = root / 'build/g2-sram-macro-drc-probe-05'
out.mkdir()
(out / 'reports').mkdir()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'followup-runner.py').write_bytes(Path('/workspace/build/probe_sram_macro_longer.py').read_bytes())
(out / 'previous-result.json').write_bytes(Path('/workspace/build/g2-sram-macro-drc-probe-04/result.json').read_bytes())
(out / 'baseline-runner.py').write_bytes(Path('/workspace/build/probe_sram_macro_drc.py').read_bytes())
(out / 'declared-decision.json').write_bytes(Path('/workspace/build/g2-sram-macro-longer-decision.json').read_bytes())
(out / 'read_sram_gds.tcl').write_bytes(Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.tech/magic/read_sram_gds.tcl').read_bytes())
macro = 'RM_IHPSG13_1P_256x32_c2_bm_bist'
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
gds = pdk / 'libs.ref/sg13cmos5l_sram/gds' / (macro + '.gds')
scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
original_env = root / 'build/g2-sram-full-03/runs/integrated/65-magic-drc/_env.tcl'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(gds) == 'e77a4d177e02541fe6c58351008455f9a05a715b504f8e318599f3d41bf5f959'
text = original_env.read_text()
assert text.count('set ::env(DESIGN_NAME) ') == text.count('set ::env(CURRENT_GDS) ') == 1
text, count = re.subn(r'^set ::env\(DESIGN_NAME\) .*$', 'set ::env(DESIGN_NAME) ' + macro, text, flags=re.M)
assert count == 1
text, count = re.subn(r'^set ::env\(CURRENT_GDS\) .*$', 'set ::env(CURRENT_GDS) ' + str(gds), text, flags=re.M)
assert count == 1
text += '\nset ::env(STEP_DIR) ' + str(out) + '\n'
text += '\nset ::env(MAGIC_GDS_FLATGLOB) {lvsres_* *_CELL_SUB VIA_M1_* VIA_M2_* RSC_* *_CELL_CORNER *_BITKIT_CORNER}\n'
(out / '_env.tcl').write_text(text)
(out / 'original-env.tcl').write_bytes(original_env.read_bytes())
inputs = {str(p): sha(p) for p in (gds, original_env, scripts / 'drc.tcl', scripts / 'wrapper.tcl',
                                 pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc',
                                 pdk / 'libs.tech/magic/ihp-sg13cmos5l.tech')}
result = {'status': 'RUNNING_MACRO_ONLY_DIAGNOSTIC', 'inputs': inputs, 'wall_limit': 1200,
          'scope': 'Unmodified vendor macro in isolation under the exact full-chip Magic DRC script/deck. Diagnose runtime/errors only; this cannot qualify full-chip layout, boundary integration or official precheck.'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
env = dict(os.environ, _TCL_ENV_IN=str(out / '_env.tcl'), _MAGIC_SCRIPT=str(scripts / 'drc.tcl'))
command = ['magic', '-dnull', '-noconsole', '-rcfile', str(pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc'), str(scripts / 'wrapper.tcl')]
command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'macro-drc-probe', str(out), *command]
result['working_directory'] = str(out)
result['execution'] = execute(command, out / 'run.log', 1200, env=env)
result['status'] = 'COMMAND_COMPLETED_REQUIRES_DIAGNOSTIC_REVIEW' if result['execution']['returncode'] == 0 else 'INCOMPLETE_OR_FAILED_MACRO_DIAGNOSTIC'
report = out / 'reports/drc.magic.rpt'
if report.exists():
    matches = re.findall(r'\[INFO\] COUNT: (\d+)', report.read_text())
    if matches:
        result['reported_count'] = int(matches[-1])
save()
print(json.dumps(result, indent=2))
