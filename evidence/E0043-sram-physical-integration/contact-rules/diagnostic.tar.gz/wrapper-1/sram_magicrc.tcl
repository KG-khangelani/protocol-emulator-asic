# SPDX-License-Identifier: Apache-2.0
# Keep every native Magic step; align only the complete GDS DRC invocation.
if {![info exists ::env(_TCL_ENV_IN)]} {
    error "SRAM Magic setup requires the native flow environment"
}
source $::env(_TCL_ENV_IN)
set sram_native_magic_dir [file dirname $::env(MAGIC_TECH)]
if {$::env(STEP_ID) eq "Magic.DRC"} {
    set sram_aligned_dir [file join $::env(STEP_DIR) sram-magic-aligned]
    set sram_helper [file join [file dirname [file normalize [info script]]] align_sram_magic.py]
    puts stdout [exec python3 $sram_helper --source-tech $::env(MAGIC_TECH) --output $sram_aligned_dir]
    source [file join $sram_aligned_dir ihp-sg13cmos5l.magicrc]

    # The original drc.tcl still executes its complete synchronous rule check.
    # Avoid background DRC on partially imported hierarchy; restore it even
    # when the native import raises an error.
    rename ::gds ::sram_native_gds
    proc ::gds {args} {
        if {[lindex $args 0] eq "read"} {
            drc off
            try {
                uplevel 1 [list ::sram_native_gds {*}$args]
            } finally {
                drc on
            }
        } else {
            uplevel 1 [list ::sram_native_gds {*}$args]
        }
    }
} else {
    source [file join $sram_native_magic_dir ihp-sg13cmos5l.magicrc]
}
