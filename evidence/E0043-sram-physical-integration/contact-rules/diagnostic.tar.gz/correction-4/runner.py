"""Bound a documented Magic Cnt.c alignment experiment; never edit the PDK."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
out = root / 'build/g2-sram-contact-rule-probe-04'
assert not out.exists()
out.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'utc': datetime.now(timezone.utc).isoformat(),
    'macro_wall_limit': 1200, 'control_wall_limit': 60,
    'hypothesis': 'The 12 ordinary Cnt.c and 20 SRAM Cnt.c markers on the unmodified macro result from Magic omitting DigiBnd Cnt.c and using an older SRAM enclosure threshold.',
    'sources': {'DigiBnd': 'Pinned SG13CMOS5L_os_layout_rules.pdf, printed page 58, section 8.1.2: 0.05 um.',
        'SRAM': 'Pinned KLayout sg13cmos5l_tech_default.json Cnt_c_sram=0.006 um and 5_14_cont.drc. The PDF section 8.3 is explicitly work in progress; it does not supply this SRAM value.'},
    'change': 'Copy the pinned Magic technology locally. Add GDS-derived contact-specific mask hints for DigiBnd outside SRAM and their union; retain 70 nm outside both, apply 50 nm inside DigiBnd outside SRAM, use the pinned KLayout 6 nm SRAM threshold. Keep the original 70 nm SRAM directional check and every other rule unchanged.',
    'acceptance': 'Diagnostic only. Require zero original-macro markers AND boundary controls that still reject below-threshold geometry and missing markers. No existing full flow, PDK files, geometry, netlist, rule waiver, count filter or acceptance configuration is modified.',
    'full_physical_qualification': 'OPEN'}
(out / 'declared-decision.json').write_bytes((json.dumps(decision, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
source = pdk / 'libs.tech/magic'
local = out / 'magic'
shutil.copytree(source, local)
original_hashes = {p.name: sha(p) for p in source.iterdir() if p.is_file()}
rules = local / 'ihp-sg13cmos5l-drc.tech'
text = rules.read_text()
start = text.index('  exemption SRAMID\n  surround ndc/a') if '  exemption SRAMID\n  surround ndc/a' in text else text.index(' exemption SRAMID\n surround ndc/a')
end = text.index(' exception none', start)
block = text[start:end]
assert block.count('70 absence_illegal') == 3 and block.count('20 absence_illegal') == 3 and block.count('70 directional') == 3
digital = ''' exception CONTACTDIGITAL
 surround ndc/a *ndiff,nfet 50 absence_illegal \\
    "N-diffusion overlap of contact in DigiBnd < %d (Cnt.c DigiBnd)"
 surround pdc/a *pdiff,pfet 50 absence_illegal \\
    "P-diffusion overlap of contact in DigiBnd < %d (Cnt.c DigiBnd)"
 surround nsc/a *nsd,*ntap 50 absence_illegal \\
    "N-tap overlap of contact in DigiBnd < %d (Cnt.c DigiBnd)"
'''
changed = block.replace('exemption SRAMID', 'exemption CONTACTSPECIAL', 1).replace(' exception SRAMID', digital + ' exception SRAMID', 1).replace('20 absence_illegal', '6 absence_illegal')
rules.write_text(text[:start] + changed + text[end:])
cifin = local / 'ihp-sg13cmos5l-cifin.tech'
text = cifin.read_text()
anchor = ' templayer sramarea SRAMID\n mask-hints SRAMID\n'
assert text.count(anchor) == 1
added = '''
  # Cnt.c regions derived from actual GDS marker geometry.
  templayer contactspecial DIGITALID
  or SRAMID
  mask-hints CONTACTSPECIAL
  templayer contactdigital DIGITALID
  and-not SRAMID
  mask-hints CONTACTDIGITAL
'''
cifin.write_text(text.replace(anchor, anchor + added))
changed_files = {p.name: {'before': original_hashes[p.name], 'after': sha(p)} for p in local.iterdir() if p.is_file() and sha(p) != original_hashes[p.name]}
assert set(changed_files) == {'ihp-sg13cmos5l-drc.tech', 'ihp-sg13cmos5l-cifin.tech'}
(out / 'patch.json').write_bytes((json.dumps({'changed_files': changed_files, 'all_original_files': original_hashes}, indent=2) + '\n').encode())

scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
original_env = (root / 'build/g2-sram-macro-drc-probe-05/_env.tcl').read_text()
assert original_env.count('set ::env(STEP_DIR) ') == 1
work = out / 'macro'
work.mkdir()
(work / 'reports').mkdir()
text, count = re.subn(r'^set ::env\(STEP_DIR\) .*$', 'set ::env(STEP_DIR) ' + str(work), original_env, flags=re.M)
assert count == 1
(work / '_env.tcl').write_text(text)
command = ['magic', '-dnull', '-noconsole', '-rcfile', str(local / 'ihp-sg13cmos5l.magicrc'), str(scripts / 'wrapper.tcl')]
command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'contact-rule-probe', str(work), *command]
result = {'status': 'RUNNING_DIAGNOSTIC', 'decision_sha256': sha(out / 'declared-decision.json'), 'patch_sha256': sha(out / 'patch.json'), 'full_physical_qualification': 'OPEN'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
result['execution'] = execute(command, work / 'run.log', 1200, env=dict(os.environ, _TCL_ENV_IN=str(work / '_env.tcl'), _MAGIC_SCRIPT=str(scripts / 'drc.tcl')))
report = work / 'reports/drc.magic.rpt'
result['status'] = 'INCOMPLETE_OR_FAILED_DIAGNOSTIC'
if report.exists():
    result['reported_count'] = int(re.findall(r'\[INFO\] COUNT: (\d+)', report.read_text())[-1])
    result['status'] = 'COMPLETED_REQUIRES_CONTROL_REVIEW'
save()
assert all(sha(source / name) == expected for name, expected in original_hashes.items())
print(json.dumps(result, indent=2))
