puts stdout "GDS ORIGIN [namespace origin ::gds]"
puts stdout "GDS COMMANDS [info commands ::magic::*gds*]"
puts stdout "ORIGINAL [catch {gds noduplicates true} value] $value"
rename ::gds ::sram_test_gds
set code [catch {sram_test_gds noduplicates true} value]
puts stdout "RENAMED $code $value"
if {$code} {puts stdout $::errorInfo}
puts stdout "NAMESPACED [catch {::magic::gds noduplicates true} value] $value"
exit 0
