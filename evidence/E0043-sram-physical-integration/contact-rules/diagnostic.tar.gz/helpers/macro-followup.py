"""Predeclare a longer isolated macro diagnostic without changing acceptance rules."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import runpy

root = Path('/workspace')
base = root / 'build/g2-sram-macro-flatglob-runner.py'
original = base.read_bytes()
previous = json.loads((root / 'build/g2-sram-macro-drc-probe-04/result.json').read_bytes())
assert previous['execution']['timed_out'] and previous['wall_limit'] == 120
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'declared_utc': datetime.now(timezone.utc).isoformat(),
    'wall_limit': 1200, 'previous_limit': 120,
    'previous_result_sha256': hashlib.sha256((root / 'build/g2-sram-macro-drc-probe-04/result.json').read_bytes()).hexdigest(),
    'baseline_runner_sha256': hashlib.sha256(original).hexdigest(),
    'reason': 'The corrected full GDS passes the separate KLayout deck and native LVS diagnostic, while original full-chip Magic remains running. Complete the earlier inconclusive whole-macro Magic diagnostic to distinguish vendor macro findings from integration findings.',
    'sole_experimental_change': 'Increase this separate whole-macro diagnostic wall bound from 120 to 1200 seconds. Output paths change only to preserve prior attempts.',
    'unchanged': 'Exact vendor macro GDS; all seven pinned vendor import patterns; original Magic full DRC script, rule deck, image and PDK. Full-chip local and official bounds remain unchanged.',
    'acceptance': 'Diagnostic only; a scoped macro pass cannot qualify the complete chip or replace official checks.'}
decision_path = root / 'build/g2-sram-macro-longer-decision.json'
assert not decision_path.exists()
decision_path.write_bytes((json.dumps(decision, indent=2) + '\n').encode())
text = original.decode()
replacements = {
    "out = root / 'build/g2-sram-macro-drc-probe-04'": "out = root / 'build/g2-sram-macro-drc-probe-05'",
    "'wall_limit': 120,": "'wall_limit': 1200,",
    "execute(command, out / 'run.log', 120, env=env)": "execute(command, out / 'run.log', 1200, env=env)",
    "Path('/workspace/build/g2-sram-macro-flatglob-decision.json')": "Path('/workspace/build/g2-sram-macro-longer-decision.json')",
}
for old, new in replacements.items():
    assert text.count(old) == 1, old
    text = text.replace(old, new)
anchor = "(out / 'reports').mkdir()"
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + "\n(out / 'runner.py').write_bytes(Path(__file__).read_bytes())\n(out / 'followup-runner.py').write_bytes(Path('/workspace/build/probe_sram_macro_longer.py').read_bytes())\n(out / 'previous-result.json').write_bytes(Path('/workspace/build/g2-sram-macro-drc-probe-04/result.json').read_bytes())")
runner = root / 'build/g2-sram-macro-longer-runner.py'
assert not runner.exists()
runner.write_bytes(text.encode())
runpy.run_path(str(runner), run_name='__main__')
