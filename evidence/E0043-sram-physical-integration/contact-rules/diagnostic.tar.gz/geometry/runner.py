"""Measure Activ enclosure at every original isolated-macro Cnt.c marker."""
import hashlib
import json
from pathlib import Path
import re
import klayout.db as db

root = Path('/workspace')
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
gds = pdk / 'libs.ref/sg13cmos5l_sram/gds/RM_IHPSG13_1P_256x32_c2_bm_bist.gds'
raw = gds.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'e77a4d177e02541fe6c58351008455f9a05a715b504f8e318599f3d41bf5f959'
layout = db.Layout()
layout.read(str(gds))
assert layout.dbu == .001
top = layout.cell('RM_IHPSG13_1P_256x32_c2_bm_bist')
report = (root / 'build/g2-sram-macro-drc-probe-05/reports/drc.magic.rpt').read_text()
markers = [db.Box(*[round(float(v)*1000) for v in re.findall(r'([0-9.]+)um', line)]) for line in report.splitlines() if line.startswith(' ')]
assert len(markers) == 32
result = []
for marker in markers:
    query = marker.enlarged(1000)
    contact_iter = top.begin_shapes_rec_overlapping(layout.layer(6, 0), marker)
    contacts = []
    while not contact_iter.at_end():
        shape = contact_iter.shape()
        box = shape.bbox().transformed(contact_iter.trans())
        if not (db.Region(box) & db.Region(marker)).is_empty():
            contacts.append((box, contact_iter.cell().name))
        contact_iter.next()
    assert len({str(b) for b, c in contacts}) == 1, (str(marker), [(str(b), c) for b, c in contacts])
    contact, cell = contacts[0]
    activ = db.Region(top.begin_shapes_rec_overlapping(layout.layer(1, 0), query)).merged()
    encl = max(n for n in range(201) if (db.Region(contact.enlarged(n)) - activ).is_empty())
    marker_coverage = {}
    for name, layer in [('digital', 16), ('sram', 25)]:
        region = db.Region(top.begin_shapes_rec_overlapping(layout.layer(layer, 0), query)).merged()
        marker_coverage[name] = (db.Region(contact) - region).is_empty()
    threshold = 6 if marker_coverage['sram'] else 50 if marker_coverage['digital'] else 70
    assert encl >= threshold
    result.append({'marker_nm': str(marker), 'source_cell': cell, 'coincident_contact_occurrences': len(contacts), 'contact_nm': str(contact),
        'minimum_activ_enclosure_nm': encl, 'marker_coverage': marker_coverage, 'reference_limit_nm': threshold})
summary = {'status': 'PASS_ALL_32_REFERENCE_ENCLOSURES', 'gds_sha256': hashlib.sha256(raw).hexdigest(),
    'method': 'Union actual recursively transformed Activ polygons. Increase the real contact box in integer nanometres until it is no longer wholly enclosed. Determine SRAM/DigiBnd coverage from actual GDS marker polygons; SRAM takes priority.',
    'observations': result, 'full_physical_qualification': 'OPEN'}
out = root / 'build/g2-sram-contact-geometry-02.json'
assert not out.exists()
out.write_bytes((json.dumps(summary, indent=2) + '\n').encode())
print(summary['status'], {str(v): sum(o['minimum_activ_enclosure_nm'] == v for o in result) for v in sorted({o['minimum_activ_enclosure_nm'] for o in result})})
