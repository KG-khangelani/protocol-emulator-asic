"""Challenge the contact-rule diagnostic with real GDS boundary controls."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import klayout.db as db

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
out = root / 'build/g2-sram-contact-controls-01'
assert not out.exists()
out.mkdir()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
cases = [
    ('general_065', 65, 'none', True, True), ('general_070', 70, 'none', False, False),
    ('digital_045', 45, 'digital', True, True), ('digital_050', 50, 'digital', True, False),
    ('digital_060', 60, 'digital', True, False),
    ('sram_005', 5, 'sram', True, True), ('sram_006', 6, 'sram', True, False),
    ('sram_010', 10, 'sram', True, False), ('sram_020', 20, 'sram', False, False),
    ('both_005', 5, 'both', True, True), ('both_010', 10, 'both', True, False),
    ('digital_elsewhere_060', 60, 'digital_elsewhere', True, True),
    ('sram_elsewhere_010', 10, 'sram_elsewhere', True, True),
    ('digital_partial_060', 60, 'digital_partial', True, True),
    ('digital_hole_060', 60, 'digital_hole', True, True),
    ('sram_directional_010', 10, 'sram_directional', True, True),
]
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'utc': datetime.now(timezone.utc).isoformat(),
    'wall_limit_per_run': 60, 'cases': cases, 'types': ['ndc', 'pdc', 'nsc'],
    'description': 'For each actual contact type, place flat GDS Activ/Cont/Metal1 and real DigiBnd/SRAM markers. Test both sides of the intended bounds, marker priority, missing/remote/partial/holed markers, the unchanged SRAM directional constraint and an unrelated undersized Metal2 shape. A 6 nm synthetic enclosure isolates rounding behavior; full-rule off-grid findings are preserved, not accepted as legal layout.',
    'scope': 'Diagnostic controls only; original and experimental full DRC commands execute without rule/count filtering. Cnt.c category interpretation is used only for this focused comparison.'}
(out / 'declared-decision.json').write_bytes((json.dumps(decision, indent=2) + '\n').encode())
layout = db.Layout()
layout.dbu = .001
top = layout.create_cell('CONTACT_TESTS')
layers = {name: layout.layer(n, 0) for name, n in [('activ', 1), ('cont', 6), ('metal1', 8), ('metal2', 10), ('psd', 14), ('nwell', 31), ('digital', 16), ('sram', 25)]}
expected = {'original': [], 'proposed': []}
sites = []
for row, kind in enumerate(('ndc', 'pdc', 'nsc')):
    for col, (label, enc, marker, old_bad, new_bad) in enumerate(cases):
        x, y = 2000 + col * 12000, 2000 + row * 12000
        name = kind + '_' + label
        def put(layer, box):
            top.shapes(layers[layer]).insert(db.Box(*box).transformed(db.Trans(x, y)))
        vertical = 10 if marker == 'sram_directional' else 70
        put('activ', (-enc, -vertical, 160 + enc, 160 + vertical))
        put('cont', (0, 0, 160, 160))
        put('metal1', (-100, -100, 260, 260))
        if kind in ('pdc', 'nsc'):
            put('nwell', (-1000, -1000, 1160, 1160))
        if kind == 'pdc':
            put('psd', (-200, -200, 360, 360))
        if marker.startswith('digital') or marker == 'both':
            if marker == 'digital_elsewhere':
                put('digital', (2000, 2000, 3000, 3000))
            elif marker == 'digital_partial':
                put('digital', (80, -1000, 1160, 1160))
            elif marker == 'digital_hole':
                region = db.Region(db.Box(-1000, -1000, 1160, 1160)) - db.Region(db.Box(-500, -500, 660, 660))
                for polygon in region:
                    top.shapes(layers['digital']).insert(polygon.transformed(db.Trans(x, y)))
            else:
                put('digital', (-1000, -1000, 1160, 1160))
        if marker.startswith('sram') or marker == 'both':
            box = (2000, 2000, 3000, 3000) if marker == 'sram_elsewhere' else (-1000, -1000, 1160, 1160)
            put('sram', box)
        for key, bad in [('original', old_bad), ('proposed', new_bad)]:
            if bad:
                expected[key].append(name)
        sites.append({'name': name, 'x_nm': x, 'y_nm': y, 'kind': kind, 'marker': marker,
            'x_enclosure_nm': enc, 'y_enclosure_nm': vertical})
top.shapes(layers['metal2']).insert(db.Box(-3000, -3000, -2950, -2950))
gds = out / 'controls.gds'
layout.write(str(gds))
(out / 'sites.json').write_bytes((json.dumps({'sites': sites, 'expected_failing_cases': expected}, indent=2) + '\n').encode())
scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
original_env = (root / 'build/g2-sram-macro-drc-probe-05/_env.tcl').read_text()
result = {'status': 'RUNNING', 'gds_sha256': hashlib.sha256(gds.read_bytes()).hexdigest(), 'runs': {}, 'full_physical_qualification': 'OPEN'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
for key, tech in [('original', pdk / 'libs.tech/magic'), ('proposed', root / 'build/g2-sram-contact-rule-probe-04/magic')]:
    work = out / key
    work.mkdir()
    (work / 'reports').mkdir()
    text = original_env
    for setting, value in [('DESIGN_NAME', 'CONTACT_TESTS'), ('CURRENT_GDS', str(gds)), ('STEP_DIR', str(work))]:
        text, count = re.subn(r'^set ::env\(' + setting + r'\) .*$', 'set ::env(' + setting + ') ' + value, text, flags=re.M)
        assert count == 1
    (work / '_env.tcl').write_text(text)
    command = ['magic', '-dnull', '-noconsole', '-rcfile', str(tech / 'ihp-sg13cmos5l.magicrc'), str(scripts / 'wrapper.tcl')]
    command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'contact-control', str(work), *command]
    execution = execute(command, work / 'run.log', 60, env=dict(os.environ, _TCL_ENV_IN=str(work / '_env.tcl'), _MAGIC_SCRIPT=str(scripts / 'drc.tcl')))
    result['runs'][key] = {'execution': execution}
    save()
    assert execution['returncode'] == 0 and not execution['timed_out']
    report = (work / 'reports/drc.magic.rpt').read_text()
    category = ''
    violations = []
    all_categories = {}
    for line in report.splitlines()[1:]:
        if not line or line.startswith(('-', '[INFO]')):
            continue
        if line.startswith(' '):
            coords = [float(v.removesuffix('um')) * 1000 for v in line.split()]
            all_categories[category] = all_categories.get(category, 0) + 1
            if '(Cnt.c' in category:
                cx, cy = (coords[0] + coords[2]) / 2, (coords[1] + coords[3]) / 2
                matching = [s['name'] for s in sites if abs(s['x_nm'] + 80 - cx) < 500 and abs(s['y_nm'] + 80 - cy) < 500]
                assert len(matching) == 1, (category, coords, matching)
                violations.append({'case': matching[0], 'category': category, 'rectangle_nm': coords})
        else:
            category = line
    observed = sorted({v['case'] for v in violations})
    result['runs'][key].update(observed_failing_cases=observed, expected_failing_cases=sorted(expected[key]),
        category_counts=all_categories, contact_findings=violations, matched=observed == sorted(expected[key]))
    save()
result['status'] = 'PASS_CONTACT_BOUNDARY_CONTROLS' if all(r['matched'] for r in result['runs'].values()) else 'REJECTED_CONTACT_BOUNDARY_CONTROLS'
save()
print(result['status'])
for name, value in result['runs'].items():
    print(name, 'unexpected', sorted(set(value['observed_failing_cases']) - set(value['expected_failing_cases'])), 'missed', sorted(set(value['expected_failing_cases']) - set(value['observed_failing_cases'])))
