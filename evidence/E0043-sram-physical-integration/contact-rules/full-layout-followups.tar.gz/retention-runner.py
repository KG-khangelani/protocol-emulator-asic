"""Retain the separately declared one-hour diagnostics as inconclusive."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/contact-rules'
assert not (out / 'full-layout-followups.tar.gz').exists()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files, outcomes = {}, {}
for label, folder in [('original', 'g2-sram-import-schedule-probe-04'), ('aligned', 'g2-sram-contact-full-probe-02')]:
    base = root / 'build' / folder
    result = json.loads((base / 'result.json').read_bytes())
    declared = json.loads((base / 'declared-decision.json').read_bytes())
    assert result['status'] == 'INCONCLUSIVE_TIMEOUT' and result['execution']['timed_out']
    assert result['execution']['returncode'] == 124 and result['execution']['wall_limit'] == declared['wall_limit'] == 3600
    assert 'reported_count' not in result and (base / 'reports/drc.magic.rpt').read_bytes() == b''
    assert 'DIAGNOSTIC FULL DRC START' in (base / 'run.log').read_text()
    outcomes[label] = result
    for path in base.rglob('*'):
        if path.is_file():
            files[label + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
assert files['original/drc-scheduled.tcl'] == files['aligned/drc-scheduled.tcl']
assert files['original/drc-original.tcl'] == files['aligned/drc-original.tcl']
assert sha(files['original/drc-original.tcl']) == '815c0ada08d55bb0b3b5c84cd80e0620590897b7f3e8e3c7c3d3f117bbe1f74b'
files['retention-runner.py'] = Path(__file__).read_bytes()
with (out / 'full-layout-followups.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
raw = (out / 'full-layout-followups.tar.gz').read_bytes()
(out / 'full-layout-followups.json').write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
    'files': {n: sha(r) for n, r in sorted(files.items())}, 'outcomes': outcomes,
    'qualification': 'NO_MANUFACTURING_RESULT',
    'next': 'Do not extend these attempts. Complete the already running corrected official workflow under its original 180-minute GDS limit.'}, indent=2) + '\n').encode())
print('RETAINED_ONE_HOUR_TIMEOUTS', len(files), len(raw))
