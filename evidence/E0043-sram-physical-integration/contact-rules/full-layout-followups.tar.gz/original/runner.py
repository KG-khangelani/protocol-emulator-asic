"""Bound a background-check scheduling experiment with every full DRC rule."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

base = root / 'build/g2-sram-full-05/runs/integrated/66-magic-drc'
out = root / 'build/g2-sram-import-schedule-probe-04'
assert not out.exists()
out.mkdir()
(out / 'reports').mkdir()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
scripts = Path('/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/magic')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
gds = Path(json.loads((base / 'state_in.json').read_bytes())['gds'])
decision = {'status': 'DECLARED_BEFORE_EXECUTION', 'utc': datetime.now(timezone.utc).isoformat(), 'wall_limit': 3600,
    'followup_reason': 'Both earlier 1200-second complete-layout trials reached the explicit full DRC phase on a hierarchy with over 155000 uses and ended without a report. Retain their incomplete outcomes and separate report-parser error. Increase only this separately declared diagnostic bound to 3600 seconds; actual geometry, complete DRC and original official/full-flow limits are unchanged.',
    'hypothesis': 'Background DRC during GDS import may explain why full trial 05 has spent over an hour before the explicit top-cell full DRC call, while the isolated macro completed in six minutes.',
    'change': 'Turn background DRC off only around gds read, then turn it back on. Retain the entire original synchronous full-rule DRC, its count/report handling, original unmodified PDK and exact full05 GDS. Add flushed phase markers around read and explicit DRC for diagnosis.',
    'gds_sha256': sha(gds), 'original_script_sha256': sha(scripts / 'drc.tcl'),
    'scope': 'Diagnostic only; every original/full acceptance run is unchanged and remains open.'}
(out / 'declared-decision.json').write_bytes((json.dumps(decision, indent=2) + '\n').encode())
script = (scripts / 'drc.tcl').read_text()
anchor = '    gds read $::env(CURRENT_GDS)'
assert script.count(anchor) == 1
script = script.replace(anchor, '''    puts stdout "DIAGNOSTIC READ START"
    flush stdout
    drc off
    gds read $::env(CURRENT_GDS)
    drc on
    puts stdout "DIAGNOSTIC READ FINISHED"
    flush stdout''')
anchor = 'set drcresult [drc listall why]'
assert script.count(anchor) == 1
script = script.replace(anchor, '''puts stdout "DIAGNOSTIC FULL DRC START"
flush stdout
set drcresult [drc listall why]
puts stdout "DIAGNOSTIC FULL DRC FINISHED"
flush stdout''')
(out / 'drc-scheduled.tcl').write_text(script)
(out / 'drc-original.tcl').write_bytes((scripts / 'drc.tcl').read_bytes())
env = (base / '_env.tcl').read_text()
assert 'set ::env(STEP_DIR) ' not in env
env += '\nset ::env(STEP_DIR) ' + str(out) + '\n'
(out / '_env.tcl').write_text(env)
command = ['magic', '-dnull', '-noconsole', '-rcfile', str(pdk / 'libs.tech/magic/ihp-sg13cmos5l.magicrc'), str(scripts / 'wrapper.tcl')]
command = ['sh', '-c', 'cd "$1" && shift && exec "$@"', 'import-schedule-probe', str(out), *command]
result = {'status': 'RUNNING_DIAGNOSTIC', 'gds_sha256': sha(gds), 'full_physical_qualification': 'OPEN'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
result['execution'] = execute(command, out / 'run.log', 3600, env=dict(os.environ, _TCL_ENV_IN=str(out / '_env.tcl'), _MAGIC_SCRIPT=str(out / 'drc-scheduled.tcl')))
result['status'] = 'INCONCLUSIVE_TIMEOUT' if result['execution']['timed_out'] else 'INCOMPLETE_OR_FAILED_DIAGNOSTIC'
save()
report = out / 'reports/drc.magic.rpt'
if report.exists():
    counts = re.findall(r'\[INFO\] COUNT: (\d+)', report.read_text())
    if counts:
        result['reported_count'] = int(counts[-1])
        if result['execution']['returncode'] == 0 and not result['execution']['timed_out']:
            result['status'] = 'COMPLETED_REQUIRES_REVIEW'
assert sha(gds) == result['gds_sha256']
save()
print(json.dumps(result, indent=2))
