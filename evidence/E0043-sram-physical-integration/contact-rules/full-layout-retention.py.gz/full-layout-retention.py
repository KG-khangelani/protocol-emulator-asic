"""Preserve both bounded whole-layout attempts and their reporting error."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root=Path(__file__).resolve().parents[1]
out=root/'evidence/E0043-sram-physical-integration/contact-rules'
archive_path=out/'full-layout-incomplete.tar.gz'
assert not archive_path.exists()
files={}
for label,name in [('original','g2-sram-import-schedule-probe-03'),('aligned','g2-sram-contact-full-probe-01')]:
    base=root/'build'/name
    review=json.loads((base/'completion-review.json').read_bytes())
    assert review['status']=='INCOMPLETE_AFTER_DECLARED_BOUND_WITH_REPORTING_ERROR' and review['report_bytes']==0
    for path in sorted(base.rglob('*')):
        if path.is_file():files[label+'/'+path.relative_to(base).as_posix()]=path.read_bytes()
for label,name in [('original','g2-sram-import-schedule-probe-04'),('aligned','g2-sram-contact-full-probe-02')]:
    base=root/'build'/name
    for filename in ('runner.py','declared-decision.json','drc-scheduled.tcl','drc-original.tcl','_env.tcl'):
        files['followup-declarations/'+label+'/'+filename]=(base/filename).read_bytes()
with archive_path.open('wb') as stream:
    with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as bundle:
            for name,raw in sorted(files.items()):
                item=tarfile.TarInfo(name)
                item.size,item.mode,item.mtime=len(raw),0o644,0
                bundle.addfile(item,io.BytesIO(raw))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
raw=archive_path.read_bytes()
index={'bytes':len(raw),'sha256':sha(raw),'files':{n:sha(v) for n,v in sorted(files.items())}}
(out/'full-layout-incomplete-index.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
(out/'full-layout-retention.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('RETAINED_INCOMPLETE_FULL_DRC',len(files),len(raw))
