"""Bound an independent unchanged native extraction/LVS diagnostic on trial 05."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

base = root / 'build/g2-sram-full-05'
out = root / 'build/g2-sram-guarded-lvs-probe-01'
assert not out.exists()
out.mkdir()
read = lambda p: json.loads(p.read_bytes())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
initial = base / 'runs/integrated/66-magic-drc/state_in.json'
state = read(initial)
resolved = read(base / 'runs/integrated/resolved.json')
assert resolved['meta']['flow'] == 'SramGuardedClassic'
assert resolved['ERROR_ON_LVS_ERROR'] and resolved['ERROR_ON_ILLEGAL_OVERLAPS']
result = {'status': 'DECLARED_BEFORE_EXECUTION', 'declared_utc': datetime.now(timezone.utc).isoformat(),
          'wall_limit': 600, 'source_trial': 'g2-sram-full-05',
          'scope': 'Separate diagnostic of native Magic extraction, illegal-overlap checker and Netgen LVS on the exact corrected routed design. No geometry, rule, source, acceptance setting or full trial is changed. Full manufacturing qualification and official checks remain required.',
          'config_sha256': sha(base / 'src/config_merged.json'), 'resolved_sha256': sha(base / 'runs/integrated/resolved.json'),
          'initial_state_sha256': sha(initial),
          'input_view_sha256': {name: sha(Path(state[name])) for name in ('gds', 'mag_gds', 'mag', 'nl', 'pnl', 'odb')}}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'initial-state.json').write_bytes(initial.read_bytes())
command = ['librelane', '--pdk-root', '/pdk', '--pdk', 'ihp-sg13cmos5l',
           '--run-tag', 'guarded-lvs-probe', '--force-run-dir', str(out / 'run'),
           '--design-dir', str(base), '--with-initial-state', str(out / 'initial-state.json'),
           '--from', 'Magic.SpiceExtraction', '--to', 'Checker.LVS', str(base / 'src/config_merged.json')]
result['execution'] = execute(command, out / 'run.log', result['wall_limit'], env=dict(os.environ, PYTHONPATH=str(base)))
result['status'] = 'INCONCLUSIVE_TIMEOUT' if result['execution']['timed_out'] else 'NATIVE_DIAGNOSTIC_REJECTED'
save()
assert result['execution']['returncode'] == 0 and not result['execution']['timed_out']
finals = list((out / 'run').glob('*-checker-lvs/state_out.json'))
assert len(finals) == 1
metrics = read(finals[0])['metrics']
assert metrics['design__lvs_error__count'] == metrics['magic__illegal_overlap__count'] == 0
assert sha(base / 'src/config_merged.json') == result['config_sha256'] and sha(initial) == result['initial_state_sha256']
assert {name: sha(Path(state[name])) for name in result['input_view_sha256']} == result['input_view_sha256']
result.update(status='PASS_SCOPED_NATIVE_EXTRACTION_AND_LVS', lvs_errors=0, illegal_overlaps=0,
              final_state_sha256=sha(finals[0]), full_physical_qualification='OPEN')
save()
print(result['status'])
