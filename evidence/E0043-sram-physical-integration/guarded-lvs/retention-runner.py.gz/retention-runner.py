"""Retain the bounded native LVS diagnostic, including the launch error."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
out = root / 'evidence/E0043-sram-physical-integration/guarded-lvs'
assert not out.exists()
files = {}
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
for label, name in [('launch-error', 'g2-sram-guarded-lvs-probe-01'), ('passed', 'g2-sram-guarded-lvs-probe-02')]:
    base = root / 'build' / name
    for path in sorted(base.rglob('*')):
        if path.is_file():
            files[label + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
    runtime = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert runtime['Image'] == runtime['Config']['Image'] == 'sha256:b4f7c1e0f99a5d5b419571277a3e93bac37ea22eb7e4af3787d59927b73067c5'
    assert runtime['State']['Status'] == 'exited'
    assert runtime['State']['ExitCode'] == (1 if label == 'launch-error' else 0)
    files[label + '/runtime.json'] = (json.dumps({'image_id': runtime['Image'], 'configured_image': runtime['Config']['Image'],
        'state': runtime['State'], 'command': runtime['Config']['Cmd'],
        'mounts': [m for m in runtime['Mounts'] if m['Destination'] in ('/workspace', '/pdk')]}, indent=2) + '\n').encode()
base = root / 'build/g2-sram-full-05'
for name in ('preparation.json', 'runtime-observation.json', 'librelane_plugin_sram.py', 'audit_sram_pin_power.py',
             'sram_power_step.py', 'connect_sram_power.py', 'check_sram_power.tcl', 'sram_input_buffers.tcl', 'audit_sram_input_buffers.py'):
    files['source/' + name] = (base / name).read_bytes()
for path in (base / 'src').iterdir():
    if path.is_file():
        files['source/src/' + path.name] = path.read_bytes()
files['source/original-resolved.json'] = (base / 'runs/integrated/resolved.json').read_bytes()
files['source/portable-pin-audit.py'] = (root / 'experiments/i2c/audit_sram_pin_power.py').read_bytes()
files['candidate.json'] = (root / 'evidence/E0042-sram-prefetch-screen/candidate.json').read_bytes()
out.mkdir()
with (out / 'diagnostic.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
raw = (out / 'diagnostic.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'bytes': len(raw), 'sha256': sha(raw),
    'files': {n: sha(v) for n, v in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_GUARDED_NATIVE_LVS_DIAGNOSTIC', len(files), len(raw))
