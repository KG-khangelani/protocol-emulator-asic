"""Bound the original precheck's complete CMOS5L KLayout rule deck on trial 05."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path('/workspace')
sys.path.insert(0, str(root / 'experiments/spi_phase'))
from run_program_sensitivity import execute

base = root / 'build/g2-sram-full-05'
out = root / 'build/g2-sram-guarded-klayout-probe-01'
assert not out.exists()
out.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = json.loads((base / 'runs/integrated/66-magic-drc/state_in.json').read_bytes())
gds = Path(state['gds'])
pdk = Path('/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l')
deck = pdk / 'libs.tech/klayout/tech/drc/ihp-sg13cmos5l.drc'
report = out / 'drc.xml'
result = {'status': 'DECLARED_BEFORE_EXECUTION', 'declared_utc': datetime.now(timezone.utc).isoformat(),
    'source_trial': 'g2-sram-full-05', 'wall_limit': 900, 'gds_sha256': sha(gds),
    'pinned_support_revision': '9d13ff3e3e6202090740110438c6a10c1d62ca0f',
    'precheck_source_sha256': sha(root / 'build/g2-sram-precheck-reference.py'),
    'klayout_version': subprocess.check_output(['klayout', '-v'], text=True).strip(),
    'rule_files': {str(p.relative_to(deck.parent)): sha(p) for p in sorted(deck.parent.rglob('*')) if p.is_file()},
    'scope': 'Independent bounded diagnostic of the exact original precheck rule-deck command on trial 05 GDS, using the pinned physical image KLayout 0.30.12. No rule, geometry or setting changed. This does not run the other nine prechecks or replace the original Magic DRC/full flow or official workflow.'}
save = lambda: (out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
(out / 'precheck-reference.py').write_bytes((root / 'build/g2-sram-precheck-reference.py').read_bytes())
command = ['klayout', '-b', '-r', str(deck), '-rd', 'sg13cmos5l=true', '-rd', 'input=' + str(gds),
           '-rd', 'thr=1', '-rd', 'report=' + str(report), '-rd', 'report_file=' + str(report)]
result['execution'] = execute(command, out / 'run.log', result['wall_limit'],
    env=dict(os.environ, PDK_ROOT=str(pdk.parent), PDK='ihp-sg13cmos5l'))
result['status'] = 'INCONCLUSIVE_TIMEOUT' if result['execution']['timed_out'] else 'NATIVE_COMMAND_FAILED'
save()
assert result['execution']['returncode'] == 0 and not result['execution']['timed_out']
assert sha(gds) == result['gds_sha256']
items = ET.parse(report).getroot().findall('.//items/item')
counts = {}
for item in items:
    name = item.findtext('category')
    counts[name] = counts.get(name, 0) + 1
result.update(status='REJECTED_KLAYOUT_RULE_DECK' if items else 'PASS_SCOPED_KLAYOUT_RULE_DECK',
              violations=len(items), categories=counts, report_sha256=sha(report), full_physical_qualification='OPEN')
save()
print(result['status'], len(items))
