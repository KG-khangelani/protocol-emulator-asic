`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  wire [0:0] PI_clk = clock;
  public_spi UUT (
    .clk(PI_clk)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$5664  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5694  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5700  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5706  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5712  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5718  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5724  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5730  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5736  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5742  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5748  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5754  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5760  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5778  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5784  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5790  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5802  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$5392  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5398  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5404  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5410  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5416  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5422  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5428  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5434  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5440  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5446  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5452  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5458  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5464  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5470  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5476  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5482  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5488  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5494  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5500  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5506  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5512  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5518  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5524  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5530  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5536  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5542  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5548  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5554  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5560  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5566  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5572  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5578  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5584  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5590  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5596  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5602  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5608  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5614  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5620  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5626  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5632  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5638  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5644  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5650  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5656  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5662  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5668  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5674  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5680  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5686  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5692  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5698  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5704  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5710  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5716  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5722  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5728  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5734  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5740  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5746  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5752  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5758  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5764  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5770  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5776  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5782  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5788  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5794  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5800  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5806  = 1'b1;
    UUT._witness_.anyinit_procdff_5212 = 1'b1;
    UUT._witness_.anyinit_procdff_5213 = 8'b00100000;
    UUT._witness_.anyinit_procdff_5214 = 1'b1;
    UUT._witness_.anyinit_procdff_5215 = 1'b0;
    UUT._witness_.anyinit_procdff_5216 = 1'b1;
    UUT._witness_.anyinit_procdff_5217 = 8'b00001000;
    UUT._witness_.anyinit_procdff_5218 = 8'b00001000;
    UUT.cycle = 9'b000000000;
    UUT.dut.data_store.rx_result = 8'b00100000;
    UUT.dut.data_store.rx_valid = 1'b1;
    UUT.dut.data_store.tx_payload = 8'b00000010;
    UUT.dut.data_store.tx_payload_alt = 8'b00000000;
    UUT.dut.engine.gpio_oe = 8'b10000000;
    UUT.dut.engine.gpio_value = 8'b00001000;
    UUT.dut.engine.loop_active = 1'b0;
    UUT.dut.engine.loop_end = 5'b00001;
    UUT.dut.engine.loop_remaining = 8'b00000000;
    UUT.dut.engine.loop_start = 5'b10000;
    UUT.dut.engine.pc = 5'b01000;
    UUT.dut.engine.phase_active = 1'b0;
    UUT.dut.engine.phase_prepared = 1'b0;
    UUT.dut.engine.shift_active = 1'b0;
    UUT.dut.engine.shift_bits_done = 3'b000;
    UUT.dut.engine.shift_msb_first = 1'b0;
    UUT.dut.engine.shift_period = 16'b0000000010000000;
    UUT.dut.engine.shift_rx_data = 8'b00010010;
    UUT.dut.engine.shift_rx_pin = 3'b000;
    UUT.dut.engine.shift_tx_data = 8'b01000000;
    UUT.dut.engine.shift_tx_pin = 3'b000;
    UUT.dut.engine.shift_tx_slot = 1'b1;
    UUT.dut.engine.state = 2'b00;
    UUT.dut.engine.wait_is_input = 1'b0;
    UUT.dut.engine.wait_left = 16'b0000000100000000;
    UUT.dut.engine.wait_level = 1'b0;
    UUT.dut.engine.wait_pin = 3'b000;
    UUT.dut.engine.wait_timeout_skip = 1'b0;
    UUT.dut.input_sync.metastability_stage = 8'b00000000;
    UUT.dut.input_sync.sampled_in = 8'b00000000;
    UUT.dut.store.program_length = 4'b0001;
    UUT.dut.store.program_ready = 1'b1;
    UUT.dut.store.word0 = 32'b00100010000000000000000000000000;
    UUT.dut.store.word1 = 32'b00000001000001000010000000000000;
    UUT.dut.store.word2 = 32'b00000000000010000000000100000000;
    UUT.dut.store.word3 = 32'b10000000000000000000000000000100;
    UUT.dut.store.word4 = 32'b00000000000000000100000000000000;
    UUT.dut.store.word5 = 32'b00000000001000000000001000000100;
    UUT.dut.store.word6 = 32'b00010000000000100000100000000000;
    UUT.dut.store.word7 = 32'b00000000000000000000000000000000;
    UUT.history1 = 1'b0;
    UUT.history2 = 1'b0;
    UUT.reference_meta = 8'b00001000;
    UUT.reference_sampled = 8'b00000010;
    UUT.tx_byte = 8'b10001000;
    UUT.msb_first = 1'b0;
    UUT.rx_byte = 8'b01111100;
    UUT.cpol = 1'b0;

    // state 0
    UUT.raw_miso = 1'b0;
    UUT.select_valid = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 2
    if (cycle == 1) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 4
    if (cycle == 3) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 5
    if (cycle == 4) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 6
    if (cycle == 5) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 7
    if (cycle == 6) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 8
    if (cycle == 7) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 9
    if (cycle == 8) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 10
    if (cycle == 9) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 11
    if (cycle == 10) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 12
    if (cycle == 11) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 13
    if (cycle == 12) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 14
    if (cycle == 13) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 15
    if (cycle == 14) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 16
    if (cycle == 15) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 17
    if (cycle == 16) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 18
    if (cycle == 17) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 19
    if (cycle == 18) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 20
    if (cycle == 19) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 21
    if (cycle == 20) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 22
    if (cycle == 21) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 23
    if (cycle == 22) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 24
    if (cycle == 23) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 25
    if (cycle == 24) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 26
    if (cycle == 25) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 27
    if (cycle == 26) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 28
    if (cycle == 27) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 29
    if (cycle == 28) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 30
    if (cycle == 29) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 31
    if (cycle == 30) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 32
    if (cycle == 31) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 33
    if (cycle == 32) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 34
    if (cycle == 33) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 35
    if (cycle == 34) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 36
    if (cycle == 35) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 37
    if (cycle == 36) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 38
    if (cycle == 37) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 39
    if (cycle == 38) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 40
    if (cycle == 39) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 41
    if (cycle == 40) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    genclock <= cycle < 41;
    cycle <= cycle + 1;
  end
endmodule
