`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  wire [0:0] PI_clk = clock;
  public_spi UUT (
    .clk(PI_clk)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$5685  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5715  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5721  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5727  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5733  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5739  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5745  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5751  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5757  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5763  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5769  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5775  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5781  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5799  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5805  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5811  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$5823  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$5413  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5419  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5425  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5431  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5437  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5443  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5449  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5455  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5461  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5467  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5473  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5479  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5485  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5491  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5497  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5503  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5509  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5515  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5521  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5527  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5533  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5539  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5545  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5551  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5557  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5563  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5569  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5575  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5581  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5587  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5593  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5599  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5605  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5611  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5617  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5623  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5629  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5635  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5641  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5647  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5653  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5659  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5665  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5671  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5677  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5683  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5689  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5695  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5701  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5707  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5713  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5719  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5725  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5731  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5737  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5743  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5749  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5755  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5761  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5767  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5773  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5779  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5785  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5791  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5797  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5803  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5809  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5815  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5821  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$5827  = 1'b1;
    UUT._witness_.anyinit_procdff_5233 = 1'b1;
    UUT._witness_.anyinit_procdff_5234 = 8'b00000000;
    UUT._witness_.anyinit_procdff_5235 = 1'b1;
    UUT._witness_.anyinit_procdff_5236 = 1'b0;
    UUT._witness_.anyinit_procdff_5237 = 1'b1;
    UUT._witness_.anyinit_procdff_5238 = 8'b00000000;
    UUT._witness_.anyinit_procdff_5239 = 8'b00000000;
    UUT.cycle = 9'b000000000;
    UUT.dut.data_store.rx_result = 8'b00000100;
    UUT.dut.data_store.rx_valid = 1'b1;
    UUT.dut.data_store.tx_payload = 8'b00000000;
    UUT.dut.data_store.tx_payload_alt = 8'b10000000;
    UUT.dut.engine.gpio_oe = 8'b00001101;
    UUT.dut.engine.gpio_value = 8'b00000000;
    UUT.dut.engine.loop_active = 1'b0;
    UUT.dut.engine.loop_end = 5'b10000;
    UUT.dut.engine.loop_remaining = 8'b00000000;
    UUT.dut.engine.loop_start = 5'b10000;
    UUT.dut.engine.pc = 5'b00000;
    UUT.dut.engine.phase_active = 1'b1;
    UUT.dut.engine.phase_prepared = 1'b0;
    UUT.dut.engine.shift_active = 1'b0;
    UUT.dut.engine.shift_bits_done = 3'b010;
    UUT.dut.engine.shift_msb_first = 1'b0;
    UUT.dut.engine.shift_period = 16'b0000000000000000;
    UUT.dut.engine.shift_rx_data = 8'b00000000;
    UUT.dut.engine.shift_rx_pin = 3'b001;
    UUT.dut.engine.shift_tx_data = 8'b00000000;
    UUT.dut.engine.shift_tx_pin = 3'b010;
    UUT.dut.engine.shift_tx_slot = 1'b0;
    UUT.dut.engine.state = 2'b00;
    UUT.dut.engine.wait_is_input = 1'b0;
    UUT.dut.engine.wait_left = 16'b0000000000000000;
    UUT.dut.engine.wait_level = 1'b0;
    UUT.dut.engine.wait_pin = 3'b100;
    UUT.dut.engine.wait_timeout_skip = 1'b0;
    UUT.dut.input_sync.metastability_stage = 8'b00000010;
    UUT.dut.input_sync.sampled_in = 8'b00000000;
    UUT.dut.store.program_length = 4'b0001;
    UUT.dut.store.program_ready = 1'b1;
    UUT.dut.store.word0 = 32'b00000000000000100000000000000000;
    UUT.dut.store.word1 = 32'b10000000000001000100000010000000;
    UUT.dut.store.word2 = 32'b00000100100000000000000000000000;
    UUT.dut.store.word3 = 32'b10000000000000000000000000000000;
    UUT.dut.store.word4 = 32'b00010000000010000000000010010100;
    UUT.dut.store.word5 = 32'b01000000000000010001000000000000;
    UUT.dut.store.word6 = 32'b00001000000010000000100000000000;
    UUT.dut.store.word7 = 32'b00100000000000000000000000000000;
    UUT.history1 = 1'b0;
    UUT.history2 = 1'b0;
    UUT.reference_meta = 8'b00000000;
    UUT.reference_sampled = 8'b00001000;
    UUT.tx_byte = 8'b00001000;
    UUT.msb_first = 1'b0;
    UUT.rx_byte = 8'b00000010;
    UUT.cpol = 1'b0;

    // state 0
    UUT.raw_miso = 1'b1;
    UUT.select_valid = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 2
    if (cycle == 1) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 4
    if (cycle == 3) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 5
    if (cycle == 4) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 6
    if (cycle == 5) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 7
    if (cycle == 6) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 8
    if (cycle == 7) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 9
    if (cycle == 8) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 10
    if (cycle == 9) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 11
    if (cycle == 10) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 12
    if (cycle == 11) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 13
    if (cycle == 12) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 14
    if (cycle == 13) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 15
    if (cycle == 14) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 16
    if (cycle == 15) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 17
    if (cycle == 16) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 18
    if (cycle == 17) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 19
    if (cycle == 18) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 20
    if (cycle == 19) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 21
    if (cycle == 20) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 22
    if (cycle == 21) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 23
    if (cycle == 22) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 24
    if (cycle == 23) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 25
    if (cycle == 24) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 26
    if (cycle == 25) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 27
    if (cycle == 26) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 28
    if (cycle == 27) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 29
    if (cycle == 28) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 30
    if (cycle == 29) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 31
    if (cycle == 30) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 32
    if (cycle == 31) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 33
    if (cycle == 32) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 34
    if (cycle == 33) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 35
    if (cycle == 34) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 36
    if (cycle == 35) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 37
    if (cycle == 36) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 38
    if (cycle == 37) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 39
    if (cycle == 38) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 40
    if (cycle == 39) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 41
    if (cycle == 40) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 42
    if (cycle == 41) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 43
    if (cycle == 42) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b1;
    end

    // state 44
    if (cycle == 43) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 45
    if (cycle == 44) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 46
    if (cycle == 45) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 47
    if (cycle == 46) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 48
    if (cycle == 47) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 49
    if (cycle == 48) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 50
    if (cycle == 49) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 51
    if (cycle == 50) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 52
    if (cycle == 51) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 53
    if (cycle == 52) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 54
    if (cycle == 53) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 55
    if (cycle == 54) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 56
    if (cycle == 55) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b1;
    end

    // state 57
    if (cycle == 56) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 58
    if (cycle == 57) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 59
    if (cycle == 58) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 60
    if (cycle == 59) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 61
    if (cycle == 60) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 62
    if (cycle == 61) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 63
    if (cycle == 62) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 64
    if (cycle == 63) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 65
    if (cycle == 64) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 66
    if (cycle == 65) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 67
    if (cycle == 66) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 68
    if (cycle == 67) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 69
    if (cycle == 68) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 70
    if (cycle == 69) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 71
    if (cycle == 70) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 72
    if (cycle == 71) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 73
    if (cycle == 72) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 74
    if (cycle == 73) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 75
    if (cycle == 74) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 76
    if (cycle == 75) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b1;
    end

    // state 77
    if (cycle == 76) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 78
    if (cycle == 77) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 79
    if (cycle == 78) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 80
    if (cycle == 79) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 81
    if (cycle == 80) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 82
    if (cycle == 81) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 83
    if (cycle == 82) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 84
    if (cycle == 83) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b0;
    end

    // state 85
    if (cycle == 84) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 86
    if (cycle == 85) begin
      UUT.raw_miso <= 1'b1;
      UUT.select_valid <= 1'b1;
    end

    // state 87
    if (cycle == 86) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b1;
    end

    // state 88
    if (cycle == 87) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    // state 89
    if (cycle == 88) begin
      UUT.raw_miso <= 1'b0;
      UUT.select_valid <= 1'b0;
    end

    genclock <= cycle < 89;
    cycle <= cycle + 1;
  end
endmodule
