import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'experiments/i2c'))
from audit_store_proofs import audit
from tools import physical_g2 as physical

BASE = ROOT / 'build/g2-ci-e5eef5b'
OUT = ROOT / 'build/g2-ci-e5-audit-01'
assert not OUT.exists()
OUT.mkdir()
DEST = ROOT / 'evidence/E0037-explicit-store-lanes/ci/e5'
DEST.mkdir(parents=True, exist_ok=True)
def read(path): return json.loads(path.read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
run, jobs, artifacts = read(BASE / 'run.json'), read(BASE / 'jobs.json')['jobs'], read(BASE / 'artifacts.json')['artifacts']
assert run['id'] == 43238830793 and run['head_sha'] == 'e5eef5b413a9423ca6b6ea8bc463f2bb0673ee03'
assert run['status'] == 'completed' and run['conclusion'] == 'success'
names = ('od128', 'literal255', 'architecture', 'physical-selection', 'store', 'lanes-selection', 'lanes-store')
assert sorted(j['name'] for j in jobs) == sorted('qualify (' + n + ')' for n in names)
assert all(j['status'] == 'completed' and j['conclusion'] == 'success' and j['run_id'] == run['id'] for j in jobs)
sources = physical.candidate_manifest('od128-lanes')['source_sha256']
verified = {}
for gate, ident in (('lanes-selection', 13954448623), ('lanes-store', 13953159096)):
    selected = [a for a in artifacts if a['id'] == ident]
    assert len(selected) == 1
    item = selected[0]
    assert item['name'] == 'i2c-general-' + gate + '-' + run['head_sha']
    assert item['workflow_run']['id'] == run['id'] and item['workflow_run']['head_sha'] == run['head_sha']
    packed = BASE / (str(ident) + '.zip')
    assert packed.stat().st_size == item['size_in_bytes'] and 'sha256:' + sha(packed) == item['digest']
    with zipfile.ZipFile(packed) as archive:
        entries = archive.namelist()
        assert len(entries) == len(set(entries))
        for name in entries:
            if not name.endswith('/'):
                assert archive.read(name) == (BASE / str(ident) / name).read_bytes()
    path = BASE / str(ident)
    assert physical.verify_sources(path / 'variants/od128/src', 'od128-lanes') == sources
    result = read(path / 'result.json')
    assert result['sources']['od128']['source_sha256'] == sources
    if gate == 'lanes-selection':
        assert result['status'] == 'PASS_LANES_PUBLIC_SELECTION'
        selection = read(path / 'selection/result.json')
        assert selection['status'] == 'PASS_G2_PHYSICAL_SELECTION_ON_BOTH_RTL_SIMULATORS' and selection['sources'] == sources
        assert [s['simulator'] for s in selection['stages']] == ['icarus', 'verilator']
        for stage in selection['stages']:
            sim = stage['simulator']
            stage_path = path / 'selection' / sim
            assert stage['returncode'] == 0
            identity = 'Running on Icarus Verilog' if sim == 'icarus' else 'Running on Verilator'
            assert identity in (stage_path / 'run.log').read_text()
            checked = OUT / (sim + '.json')
            physical.check_tests(SimpleNamespace(junit=stage_path / 'results.xml', records=stage_path / 'records',
                                                output=checked, require_netlist=False))
            assert read(checked) == stage['check']
    else:
        assert result['status'] == 'PASS_LANES_AUDITED_STORE'
        proof = path / 'store'
        proof_result = read(proof / 'result.json')
        assert proof_result['status'] == 'PASS_SELECTED_STORE_TASKS'
        runner = subprocess.check_output(['git', 'show', run['head_sha'] + ':experiments/i2c/run_store_local_proof.py'], cwd=ROOT)
        assert hashlib.sha256(runner).hexdigest() == proof_result['runner_sha256']
        for task in proof_result['tasks']:
            directory = proof / task['directory']
            target = directory / 'proof/src'
            target.mkdir(parents=True, exist_ok=True)
            if task['name'] in ('state', 'read'):
                shutil.copyfile(proof / 'od128-model/prepared.il', target / 'prepared.il')
            else:
                shutil.copyfile(directory / 'store.v', target / 'store.v')
        observed = audit(proof, proof, 'od128', (path / 'audit/od128.positive.json').read_bytes(), 'explicit-lanes')
        assert observed == {k:v for k,v in read(path / 'audit/od128.json').items() if k != 'positive_checkpoint'}
        assert observed['assertions'] == 652 and observed['positive_task_count'] == 33 and len(observed['negative_controls']) == 2
        checked = OUT / 'auditor-controls.json'
        subprocess.run([sys.executable, str(ROOT / 'experiments/i2c/falsify_store_audit.py'),
                        '--positive', str(proof), '--controls', str(proof), '--snapshot', str(path / 'audit/od128.positive.json'),
                        '--source-revision', 'explicit-lanes', '--output', str(checked)], cwd=ROOT, check=True)
        assert read(checked) == read(path / 'audit/auditor-controls.json')
    target = DEST / (gate + '-original.zip')
    shutil.copyfile(packed, target)
    verified[gate] = {'artifact_id': ident, 'sha256': sha(packed), 'retained_file': target.name}
for name in ('run.json', 'jobs.json', 'artifacts.json'):
    shutil.copyfile(BASE / name, DEST / name)
report = {'status': 'PASS_AUDITED_LANES_CI', 'run_id': run['id'], 'source_commit': run['head_sha'],
          'all_seven_jobs_successful': True, 'source_sha256': sources, 'audited_archives': verified,
          'store_assertions': 652, 'positive_store_tasks': 33, 'checked_mutations': 2, 'replayed_auditor_controls': 9,
          'public_groups_per_simulator': 18, 'all_reference_records_identical': True,
          'scope': 'Both new D38 archives are fully byte/source/proof/public-record audited. The other five job successes are observed from GitHub; their current archives are not re-audited here. This commit predates the separately retained style review and the fresh-checkout unit-test fix.',
          'physical': 'Separate 869ee34 run43241097269 is still required'}
(DEST / 'verification.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
(DEST / 'verification-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(report['status'])
