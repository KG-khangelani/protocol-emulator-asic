import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0037-explicit-store-lanes/shared-read-screen'
OUT.mkdir(parents=True, exist_ok=True)
retained = {}
for attempt in ('01', '02', '03'):
    base = ROOT / ('build/g2-shared-read-' + attempt)
    paths = [base / 'result.json']
    if attempt == '03':
        paths += [base / p for p in ('src/m1_program_store.v', 'gold.v', 'gate.v', 'synth.ys', 'proof.ys', 'synthesis.log', 'equivalence.log')]
        paths += [ROOT / 'build/screen_g2_shared_read.py']
    else:
        paths += [base / 'runner.py']
    for path in paths:
        name = 'attempt-' + attempt + '/' + (path.relative_to(base).as_posix() if path.is_relative_to(base) else 'runner.py')
        target = OUT / (name + '.gz')
        raw = path.read_bytes()
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(raw, mtime=0))
        retained[name] = {'original_sha256': hashlib.sha256(raw).hexdigest(),
                          'retained_file': target.relative_to(OUT).as_posix(),
                          'retained_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
result = json.loads((ROOT / 'build/g2-shared-read-03/result.json').read_bytes())
assert result['status'] == 'PASS_BOUNDED_SHARED_READ_SCREEN'
assert result['counts']['primitive_cells'] == 15211 and result['counts']['state_bits'] == 4278
assert result['conditional_store_equivalence']['returncode'] == 0 and not result['conditional_store_equivalence']['timed_out']
report = {'status': 'PROMISING_CONDITIONAL_SCREEN_NOT_ADOPTED', 'sources': result['sources'],
          'parent_sources': result['parent_sources'], 'primitive_cells': 15211, 'parent_primitive_cells': 24391,
          'generic_reduction_percent': round(100 * (24391 - 15211) / 24391, 6), 'unchanged_state_bits': 4278,
          'conditional_store_equivalence': result['conditional_store_equivalence'],
          'scope': 'Compare instruction only outside store load mode and data_out only inside load mode. All other outputs/state are compared normally from corresponding state; identical reset establishes correspondence. Top ownership is a source-derived premise, not a full-chip proof.',
          'initial_failures': '01 expected a different always-block spelling. 02 matched through the combined read/fetch block and then rejected missing fetch. Both stopped before synthesis; original results and runner bytes retained. 03 preserves length readback and evaluates instruction before selecting its byte.',
          'missing_gates': 'Public regression, architecture/negative controls, mapped/routed qualification and adoption. D38 physical trial remains separate.',
          'retained': retained}
(OUT / 'verification.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(report['status'], report['generic_reduction_percent'])
