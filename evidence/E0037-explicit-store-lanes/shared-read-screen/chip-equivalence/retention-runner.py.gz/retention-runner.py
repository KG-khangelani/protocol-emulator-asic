import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0037-explicit-store-lanes/shared-read-screen/chip-equivalence'
OUT.mkdir(parents=True, exist_ok=True)
def read(path): return json.loads(path.read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
base = ROOT / 'build/g2-shared-read-chip-01'
temporal = read(base / 'result.json')
reset = read(ROOT / 'build/g2-shared-read-reset-02/result.json')
assert temporal['status'] == 'PASS_CORRESPONDING_STATE_CHIP_EQUIVALENCE'
assert temporal['state_bits_per_chip'] == 4278 and temporal['public_output_bits_compared'] == 24
assert temporal['all_comparisons_proven'] == reset['compared_bits_including_aliases'] == 4572
assert reset['status'] == 'PASS_RESET_ESTABLISHES_CORRESPONDENCE' and reset['assertion_cells'] == 217
log = (base / 'proof.log').read_text()
assert 'Proving induction step 1.' in log and 'Entire workset of 4516 cells proven!' in log
assert 'Proving induction step 2.' not in log and '0 are unproven.' in log
assert 'sat -verify -seq 2 -set-at 1 rst_n 0 -prove-asserts -prove-skip 1 -set-def-inputs' in (ROOT / 'build/g2-shared-read-reset-02/proof.ys').read_text()
assert 'SAT proof finished - no model found: SUCCESS!' in (ROOT / 'build/g2-shared-read-reset-02/run.log').read_text()
for name, digest in reset['inputs'].items():
    assert sha(base / name) == digest
screen = read(ROOT / 'build/g2-shared-read-03/result.json')
assert temporal['sources']['gate'] == screen['sources']
assert temporal['sources']['gold'] == screen['parent_sources']
retained = {}
for label, directory, names in (
    ('temporal', base, ('result.json', 'gold.il', 'gate.il', 'gold.json', 'gate.json', 'gold.ys', 'gate.ys', 'gold.log', 'gate.log', 'blacklist.txt', 'before.json', 'after.json', 'proof.ys', 'proof.log')),
    ('reset-initial', ROOT / 'build/g2-shared-read-reset-01', ('proof.ys', 'assertions.json', 'run.log', 'runner.py')),
    ('reset', ROOT / 'build/g2-shared-read-reset-02', ('result.json', 'proof.ys', 'assertions.json', 'run.log', 'runner.py')),
    ('extra-base-timeout', ROOT / 'build/g2-shared-read-reset-03', ('result.json', 'proof.ys', 'assertions.json', 'run.log')),
):
    for name in names:
        path = directory / name
        target = OUT / label / (name + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        raw = path.read_bytes()
        target.write_bytes(gzip.compress(raw, mtime=0))
        retained[label + '/' + name] = {'original_sha256': hashlib.sha256(raw).hexdigest(),
                                      'retained_file': target.relative_to(OUT).as_posix(), 'retained_sha256': sha(target)}
for name in ('prove_shared_read_chip.py', 'prove_shared_read_reset.py'):
    (OUT / (name + '.gz')).write_bytes(gzip.compress((ROOT / 'build' / name).read_bytes(), mtime=0))
report = {'status': 'PASS_RESET_REACHABLE_COMPLETE_CHIP_EQUIVALENCE', 'sources': temporal['sources'],
          'actual_state_bits_per_chip': 4278, 'public_output_bits': 24, 'proven_bit_comparisons_including_aliases': 4572,
          'temporal': {'observed_induction_step': 1, 'configured_maximum': 3, 'seconds': temporal['proof']['seconds']},
          'reset_base': {'vector_assertions': 217, 'seconds': reset['run']['seconds'],
                         'assumptions': 'rst_n low on first sampled edge; all other public inputs arbitrary defined digital values; initial actual state is independent and unconstrained'},
          'scope': 'All public outputs remain equivalent after reset. Every actual flip-flop bit is included in common state matches; only combinational internal match points are excluded. Complete real memories and modules are retained, without abstract storage or protocol restrictions. Digital synchronous model only.',
          'limits': 'Shared-read public simulator regression, adversarial mutation sensitivity and physical qualification remain pending. This does not adopt the screen.',
          'retained_failures': 'Initial reset proof collection compared vector assertion count with bit count and failed after SAT succeeded. Corrected reset run has 217 vector assertions covering 4572 comparisons. An extra seq-4 base timed out at 90.064 seconds; it is not needed because the actual temporal proof closes at step 1, not the configured maximum 3.',
          'retained': retained}
(OUT / 'verification.json').write_bytes((json.dumps(report, indent=2) + '\n').encode())
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print(report['status'])
