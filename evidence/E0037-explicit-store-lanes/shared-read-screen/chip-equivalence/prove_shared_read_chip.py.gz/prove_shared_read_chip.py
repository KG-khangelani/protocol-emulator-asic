import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute
OUT = ROOT / 'build/g2-shared-read-chip-01'
assert not OUT.exists()
OUT.mkdir()
TOP = 'tt_um_khangelani_protocol_emulator'
FILES = ('project.v', 'm1_engine.v', 'm1_program_store.v', 'm1_data_store.v', 'm1_input_sync.v')
dirs = {'gold': ROOT / 'evidence/E0037-explicit-store-lanes/sources/od128',
        'gate': ROOT / 'build/g2-shared-read-03/src'}
result = {'status': 'RUNNING', 'scope': 'COMPLETE_CHIP_EQUIVALENCE_FROM_CORRESPONDING_STATE', 'sources': {}}
def save(): (OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
try:
    models = {}
    for label, source in dirs.items():
        result['sources'][label] = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in FILES}
        script = 'read_verilog ' + ' '.join(str(source / name) for name in FILES)
        script += f'; hierarchy -check -top {TOP}; proc; flatten; opt; check -assert; rename {TOP} {label}; write_rtlil {OUT / (label + ".il")}; write_json {OUT / (label + ".json")}'
        (OUT / (label + '.ys')).write_text(script + '\n')
        run = execute(['yosys', '-Q', '-s', str(OUT / (label + '.ys'))], OUT / (label + '.log'), 60)
        assert run['returncode'] == 0 and not run['timed_out']
        models[label] = json.loads((OUT / (label + '.json')).read_bytes())['modules'][label]
    states, ports, all_names = {}, {}, set()
    for label, module in models.items():
        qbits = {bit for cell in module['cells'].values() if 'dff' in cell['type'].lower()
                 for bit in cell['connections']['Q'] if isinstance(bit, int)}
        assert len(qbits) == 4278
        assert not any('latch' in cell['type'].lower() or cell['type'] in ('$assume', '$anyseq') for cell in module['cells'].values())
        names = {name: wire['bits'] for name, wire in module['netnames'].items() if not name.startswith('$')}
        states[label] = {name: bits for name, bits in names.items()
                         if any(bit in qbits for bit in bits) and all(not isinstance(bit, int) or bit in qbits for bit in bits)}
        ports[label] = set(module['ports'])
        all_names |= set(names)
        covered = {bit for bits in states[label].values() for bit in bits if isinstance(bit, int)}
        assert qbits <= covered
    common_states = set(states['gold']) & set(states['gate'])
    for label, module in models.items():
        qbits = {bit for cell in module['cells'].values() if 'dff' in cell['type'].lower() for bit in cell['connections']['Q'] if isinstance(bit, int)}
        assert qbits <= {bit for name in common_states for bit in states[label][name]}
    assert ports['gold'] == ports['gate']
    excluded = sorted(all_names - common_states - ports['gold'])
    (OUT / 'blacklist.txt').write_text('\n'.join(excluded) + '\n')
    result.update(state_bits_per_chip=4278, common_state_names=sorted(common_states), excluded_combinational_names=excluded)
    save()
    script = f'read_rtlil {OUT / "gold.il"} {OUT / "gate.il"}; equiv_make -blacklist {OUT / "blacklist.txt"} gold gate equivalence; hierarchy -top equivalence; write_json {OUT / "before.json"}; equiv_simple; equiv_induct -seq 3; equiv_status -assert; write_json {OUT / "after.json"}'
    (OUT / 'proof.ys').write_text(script + '\n')
    run = execute(['yosys', '-Q', '-s', str(OUT / 'proof.ys')], OUT / 'proof.log', 300)
    result['proof'] = run
    passed = run['returncode'] == 0 and not run['timed_out'] and 'Equivalence successfully proven!' in (OUT / 'proof.log').read_text()
    if passed:
        before = json.loads((OUT / 'before.json').read_bytes())['modules']['equivalence']
        after = json.loads((OUT / 'after.json').read_bytes())['modules']['equivalence']
        output_bits = {b for p in before['ports'].values() if p['direction'] == 'output' for b in p['bits']}
        comparisons = {n:c for n,c in before['cells'].items() if c['type'] == '$equiv'}
        assert len(output_bits) == 24
        assert output_bits <= {b for c in comparisons.values() for b in c['connections']['Y']}
        assert all(after['cells'][n]['connections']['A'] == after['cells'][n]['connections']['B'] for n in comparisons)
        result.update(public_output_bits_compared=24, all_comparisons_proven=len(comparisons))
    result['status'] = 'PASS_CORRESPONDING_STATE_CHIP_EQUIVALENCE' if passed else 'NOT_QUALIFIED'
    print(result['status'], flush=True)
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE', error=str(error))
    raise
finally:
    save()
