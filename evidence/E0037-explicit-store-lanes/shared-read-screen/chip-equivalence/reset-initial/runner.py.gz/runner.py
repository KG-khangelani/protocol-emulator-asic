import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute
BASE = ROOT / 'build/g2-shared-read-chip-01'
OUT = ROOT / 'build/g2-shared-read-reset-01'
assert not OUT.exists()
OUT.mkdir()
script = f'read_rtlil {BASE / "gold.il"} {BASE / "gate.il"}; equiv_make -make_assert -blacklist {BASE / "blacklist.txt"} gold gate equivalence; hierarchy -top equivalence; dffunmap; opt_clean; write_json {OUT / "assertions.json"}; '
script += 'sat -verify -seq 2 -set-at 1 rst_n 0 -prove-asserts -prove-skip 1 -set-def-inputs -show-ports'
(OUT / 'proof.ys').write_text(script + '\n')
run = execute(['yosys', '-Q', '-s', str(OUT / 'proof.ys')], OUT / 'run.log', 90)
passed = run['returncode'] == 0 and not run['timed_out'] and 'SAT proof finished - no model found: SUCCESS!' in (OUT / 'run.log').read_text()
model = json.loads((OUT / 'assertions.json').read_bytes())['modules']['equivalence']
assertions = sum(c['type'] == '$assert' for c in model['cells'].values())
assert assertions >= 24 + 4278
result = {'status': 'PASS_RESET_ESTABLISHES_CORRESPONDENCE' if passed else 'NOT_QUALIFIED',
          'run': run, 'assertion_cells': assertions,
          'inputs': {name: hashlib.sha256((BASE / name).read_bytes()).hexdigest() for name in ('gold.il', 'gate.il', 'blacklist.txt')},
          'scope': 'Both complete chips start from independent arbitrary state. rst_n=0 on first sampled edge; all public inputs otherwise unconstrained/defined. Every matched state bit and public-output assertion holds after that edge. Temporal preservation is a separate proof.'}
(OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(result['status'])
