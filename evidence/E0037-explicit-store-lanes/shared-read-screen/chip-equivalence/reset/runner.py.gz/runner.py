import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute
BASE = ROOT / 'build/g2-shared-read-chip-01'
OUT = ROOT / 'build/g2-shared-read-reset-02'
assert not OUT.exists()
OUT.mkdir()
script = f'read_rtlil {BASE / "gold.il"} {BASE / "gate.il"}; equiv_make -make_assert -blacklist {BASE / "blacklist.txt"} gold gate equivalence; hierarchy -top equivalence; dffunmap; opt_clean; write_json {OUT / "assertions.json"}; '
script += 'sat -verify -seq 2 -set-at 1 rst_n 0 -prove-asserts -prove-skip 1 -set-def-inputs -show-ports'
(OUT / 'proof.ys').write_text(script + '\n')
run = execute(['yosys', '-Q', '-s', str(OUT / 'proof.ys')], OUT / 'run.log', 90)
passed = run['returncode'] == 0 and not run['timed_out'] and 'SAT proof finished - no model found: SUCCESS!' in (OUT / 'run.log').read_text()
model = json.loads((OUT / 'assertions.json').read_bytes())['modules']['equivalence']
assertions = [c for c in model['cells'].values() if c['type'] == '$assert']
comparisons = [c for c in model['cells'].values() if c['type'] == '$eqx']
assert {tuple(c['connections']['Y']) for c in comparisons} == {tuple(c['connections']['A']) for c in assertions}
assert all(c['connections']['EN'] == ['1'] for c in assertions)
temporal = json.loads((BASE / 'result.json').read_bytes())
targets = temporal['common_state_names'] + [n for n,p in model['ports'].items() if p['direction'] == 'output']
pairs = {(tuple(c['connections']['A']), tuple(c['connections']['B'])) for c in comparisons}
for name in targets:
    gold = tuple(model['netnames'][name + '_gold']['bits'])
    gate = tuple(model['netnames'][name + '_gate']['bits'])
    assert (gold, gate) in pairs or (gate, gold) in pairs, name
bits = sum(int(c['parameters']['A_WIDTH'], 2) for c in comparisons)
assert bits == temporal['all_comparisons_proven'] == 4572
result = {'status': 'PASS_RESET_ESTABLISHES_CORRESPONDENCE' if passed else 'NOT_QUALIFIED',
          'run': run, 'assertion_cells': len(assertions), 'compared_bits_including_aliases': bits,
          'inputs': {name: hashlib.sha256((BASE / name).read_bytes()).hexdigest() for name in ('gold.il', 'gate.il', 'blacklist.txt')},
          'scope': 'Both complete chips start from independent arbitrary state. rst_n=0 on first sampled edge; all public inputs otherwise unconstrained/defined. Every matched state bit and public-output assertion holds after that edge. Temporal preservation is a separate proof.'}
(OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
print(result['status'])
