import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_comparison import cell_counts, TOP
from run_program_sensitivity import execute
OUT = ROOT / 'build/g2-shared-read-02'
assert not OUT.exists()
src = OUT / 'src'
src.mkdir(parents=True)
original = ROOT / 'evidence/E0037-explicit-store-lanes/sources/od128'
manifest = json.loads((original.parent / 'source-manifest.json').read_bytes())['od128']['source_sha256']
result = {'status': 'RUNNING', 'scope': 'BOUNDED_GENERIC_AND_CONDITIONAL_STORE_EQUIVALENCE_ONLY'}
def save(): (OUT / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
save()
try:
    for name, expected in manifest.items():
        raw = (original / name).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        if name == 'm1_program_store.v':
            text = raw.decode()
            pattern = r'    always @\(\*\) begin\n        case \(bank_address\[8:2\]\).*?\n        endcase\n    end\n'
            text, count = re.subn(pattern, '', text, flags=re.S)
            assert count == 1
            assert text.count('case (pc)') == 1
            text = text.replace('case (pc)', 'case (read_address)')
            position = '    always @(*) begin\n        case (read_address)'
            assert text.count(position) == 1
            text = text.replace(position, "    wire [7:0] read_address = load_mode ? {1'b0, bank_address[8:2]} : pc;\n"
                                          "    always @* begin\n        data_out = instruction[8*byte_address[1:0] +: 8];\n    end\n" + position)
            raw = text.encode()
        (src / name).write_bytes(raw)
    result['sources'] = {name: hashlib.sha256((src / name).read_bytes()).hexdigest() for name in manifest}
    result['parent_sources'] = manifest
    script = 'read_verilog ' + ' '.join(str(src / name) for name in manifest)
    script += f'; hierarchy -check -top {TOP}; synth -top {TOP}; check -assert; stat; write_json {OUT / "synth.json"}'
    (OUT / 'synth.ys').write_text(script + '\n')
    run = execute(['yosys', '-Q', '-s', str(OUT / 'synth.ys')], OUT / 'synthesis.log', 300)
    result['synthesis'] = run
    assert run['returncode'] == 0 and not run['timed_out']
    result['counts'] = cell_counts(OUT / 'synth.json')
    save()
    print(result['counts'], flush=True)
    # Preserve the complete state machine and mask only the two unobserved read ports.
    for label, path in (('gold', original / 'm1_program_store.v'), ('gate', src / 'm1_program_store.v')):
        text = path.read_text()
        text = text.replace('output reg [7:0] data_out, output reg [7:0] program_length,',
                            'output wire [7:0] visible_data, output reg [7:0] program_length,')
        text = text.replace('output reg [31:0] instruction, output wire instruction_valid',
                            'output wire [31:0] visible_instruction, output wire instruction_valid')
        text = text.replace('    reg [31:0] word0;',
            "    reg [7:0] data_out;\n    reg [31:0] instruction;\n"
            "    assign visible_data = load_mode ? data_out : 8'd0;\n"
            "    assign visible_instruction = load_mode ? 32'd0 : instruction;\n    reg [31:0] word0;")
        # Do not match the deliberately unobserved raw internal read signals.
        text = re.sub(r'\b(data_out|instruction)\b', lambda m: label + '_' + m[1], text)
        (OUT / (label + '.v')).write_text(text)
    script = f'read_verilog {OUT / "gold.v"}; rename m1_program_store gold; read_verilog {OUT / "gate.v"}; rename m1_program_store gate; '
    script += 'proc; opt; equiv_make gold gate equivalence; hierarchy -top equivalence; equiv_simple; equiv_induct -seq 3; equiv_status -assert'
    (OUT / 'proof.ys').write_text(script + '\n')
    run = execute(['yosys', '-Q', '-s', str(OUT / 'proof.ys')], OUT / 'equivalence.log', 240)
    result['conditional_store_equivalence'] = run
    passed = run['returncode'] == 0 and not run['timed_out'] and 'Equivalence successfully proven!' in (OUT / 'equivalence.log').read_text()
    result['status'] = 'PASS_BOUNDED_SHARED_READ_SCREEN' if passed else 'NOT_QUALIFIED'
    print(result['status'], flush=True)
except Exception as error:
    result.update(status='FAILED_OR_INCOMPLETE', error=str(error))
    raise
finally:
    save()
