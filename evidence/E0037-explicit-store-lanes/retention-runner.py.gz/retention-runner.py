"""Retain exact D38 qualification inputs and results without solver bulk files."""
import gzip
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0037-explicit-store-lanes'
def sha(data): return hashlib.sha256(data).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('--gate', action='append', choices=('store', 'selection'))
args = parser.parse_args()
index = json.loads((OUT / 'archives.json').read_bytes()) if (OUT / 'archives.json').exists() else {}
for gate in args.gate or ('store', 'selection'):
    base = ROOT / ('build/g2-lanes-' + gate + '-01')
    report = json.loads((base / 'result.json').read_bytes())
    expected = 'PASS_LANES_AUDITED_STORE' if gate == 'store' else 'PASS_LANES_PUBLIC_SELECTION'
    assert report['status'] == expected, (gate, report['status'])
    files = {}
    for path in base.rglob('*'):
        if not path.is_file(): continue
        relative = path.relative_to(base)
        if 'sim' in relative.parts: continue
        if 'proof' in relative.parts:
            if relative.parts[-2:] == ('proof', 'status') or path.suffix == '.vcd' and path.name.startswith('trace'):
                files[relative.as_posix()] = path.read_bytes()
        elif 'records' in relative.parts or 'audit' in relative.parts or 'variants' in relative.parts or path.name in (
            'result.json', 'results.xml', 'check.json', 'model.json', 'prepare.ys', 'prepared.il', 'prepared.json', 'store.v', 'proof.sby', 'run.log'):
            files[relative.as_posix()] = path.read_bytes()
    if gate == 'store':
        raw = (ROOT / 'experiments/i2c/run_store_local_proof.py').read_bytes()
        # Linux read bytes may differ from the Windows checkout's line endings.
        raw = raw.replace(b'\r\n', b'\n')
        assert sha(raw) == json.loads(files['store/result.json'])['runner_sha256']
        files['store/runner.py'] = raw
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w') as archive:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(data), 0o644
            archive.addfile(member, io.BytesIO(data))
    packed = gzip.compress(stream.getvalue(), mtime=0)
    (OUT / (gate + '.tar.gz')).write_bytes(packed)
    index[gate] = {'archive_sha256': sha(packed), 'files': {name: sha(data) for name, data in sorted(files.items())}}
(OUT / 'archives.json').write_bytes((json.dumps(index, indent=2) + '\n').encode())
style = OUT / 'style'
style.mkdir(exist_ok=True)
for path in (ROOT / 'build/g2-lanes-style-01').iterdir():
    raw = path.read_bytes()
    target = style / (path.name + '.gz' if path.suffix == '.log' else path.name)
    target.write_bytes(gzip.compress(raw, mtime=0) if path.suffix == '.log' else raw)
(OUT / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('Retained', sum(len(i['files']) for i in index.values()), 'exact D38 files')
