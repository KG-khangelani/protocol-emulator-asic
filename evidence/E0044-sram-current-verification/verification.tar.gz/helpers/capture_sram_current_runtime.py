import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
image_id = 'sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909'
out = root / 'build/g2-sram-current-runtime-01'
out.mkdir(exist_ok=True)
for name in (
    'g2-sram-prefetch-invariant-01', 'g2-sram-current-fast-probe-01',
    'g2-sram-current-formal-probe-01', 'g2-sram-current-formal-probe-02',
    'g2-sram-public-readout-flat-01', 'g2-sram-current-normal-formal-01',
    'g2-sram-current-repo-check-01', 'g2-sram-current-proof-audit-01',
    'g2-sram-cell-model-probe-01', 'g2-sram-reset-alias-probe-01',
    'g2-sram-netlist-verilator-03', 'g2-sram-netlist-verilator-04',
    'g2-sram-netlist-verilator-05', 'g2-sram-netlist-icarus-01',
):
    item = json.loads(subprocess.check_output(['docker', 'inspect', name]))[0]
    assert item['Image'] == item['Config']['Image'] == image_id
    result = {'status': 'OBSERVED_IDENTIFIED_CONTAINER', 'observed_utc': datetime.now(timezone.utc).isoformat(),
              'name': name, 'id': item['Id'], 'image_id': item['Image'], 'configured_image': item['Config']['Image'],
              'command': item['Config']['Cmd'], 'started_at': item['State']['StartedAt'],
              'finished_at': item['State']['FinishedAt'], 'state': item['State']['Status'],
              'exit_code': item['State']['ExitCode'],
              'mounts': [m for m in item['Mounts'] if m['Destination'] in ('/pdk', '/workspace')]}
    (out / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n', newline='\n')
    print(name, result['state'], result['exit_code'])
(out / 'capture.py').write_bytes(Path(__file__).read_bytes())
