import json
from pathlib import Path
import sys
ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'experiments/spi_phase'))
from run_program_sensitivity import execute
out = ROOT / 'build/g2-sram-public-readout-flat-01'
out.mkdir()
before = (ROOT / 'build/g2-sram-current-formal-probe-02/m1_public_readout.sby').read_text()
assert before.count('prep -top tt_um_khangelani_protocol_emulator\n') == 1
after = before.replace('prep -top tt_um_khangelani_protocol_emulator\n', 'prep -top tt_um_khangelani_protocol_emulator -flatten\n')
(out / 'before.sby').write_text(before)
(out / 'proof.sby').write_text(after)
result = execute(['sby', '-f', '-d', str(out / 'proof'), str(out / 'proof.sby')], out / 'run.log', 300)
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
assert result['returncode'] == 0 and not result['timed_out']
assert (out / 'proof/status').read_text().split()[0] == 'PASS'
assert 'successful proof by k-induction' in (out / 'run.log').read_text()
print('PASS_ACTUAL_PUBLIC_READOUT_AFTER_CONSTANT_BIST_TIEOFF_PROPAGATION')
