import json
from pathlib import Path
import sys

root = Path('/workspace')
sys.path.insert(0, str(root / 'tools'))
from current_profile import describe
from current_sram import audit_current_formal, audit_formal

base = root / 'build/g2-sram-current-01/runs/20261112T210358856942Z-formal'
profile = describe(root / 'build/g2-sram-candidate-01/src')
checked = audit_current_formal(base, profile)
try:
    audit_formal(base, profile)
except AssertionError:
    legacy = json.loads((base / 'legacy/result.json').read_bytes())
    assert legacy['status'] == 'FAILED_OR_INCOMPLETE' and 'timed out after' in legacy['error']
else:
    raise AssertionError('historical timeout must prevent aggregate acceptance')
result = {'status': 'PASS_CURRENT_SRAM_FORMAL_WITH_RETAINED_HISTORICAL_TIMEOUT',
          'current': checked, 'historical': 'FAILED_OR_INCOMPLETE_300_SECOND_TIMEOUT',
          'combined_acceptance': False}
(root / 'build/g2-sram-current-01/current-formal-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(result['status'])
