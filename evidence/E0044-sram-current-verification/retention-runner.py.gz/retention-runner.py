import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from current_profile import verification_inputs

out = ROOT / 'evidence/E0044-sram-current-verification'
out.mkdir(exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda p: json.loads(p.read_bytes())
files = {}
locations = (
    ('fast', 'g2-sram-current-fast-probe-01'),
    ('preparation-01', 'g2-sram-current-formal-probe-01'),
    ('preparation-02', 'g2-sram-current-formal-probe-02'),
    ('flat-readout', 'g2-sram-public-readout-flat-01'),
    ('normal', 'g2-sram-current-01'),
    ('prediction', 'g2-sram-prefetch-invariant-01'),
)
for label, folder in locations:
    base = ROOT / 'build' / folder
    for path in sorted(base.rglob('*')):
        name = path.relative_to(base).as_posix()
        if not path.is_file() or any(p in ('__pycache__', 'sim', 'obj_dir', 'sim_build') for p in path.relative_to(base).parts):
            continue
        if path.suffix in ('.vvp', '.o', '.a', '.so', '.d') or path.name in ('Vstore_ports', 'Vsram_program_store'):
            continue
        files[label + '/' + name] = path.read_bytes()
inputs = verification_inputs()
for name, expected in inputs.items():
    raw = (ROOT / name).read_bytes()
    assert sha(raw) == expected
    files['inputs/' + name] = raw
receipt = read(ROOT / 'build/g2-sram-current-01/receipts/formal.json')
assert receipt['status'] == 'FAILED_OR_INCOMPLETE'
# Recover the pre-audit-refactor driver, and require the hash frozen at launch.
current = (ROOT / 'tools/current_sram.py').read_text()
before = current[:current.index('def audit_current_formal')]
header = '''def audit_formal(directory, profile):
    sources = profile['source_sha256']
    current, legacy = read(directory / 'current/result.json'), read(directory / 'legacy/result.json')
    assert current['status'] == 'PASS_CURRENT_SRAM_COMPOSITION_INSTRUCTIONS_AND_SUPPORT_FORMAL'
    assert current['sources'] == sources and all(s['returncode'] == 0 and not s['timed_out'] for s in current['stages'])
    assert len(current['stages']) == 11 and len(current['units']) == 5
'''
body = current[current.index("    path = ROOT / 'evidence/E0042-sram-prefetch-screen/ci-95120d8/proof_checks.py'"):current.index("    return {'composition': composition")]
legacy = current[current.index("    assert legacy['status'] == 'PASS_COMPLETE_HISTORICAL_FORMAL_BASELINE'"):current.index("    return {'kind': 'CURRENT_SRAM_COMPOSITION_AND_SOURCE_MATCHED_FORMAL'")]
footer = '''    return {'kind': 'CURRENT_SRAM_COMPOSITION_AND_SOURCE_MATCHED_FORMAL', 'composition': composition,
            'prediction': prediction, 'instruction_tasks': 4, 'support_tasks': 5, 'historical_tasks': 10,
            'boundary': 'Vendor digital memory model. Earlier complete-chip equivalence timeouts remain incomplete.'}


'''
original = (before + header + body + legacy + footer + current[current.index('def check_candidate'):]).encode()
assert sha(original) == receipt['verification_inputs']['tools/current_sram.py']
for name, expected in receipt['verification_inputs'].items():
    raw = original if name == 'tools/current_sram.py' else (ROOT / name).read_bytes()
    assert sha(raw) == expected, name
    files['normal-inputs/' + name] = raw
for name in ('g2-sram-current-fast-probe-01', 'g2-sram-current-normal-formal-01',
             'g2-sram-current-repo-check-01', 'g2-sram-current-repo-check-02'):
    files['logs/' + name + '.log'] = (ROOT / 'build' / (name + '.log')).read_bytes()
for name in ('g2-sram-prefetch-invariant-01', 'g2-sram-current-fast-probe-01',
             'g2-sram-current-formal-probe-01', 'g2-sram-current-formal-probe-02',
             'g2-sram-public-readout-flat-01', 'g2-sram-current-normal-formal-01',
             'g2-sram-current-repo-check-01', 'g2-sram-current-proof-audit-01'):
    files['runtime/' + name + '.json'] = (ROOT / 'build/g2-sram-current-runtime-01' / (name + '.json')).read_bytes()
for name in ('capture_sram_current_runtime.py', 'audit_sram_current_proof.py', 'probe_sram_public_readout.py'):
    files['helpers/' + name] = (ROOT / 'build' / name).read_bytes()
files['preparation-01/original-run-general-formal.py'] = subprocess.check_output(
    ['git', 'show', '2bd2688:experiments/i2c/run_general_formal.py'], cwd=ROOT)
with (out / 'verification.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
packed = (out / 'verification.tar.gz').read_bytes()
index = {'sha256': sha(packed), 'bytes': len(packed), 'files': {n: sha(raw) for n, raw in sorted(files.items())}}
(out / 'archive.json').write_text(json.dumps(index, indent=2) + '\n', newline='\n')
(out / 'manifest.json').write_text(json.dumps({
    'status': 'CURRENT_SRAM_PREPARATION_WITH_RETAINED_HISTORICAL_TIMEOUT',
    'profile': receipt['profile'], 'verification_inputs': inputs,
    'formal_run': Path(receipt['directory']).name,
    'current_formal': 'PASS_CURRENT_SRAM_COMPOSITION_INSTRUCTIONS_AND_SUPPORT_FORMAL',
    'historical_formal': 'FAILED_OR_INCOMPLETE_300_SECOND_TIMEOUT',
    'normal_aggregate': 'NOT_PASSED', 'production': 'NOT_PROMOTED',
    'source_identity': 'Five immutable E0042 files; separate original launch inputs and later semantic audit inputs retained.',
}, indent=2) + '\n', newline='\n')
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_SRAM_CURRENT', len(files), len(packed))
