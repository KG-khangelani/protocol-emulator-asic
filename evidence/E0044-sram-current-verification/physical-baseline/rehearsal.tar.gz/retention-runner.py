"""Retain the nine-profile comparison and the actually tested implementation."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tools import physical_candidate as common, physical_g2, physical_sram
base = root / 'build/g2-d34-baseline-rehearsal-01'
out = root / 'evidence/E0044-sram-current-verification/physical-baseline'
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
result = json.loads((base / 'result.json').read_bytes())
assert result['status'] == 'PASS_NINE_PHYSICAL_PROFILES_IDENTICAL_CONFIGURATIONS_AND_RTL'
log = (root / 'build/g2-physical-baseline-check-01.log').read_bytes()
assert sum(map(int, re.findall(rb'Ran (\d+) tests?', log))) == 118
assert log.count(b'\nOK\n') == 12 and b'FAILED' not in log
files = {p.relative_to(base).as_posix(): p.read_bytes() for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
expected = {'g1-P': common.expected_sources('P'), 'g1-compact10': common.expected_sources('compact10')}
for label, variant in [('g2-od128', 'od128'), ('g2-literal255', 'literal255'), ('g2-lanes', 'od128-lanes'), ('g2-shared', 'od128-shared')]:
    expected[label] = physical_g2.candidate_manifest(variant)['source_sha256']
for label in ('sram-buffered', 'sram-guarded', 'sram-aligned'):
    expected[label] = physical_sram.candidate()['source_sha256']
files['expected-candidates.json'] = (json.dumps(expected, indent=2) + '\n').encode()
for name in ('tools/physical_candidate.py', 'tools/physical_g2.py', 'tools/physical_sram.py',
             'tools/audit_g2_physical.py', 'tools/check_project.py', 'test/test_physical_candidate.py',
             'experiments/physical/d34-config.json', 'tools/workbench/toolchain.lock.json'):
    files['tested-inputs/' + name] = (root / name).read_bytes()
files['repository-check.log'] = log
files['retention-runner.py'] = Path(__file__).read_bytes()
files['runtime.json'] = (json.dumps({'staging_python': sys.version, 'platform': sys.platform,
    'repository_checks_image': 'protocol-emulator-asic-workbench@sha256:9e300db4db672314f6dc5394d19e4b7d5d72917588fa2a963ace1a8118391909',
    'repository_tests': 118, 'two_new_controls': ['incompatible future production config is ignored', 'changed archived clock is rejected']}, indent=2) + '\n').encode()
with (out / 'rehearsal.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                item = tarfile.TarInfo(name)
                item.size, item.mode, item.mtime = len(raw), 0o644, 0
                archive.addfile(item, io.BytesIO(raw))
raw = (out / 'rehearsal.tar.gz').read_bytes()
(out / 'archive.json').write_bytes((json.dumps({'sha256': sha(raw), 'bytes': len(raw),
    'files': {n: sha(r) for n, r in sorted(files.items())}}, indent=2) + '\n').encode())
(out / 'result.json').write_bytes((base / 'result.json').read_bytes())
print('RETAINED_BASELINE_REHEARSAL', len(files), len(raw))
