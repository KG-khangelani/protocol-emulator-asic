"""Compare every retained physical candidate after relocating its base input."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tools import physical_candidate as common, physical_g2, physical_sram

out = root / 'build/g2-d34-baseline-rehearsal-01'
assert not out.exists()
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = '232ee20e1eb35726f785225ecfc1a2641e10af33'
before = subprocess.check_output(['git', 'show', source + ':tools/physical_sram.py'], cwd=root)
reference_config = subprocess.check_output(['git', 'show', source + ':src/config.json'], cwd=root)
assert reference_config == common.baseline_config().read_bytes()
(out / 'reference/tools').mkdir(parents=True)
(out / 'reference/tools/physical_sram.py').write_bytes(before)
(out / 'reference/src').mkdir()
(out / 'reference/src/config.json').write_bytes(reference_config)
nodes = [node for node in ast.parse(before).body if isinstance(node, ast.FunctionDef) and node.name == 'portable_config']
assert len(nodes) == 1
scope = {'ROOT': out / 'reference', 'read': common.read_json, 'require': common.require,
         'MACRO': physical_sram.MACRO, 'MODEL_SETS': physical_sram.MODEL_SETS,
         'SRAM_IMPORT_PATTERNS': physical_sram.SRAM_IMPORT_PATTERNS}
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<frozen-portable-config>', 'exec'), scope)
observations = {}
started = datetime.now(timezone.utc).isoformat()
for label, module, variant in [('g1-P', common, 'P'), ('g1-compact10', common, 'compact10'),
        ('g2-od128', physical_g2, 'od128'), ('g2-literal255', physical_g2, 'literal255'),
        ('g2-lanes', physical_g2, 'od128-lanes'), ('g2-shared', physical_g2, 'od128-shared')]:
    path = out / label
    module.prepare(SimpleNamespace(output=path, variant=variant, stage_ci=False))
    record = common.read_json(path / 'inputs.json')
    assert (path / 'config.json').read_bytes() == reference_config
    assert record['config_source_path'] == common.BASE_CONFIG_PATH
    assert record['provenance_sha256_lf'][common.BASE_CONFIG_PATH] == sha(reference_config)
    observations[label] = {'config_sha256': sha(reference_config), 'source_sha256': record['source_sha256'],
                           'program_words': record['program_words']}
for label, guarded, aligned in [('sram-buffered', False, False), ('sram-guarded', True, False), ('sram-aligned', True, True)]:
    path = out / label
    physical_sram.prepare(SimpleNamespace(output=path, stage_ci=False, guarded=guarded, align_magic=aligned))
    expected = scope['portable_config'](physical_sram.MACRO + '.vh', guarded=guarded, aligned=aligned)
    config = path / 'workspace/src/config.json'
    assert common.read_json(config) == expected
    assert config.read_bytes() == (json.dumps(expected, indent=2, sort_keys=True) + '\n').encode()
    record = common.read_json(path / 'inputs.json')
    assert record['config_source_path'] == common.BASE_CONFIG_PATH
    assert record['provenance_sha256'][common.BASE_CONFIG_PATH] == sha(reference_config)
    observations[label] = {'config_sha256': sha(config.read_bytes()), 'source_sha256': record['candidate']['source_sha256'],
                           'model_sha256': record['candidate']['model_sha256'], 'staged_sha256': record['staged_sha256']}
result = {'status': 'PASS_NINE_PHYSICAL_PROFILES_IDENTICAL_CONFIGURATIONS_AND_RTL',
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'reference_source_commit': source, 'baseline_sha256': sha(reference_config), 'profiles': observations,
    'input_relocation_only': True, 'physical_qualification': 'UNCHANGED_OPEN_FOR_SRAM', 'production': 'NOT_PROMOTED'}
(out / 'result.json').write_bytes((json.dumps(result, indent=2) + '\n').encode())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
print(result['status'])
