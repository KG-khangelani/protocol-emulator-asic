`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [7:0] PI_tx_payload;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_sampled_inputs;
  reg [0:0] PI_instruction_valid;
  reg [7:0] PI_tx_payload_alt;
  reg [31:0] PI_instruction;
  reg [0:0] PI_ena;
  reg [0:0] PI_rst_n;
  m1_engine UUT (
    .tx_payload(PI_tx_payload),
    .clk(PI_clk),
    .sampled_inputs(PI_sampled_inputs),
    .instruction_valid(PI_instruction_valid),
    .tx_payload_alt(PI_tx_payload_alt),
    .instruction(PI_instruction),
    .ena(PI_ena),
    .rst_n(PI_rst_n)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$13139  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13145  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13187  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13193  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13199  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13205  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13217  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13223  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13235  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13241  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13247  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13265  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13271  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13277  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13289  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$13125  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13137  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13143  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13149  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13155  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13161  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13167  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13173  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13179  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13185  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13191  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13197  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13203  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13209  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13215  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13221  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13233  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13239  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13245  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13251  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13257  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13263  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13269  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13275  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13281  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13287  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13293  = 1'b1;
    // UUT.$past$engine.\v:558$15$0  = 1'b0;
    // UUT.$past$engine.\v:563$16$0  = 1'b0;
    // UUT.$past$engine.\v:566$18$0  = 1'b0;
    // UUT.$past$engine.\v:575$21$0  = 1'b0;
    // UUT.$past$engine.\v:583$30$0  = 1'b0;
    // UUT.$past$engine.\v:585$31$0  = 1'b0;
    // UUT.$past$engine.\v:587$32$0  = 1'b0;
    // UUT.$past$engine.\v:592$35$0  = 1'b0;
    // UUT.$past$engine.\v:596$37$0  = 1'b0;
    // UUT.$past$engine.\v:601$39$0  = 1'b0;
    UUT._witness_.anyinit_procdff_12961 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT._witness_.anyinit_procdff_12963 = 8'b00001000;
    UUT._witness_.anyinit_procdff_12964 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_12966 = 1'b0;
    UUT._witness_.anyinit_procdff_12967 = 8'b11100010;
    UUT._witness_.anyinit_procdff_12968 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12969 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12970 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12971 = 8'b00011101;
    UUT._witness_.anyinit_procdff_12972 = 8'b11111101;
    UUT._witness_.anyinit_procdff_12973 = 6'b000000;
    UUT._witness_.anyinit_procdff_12977 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_12978 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12980 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12982 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12984 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12985 = 1'b0;
    UUT._witness_.anyinit_procdff_12986 = 1'b1;
    UUT._witness_.anyinit_procdff_12987 = 8'b00000001;
    UUT._witness_.anyinit_procdff_12988 = 8'b11111111;
    UUT._witness_.anyinit_procdff_12989 = 1'b0;
    UUT._witness_.anyinit_procdff_12990 = 1'b0;
    UUT._witness_.anyinit_procdff_12991 = 8'b00000001;
    UUT._witness_.anyinit_procdff_12992 = 8'b11111111;
    UUT.f_past_valid = 1'b0;
    UUT.gpio_oe = 8'b11111111;
    UUT.gpio_value = 8'b00000000;
    UUT.loop_active = 1'b1;
    UUT.loop_end = 8'b00000000;
    UUT.loop_remaining = 8'b00000000;
    UUT.loop_start = 8'b00000001;
    UUT.pc = 8'b11100010;
    UUT.phase_active = 1'b1;
    UUT.phase_prepared = 1'b0;
    UUT.shift_active = 1'b1;
    UUT.shift_bits_done = 3'b000;
    UUT.shift_msb_first = 1'b0;
    UUT.shift_period = 16'b0000000000000000;
    UUT.shift_rx_data = 8'b00000000;
    UUT.shift_rx_pin = 3'b000;
    UUT.shift_tx_data = 8'b00000001;
    UUT.shift_tx_pin = 3'b000;
    UUT.shift_tx_slot = 1'b0;
    UUT.state = 2'b00;
    UUT.wait_failure_pc = 8'b00000001;
    UUT.wait_is_input = 1'b0;
    UUT.wait_left = 16'b0000000000000001;
    UUT.wait_level = 1'b0;
    UUT.wait_pin = 3'b000;
    UUT.wait_timeout_jump = 1'b1;
    UUT.wait_timeout_skip = 1'b0;

    // state 0
    PI_tx_payload = 8'b10000000;
    PI_sampled_inputs = 8'b00000001;
    PI_instruction_valid = 1'b1;
    PI_tx_payload_alt = 8'b00000001;
    PI_instruction = 32'b00010010010000000000000000000000;
    PI_ena = 1'b0;
    PI_rst_n = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_tx_payload <= 8'b10010000;
      PI_sampled_inputs <= 8'b00101110;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b10010000;
      PI_instruction <= 32'b10111100010000000000000000000001;
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_tx_payload <= 8'b10000001;
      PI_sampled_inputs <= 8'b00000010;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b00000000;
      PI_instruction <= 32'b00000000000010000000000000001000;
      PI_ena <= 1'b0;
      PI_rst_n <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_tx_payload <= 8'b10000000;
      PI_sampled_inputs <= 8'b00000001;
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b00000001;
      PI_instruction <= 32'b00010000010000000000000000000000;
      PI_ena <= 1'b0;
      PI_rst_n <= 1'b0;
    end

    genclock <= cycle < 3;
    cycle <= cycle + 1;
  end
endmodule
