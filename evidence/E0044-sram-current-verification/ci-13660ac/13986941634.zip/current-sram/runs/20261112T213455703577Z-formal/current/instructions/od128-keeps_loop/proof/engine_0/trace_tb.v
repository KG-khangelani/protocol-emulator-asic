`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_instruction_valid;
  reg [7:0] PI_tx_payload_alt;
  reg [0:0] PI_ena;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_sampled_inputs;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_tx_payload;
  reg [31:0] PI_instruction;
  m1_engine UUT (
    .instruction_valid(PI_instruction_valid),
    .tx_payload_alt(PI_tx_payload_alt),
    .ena(PI_ena),
    .clk(PI_clk),
    .sampled_inputs(PI_sampled_inputs),
    .rst_n(PI_rst_n),
    .tx_payload(PI_tx_payload),
    .instruction(PI_instruction)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$13143  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13149  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13191  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13197  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13203  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13209  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13221  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13227  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13239  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13245  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13251  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13269  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13275  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13281  = 1'b0;
    // UUT.$auto$async2sync.\cc:107:execute$13293  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$13129  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13141  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13147  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13153  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13159  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13165  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13171  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13177  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13183  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13189  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13195  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13201  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13207  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13213  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13219  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13225  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13237  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13243  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13249  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13255  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13261  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13267  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13273  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13279  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13285  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13291  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$13297  = 1'b1;
    // UUT.$past$engine.\v:558$15$0  = 1'b0;
    // UUT.$past$engine.\v:563$16$0  = 1'b0;
    // UUT.$past$engine.\v:566$18$0  = 1'b0;
    // UUT.$past$engine.\v:575$21$0  = 1'b0;
    // UUT.$past$engine.\v:583$30$0  = 1'b0;
    // UUT.$past$engine.\v:585$31$0  = 1'b0;
    // UUT.$past$engine.\v:587$32$0  = 1'b0;
    // UUT.$past$engine.\v:592$35$0  = 1'b0;
    // UUT.$past$engine.\v:596$37$0  = 1'b0;
    // UUT.$past$engine.\v:601$39$0  = 1'b0;
    UUT._witness_.anyinit_procdff_12965 = 128'b00000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT._witness_.anyinit_procdff_12967 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12968 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_12970 = 1'b1;
    UUT._witness_.anyinit_procdff_12971 = 8'b11111110;
    UUT._witness_.anyinit_procdff_12972 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12973 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12974 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12975 = 8'b00000001;
    UUT._witness_.anyinit_procdff_12976 = 8'b11111110;
    UUT._witness_.anyinit_procdff_12977 = 6'b000000;
    UUT._witness_.anyinit_procdff_12981 = 16'b0000000000000000;
    UUT._witness_.anyinit_procdff_12982 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12984 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12986 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12988 = 8'b00000000;
    UUT._witness_.anyinit_procdff_12989 = 1'b0;
    UUT._witness_.anyinit_procdff_12990 = 1'b1;
    UUT._witness_.anyinit_procdff_12991 = 8'b00000001;
    UUT._witness_.anyinit_procdff_12992 = 8'b11111111;
    UUT._witness_.anyinit_procdff_12993 = 1'b0;
    UUT._witness_.anyinit_procdff_12994 = 1'b0;
    UUT._witness_.anyinit_procdff_12995 = 8'b00000001;
    UUT._witness_.anyinit_procdff_12996 = 8'b11111111;
    UUT.f_past_valid = 1'b0;
    UUT.gpio_oe = 8'b11111111;
    UUT.gpio_value = 8'b00000000;
    UUT.loop_active = 1'b1;
    UUT.loop_end = 8'b00000000;
    UUT.loop_remaining = 8'b00000000;
    UUT.loop_start = 8'b00000001;
    UUT.pc = 8'b11111110;
    UUT.phase_active = 1'b1;
    UUT.phase_prepared = 1'b0;
    UUT.shift_active = 1'b1;
    UUT.shift_bits_done = 3'b000;
    UUT.shift_msb_first = 1'b0;
    UUT.shift_period = 16'b0000000000000000;
    UUT.shift_rx_data = 8'b00000000;
    UUT.shift_rx_pin = 3'b000;
    UUT.shift_tx_data = 8'b00000001;
    UUT.shift_tx_pin = 3'b000;
    UUT.shift_tx_slot = 1'b0;
    UUT.state = 2'b00;
    UUT.wait_failure_pc = 8'b00000001;
    UUT.wait_is_input = 1'b0;
    UUT.wait_left = 16'b0000000000000001;
    UUT.wait_level = 1'b0;
    UUT.wait_pin = 3'b000;
    UUT.wait_timeout_jump = 1'b1;
    UUT.wait_timeout_skip = 1'b0;

    // state 0
    PI_instruction_valid = 1'b1;
    PI_tx_payload_alt = 8'b00000001;
    PI_ena = 1'b0;
    PI_sampled_inputs = 8'b00000001;
    PI_rst_n = 1'b0;
    PI_tx_payload = 8'b10000000;
    PI_instruction = 32'b00010010010000000000000000000000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b01000001;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010001;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b01000001;
      PI_instruction <= 32'b01100010000000000000000010000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b01000101;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010001;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b01000101;
      PI_instruction <= 32'b11101101000010000000000000000000;
    end

    // state 3
    if (cycle == 2) begin
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b01000000;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00000001;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b10000001;
      PI_instruction <= 32'b10110110000000000000000000000010;
    end

    // state 4
    if (cycle == 3) begin
      PI_instruction_valid <= 1'b1;
      PI_tx_payload_alt <= 8'b00000001;
      PI_ena <= 1'b1;
      PI_sampled_inputs <= 8'b00010001;
      PI_rst_n <= 1'b1;
      PI_tx_payload <= 8'b10000000;
      PI_instruction <= 32'b00010010000000000000000000000000;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
