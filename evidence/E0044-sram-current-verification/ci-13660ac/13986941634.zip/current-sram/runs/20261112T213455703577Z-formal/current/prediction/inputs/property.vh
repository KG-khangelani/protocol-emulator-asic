
    // Observe the unmodified engine; only the proof observer is initialized.
    reg f_prefetch_past = 1'b0;
    always @(posedge clk) begin
        f_prefetch_past <= 1'b1;
        if (f_prefetch_past)
            assert (pc == $past(prefetch_pc));
        cover (f_prefetch_past && rst_n && ena && pc != $past(pc));
    end
