`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_ena;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_load_mode;
  reg [7:0] PI_pc;
  wire [0:0] PI_clk = clock;
  reg [7:0] PI_prefetch_pc;
  reg [0:0] PI_load_length;
  reg [4:0] PI_byte_address;
  reg [0:0] PI_load_write;
  reg [7:0] PI_data_in;
  reg [0:0] PI_load_bank;
  m1_program_store UUT (
    .ena(PI_ena),
    .rst_n(PI_rst_n),
    .load_mode(PI_load_mode),
    .pc(PI_pc),
    .clk(PI_clk),
    .prefetch_pc(PI_prefetch_pc),
    .load_length(PI_load_length),
    .byte_address(PI_byte_address),
    .load_write(PI_load_write),
    .data_in(PI_data_in),
    .load_bank(PI_load_bank)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:116:execute$735  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$741  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$747  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$753  = 1'b1;
    UUT.f_expected = 32'b00000000000000000000000000000000;
    UUT.f_past_valid = 1'b0;
    UUT.f_reset_seen = 1'b0;
    UUT.f_seen_write = 1'b0;
    UUT.program_bank = 4'b0000;
    UUT.program_length = 8'b00000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.dr_r = 32'b00000000000000000000000100000000;
    UUT.program_ready = 1'b0;
    UUT.read_address = 8'b00000000;
    UUT.read_lane = 2'b00;
    UUT.read_present = 1'b0;
    UUT.word_valid = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.word_zero = 32'b00000000000000000000000000000000;
    UUT.f_index = 7'b0000010;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b00000010] = 32'b00000000000000000000000000000000;
    UUT.program_memory.i_SRAM_1P_behavioral_bm_bist.memory[8'b10000010] = 32'b00000000000000000000000000000000;

    // state 0
    PI_ena = 1'b1;
    PI_rst_n = 1'b0;
    PI_load_mode = 1'b1;
    PI_pc = 8'b00000000;
    PI_prefetch_pc = 8'b00000000;
    PI_load_length = 1'b0;
    PI_byte_address = 5'b01000;
    PI_load_write = 1'b1;
    PI_data_in = 8'b00000010;
    PI_load_bank = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b1;
      PI_load_mode <= 1'b1;
      PI_pc <= 8'b00000000;
      PI_prefetch_pc <= 8'b00000000;
      PI_load_length <= 1'b0;
      PI_byte_address <= 5'b01000;
      PI_load_write <= 1'b1;
      PI_data_in <= 8'b00000010;
      PI_load_bank <= 1'b0;
    end

    // state 2
    if (cycle == 1) begin
      PI_ena <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_load_mode <= 1'b0;
      PI_pc <= 8'b00000000;
      PI_prefetch_pc <= 8'b10000010;
      PI_load_length <= 1'b1;
      PI_byte_address <= 5'b00000;
      PI_load_write <= 1'b0;
      PI_data_in <= 8'b00000001;
      PI_load_bank <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_ena <= 1'b1;
      PI_rst_n <= 1'b0;
      PI_load_mode <= 1'b1;
      PI_pc <= 8'b00000000;
      PI_prefetch_pc <= 8'b00000000;
      PI_load_length <= 1'b0;
      PI_byte_address <= 5'b01000;
      PI_load_write <= 1'b1;
      PI_data_in <= 8'b00000010;
      PI_load_bank <= 1'b0;
    end

    genclock <= cycle < 3;
    cycle <= cycle + 1;
  end
endmodule
