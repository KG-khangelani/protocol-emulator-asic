`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_instruction_valid;
  reg [0:0] PI_rst_n;
  reg [0:0] PI_ena;
  reg [7:0] PI_tx_payload;
  reg [31:0] PI_instruction;
  reg [7:0] PI_sampled_inputs;
  reg [7:0] PI_tx_payload_alt;
  wire [0:0] PI_clk = clock;
  m1_engine_formal UUT (
    .instruction_valid(PI_instruction_valid),
    .rst_n(PI_rst_n),
    .ena(PI_ena),
    .tx_payload(PI_tx_payload),
    .instruction(PI_instruction),
    .sampled_inputs(PI_sampled_inputs),
    .tx_payload_alt(PI_tx_payload_alt),
    .clk(PI_clk)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.$auto$async2sync.\cc:107:execute$7936  = 1'b0;
    // UUT.$auto$async2sync.\cc:116:execute$7922  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7928  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7934  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7940  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7946  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7952  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7958  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7964  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7970  = 1'b1;
    // UUT.$auto$async2sync.\cc:116:execute$7976  = 1'b1;
    UUT.dut.gpio_oe = 8'b01000000;
    UUT.dut.gpio_value = 8'b00010000;
    UUT.dut.loop_active = 1'b1;
    UUT.dut.loop_end = 5'b00000;
    UUT.dut.loop_remaining = 8'b00000000;
    UUT.dut.loop_start = 5'b00100;
    UUT.dut.pc = 5'b11111;
    UUT.dut.shift_active = 1'b0;
    UUT.dut.shift_bits_done = 3'b000;
    UUT.dut.shift_msb_first = 1'b1;
    UUT.dut.shift_period = 16'b0000000000000010;
    UUT.dut.shift_rx_data = 8'b00000001;
    UUT.dut.shift_rx_pin = 3'b010;
    UUT.dut.shift_tx_data = 8'b00000100;
    UUT.dut.shift_tx_pin = 3'b001;
    UUT.dut.shift_tx_slot = 1'b0;
    UUT.dut.state = 2'b01;
    UUT.dut.wait_is_input = 1'b1;
    UUT.dut.wait_left = 16'b0000000000000001;
    UUT.dut.wait_level = 1'b0;
    UUT.dut.wait_pin = 3'b010;
    UUT.dut.wait_timeout_skip = 1'b1;
    UUT.reset_seen = 1'b0;

    // state 0
    PI_instruction_valid = 1'b0;
    PI_rst_n = 1'b0;
    PI_ena = 1'b1;
    PI_tx_payload = 8'b00000001;
    PI_instruction = 32'b00000000010000001011111111100000;
    PI_sampled_inputs = 8'b00000011;
    PI_tx_payload_alt = 8'b00000100;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_instruction_valid <= 1'b0;
      PI_rst_n <= 1'b1;
      PI_ena <= 1'b1;
      PI_tx_payload <= 8'b00000101;
      PI_instruction <= 32'b10100000010000000000000000000000;
      PI_sampled_inputs <= 8'b00011100;
      PI_tx_payload_alt <= 8'b00000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_instruction_valid <= 1'b0;
      PI_rst_n <= 1'b0;
      PI_ena <= 1'b0;
      PI_tx_payload <= 8'b00100001;
      PI_instruction <= 32'b11001000000000001011011100000000;
      PI_sampled_inputs <= 8'b00000111;
      PI_tx_payload_alt <= 8'b00100000;
    end

    // state 3
    if (cycle == 2) begin
      PI_instruction_valid <= 1'b0;
      PI_rst_n <= 1'b1;
      PI_ena <= 1'b0;
      PI_tx_payload <= 8'b00000000;
      PI_instruction <= 32'b00011101100000000000000000000001;
      PI_sampled_inputs <= 8'b01000000;
      PI_tx_payload_alt <= 8'b00000000;
    end

    genclock <= cycle < 3;
    cycle <= cycle + 1;
  end
endmodule
