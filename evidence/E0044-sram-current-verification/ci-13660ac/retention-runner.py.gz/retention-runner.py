"""Retain the audited original normal-command CI archive and exact frozen inputs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parents[1]
base = root / 'build/g2-sram-current-ci-02'
out = root / 'evidence/E0044-sram-current-verification/ci-13660ac'
assert not out.exists()
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report = read(base / 'verification.json')
assert report['status'] == 'PASS_CURRENT_SRAM_COMMAND_CI_ORIGINAL_ARCHIVE'
out.mkdir()
for name in ('run.json', 'jobs.json', 'artifacts.json', 'verification.json', 'zip-files.json', '13986941634.zip', 'failed-windows-audit.json'):
    (out / name).write_bytes((base / name).read_bytes())
for name in ('current-job.log', 'failed-windows-audit.py'):
    (out / (name + '.gz')).write_bytes(gzip.compress((base / name).read_bytes(), mtime=0))
evidence = read(base / 'original/current-sram/evidence.json')
files = {}
for name, expected in evidence['verification_inputs'].items():
    raw = (base / 'inputs' / name).read_bytes()
    assert sha(raw) == expected
    files[name] = raw
with (out / 'inputs.tar.gz').open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, raw in sorted(files.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                archive.addfile(entry, io.BytesIO(raw))
packed = (out / 'inputs.tar.gz').read_bytes()
(out / 'inputs.json').write_bytes((json.dumps({'bytes': len(packed), 'sha256': sha(packed),
    'files': {name: sha(raw) for name, raw in sorted(files.items())}}, indent=2) + '\n').encode())
audit = (root / 'build/audit_sram_current_ci.py').read_text()
audit = audit.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path(__file__).resolve().parents[3]')
start = audit.index("inputs = base / 'inputs'\n")
end = audit.index('sys.path.insert(0, str(inputs))', start)
audit = audit[:start] + "inputs = base / 'inputs'\nfor name, expected in evidence['verification_inputs'].items():\n    path = (inputs / name).resolve()\n    assert path.is_relative_to(inputs) and sha(path.read_bytes()) == expected, name\n" + audit[end:]
(out / 'audit.py').write_bytes(audit.encode())
(out / 'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
print('RETAINED_ORIGINAL_SRAM_CI', report['original_zip_files'], len(files), len(packed))
