import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'build/g2-routing-diagnostic-03'
OUT=ROOT/'evidence/E0041-clock-routing-diagnostic'
TARGET=OUT/'attempt-2400s'
TARGET.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
sha=lambda raw:hashlib.sha256(raw).hexdigest()
result=read(BASE/'ablation-result.json')
assert result['returncode']==0 and result['timed_out'] is False and result['wall_limit_seconds']==2400
assert result['status']=='GLOBAL_ROUTING_COMMAND_SUCCEEDED_REQUIRES_AUDIT'
assert read(BASE/'input-audit.json')['status']=='PASS_ISOLATED_ROUTING_INPUTS'
assert sha((BASE/'run_ablation.py').read_bytes())==result['runner_sha256']
assert sha((BASE/'spec-at-start.md').read_bytes())==result['spec_sha256']
for name in ('before.def','after.def'):
    assert (BASE/name).read_bytes()==gzip.decompress((OUT/'attempt-1200s'/(name+'.gz')).read_bytes())
assert result['modified_odb_sha256']==read(OUT/'attempt-1200s/result.json')['modified_odb_sha256']
step=BASE/'runs/no-clock-ndr/01-openroad-globalrouting'
log=(step/'openroad-globalrouting.log').read_text()
assert 'Start extra iteration 50/50' in log and '[ERROR GRT-0228]' not in log
assert '[WARNING GRT-0115]' in log
rows={}
for name,resource,demand,usage,horizontal,vertical,total in re.findall(
        r'^(Metal[1-4]|Total)\s+(\d+)\s+(\d+)\s+([\d.]+)%\s+(\d+) /\s*(\d+) /\s*(\d+)$',log,re.M):
    rows[name]={'resource':int(resource),'demand':int(demand),'usage_percent':float(usage),
                'max_horizontal_overflow':int(horizontal),'max_vertical_overflow':int(vertical),'total_overflow':int(total)}
assert set(rows)=={'Metal1','Metal2','Metal3','Metal4','Total'}
assert rows['Total']['total_overflow']==159781 and rows['Metal3']['usage_percent']==152.09
assert sum(rows[n]['total_overflow'] for n in rows if n!='Total')==rows['Total']['total_overflow']
report={'status':'COMPLETED_WITH_CONGESTION_NOT_QUALIFIED','source_commit':'426cea1252eb2a1f38cf32eeacda710f16e61ca0',
        'original_physical_run':43249867361,'seconds':result['seconds'],'wall_limit_seconds':2400,
        'exit_code':0,'source_odb_sha256':result['source_odb_sha256'],'modified_odb_sha256':result['modified_odb_sha256'],
        'changed_ndr_assignments':16,'final_congestion':rows,
        'global_wirelength_um':6613869,'global_vias':387200,'routed_nets':39768,
        'qualification':'NOT_QUALIFIED','decision':'STOP_CLOCK_SPACING_ONLY_BRANCH',
        'limits':'Global routing only. GRT_ALLOW_CONGESTION was inherited true. Inherited timing metrics are not routed signoff.'}
files={}
for path in BASE.rglob('*'):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    name=path.relative_to(BASE).as_posix()
    if name in ('before.def','after.def','no-clock-ndr.odb') or '/final/' in name:
        continue
    files[name]=path.read_bytes()
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size,entry.mtime,entry.mode=len(raw),0,0o644
        archive.addfile(entry,io.BytesIO(raw))
packed=gzip.compress(buffer.getvalue(),mtime=0)
(TARGET/'routing.tar.gz').write_bytes(packed)
(TARGET/'archive.json').write_bytes((json.dumps({'sha256':sha(packed),'bytes':len(packed),'files':{n:sha(v) for n,v in sorted(files.items())},
    'input_aliases':{'before.def':'../attempt-1200s/before.def.gz','after.def':'../attempt-1200s/after.def.gz'},
    'copied_input_odb_sha256':result['modified_odb_sha256'],
    'omitted_duplicate_views':'runs/no-clock-ndr/final duplicates the retained global-routing step'},indent=2)+'\n').encode())
(TARGET/'verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
(TARGET/'retention-runner.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
lines=[sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts]
(OUT/'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(json.dumps({'status':report['status'],'total_overflow':159781,'files':len(files),'archive_bytes':len(packed)}))
