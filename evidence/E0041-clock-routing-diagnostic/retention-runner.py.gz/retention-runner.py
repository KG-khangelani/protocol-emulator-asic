import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'evidence/E0041-clock-routing-diagnostic'
OUT.mkdir(parents=True, exist_ok=True)
ONE = ROOT / 'build/g2-routing-diagnostic-01'
TWO = ROOT / 'build/g2-routing-diagnostic-02'
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
result = read(TWO / 'ablation-result.json')
assert result['status'] == 'FAILED_OR_INCOMPLETE' and result['returncode'] == 124 and result['timed_out'] is True
assert result['wall_limit_seconds'] == 1200 and len(result['removed_ndr_nets']) == 16
assert read(TWO / 'input-audit.json')['status'] == 'PASS_ISOLATED_ROUTING_INPUTS'
assert sha((TWO / 'spec-at-start.md').read_bytes()) == result['spec_sha256']
assert sha((TWO / 'run_ablation.py').read_bytes()) == result['runner_sha256']
before, after = ((TWO / n).read_bytes() for n in ('before.def', 'after.def'))
marker = b' + NONDEFAULTRULE CTS_NDR_0'
assert before.count(marker) == 16 and before.replace(marker, b'') == after
assert (ONE / 'before.def').read_bytes() == before and (ONE / 'after.def').read_bytes() == after
log = (TWO / 'ablation.log').read_bytes()
assert b'Start extra iteration 40/50' in log and b'Final congestion report' not in log
files = {
  'attempt-1200s/result.json': TWO / 'ablation-result.json',
  'attempt-1200s/input-audit.json': TWO / 'input-audit.json',
  'attempt-1200s/runner.py': TWO / 'run_ablation.py',
  'attempt-1200s/audit-inputs.py': TWO / 'audit_inputs.py',
  'attempt-1200s/spec-at-start.md': TWO / 'spec-at-start.md',
  'attempt-1200s/config.json': TWO / 'config.json',
  'attempt-1200s/initial-state.json': TWO / 'initial-state.json',
  'attempt-1200s/ndr-only.patch': TWO / 'ndr-only.patch',
  'attempt-1200s/resolved.json': TWO / 'runs/no-clock-ndr/resolved.json',
  'attempt-1200s/COMMANDS': TWO / 'runs/no-clock-ndr/01-openroad-globalrouting/COMMANDS',
  'attempt-1200s/step-env.tcl': TWO / 'runs/no-clock-ndr/01-openroad-globalrouting/_env.tcl',
  'preparation-failure/result.json': ONE / 'ablation-result.json',
  'preparation-failure/runner.py': ONE / 'run_ablation.py',
  'database-inspection.json': ONE / 'database.json',
  'database-inspector.py': ONE / 'inspect_database.py',
  'upstream/sources.json': ONE / 'upstream/sources.json',
}
for target, source in files.items():
    path = OUT / target
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(source.read_bytes())
for name, raw in [('attempt-1200s/before.def.gz', before), ('attempt-1200s/after.def.gz', after),
                  ('attempt-1200s/run.log.gz', log),
                  ('runtime-image.json.gz', (ROOT / 'build/g2-banked-mapped-01/image-inspect.json').read_bytes()),
                  ('retention-runner.py.gz', Path(__file__).read_bytes())]:
    (OUT / name).write_bytes(gzip.compress(raw, mtime=0))
for source in (ONE / 'upstream').glob('*.cpp'):
    (OUT / 'upstream' / (source.name+'.gz')).write_bytes(gzip.compress(source.read_bytes(),mtime=0))
report = {'status': 'INCOMPLETE_CLOCK_NDR_ABLATION', 'original_physical_run': 43249867361,
          'source_commit': '426cea1252eb2a1f38cf32eeacda710f16e61ca0',
          'source_odb_sha256': result['source_odb_sha256'], 'changed_assignments': 16,
          'before_def_sha256': sha(before), 'after_def_sha256': sha(after),
          'last_observed_extra_iteration': 40, 'requested_extra_iterations': 50,
          'seconds': result['seconds'], 'wall_limit': 1200, 'exit_code': 124,
          'qualification': 'NOT_QUALIFIED', 'follow_up': 'SEPARATE_2400_SECOND_ATTEMPT_DECLARED'}
(OUT / 'verification.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
lines = [sha(p.read_bytes())+'  '+p.relative_to(OUT).as_posix() for p in sorted(OUT.rglob('*'))
         if p.is_file() and p.name != 'SHA256SUMS' and '__pycache__' not in p.parts]
(OUT / 'SHA256SUMS').write_bytes(('\n'.join(lines)+'\n').encode())
print(json.dumps(report))
